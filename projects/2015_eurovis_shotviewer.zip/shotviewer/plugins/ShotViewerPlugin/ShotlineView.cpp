#include "ShotlineView.h"
#include "IRDocument.h"

#include <QMenu>
#include <QDebug>

QStringList ShotlineView::getRequiredDocTypes()
{
    QStringList types;
    types.append("IR");
    return types;
}

void ShotlineView::mouseOverComponentEvent(int aimPoint, int traceIdx, bool highlight)
{
    // Find common components along shotlines.
    IRDocument *irDoc = (IRDocument*) m_appDoc;
    QMap<int, QList<int> > map = irDoc->getCommonTraceIndexes(aimPoint, traceIdx);

    // Set children to be highlighted
    setMouseHoverHighlight(map, traceIdx, highlight, aimPoint);

    // Tell all other views that mouse hover highlight has been changed.
    emit mouseHoverHighlightChanged(map, traceIdx, highlight, aimPoint);
}

void ShotlineView::mouseOverComponentEvent(QString &component, bool highlight, int aimPoint)
{
    // Find common components along shotlines.
    IRDocument *irDoc = (IRDocument*) m_appDoc;
    QMap<int, QList<int> > map = irDoc->getCommonTraceIndexes(component);

    // Set children to be highlighted
    int traceIdx = -1;
    foreach (QList<int> list, map.values()) {
        if (list.size() > 0) {
            traceIdx = list.first();
        }
    }

    setMouseHoverHighlight(map, traceIdx, highlight, -1);

    // Tell all other views that mouse hover highlight has been changed.
    emit mouseHoverHighlightChanged(map, traceIdx, highlight, aimPoint);
}

void ShotlineView::mouseDoubleClickComponentEvent(QString &component)
{
    emit mouseDoubleClickedComponent(component);
}

void ShotlineView::mouseDoubleClickComponentEvent(int aimPoint, int component)
{
    IRDocument *irDoc = (IRDocument*) m_appDoc;
    QString componentName = irDoc->getComponentName(aimPoint, component);
    emit mouseDoubleClickComponentEvent(componentName);
}

QWidget *ShotlineView::getImageWidget() const
{
    return NULL;
}

void ShotlineView::showAimPointDialog()
{
    getDocument()->showAimPointDialog();
}

void ShotlineView::attachDocument(ApplicationDocument *doc)
{
    if(dynamic_cast<IRDocument*>(doc)) {
        this->m_appDoc = doc;

        connect(this, SIGNAL(closeAimPoint(const int &)),
                doc, SLOT(closeAimPoint(const int &)));

        connect(doc, SIGNAL(changeAllShotlines()),
                this, SLOT(updateShotlines()));
    }
}

void ShotlineView::connectToView(ApplicationView *view)
{
    ShotlineView *shotlineView = dynamic_cast<ShotlineView*>(view);

    if (shotlineView) {
        connect(this, SIGNAL(mouseHoverHighlightChanged(QMap<int,QList<int> >, int, bool, int)),
                shotlineView, SLOT(setMouseHoverHighlight(QMap<int,QList<int> >, int, bool, int)));
    }
}

IRDocument *ShotlineView::getDocument() const
{
    return (IRDocument*)m_appDoc;
}
