#ifndef IRDOCUMENT_H
#define IRDOCUMENT_H

#include <QSharedPointer>
#include <QMap>
#include <QColor>
#include <QPointF>

#include "ApplicationDocument.h"
#include "IrData.h"

struct IRFile;
class ColorMap;
class ColorMapBuilder;
class ShotlineModel;

/** IRDocument is the data model that represents the contents of an IR file.
 *
 * Assumptions about the IR file format.
 *
 * If the IR file fails to meet these assumptions it will result in undefined
 * behavior.
 * 1. The IR file will be for a direct-fire MUVES simulation run. Bursting
 *      munitions are not supported.
 * 2. There will be qualifiers on damaged components. Simulations run without
 *      qualifiers are not supported.
 *
 * Process of loading aimpoints.
 *
 * This will invoke an IfrParser to parse the IR file when the application is
 * first launched. The set of "parsed aimPoints" contains all the aim points
 * in the IR file. The following methods are used to actually load aim points
 * and setup the necessary internal state.
 *
 * 1. The method showAimPointDialog() is called, displaying the Select Shotlines
 *      Dialog. This dialog asks the user for a list of aim points, a qualifier,
 *      and a threat name. This method clears all internal state and sets
 *      the member variable m_aimPoints to the user-selected values.
 * 2. After m_aimPoints has been set, updateLoadedAimPoints() is called. This
 *      method searches m_irFile for the user-specified aim points.
 * 3. After loading aimPoints, this updates its internal state by calling
 *      updateThreatPks() and updateTMax(). (The threat pks and t-max value are
 *      used by many views, so it is cheaper to compute them once and re-use
 *      the value instead of recomputing it for each view.)
 * 4. This tells all its connected views that the loaded aim points have changed
 *      by emitting the signal updateAllShotlines().
 */
class IRDocument : public ApplicationDocument
{
    Q_OBJECT

public:

    IRDocument(QObject *parent = 0);
    IRDocument(const QList<int>& initialAimPoints,
               QString threatName,
               QObject *parent=0);

    ~IRDocument();

    //// Methods for changing view-specific paramaters. ////////////////////////
    /// These should probably be moved to a view-specific scope.

    /// Returns the colormap for converting pk values to colors.
    ColorMap *getPkColorMap() const
    {
        return m_pkColorMap;
    }

    /// Returns true if we are using the wtlos instead of los for thickness.
    bool getUseWtLos() const
    {
        return m_useWtLos;
    }

    //// Methods for loading parsed aimPoints.//////////////////////////////////

    /// Returns list of aimpoints available in IR file.
    QStringList getAvailableAimPoints() const;

    /// Returns a list of all qualifiers in IR file.
    QStringList getAvailableQualifiers() const;

    /// Returns list of all threat types in IR file.
    QStringList getAvailableThreatNames() const;

    //// Methods for getting information about loaded aimpoints.////////////////

    /// Returns a pointer to the ShotlineThreat for the aimPoint.
    const IRShotlineThreat* getThreat(int aimPoint) const;

    /// Returns a list of all loaded ShotlineThreats.
    QList<IRShotlineThreat *> getThreats() const;

    /// Returns a list of the loaded aimPoints.
    QList<int> getAimPoints() const;

    /// Returns a list of the loaded aimPoints.
    QStringList getAimPointsAsStringList() const;

    /// Returns the categorical color used to identify the aimPoint.
    QColor getThreatColor(int aimPoint) const;

    /// Returns a list of pk values for components along aimPoint. They are
    /// indexed by the order of aimPoint's trace list.
    QList<float> getPkList(int aimPoint) const;

    /// Returns a list of world-space intervals along a shotline.
    /// Points in the returns list:
    ///     -x: interval start
    ///     -y: interval thickness
    QList<QPointF> getTList(int aimPoint) const;

    QList<QPointF> getTrueTList(int aimPoint);

    /// Returns the point farthest from the entry point of all loaded aimPoints.
    /// This is used by the LinePlot and Compare ShotlineViews to convert
    /// from world-space into scene-space.
    float getTMax() const
    {
        return m_tMax;
    }

    /// Returns the qualifier used to find damaged components.
    QString getCurrentQualifier() const
    {
        return m_qualifier;
    }

    /// Returns the components damaged by an aimPoint. TODO: explain this.
    QMap<QString, float> getDamagedComponentsFromShotline(const int &aimPoint) const;

    /// Returns a list of values for the given parameter name. They are ordered
    /// by trace index.
    QMap<int, QList<float> > getThreatParameterValues(const QString &name) const;

    /// Returns the min and max values of the parameter for all aim points
    /// list[0] = min value, and list[1] = max value.
    QList<float> getThreatParameterRange(const QString &name) const;

    /// Returns the indexes of components with the same name as the component
    /// along the shotline defined by aimPoint.
    QMap<int, QList<int> > getCommonTraceIndexes(const int &aimPoint,
            const int &traceIdx) const;

    /// Finds instances of a given componentName along all loaded shotlines.
    /// returns map: key = aimPoint, value = list of traces with componentName.
    QMap<int, QList<int> > getCommonTraceIndexes(const QString &componentName) const;

    /// Returns the component name at the given trace index of aimPoint.
    QString getComponentName(const int &aimPoint, const int &traceIdx) const;

    /// Returns a list of component names corresponding to the input map:
    /// keys = aimPoints, values = trace indexes
    QStringList getComponentNames(const QMap<int, QList<int> > &) const;

    /// Returns a list of all components along all loaded shotlines with
    /// duplicated removed.
    QStringList getComponentNames() const;

    /// Returns a list of components along the aimPoint.
    QStringList getComponentNames(const int &aimPoint) const;

    /// Returns a map with keys = aimpoints and values = index of traces
    /// within the distance interval. x0 and x1 are worldspace
    QMap<int, QList<int> > getTracesInInterval(const float &x0,
            const float &x1) const;

    // Overridden from ApplicationDocument ////////////////////////////////////

    /// Import a file to the document. This will set the document file name if
    /// the document was previously empty. This method emits "documentLoaded"
    /// when the document is finished loading. (on first import only?)
    bool importFileByName(QString fileName);

    /// Implemented as a no-op
    void saveFile();

    /// Implemented as a no-op
    void saveFileByName(QString fileName);

    /// Gets the text string which indicates the type or category of this
    /// document within the application. (eg "Text" or "SysDef" or "Geometry")
    QString getDocumentType();

public slots:

    /// Called when the user selects that they want to use the wtlos for
    /// drawing components.
    void setUseWtLos(bool);

    /// Called when the user closes an aimPoint.
    void closeAimPoint(const int &);

    /// Displays the shotline dialog to let the user select aimpoints.
    void showAimPointDialog();

    /// Makes colormap builder visible for the user.
    void showPkColorMapDialog() const;

    /// Called by the ColorMapBuilder created by the slot showPkColorMapDialog.
    void setPkColorMap(ColorMap *);

signals:

    /// Emitted when this has changed the loaded shotlines. When views receive
    /// this signal they destroy their current visualization and then recreate
    /// it using the new data.
    void changeAllShotlines();

    void warningDialog(const QString &);//<--TODO: remove

private:

    /// These two functions require significantly changing this object's state
    /// e.g., m_threatMap and m_threatPks. They should only be called by
    /// updateLoadedAimPoints.
    void setThreatName(const QRegExp &);
    void setCurrentQualifier(const QString &);

    /// Search m_irFile for the aimPoint. Returns true if the aimPoint is found.
    bool loadAimPoint(int aimPoint);

    /// Updates internal state according the recently selected aimPoints.
    void updateLoadedAimPoints();

    /// Updates the m_tMax value.
    void updateTMax();

    /// Populate the pkList for each of the IrShotlineThreats from the SA line.
    /// Match only by component name. This may be a problem for analyst tags.
    /// If no pK value is given then assign pK value of -1
    void updateThreatPks();

    //// Private variables ////////////////////////////////////////////////////

    /// Pointer to a struct containing information about the parsed IR file
    QSharedPointer<IRFile> m_irFile;

    /// List of aimpoints that we have been asked to load.
    QList<int> m_aimPoints;

    /// Regular expression used to match the threat name when loading aimpoints.
    QRegExp m_threatName;

    /// Qualifier string used to pull pk values from SA lines.
    QString m_qualifier;

    /// The loaded threats for each aimPoint.
    /// key = aimPoint, value = threat that matches m_threatName.
    QMap<int, IRShotlineThreat*> *m_threatMap;

    /// The categorical colors assigned to each aimPoint.
    /// key = aimPoint, value = color
    QMap<int, QColor> *m_threatColors;

    /// Colormap being used for pk values. (Should be moved to a view)
    ColorMap *m_pkColorMap;

    /// Class used to manipulate m_pkColorMap.
    ColorMapBuilder *m_colorMapBuilder;

    /// key = aimpoint. value = list of pKs for each trace on the shotlinethreat
    /// value of -1 in the list implies no pK defined in the file
    QMap<int, QList<float> > *m_threatPks;

    /// Farthest point (in world-space) from all the loaded shotlines.
    float m_tMax;

    /// True only if we are supposed to use wtlos instead of plain los.
    bool m_useWtLos;

    /// Basic list of categorical colors for loaded aimPoints.
    QList<QColor> m_standardColors;
};
#endif // IRDOCUMENT_H
