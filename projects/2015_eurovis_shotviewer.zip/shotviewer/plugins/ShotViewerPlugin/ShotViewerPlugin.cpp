#include "ShotViewerPlugin.h"

#include <QDebug>

#include "IRDocument.h"
#include "CompareShotlineView.h"
#include "TableShotlineView.h"
#include "LineplotShotlineView.h"
#include "SysDefShotlineView.h"

ShotViewerPlugin::ShotViewerPlugin(QObject *parent)
    : QObject(parent)
    , m_aimPoints(QList<int>())

{
    /*no-op*/
}

ShotViewerPlugin::~ShotViewerPlugin()
{
    /*no-op*/
}

//------------ ICommandLinePlugin -------------

QStringList ShotViewerPlugin::getCommandLineOptions()
{
    QStringList args;
    args.append("--ap");
    args.append("--ap=");
    args.append("ap");
    return args;
}

void ShotViewerPlugin::handleArguments(QStringList arguments)
{
    QString aimPoints = argByKey("--ap",'=', arguments);
    if (!aimPoints.isEmpty()) {
        QStringList aimPointList = aimPoints.split(",");
        foreach (QString aimPoint, aimPointList) {
            int val = aimPoint.toInt();
            m_aimPoints.push_back(val);
        }
    }
    QString threatName = argByKey("--pat", '=', arguments);
    if (threatName.isEmpty()) {
        m_threatName = "SCJ";
    } else {
        m_threatName = threatName;
    }

    QString columns = argByKey("--tp", '=', arguments);
    if (columns.isEmpty()) {
        m_initialColumns << "pk";
    } else {
        m_initialColumns << columns.split(",");
    }
}

//---------------- IDocPlugin -----------------

QStringList ShotViewerPlugin::getFilenameExtensions()
{
    QStringList extList;
    extList.append("ir");
    return extList;
}

QString ShotViewerPlugin::getDocumentCategory()
{
    return QString("IR");
}

ApplicationDocument * ShotViewerPlugin::createDocument()
{
    IRDocument *doc = new IRDocument(m_aimPoints, m_threatName, this);
    return doc;
}

QString ShotViewerPlugin::getPluginName()
{
    return QString("ShotViewerPlugin");
}

QStringList ShotViewerPlugin::defaultViews()
{
    QStringList views;
    views.append("Table Shotline View");
    views.append("Compare Shotline View");
    views.append("Lineplot Shotline View");
    return views;
}

//---------------- IViewPlugin -----------------

QStringList ShotViewerPlugin::getViewNames()
{
    QStringList viewNames;
    viewNames.append("Compare Shotline View");
    viewNames.append("Table Shotline View");
    viewNames.append("Lineplot Shotline View");
    viewNames.append("SysDef Shotline View");
    return viewNames;
}

QStringList ShotViewerPlugin::dataModelTypesSupported(const QString viewName)
{
    QStringList models;

    if (!viewName.compare("Compare Shotline View"))
        models.append("IR");
    else if (!viewName.compare("Table Shotline View"))
        models.append("IR");
    else if (!viewName.compare("Lineplot Shotline View"))
        models.append("IR");
    else if (!viewName.compare("SysDef Shotline View"))
        models.append("SysDef");

    return models;
}

ApplicationView *ShotViewerPlugin::genView(const QString name)
{
    ApplicationView *view = 0;
    if (!name.compare("Compare Shotline View")) {
        view = new CompareShotlineView;
    } else if (!name.compare("Table Shotline View")) {
        TableShotlineView *table = new TableShotlineView;
        table->setInitialColumns(m_initialColumns);
        view = table;
    } else if (!name.compare("Lineplot Shotline View")) {
        view = new LineplotShotlineView;
    } else if (!name.compare("SysDef Shotline View")) {
        view = new SysDefShotlineView;
    }
    return view;
}

Q_EXPORT_PLUGIN2(ShotViewerPlugin, ShotViewerPlugin)
