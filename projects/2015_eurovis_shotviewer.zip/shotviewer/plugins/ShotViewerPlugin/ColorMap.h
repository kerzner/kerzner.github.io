#ifndef COLORMAP_H
#define COLORMAP_H

#include <QObject>
#include <QImage>
#include <QColor>

#define SCALE_HEIGHT 35

class ColorMap : public QObject
{
    Q_OBJECT
public:
    explicit ColorMap(QObject *parent = 0, bool interpolated = false,
                      bool separateMinColor = false,
                      bool separateMaxColor = false,
                      QList<QColor> colors = QList<QColor>(),
                      QString name = "ColorMap");

    explicit ColorMap(QString filename);

    //ColorMap(const ColorMap &colorMap);

    /**
     * Builds and returns an image representing this color map.
     * @param   width   The width of the image.  The image's height is 1.
     * @return A width x 1 image representing the color map.
     */
    QImage getColorMapImage(int width);

    /**
     * Builds and returns an image representing the scale for this color map.
     * @param   width   The width of the color map image.
     * @return An image representing the scale.
     */
    QImage getScaleImage(int width,
                         QColor backgroundColor = QColor(255, 255, 255));

    /**
     * Translates normalizedValue to it's color on the color map
     * @param   normalizedValue     The value to be translated.
     * @return The color representation of normalizedValue.
     */
    QColor getColor(float normalizedValue);

    /// @return Get the list of colors in this color map
    QList<QColor> getColors() {
        return m_colors;
    }

    /**
     * Inserts a color into the color map at index.
     * @param color     The color to insert.
     * @param index     The index to insert the color into.  If this value is
     *                  -1, the color is appended.
     * @return Whether the color was inserted or not.
     */
    bool insertColor(QColor color, int index = -1);

    /**
     * Removes the color at index from the color map.
     * @param   index   The index of the color to remove.  If this value is -1,
     *                  the last color in the list is removed.
     * @return Whether a color was removed or not.
     */
    bool removeColor(int index = -1);

    /**
     * Set whether colors in the color map are interpolated or not.
     * @param interpolated  The new interpolated value.
     */
    void setInterpolated(bool interpolated) {
        m_interpolated = interpolated;
    }

    /// @return Whether the color map is interpolated or binned
    bool interpolated() {
        return m_interpolated;
    }

    /**
     * Sets whether the first color only represents the minimum value or not
     * @param separateMinColor  The new seperate minimum color value.
     */
    bool setSeparateMinColor(bool separateMinColor);

    /// @return Whether the first color only represents the minimum value or not
    bool separateMinColor() {
        return m_separateMinColor;
    }

    /**
     * Sets whether the last color only represents the maximum value or not
     * @param separateMaxColor  The new seperate maximum color value.
     */
    bool setSeparateMaxColor(bool separateMaxColor);

    /// @return Whether the last color only represents the maximum value or not
    bool separateMaxColor() {
        return m_separateMaxColor;
    }

    /// @return The name of the color map
    QString name() {
        return m_name;
    }

    /**
     * Sets the name of the color map to name.
     * @param name The new name of the color map.
     */
    void setName(QString name) {
        m_name = name;
    }

    /// @return The last error that occurred.
    QString errorMessage() {
        return m_errorMessage;
    }

signals:

public slots:

private:
    /// The colors in the color map
    QList<QColor> m_colors;

    /// Are the colors interpolated or not
    bool m_interpolated;

    /// Does the first color in m_colors only represent the minimum value
    bool m_separateMinColor;

    /// Does the last color in m_colors only represent the maximum value
    bool m_separateMaxColor;

    /// The name of the color map
    QString m_name;

    /// The container for the last error that occurred
    QString m_errorMessage;
};

#endif // COLORMAP_H
