#ifndef IFRPARSER_H
#define IFRPARSER_H

#include <QObject>
#include <QHash>
#include <QVariant>
#include <QSharedPointer>

#include "IrData.h"

class IfrParser : public QObject
{
    Q_OBJECT

public:
    explicit IfrParser(QObject *parent = 0);
    ~IfrParser() {}
    bool parse(const QString &fileName);
    QSharedPointer<IRFile> getIrFile() const {
        return irFile;
    }

signals:
public slots:
private:

    void processLine(const QString line, const int lineNumber);
    QString quotedString(const QString s);
    void setNVP(QHash<QString, QVariant> &h, const QString str);
    int stgFunc(const QString s);
    int tpFunc(const QString s);
    int tdFunc(const QString s);
    int saFunc(const QString s);
    int tgFunc(const QString s);
    int tFunc(const QString s);
    int stFunc(const QString s);
    int sFunc(const QString s);
    int bFunc(const QString s);
    int apFunc(const QString s);
    int vFunc(const QString s);
    int versionFunc(const QString s) {
        irFile->muvesVersion = s;
        return 0;
    }
    int viewUnitsFunc(const QString s) {
        irFile->viewUnits = s;
        return 0;
    }
    int titleFunc(const QString s) {
        irFile->title = s;
        return 0;
    }
    int approxFunc(const QString s) {
        irFile->approx = s;
        return 0;
    }
    int targetFunc(const QString s) {
        irFile->target = s;
        return 0;
    }
    int modkeyFunc(const QString s) {
        setNVP(irFile->modKeys, s);
        return 0;
    }

    QSharedPointer<IRFile>irFile;
    IRTrace *mostRecentTrace;
    IRShotlineThreat *mostRecentShotlineThreat;
    IRView *mostRecentView;

    // this is necessary to process STG lines which seem to violate syntax
    QString stashedQuotedString;
};

#endif // IFRPARSER_H
