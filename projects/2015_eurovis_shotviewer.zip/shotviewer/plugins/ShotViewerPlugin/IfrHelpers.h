#ifndef IFRHELPERS_H
#define IFRHELPERS_H

#include <QVector3D>
#include <QStringList>

#include "IrData.h"

/// Maps value from the range (istart, iend) to (ostart, oend)
inline float map(float value, float istart, float iend, float ostart,
                 float oend)
{
    return ostart + (oend - ostart) * ((value - istart) / (iend - istart));
}

/// Returns the distance (in world space) between first and current
inline float getTValue(const IRTrace *first,
                       const IRTrace *current)
{
    const double *entry = first->geom.entry;
    QVector3D start(entry[0], entry[1], entry[2]);
    entry = current->geom.entry;
    QVector3D point(entry[0], entry[1], entry[2]);
    return (point - start).length();
}

/// Returns a list of threat parameter names for the threatpacket 0
inline QStringList getTPNames(const IRTrace *trace)
{
    QStringList names;

    // This assumes one threat packet per intersection. Is this always the case?
    const QHash<QString, QVariant> *hash = &trace->threatPackets[0]->parameterList;
    QHash<QString, QVariant>::const_iterator itr;

    for (itr = hash->begin(); itr != hash->end(); ++itr) {
        QString parameterName = itr.key();

        // Do not add the name field to the parameter list.
        // Do not add empty fields to the parameter list.
        if (parameterName.compare("name") && !parameterName.isEmpty()) {
            names.append(itr.key());
        }
    }

    return names;
}

/// Returns the threat parameters names with pk and material appended
inline QStringList getExtendedTPNames(const IRTrace *trace)
{
    QStringList names;

    // Values from the TP: line
    names.append("name");
    names.append(getTPNames(trace));

    // Values from the T: and SA: lines
    names.append("pk");
    names.append("material");

    return names;
}

/// Returns the trace geometry names
inline QStringList getTGNames()
{
    QStringList names;

    names.append("norm");
    names.append("oblique");
    names.append("wtlos");
    names.append("wtnorm");

    return names;
}

/// Returns a list of all aimpoints in view.
inline QStringList getAimPointsInView(const IRView *view)
{
    QStringList aimPoints;
    foreach (IRShotline *shotline, view->shotlines) {
        aimPoints.append(QString::number(shotline->aimPointIndex));
    }
    return aimPoints;
}

/// Returns the qualifier on a name (if one exists).
inline QString getQualifier(const QString &name)
{
    // The ( ) in this regexp define a capture group.
    QRegExp qualifier("\\[(.*)\\]");

    // Search name for text between brackets.
    int index = qualifier.indexIn(name);

    if (index > -1) {
        return qualifier.capturedTexts().at(0);
    } else {
        return QString("");
    }
}

inline QString removeQualifier(QString qualifiedName)
{
    return qualifiedName.remove(QRegExp("\\[.*\\]"));
}

inline bool traceIsAir(const IRTrace *trace)
{
    QString name = trace->compName;
    return name.contains("air") || name.contains("MUVES_target_gap");
}

#endif // IFRHELPERS_H
