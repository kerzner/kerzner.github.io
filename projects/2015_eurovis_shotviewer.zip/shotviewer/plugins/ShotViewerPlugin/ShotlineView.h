#ifndef SHOTLINEVIEW_H
#define SHOTLINEVIEW_H

#include <QWidget>
#include <QList>

#include "ApplicationView.h"

class IRDocument;
/** ShotlineView is the base class for any views that display an IRDocument. It
 * provides interfaces for communicating between views and the IRDOcument.
 *
 * Communication Between Views and Highlighting
 *
 * ShotlineView provides an interface for communication between views which we
 * use for highlighting components on mouse events.
 *
 * The typical communication of a highlight event looks like this:
 * 1. A ShotlineView's representation of a component (for instance, a
 *      SegmentLineItem of the LinePlotView) registers a mouse hover enter
 *      event.
 * 2. The component item calls mouserOverComponentEvent(...), a method that
 *      converts the hover event on a single component into a list of components
 *      that should be highlighted along all aimpoints.
 * 3. In mouseOverComponentEvent(...), this class enables highlighting based
 *      on which component is moused over by calling the
 *      setMouseHoverHighlight(...) method.
 * 4. In mouseOverComponentEvent(...), this also emites the signal
 *      mouseHoverHighlightChanged(...), which is connected to the slot
 *      setMouseHoverHighlight(...) in all the other views.
 *
 * Screen Capture Interface
 *
 * The ShotlineView may consist of many different widgets. For instance, the
 * SysDefShotlineView consists of a widget that shows the system graph and the
 * text edit that shows a system string. The getImageWidget() method is
 * implemented by subclasses that have a widget of interested that we use when
 * take a screen shot. For the SysDefShotlineView, this image widget is the
 * main QGraphicsView that displays the graph, and it excludes the text edit.
 *
 */
class ShotlineView : public ApplicationView
{
    Q_OBJECT
public:

    /// Constructor.
    ShotlineView(QWidget *parent)
        : ApplicationView(parent) { }

    //// Inherited from ApplicationView ////////////////////////////////////////

    /// Returns a list of required document types.
    QStringList getRequiredDocTypes();

    //// Methods for items in this's view to communicate mouse events.//////////

    /// This gets called when a component registers a mouse hover enter or leave
    /// event. It converts the mouse event on a single component into a list of
    /// aimpoints and traces corresponding to the component. It calls
    /// this->setMouseHoverHighlight(...), then emits the signal
    /// mouseHoverHighlightChanged(...). It is used by views that have
    /// per-aimPoint representations of shotlines, such as the
    /// LinePlotShotlineView.
    /// -aimPoint: the current aimpoint of the component being moused over.
    /// -component: the trace index of the component being moused over.
    /// -highlight: true only if registering a hoverEnterEvent.
    virtual void mouseOverComponentEvent(int aimPoint,
                                         int traceIdx,
                                         bool highlight);

    /// This gets called when a component registers a mouser hover enter or
    /// leave event. It is used by views that may NOT have per-aimPoint
    /// representations of shotlines, such as the SysDefShotlineView.
    /// -component: the componnt being moused over.
    /// -highlight: true only if registering a hoverEnterEvent.
    /// -aimPoint: will be the aimPoint of the component that initiated the
    ///         mouse hover event, only if this view has per-aimPoint items.
    ///         Otherwise aimPoint will be -1.
    virtual void mouseOverComponentEvent(QString &component,
                                         bool highlight,
                                         int aimPoint);

    /// These are not currently used and should probably be removed. We do not
    /// do anything with mouseDoubleClick events.
    virtual void mouseDoubleClickComponentEvent(QString &component);
    virtual void mouseDoubleClickComponentEvent(int aimPoint, int component);

    //// Method for screen captures ////////////////////////////////////////////

    /// Returns the "imageWidget" which is the widget that this view wants to
    /// have appear in a screen capture.
    virtual QWidget *getImageWidget() const;

public slots:

    //// Methods for communicating with IRDocument /////////////////////////////

    /// This method gets called by the IRDocument when user asks to see a new
    /// set of aimpoints.
    virtual void updateShotlines() { }

    /// This method tells the IRDocument that the user wants to see a new set of
    /// aimPoints. It gets called when the user clicks on File->changeAimPoints.
    void showAimPointDialog();

    //// Methods for communicating between views ///////////////////////////////

    /// This method gets called when there is a mouse over a component in any
    /// ShotlineView.
    /// -map: keys = aimPoints, values = indexes into the trace list that need
    ///     to have their highlighting toggled. All traces in this list
    ///     correspond to intervals going through the same physical component.
    /// -traceUnderMouse - the trace that is currently under the mouse--this is
    ///     used for automatic scrolling the table views when there are many
    ///     traces with the same name along a shotline.
    /// -highlight: true only if highlighting is enabled. It will be false if
    ///     the mouse is leaving a component.
    /// -aimPointUnderMouse - the actual aimPoint that is currently under
    ///     the mouse. This is used by the LinePlotShotlineView to move
    ///     the line under mouse in front of others.
    virtual void setMouseHoverHighlight(const QMap<int, QList<int> > &map,
                                        const int &traceUnderMouse,
                                        const bool &highlight,
                                        const int &aimPointUnderMouse) = 0;

signals:

    //// Signal for communicating between IRDocument ///////////////////////////

    /// This gets called when the user closes an aimPoint. It was originally
    /// used by the CompareShotlineView where the user can click on the "X" in
    /// shotline legend. It should probably be removed since we now use the
    /// change aim point dialog to open/close aimpoints.
    /// aimPoint: the aimPoint meant to be closed.
    void closeAimPoint(const int &aimPoint);

    //// Signals for communicating between views ///////////////////////////////

    /// This signal gets emitted when the user mouses over a component. It tells
    /// all the other ShotlineViews to update their highlighting by calling the
    /// setMouseHoverHighlight(...) slot. See setMouseHoverHighlight(...) for
    /// a description of the parameters.
    void mouseHoverHighlightChanged(const QMap<int, QList<int> > &,
                                    const int &,
                                    const bool &,
                                    const int &);

    /// This signal gets emitted when the user double clicks on a component. It
    /// is not currently used.
    void mouseDoubleClickedComponent(const QString &);

protected:

    //// Overridden from ApplicationView ///////////////////////////////////////

    /// Method that returns this's IRDocument. This isn't really accurate
    /// because it it ignores the fact that there may be other documents
    /// connected to this view.
    IRDocument *getDocument() const;

    /// Attachs an IRDocument to this view and connects IRDocument-specific
    /// signals and slots.
    virtual void attachDocument(ApplicationDocument *doc);

    /// Connect this view to another ShotlineView.
    void connectToView(ApplicationView *view);
};
#endif // SHOTLINEVIEW_H
