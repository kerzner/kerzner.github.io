#ifndef COMPARESHOTLINELABEL_H
#define COMPARESHOTLINELABEL_H

#include <QGraphicsItemGroup>
class QMouseEvent;

/** This class is the label shown to the left of shotlines in the
 * CompareShotlineView. It allows the user to close shotlines by clicking on the
 * X that appears on mouse over. This class was designed before the
 * current method for opening and closing aim points, and it should probably
 * be removed.
 *
 * This class handles the mouse hover events by toggling visibility of the "x"
 * that appears when the user mouses over it. This class does NOT handle click
 * events. Rather, it relies on the CompareShotlineView's eventFilter(...)
 * in order to correctly handle clicks.
 */
class CompareShotlineLabel : public QGraphicsItemGroup
{

public:

    /// Creates a label for the aimpoint with a legend box filled with color.
    CompareShotlineLabel(int aimPoint, QColor color, QFont font,
                         int sceneWidth);

    /// Returns the aim point that this is a leged for.
    int getAimpoint() const
    {
        return m_aimPoint;
    }

    /// Makes the "x" visible on mouse hover.
    virtual void hoverEnterEvent(QGraphicsSceneHoverEvent *event);

    /// Makes the "x" invisible on mouse exit.
    virtual void hoverLeaveEvent(QGraphicsSceneHoverEvent *event);

    /// Returns true only if event->scenePos intersects with m_xText.
    bool mouseOverXText(QGraphicsSceneMouseEvent *event);

protected:

    /// Text item that holds the "x" which appears on mouse over.
    QGraphicsTextItem *m_xText;

    /// Aimpoint that this is a legend for.
    const int m_aimPoint;
};
#endif // COMPARESHOTLINELABEL_H
