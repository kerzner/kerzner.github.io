#ifndef GRAPHICSSHOTLINE_H
#define GRAPHICSSHOTLINE_H

#include <QGraphicsItemGroup>

class ShotlineView;

/** GraphicsShotline is the base class used for representing shotlines in the
 * CompareShotlineView and the LineplotShotlineView. Particularly, this class
 * is implemented by the CompareShotline and the LineplotLine.
 *
 * This class has children of type SegmentItemGroup. The SegmentItemGroups
 * represent individual components along the shotline. The trace index of each
 * SegmentItemGroup is stored in the per-child data, Qt::UserRole. This class
 * accesses per-component traces using the trace index, which is used for
 * per-component highlighting.
 *
 * This class inherits from QGraphicsItemGroup in order to: a) use the built in
 * methods for handling children, and b) handle mouse events.On mouse events,
 * this class informs its ShotlineView by calling
 * ShotlineView::mouseOverComponentEvent(...)
 *
 * Note: this class relies on the children to manually call hover*Events.
 * Initially this was because the children performed their own actions during
 * these events. These actions have been removed, but this class still relies
 * on the children to manually call the hover events. We should probably look at
 * using the handleChildEvent method to make this interface simpler.
 */
class GraphicsShotline : public QGraphicsItemGroup
{
public:

    /// Constructor.
    explicit GraphicsShotline(int aimPoint, ShotlineView *view,
                              QGraphicsItem *parent);

    /// This class is identified by the aim point it is representing.
    int getAimPoint() const;

    /// Returns the ShotlineView that is displaying this.
    ShotlineView *getView() const;

    /// This method is called by GraphicsShotlineView when the highlighting
    /// changes. It disables highlighting on all components unless both
    /// highlight is true and the component is in the list of components.
    virtual void setMouseOverComponents(const QList<int> &components,
                                        const bool &highlight);

    /// All of the mouseEvents are called by the child items--see note above.
    /// Each of these methods tells m_view that the user is mousing over a
    /// a certain component. It is then up to m_view to communicate highlighting
    /// with other views.
    virtual void hoverEnterEvent(QGraphicsSceneHoverEvent *event);
    virtual void hoverMoveEvent(QGraphicsSceneHoverEvent *event);
    virtual void hoverLeaveEvent(QGraphicsSceneHoverEvent *event);

    /// Not currently used. TODO: remove.
    virtual void mouseDoubleClickEvent(QGraphicsSceneMouseEvent *event);

protected:

    /// Aimpoint being moused over.
    int m_aimPoint;

    /// View displaying this item group
    ShotlineView *m_view;

    /// Item currently under mouse.
    int m_itemMousedOver;
};
#endif // GRAPHICSSHOTLINE_H
