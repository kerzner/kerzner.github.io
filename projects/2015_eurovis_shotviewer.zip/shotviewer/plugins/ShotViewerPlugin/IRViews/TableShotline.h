#ifndef TABLESHOTLINE_H
#define TABLESHOTLINE_H

#include <QTableWidget>

#include "IrData.h"
#include "IRDocument.h"

class TableShotlineView;

/** This class displays shotline traces in a QTableWidget. The TableShotlineView
 * creates one of these for each aim point.
 *
 * On mouse move events, this will tell its view that there is a mouse over
 * a specific trace. That information gets sent to all the views so that they
 * can highlight similar traces.
 *
 * When the user mouses over a trace in any other view, the TableShotlineView
 * that owns this will call setMouseOverComponents(...).
 */
class TableShotline : public QTableWidget
{
    Q_OBJECT
public:
    explicit TableShotline(IRShotlineThreat *threat,
                           int aimPoint,
                           IRDocument *model,
                           TableShotlineView *view,
                           QWidget *parent = 0);

    ~TableShotline();

    /// Sets column 0 to stretch and all other columns as fit-to-contents
    void correctColumnSize();

    /// Display a subset of traces in the table
    void updateTable(QList<int> traceIdxs);

    void updateTableAllVisible();

    /// Sets background color of some traces. Called after clearHighlights
    void updateHighlight(QList<int> traceIdxs);

    /// Clears all highlights. Called before updateHighlights.
    void clearHighlights();

    /// Sets all rows as hidden
    void hideRows();

    /// Creates a tableitem with contents text and inserts it at (row, col)
    void addItem(int row, int col, QString text);

    /// Shows columns with names in the list. Hides all other columns.
    void setVisibleColumns(const QStringList &columns);

    int getAimPoint() const;

    // Event for all mouse motion. Tells m_view if we are hovering over an item.
    virtual void mouseMoveEvent(QMouseEvent *event);

    // Update mouse-hover highlighting.
    void setMouseOverComponents(const QList<int> &traceIdxs,
                                const bool &highlight);

protected:

    const IRDocument *m_document;

    /// Pointer to parent view. Used for mouse highlight events.
    TableShotlineView *m_view;

    /// Aimpoint being displayed.
    int m_aimPoint;

    /// Current trace underneath the mouse. -1 if mouse is not over anything.
    int m_mousedOverTraceIdx;
};
#endif // TABLESHOTLINE_H
