#ifndef SEGMENTITEMGROUP_H
#define SEGMENTITEMGROUP_H

#include <QGraphicsItemGroup>
#include <QPen>
#include <QBrush>

class NodeItem;
class GraphicsShotline;

/** Base class group used to handle mouse interactions with the Compare and
 * Lineplot shotline views. Originally, this toggled the visibility of child
 * items on mouse hover events. Some of that stuff has not been removed.
 *
 * One of these classes represents a single component (or trace) in its view.
 *
 * SegmentLineItem and SegmentRectItem inherit from this class.
 */
class SegmentItemGroup : public QGraphicsItemGroup
{
public:

    /// Constructor.
    SegmentItemGroup();

    /// Set the name of this group that appears on mouse over.
    void setName(const QString &name);

    /// Returns the name of this group.
    QString getName() const;

    /// Set highlighting. Must be reimplemented by subclasses.
    virtual void setHighlighting(const bool &highlight);

    /// These methods pass mouse events up the parent of this item. At one
    /// point these also toggled visibility of child items. Since
    /// they no longer deal with child items, they should probably be removed.
    virtual void hoverEnterEvent(QGraphicsSceneHoverEvent *event);
    virtual void hoverLeaveEvent(QGraphicsSceneHoverEvent *event);
    virtual void hoverMoveEvent(QGraphicsSceneHoverEvent *event);
    virtual void mouseDoubleClickEvent(QGraphicsSceneMouseEvent *event);

    /// Set the parent of this item. Enables this to pass mouse events.
    void setGraphicsShotline(GraphicsShotline *parent);

protected:

    /// True if currently highlighted.
    bool m_highlighted;

private:

    /// NodeItem that used to appear on the screen during mouse over.
    /// TODO: delete this.
    NodeItem *m_node;

    /// Parent item.
    GraphicsShotline *m_shotline;
};

#endif // SEGMENTITEMGROUP_H
