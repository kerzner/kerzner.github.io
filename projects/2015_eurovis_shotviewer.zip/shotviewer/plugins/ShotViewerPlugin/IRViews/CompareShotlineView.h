#ifndef COMPARESHOTLINEVIEW_H
#define COMPARESHOTLINEVIEW_H

#include <QWidget>
#include <QGraphicsView>
#include <QList>
#include <QStringList>
#include <QLabel>

#include "ShotlineView.h"
#include "GraphicsShotlineView.h"
#include "IrData.h"

class CompareShotline;

namespace Ui
{
class CompareShotlineView;
}

/** This class draws a 1D projection of shotlines used for comparing the
 * components hit and the resulting pk values.
 *
 * This class inherits from GraphicsShotlineView, which handles view-to-view
 * communication for mouse hover highlighting and the projection of shotlines
 * from 3D to 1D.
 *
 * This class uses a ShotlineGraphicsView (QGraphicsView) to display a set of
 * CompareShotlines. This class uses CompareShotlineLabels to act as a legend
 * for the CompareShotlines.
 *
 * I wrote this class before entirely understanding how to do certain things
 * with QGraphicsViews. For instance, this class uses the eventFilter() method
 * to intercept mouse events on CompareShotlineLabels. These labels should
 * probably handle their own events instead.
 */
class CompareShotlineView : public GraphicsShotlineView
{
    Q_OBJECT

public:

    /// Constructor initializes QGraphicsViews used for the CompareShotlines
    /// and CompareShotlineLabels.
    CompareShotlineView(QWidget *parent = 0);

    /// Returns QGraphicsView used for the 1D shotline projection.
    QGraphicsView *getGraphicsView() const;

    /// Redraw shotline labels to be aligned with shotlines.
    void updateShotlineLabels(float yStride);

    /// Zooms on wheel events. Intercepts CompareShotlineLabel click events.
    bool eventFilter(QObject *object, QEvent *event);

    /// Returns true if the user wants to display pk glyphs in this view.
    bool getShowPkGlyphs() const;

public slots:

    /// Destroys current visualization and recreates it.
    void graphicsShotlinesChanged();

    /// Pass paint event along to this's widget. TODO: delete this?
    void paintEvent(QPaintEvent *event);

    /// Toggle the visiblity of pk glyphs.
    void setShowPkGlyphs(bool value);

protected:

    /// Returns menu that allows user to toggle pk glyph visibility.
    virtual QList<QMenu*> createMenus();

private slots:

private:

    // Private functions //////////////////////////////////////////////////////

    /// On resize, destroy everything and recreate it.
    void resizeEvent(QResizeEvent *event);

    // Overridden from ApplicationView //

    /// Attach an IRDocument, otherwise does nothing
    void attachDocument(ApplicationDocument *doc);

    // Private data ///////////////////////////////////////////////////////////
    Ui::CompareShotlineView *ui;

    /// True only if we're drawing pk glyphs.
    bool m_showPk;

    /// Keep a pointer to the menu action to show pks to manage checked state
    QAction *m_actionShow_pK;

    /// Keep a pointer to the menu action to show pks to manage checked state
    QAction *m_actionShow_colorMap;

    /// Keep a pointer to the menu action to use wtLos to manage checked state
    QAction *m_actionUse_wtLos;

};

#endif // COMPARESHOTLINEVIEW_H
