#include "SegmentLineItem.h"

SegmentLineItem::SegmentLineItem()
    : SegmentItemGroup()
{
}

QGraphicsLineItem *SegmentLineItem::getLine() const
{
    return m_line;
}

void SegmentLineItem::setDefaultPen(QPen pen)
{
    m_defaultPen = pen;
}

void SegmentLineItem::setMainLine(QGraphicsLineItem *line)
{
    m_line = line;
    m_line->setAcceptHoverEvents(true);
    addToGroup(m_line);
}

void SegmentLineItem::setHighlighting(const bool &highlight)
{
    QPen itemPen = m_line->pen();

    if (highlight && !m_highlighted) {
        m_defaultPen = itemPen;
        itemPen.setColor(Qt::black);
        m_line->setPen(itemPen);
    } else if (!highlight && m_highlighted) {
        itemPen.setColor(m_defaultPen.color());
    }

    m_line->setPen(itemPen);
    SegmentItemGroup::setHighlighting(highlight);
}
