#ifndef TABLEHIGHLIGHTDELEGATE_H
#define TABLEHIGHLIGHTDELEGATE_H

#include <QStyledItemDelegate>

/** Class used for changing the background color of table cells. This was
 * at one point used for interactive highlighting. Now it's not used at all.
 *
 * TODO: Delete this class!
 */
class TableHighlightDelegate : public QStyledItemDelegate
{
public:

    /// Constructor.
    TableHighlightDelegate(QObject *parent = 0);

    /// Paint a cell as highlighted.
    void paint(QPainter *painter, const QStyleOptionViewItem &option,
               const QModelIndex &index) const;

};
#endif // TABLEHIGHLIGHTDELEGATE_H
