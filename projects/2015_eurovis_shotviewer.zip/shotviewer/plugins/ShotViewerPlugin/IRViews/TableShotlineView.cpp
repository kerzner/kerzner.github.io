#include "TableShotlineView.h"

#include <QHBoxLayout>
#include <QLabel>
#include <QDebug>
#include <QHeaderView>
#include <QPalette>
#include <QMenu>
#include <QMessageBox>

#include "TableShotline.h"
#include "IRDocument.h"
#include "IfrHelpers.h"

TableShotlineView::TableShotlineView(QWidget *parent)
    : ShotlineView(parent)
    , m_ignoreSectionMoved(false)
    , m_menu(new QMenu("Columns", this))
{
    setMouseTracking(true);
}

void TableShotlineView::sectionMoved(int logicalIndex, int oldVisualIndex,
                                     int newVisualIndex)
{
    Q_UNUSED(logicalIndex);

    // Avoid a potential infinite loop of senders and receivers...
    // QHeaderView::moveSection emits the signal sectionMoved.
    if (!m_ignoreSectionMoved) {
        m_ignoreSectionMoved = true;

        // For all children, swap the columns to be consistent with the sender.
        QList<TableShotline*> tables = findChildren<TableShotline*>();
        foreach (TableShotline* table, tables) {
            QHeaderView *view = table->horizontalHeader();
            if (view != sender()) {
                view->moveSection(oldVisualIndex, newVisualIndex);
            }
        }
        m_ignoreSectionMoved = false;
    }
}

void TableShotlineView::mouseMoveEvent(QMouseEvent *event)
{
    static_cast<TableShotline*>(children().first())->mouseMoveEvent(event);
}

void TableShotlineView::setMouseHoverHighlight(const QMap<int, QList<int> > &map,
        const int &traceIdx,
        const bool &highlight,
        const int &)
{
    QList<TableShotline*> tables = findChildren<TableShotline*>();
    foreach (TableShotline *table, tables) {
        int tableAimPoint = table->getAimPoint();

        // Without it let's try to do something smart...
        if (!map.value(tableAimPoint).isEmpty() && traceIdx != -1) {
            table->scrollToItem(table->item(traceIdx, 0));
        }

        table->setMouseOverComponents(map[tableAimPoint], highlight);
    }
}

void TableShotlineView::setVisibleColumns(const QStringList &columns)
{
    QList<TableShotline*> tables = findChildren<TableShotline*>();
    foreach (TableShotline *table, tables) {
        table->setVisibleColumns(columns);
    }
    m_visibleColumns = columns;
}

void TableShotlineView::setInitialColumns(const QStringList &columns)
{
    m_initialColumns = columns;
}

QStringList TableShotlineView::getVisibleColumns() const
{
    return m_visibleColumns;
}

void TableShotlineView::updateShotlines()
{
    // If this already has a layout then delete the layout and all children.
    QHBoxLayout *hlayout = static_cast<QHBoxLayout*>(layout());
    if (hlayout) {
        hlayout->removeWidget(this);
        clearLayout(hlayout, true);
        delete hlayout;
    }

    // Create a new layout
    hlayout = new QHBoxLayout();
    hlayout->setSpacing(1);
    hlayout->setMargin(0);

    // Create tables for each of the aim points.
    IRDocument *model = getDocument();
    QList<int> aimPoints = model->getAimPoints();
    QList<IRShotlineThreat*> threats = model->getThreats();

    int i = 0;
    foreach (int aimPoint, aimPoints) {
        // Layout for table and header bar
        QVBoxLayout *sublayout = new QVBoxLayout();

        // Layout for header bar
        QHBoxLayout *subsublayout = new QHBoxLayout();
        subsublayout->setMargin(0);

        // Label with aimpoint color as background
        QLabel *label = new QLabel("   ");
        label->setAutoFillBackground(true);
        label->setSizePolicy(QSizePolicy::Fixed, QSizePolicy::Fixed);

        // Set the background color of label
        QColor color = model->getThreatColor(aimPoint);
        QPalette palette = label->palette();
        palette.setColor(label->backgroundRole(), color);
        label->setPalette(palette);
        subsublayout->addWidget(label);

        // Create a label with the aimpoint number
        label = new QLabel("AP: " + QString::number(aimPoint));
        subsublayout->addWidget(label);

        // Horizontal spacer so that the background color label doesn't expand
        QSpacerItem *spacer = new QSpacerItem(0, 0, QSizePolicy::Expanding);
        subsublayout->addItem(spacer);

        // Add the labels to the larger layout.
        sublayout->addItem(subsublayout);

        TableShotline *shot = new TableShotline(threats.at(i++),
                                                aimPoint, model, this, this);
        shot->setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Expanding);
        shot->setObjectName(QString::number(aimPoint));
        sublayout->addWidget(shot);
        hlayout->addItem(sublayout);

    }

    // TableShotline->horizontalHeader emits sectionMoved when columns are
    // rearranged. This ensures TableShotlines columns are ordered consistently.
    QStringList visibleColumns = getVisibleColumns();
    QList<TableShotline*> tables = findChildren<TableShotline*>();
    foreach (TableShotline* table, tables) {

        QHeaderView *view = table->horizontalHeader();

        connect(view, SIGNAL(sectionMoved(int, int, int)),
                this, SLOT(sectionMoved(int, int, int)));

        table->setVisibleColumns(visibleColumns);
    }
    setLayout(hlayout);
}

void TableShotlineView::clearLayout(QLayout *layout, bool deleteWidgets)
{
    while (QLayoutItem *item = layout->takeAt(0)) {
        if (deleteWidgets) {
            if (QWidget *widget = item->widget()) {
                delete widget;
            }
        }
        if (QLayout *childLayout = item->layout()) {
            clearLayout(childLayout, deleteWidgets);
        }
        delete item;
    }
}

void TableShotlineView::tableMenuSelectionChanged()
{
    // List of column names to be displayed
    QStringList visibleColumns;

    // Collect the names of all checked items in the menu
    QList<QAction*> actions = m_menu->findChildren<QAction*>();
    foreach (QAction *action, actions) {
        if(action->isChecked()) {
            visibleColumns.append(action->text());
        }
    }

    // Update the columns being displayed
    setVisibleColumns(visibleColumns);
}

void TableShotlineView::updateTableMenu(QStringList &allColumns,
                                        QStringList &currentColumns)
{
    QMenu *tableMenu = m_menu;
    foreach (QString col, allColumns) {
        QAction *action = new QAction(col, tableMenu);
        action->setCheckable(true);

        // If the action we just created has a name that the user has already
        // specified as visible then start it off as checked.
        if (currentColumns.contains(col)) {
            action->setChecked(true);
            currentColumns.removeAll(col);
        }

        connect(action, SIGNAL(changed()), this,
                SLOT(tableMenuSelectionChanged()));

        tableMenu->addAction(action);
    }

    if (!currentColumns.isEmpty()) {

        QString failedColumns;
        foreach (QString column, currentColumns) {
            failedColumns.append(column);
        }

        QMessageBox box;
        box.setText("I could not find the following threat parameters:\n" +
                    failedColumns);
        box.exec();
    }
}


void TableShotlineView::attachDocument(ApplicationDocument *doc)
{
    ShotlineView::attachDocument(doc);

    IRDocument *irdoc = dynamic_cast<IRDocument*>(doc);

    if(irdoc) {

        // Create tables for each of the shotlines.
        updateShotlines();

        QList<int> aimPoints = irdoc->getAimPoints();

        if (aimPoints.size() > 0) {
            IRTrace *trace = irdoc->getThreat(aimPoints.at(0))->traces[0];
            QStringList parameters = getExtendedTPNames(trace);
            parameters.append(getTGNames());
            parameters.removeAll("name");
            updateTableMenu(parameters, m_initialColumns);
            tableMenuSelectionChanged();
        }

        QString fileName = doc->getCurrentOpenFileName();
        QStringList s = fileName.split("/");
        fileName = s[s.size()-1];
        setWindowTitle("Table Shotline View - " + fileName);
    }
}

QList<QMenu*> TableShotlineView::createMenus()
{
    QList<QMenu*> menus = ShotlineView::createMenus();
    menus.push_back(m_menu);

    return menus;
}

