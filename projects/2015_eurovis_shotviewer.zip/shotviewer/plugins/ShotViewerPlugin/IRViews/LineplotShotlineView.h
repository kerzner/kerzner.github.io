#ifndef LINEPLOTSHOTLINEVIEW_H
#define LINEPLOTSHOTLINEVIEW_H

#include <QWidget>
#include <QGraphicsView>
#include <QList>
#include <QStringList>
#include <QLabel>

#include "IrData.h"
#include "ShotlineView.h"
#include "GraphicsShotlineView.h"

class QComboBox;
class LineplotLine;

namespace Ui
{
class LineplotShotlineView;
}

/** This class displays a user-selected paramater in a line plot. It assumes
 * that all threat parameters are piecewise linear functions. This inherits
 * from GraphicsShotlineView, which handles most of the mouse interactions.
 *
 * Like other ShotlineViews, this requires an IRDocument.
 *
 * The lineplot is created by the graphicsShotlinesChanged() method. This is
 * called when the IRDocument updates its data, on a resize event, or when
 * the user selects a new parameter to visualize. Updating shotlines is a three
 * step process:
 *  1. Clear old representation
 *  2. Add labels and tick marks to the scene
 *  3. Draw the lines
 */
class LineplotShotlineView : public GraphicsShotlineView
{
    Q_OBJECT

public:

    /// Setup the ui. Cannot create a visualization yet w/o a document.
    LineplotShotlineView(QWidget *parent = 0);

    /// Destructor.
    ~LineplotShotlineView();

    /// Returns the QGraphicsView displaying shotlines. This is used by
    /// GraphicsShotlineView to map from world space to scene space.
    virtual QGraphicsView *getGraphicsView() const;

public slots:

    /// Create the lineplot visualization.
    virtual void graphicsShotlinesChanged();

    /// Update the combo box with new threat parameters, then call
    /// graphicsShotlinesChanged() to create new visualization.
    virtual void updateShotlines();

    /// This class handles hover events by moving the aimPoint being
    /// moused over to the front of all the other LineplotLines. It then
    /// continues the event with GraphicsShotlineView::setMouseHoverHighlight
    /// which actually does the per-component highlighting.
    /// See GraphicsShotlineView or ShotlineView for parameter description.
    virtual void setMouseHoverHighlight(const QMap<int, QList<int> > &,
                                        const int &,
                                        const bool &,
                                        const int &);
protected slots:

    /// User changed the combobox. Recreate the line plots!
    void setCurrentThreatParameter(const QString &);

protected:

    /// Create labels for the x-axis of the lineplotView
    void updateXAxisLabels();

    /// Create labels for the y-axis of the lineplotView.
    /// -parameterName is set to the yLabelAxis title.
    /// -parameterRange is the min and max values of the parameter.
    void updateYAxisLabels(const QString &parameterName,
                           const QList<float> &parameterRange);

    /// User resized the window. Recreate the line plots!
    virtual void resizeEvent(QResizeEvent *event);

private:

    // Private functions //////////////////////////////////////////////////////

    /// Contains the combobox.
    QToolBar *createToolBar();

    // Overridden from ApplicationView //

    /// Attach an IRDocument, otherwise does nothing
    void attachDocument(ApplicationDocument *doc);

    // Private data ///////////////////////////////////////////////////////////

    Ui::LineplotShotlineView *ui;

    /// Current parameter being drawn.
    QString m_parameterName;

    /// Used to offset mapping from parameter space into scene space.
    /// Ensures we do not draw the lines on top of axis labels.
    float m_labelHeight;
};
#endif // LINEPLOTSHOTLINEVIEW_H
