#include "ShotlineGraphicsView.h"

#include <QDebug>
#include <QListWidget>
#include <QMouseEvent>

#include "SegmentItemGroup.h"
#include "SegmentLineItem.h"
#include "SegmentRectItem.h"

ShotlineGraphicsView::ShotlineGraphicsView(QWidget *parent)
    : QGraphicsView(parent)
    , m_listWidget(new QListWidget(this))
{
    m_listWidget->setHorizontalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
    m_listWidget->setVerticalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
    m_listWidget->setVisible(false);
}

void ShotlineGraphicsView::mouseMoveEvent(QMouseEvent *event)
{
    // Get items under mouse.
    QGraphicsScene *scene = this->scene();
    QPointF mousePosition = mapToScene(event->pos());
    QList<QGraphicsItem*> items = scene->items(mousePosition);

    // Get the item names.
    QStringList itemsUnderMouse;
    foreach (QGraphicsItem *item, items) {
        SegmentItemGroup *rectItem = dynamic_cast<SegmentRectItem*>(item);
        SegmentLineItem *lineItem = dynamic_cast<SegmentLineItem*>(item);
        if (rectItem) {
            QString name = rectItem->getName();
            itemsUnderMouse << name;
        } else if (lineItem) {
            QGraphicsLineItem *line = lineItem->getLine();
            if (line->isUnderMouse()) {
                QString name = lineItem->getName();
                itemsUnderMouse << name;
            }
        }
    }

    // Populate the list widget.
    if (itemsUnderMouse.size() > 0) {
        m_listWidget->clear();
        m_listWidget->addItems(itemsUnderMouse);

        // there's something odd going on here with the font height.
        // list height should be just height_of_font * number_of_items_in_list
        // but I don't know how to do that, so instead we pad by 20 pixelss
        QFontMetrics fontMetric  = m_listWidget->fontMetrics();
        int listHeight = fontMetric.height() * m_listWidget->count() + 20;

        // default position is lower left of mouse
        QPointF mousePosition = event->posF();
        float x = mousePosition.x() + 10;
        float y = mousePosition.y() + 10;

        // if box will go left off screen then shift to the left
        if (x + 256 > width()) {
            x = x - 256 - 20;
        }

        // if box will go below screen then shift up
        if (y + listHeight > height()) {
            y = y - listHeight - 10;
        }

        m_listWidget->setGeometry(x, y, 256, listHeight);

        m_listWidget->show();
    } else {
        m_listWidget->hide();
    }
    QGraphicsView::mouseMoveEvent(event);
}

void ShotlineGraphicsView::leaveEvent(QEvent *event)
{
    m_listWidget->hide();
}
