#ifndef GRAPHICSSHOTLINEVIEW_H
#define GRAPHICSSHOTLINEVIEW_H

#include <QGraphicsView>
#include <QList>

#include "IrData.h"
#include "ShotlineView.h"

class GraphicsShotline;

class GraphicsShotlineView : public ShotlineView
{
    Q_OBJECT
public:
    GraphicsShotlineView(QWidget *parent);

    /// Returns the graphicsView containing the shotlines
    virtual QGraphicsView *getGraphicsView() const = 0;

    // Convert points between scene and shotline coordinate systems.
    float mapFromSceneToShotline(const float &x) const;
    float mapFromShotlineToScene(const float &x) const;

    // Convert vectors between scene and shotline coordinate systems.
    float scaleFromSceneToShotline(const float &x) const;
    float scaleFromShotlineToScene(const float &x) const;

public slots:

    void updateShotlines();
    virtual void graphicsShotlinesChanged() = 0;

protected slots:

protected:

    // Protected functions ////////////////////////////////////////////////////

    // Overridden from ApplicationView //

    /// Highlight components along shotlines. See ShotlineView.h for parameters.
    virtual void setMouseHoverHighlight(const QMap<int, QList<int> > &,
                                        const int &,
                                        const bool &,
                                        const int &);

    /// Reset the list of shotlines.
    void clearShotlines();

    /// Add a shotline to the list.
    void addShotline(GraphicsShotline *shotline);

    /// List of all line items added to this group.
    QList<GraphicsShotline*> *m_lines;

    /// Create menu items for the camera to be inserted in MainWindow's menus
    QList<QMenu*> createMenus();

private:

    // Private functions //////////////////////////////////////////////////////

    // Overridden from ApplicationView //

};
#endif // GRAPHICSSHOTLINEVIEW_H
