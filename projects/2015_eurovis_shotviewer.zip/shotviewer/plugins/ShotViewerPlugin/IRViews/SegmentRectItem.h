#ifndef SEGMENTRECTITEM_H
#define SEGMENTRECTITEM_H

#include "SegmentItemGroup.h"

/** This class contains a QGraphicsRectItem which is used to show one trace
 * in a CompareShotlineView.
 *
 * This implements the setHighlighting method of SegmentItemGroup, allowing the
 * GraphicsShotline to highlight individual components.
 */
class SegmentRectItem : public SegmentItemGroup
{
public:

    /// Constructor.
    SegmentRectItem();

    /// Set the main shape that changed color on highlight events.
    void setMainRect(QGraphicsRectItem *rect);

    /// Toggle highlighting.
    virtual void setHighlighting(const bool &highlight);

private:

    /// Main item used for highlighting and mouse interactions.
    QGraphicsRectItem *m_rect;

    // Color when not highlighted.
    QColor m_color;
};
#endif // SEGMENTRECTITEM_H
