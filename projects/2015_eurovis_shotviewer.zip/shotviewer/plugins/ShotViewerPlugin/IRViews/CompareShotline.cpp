#include "CompareShotline.h"

#include <QVector3D>
#include <QGraphicsLineItem>
#include <QGraphicsScene>
#include <QDebug>
#include <QGraphicsView>
#include <QGraphicsSceneHoverEvent>

#include "IfrHelpers.h"
#include "IRDocument.h"
#include "ColorMap.h"
#include "CompareShotlineView.h"
#include "SegmentRectItem.h"

CompareShotline::CompareShotline(IRShotlineThreat *threat,
                                 int aimPoint,
                                 float tMax,
                                 IRDocument *model,
                                 QGraphicsScene *scene,
                                 float pkWidth,
                                 QGraphicsItem *parent,
                                 CompareShotlineView *view)
    : GraphicsShotline(aimPoint, view, parent)
    , m_threatenedAlpha(0.8f)
{
    // 0. Prep scene to handle this and initialize local variables.
    // 1. Convert from shotline's world coordinates into scene space
    // 2. Add traces to the scene.
    // 2a. Alternate color of traces and air
    // 2b. Set air traces thinner than others.
    // 2c. Draw pk glyph, if enabled.
    // 3. Add the rectangle and pkglyph to the scene.

    // 0. Prep scene to handle this and initialize local variables.
    setHandlesChildEvents(false);
    scene->addItem(this);

    // Get list of pks and colormap used for drawing pk glyphs
    QList<float> pkList = model->getPkList(aimPoint);
    ColorMap *pkColorMap = model->getPkColorMap();

    // Scene space values (assumes origin is center with inverted y axis)
    int width = scene->width();
    float xMin = -width/2;
    float xMax = width/2;

    // Get shotline's world space coordinates from the model.
    QList<QPointF> tList = model->getTList(aimPoint); // world space
    QList<QPointF> xList; // scene space

    // Pens and brushes used for alternating colors of rectangles.
    QPen darkPen(Qt::darkGray);
    darkPen.setWidth(0);

    QPen lightPen(Qt::lightGray);
    lightPen.setWidth(0);

    QPen dotPen(Qt::darkGray);
    dotPen.setWidth(0);

    QPen dashPen(Qt::darkGray);
    dashPen.setWidth(0);
    dashPen.setStyle(Qt::DashLine);

    QBrush darkBrush(Qt::darkGray);
    QBrush lightBrush(Qt::lightGray);

    // 1. Convert from shotline's coordinates into scene space.
    for (int i = 0; i < tList.size(); i++) {
        QPointF interval = tList[i];
        QPointF intervalSceneSpace;

        intervalSceneSpace.setX(map(interval.x(), 0.0f, tMax, xMin, xMax));
        intervalSceneSpace.setY(map(interval.y() + interval.x(),
                                    0.0f, tMax, xMin, xMax));
        xList.append(intervalSceneSpace);
    }

    // Compute width of pk glyph.
    pkWidth = map(pkWidth, 0.0f, tMax, xMin, xMax);
    pkWidth = pkWidth - xMin;

    // 2. Add rectangles to the scene.
    int n = 0;            // number of traces we've drawn.
    bool flag = true;     // alternates between true/false for every item drawn.
    float thickness = 20; // height of the rectangles being drawn.

    float airThickness = thickness / 2.0f;           // thickness of threats going through gap
    float prevX = map(0.0f, 0.0f, tMax, xMin, xMax); // x location where we will start drawing.

    // Loop over all intervals.
    for (int i = 0; i < xList.size(); i++) {

        // Data about the rectangle to be drawn.
        QPointF interval = xList[i];
        float x0 = prevX;
        float width = interval.y() - interval.x();

        // 2a. Alternate color of traces and air
        // 2b. Set air traces thinner than others.
        QGraphicsRectItem *rectangle;
        QPointF center = QPointF(0.0f, 0.0f);

        if (traceIsAir(threat->traces[i])) {
            rectangle = new QGraphicsRectItem(x0, airThickness / 2.0f, width, airThickness);
        } else {
            if (flag) {
                rectangle = new QGraphicsRectItem(x0, 0, width, thickness);
            } else {
                rectangle = new QGraphicsRectItem(x0, 2.5, width, thickness);
            }
            center = QPointF(x0 + width / 2, rectangle->y());
        }

        if (flag) {
            rectangle->setBrush(darkBrush);
            rectangle->setPen(darkPen);
        } else {
            rectangle->setBrush(lightBrush);
            rectangle->setPen(lightPen);
        }
        flag =! flag;

        // Draw flagged traces as transparent.
        if (threat->traces[i]->threatName == "FLAG") {
            rectangle->setOpacity(m_threatenedAlpha);
        }

        // 2c. Draw pk glyph, if enabled.
        if (view->getShowPkGlyphs() && pkList[i] >= 0) {
            // Upper bound of the pk glyph (scene space).
            float topY = rectangle->y() - pkWidth * 4.5f;
            // Lower bound of the pk glyph (scene space).
            float bottomY = topY + pkWidth * 3;
            // pK glyph will be filled with a rectangle based on pK.
            float fillTopY = map(pkList[i], 0.0f, 1.0f, bottomY, topY);

            // Center glyph above the trace.
            x0 = x0 + (width / 2.0f) - (pkWidth / 2.0f);
            QBrush fillBrush = QBrush(pkColorMap->getColor(pkList[i]));

            // Add the pk glyph.
            addPKGlyphNoOverlap(x0, topY, pkWidth, bottomY - topY, fillTopY,
                                fillBrush, scene, center);

            // Must call update so that add pkGlyphNoOverlap will correctly
            // find intersections.
            scene->update();
        }

        // 3. Add all that stuff to the scene.
        SegmentRectItem *group = new SegmentRectItem;
        addToGroup(group);
        group->setGraphicsShotline(this);
        group->setMainRect(rectangle);
        group->setData(Qt::UserRole, n++);
        group->setName(threat->traces[i]->compName);
        rectangle->setAcceptHoverEvents(true);
        prevX = prevX + width;
    }
}

void CompareShotline::addPKGlyph(float x0, float y0, float width, float height,
                                 float fillTop, QBrush fillBrush)
{
    float bottomY = y0 + height; // lower bounds of the filled in pK glyph
    float fillHeight = fillTop - bottomY; // height of the pK glyph

    // Create perimter rectangle
    QGraphicsRectItem *rectangle = new QGraphicsRectItem(x0, y0, width, height);
    float penWidth = rectangle->pen().widthF();

    // Create the fill rectangle and position it to not occluder the perimter
    QGraphicsRectItem *fill = new QGraphicsRectItem(x0, fillTop, width - penWidth,
            -fillHeight - penWidth);
    fill->setZValue(-0.1);
    fill->setBrush(fillBrush);
    fill->setPen(Qt::NoPen);

    rectangle->setData(PK_GLYPH_INDEX, 1);
    addToGroup(rectangle);
    addToGroup(fill);
}

void CompareShotline::addPKGlyphNoOverlap(float x0, float y0, float width,
        float height, float fillHeight,
        QBrush fillBrush,
        QGraphicsScene *scene, QPointF center)
{
    // Add a glyph to the scene while ensuring this does not overlap with
    // existing items.
    // 1. Find a space for the glyph.
    // 2. Create the glyph onces we've found space.
    // 3. Conenct the glyph with its trace.

    bool drawn = false;
    while (!drawn) {

        // 1. Find a space for the glyph.
        bool empty = true;
        QList<QGraphicsItem*> items = scene->items(x0, y0, width, height);

        // We do not care about overlapping with line items, only rectangles
        // The connection lines have very wide bounding boxes. Using them causes
        // very ugly spacing.
        foreach (QGraphicsItem *item, items) {
            if (item->data(PK_GLYPH_INDEX).isValid()) {
                empty = false;
            }
        }

        // 2. Create the glyph once we've found space.
        if (empty) {
            addPKGlyph(x0, y0, width, height, fillHeight, fillBrush);
            drawn = true;
            // There was somethign where we tried to draw. Move the glyph right.
        } else {
            x0 = x0 + width * 0.5f;
        }
    }

    // 3. Conenct the glyph with its trace.
    QGraphicsLineItem *line = new QGraphicsLineItem(x0 + width / 2.0f,
            y0 + height,
            center.x(),
            center.y());
    addToGroup(line);
}
