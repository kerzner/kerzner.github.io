#include "GraphicsShotline.h"

#include <QGraphicsScene>
#include <QGraphicsSceneHoverEvent>
#include <QGraphicsSceneMouseEvent>
#include <QDebug>
#include "ShotlineView.h"
#include "SegmentItemGroup.h"

// #define GRAPHICSSHOTLINE_DEBUG_FUNCTIONS 1
#if defined(GRAPHICSSHOTLINE_DEBUG_FUNCTIONS)
#define FUNCTION_DEBUG(x) \
{ \
    qDebug() << Q_FUNC_INFO << " " << m_aimPoint; \
}
#else
#define FUNCTION_DEBUG(x)
#endif // defined(GRAPHICSSHOTLINE_DEBUG_FUNCTIONS)

GraphicsShotline::GraphicsShotline(int aimPoint, ShotlineView *view, QGraphicsItem *parent)
    : QGraphicsItemGroup(parent)
    , m_aimPoint(aimPoint)
    , m_view(view)
    , m_itemMousedOver(-1)
{
    setAcceptHoverEvents(true);
    setHandlesChildEvents(false);
}

int GraphicsShotline::getAimPoint() const
{
    return m_aimPoint;
}

ShotlineView *GraphicsShotline::getView() const
{
    return m_view;
}

void GraphicsShotline::setMouseOverComponents(const QList<int> &components, const bool &highlight)
{
    // Loop over all children.
    foreach (QGraphicsItem *item, childItems()) {

        bool ok = false;
        int id = item->data(Qt::UserRole).toInt(&ok);

        SegmentItemGroup *segmentItem = dynamic_cast<SegmentItemGroup*>(item);

        if (ok && segmentItem) {
            segmentItem->setHighlighting(highlight && components.contains(id));
        }
    }
}

void GraphicsShotline::hoverEnterEvent(QGraphicsSceneHoverEvent *event)
{
    FUNCTION_DEBUG();

    // Loop over all items under the mouse.
    QList<QGraphicsItem*> itemsUnderMouse = scene()->items(event->scenePos());

    foreach (QGraphicsItem *item, itemsUnderMouse) {

        // Ignore the hover event if it is:
        //   -registered on this group (instead of a child item).
        //   -registered on an item that does not belong to this group
        if (item == this || item->parentItem() != this) {
            continue;
        }

        // Get the stashed component id.
        bool ok;
        int itemMousedOver = item->data(Qt::UserRole).toInt(&ok);

        // If the variant was valid and mouse is not already over this component...
        if (ok && itemMousedOver != m_itemMousedOver) {

            // Cache the component id.
            m_itemMousedOver = itemMousedOver;

            // Tell this parent that a new item is being moused over.
            m_view->mouseOverComponentEvent(m_aimPoint, m_itemMousedOver, true);

            // Pass the event along.
            QGraphicsItemGroup::hoverEnterEvent(event);
        }
    }
}

void GraphicsShotline::hoverMoveEvent(QGraphicsSceneHoverEvent *event)
{
    FUNCTION_DEBUG();

    // If we are not already over an item...
    if (m_itemMousedOver == -1) {

        // Loop over all items under the mouse.
        QList<QGraphicsItem*> itemsUnderMouse = scene()->items(event->scenePos());

        foreach (QGraphicsItem *item, itemsUnderMouse) {

            // Ignore the hover event if it is registered on this group.
            if (item == this) {
                continue;
            }

            // Get the stashed component id.
            bool ok;
            int itemMousedOver = item->data(Qt::UserRole).toInt(&ok);

            // If the variant was valid and mouse is not already over this component...
            if (ok && itemMousedOver != m_itemMousedOver) {

                // Cache the component id.
                m_itemMousedOver = itemMousedOver;

                // Tell this parent that a new item is being moused over.
                m_view->mouseOverComponentEvent(m_aimPoint, m_itemMousedOver, true);
            }
        }
        QGraphicsItemGroup::hoverMoveEvent(event);
    }
}

void GraphicsShotline::hoverLeaveEvent(QGraphicsSceneHoverEvent *event)
{
    FUNCTION_DEBUG();

    // If we are not mousing over anything already then return.
    if (m_itemMousedOver == -1) {
        return;
    }

    // Tell this parent that there's no longer a mouse over m_itemMousedOver.
    m_view->mouseOverComponentEvent(m_aimPoint, m_itemMousedOver, false);

    // Update current moused over state.
    m_itemMousedOver = -1;

    QGraphicsItemGroup::hoverLeaveEvent(event);
}

void GraphicsShotline::mouseDoubleClickEvent(QGraphicsSceneMouseEvent *event)
{
    QList<QGraphicsItem*> itemsUnderMouse = scene()->items(event->scenePos());

    foreach (QGraphicsItem *item, itemsUnderMouse) {

        // Ignore the double click event if it is:
        //   -registered on this group (instead of a child item).
        //   -registered on an item that does not belong to this group
        if (item == this) {
            continue;
        }

        // Get the stashed component id.
        bool ok;
        int itemMousedOver = item->data(Qt::UserRole).toInt(&ok);

        // If the variant was valid and mouse is not already over this component...
        if (ok) {
            m_view->mouseDoubleClickComponentEvent(m_aimPoint, itemMousedOver);
        }
    }
}
