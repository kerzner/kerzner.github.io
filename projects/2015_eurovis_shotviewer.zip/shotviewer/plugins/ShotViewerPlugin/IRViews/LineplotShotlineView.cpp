#include "LineplotShotlineView.h"
#include "ui_LineplotShotlineView.h"

#include <QGraphicsScene>
#include <QVector3D>
#include <QDebug>
#include <QMap>
#include <QSlider>
#include <QScrollBar>
#include <QWheelEvent>
#include <QComboBox>
#include <QToolBar>

#include "IfrHelpers.h"
#include "CompareShotline.h"
#include "ShotlineView.h"
#include "LineplotLine.h"
#include "IRDocument.h"

// #define LINEPLOTSHOTLINEVIEW_DEBUG 1

LineplotShotlineView::LineplotShotlineView(QWidget *parent)
    : GraphicsShotlineView(parent)
    , ui(new Ui::LineplotShotlineView)
{
    ui->setupUi(this);
}

LineplotShotlineView::~LineplotShotlineView()
{
    delete ui;
}

void LineplotShotlineView::graphicsShotlinesChanged()
{
    // Plot the shotlines of interest in this scene.
    // 1. Initialize local variables.
    // 2. Setup the scene for lines.
    // 3. Draw axes using range of parameters being drawn
    // 4. Draw lines on the

    // 1. Initialize local variables.IRDocument *model = getDocument();
    IRDocument *model = getDocument();
    QList<int> aimPoints = model->getAimPoints();

    QMap<int, QList<float> > parameterMap;
    parameterMap = model->getThreatParameterValues(m_parameterName);

    // 2. Setup the scene for lines.
    clearShotlines();

    //-10 is for clean margins around lines
    int h = ui->lineplotView->height() - 10;
    int w = ui->lineplotView->width() - 10;

    QGraphicsScene *scene = new QGraphicsScene(this);
    scene->setSceneRect(-w/2, -h/2, w, h);
    ui->lineplotView->setScene(scene);

    // 3. Draw axes using range of parameters being drawn
    QList<float> parameterRange;
    parameterRange = model->getThreatParameterRange(m_parameterName);
    updateXAxisLabels();
    updateYAxisLabels(m_parameterName, parameterRange);

    // 4. Draw lines on the graph
    int i = 0;
    QPen pen;
    pen.setWidth(2);

    foreach (int aimPoint, aimPoints) {
        // Color used to draw this aimpoint
        pen.setColor(model->getThreatColor(aimPoint));

        // List of y-values to be plotted
        QList<float> parameterValues = parameterMap.value(aimPoint);

        // Find t value of all hitpoints and convert to scene-space
        QList<QPointF> tList = model->getTList(aimPoint);
        QList<float> xList;
        for (int n = 0; n < tList.size(); n++) {
            QPointF interval = tList[n];
            xList.append(mapFromShotlineToScene(interval.x()));
        }

        QList<float> yList;

        // Turn the 1D segments into 2D lines by adding y-values.
        for (int k = 0; k < xList.size() - 1; k++) {
            float y0;

            // Get paramter values in world space.
            if (k < parameterValues.size()) {
                y0 = parameterValues[k];
            } else {
                // Flagged components have a value of the minimum parameter
                y0 = parameterRange[0];
            }

            // Map y coordinates into scene space.
            // m_labelHeight is used as offset so we do not draw over top labels
            y0 = map(y0, parameterRange[0], parameterRange[1], h/2, -h/2 + m_labelHeight);
            yList.append(y0);
        }
        QColor color = model->getThreatColor(aimPoint);

        // Create the visual representation of this shotline.
        LineplotLine *plotLine = new LineplotLine(model->getThreat(aimPoint), xList, yList, color, aimPoint, this);
        addShotline(plotLine);
        scene->addItem(plotLine);
        i = i + 1;
    }
}

void LineplotShotlineView:: updateXAxisLabels()
{
    // Create a scene for the left graphics view
    int h = ui->xLabelView->height();
    int w = ui->xLabelView->width();

    QGraphicsScene *scene = new QGraphicsScene(this);
    scene->setSceneRect(-w/2, -h/2, w, h);
    ui->xLabelView->setScene(scene);

    // Create the x label
    QGraphicsTextItem *text = new QGraphicsTextItem("distance");
    QRectF textRect = text->boundingRect();
    text->setPos(0 - (textRect.width() / 2), -h/2);
    scene->addItem(text);

    // Now we're drawing in the center scene
    scene = ui->lineplotView->scene();
    QRectF sceneRect = scene->sceneRect();

    QFont font = text->font();
    font.setPixelSize(8);

    const uint numTicks = 10;

    // Create tick marks and labels for the tick marks
    for (uint i = 1; i < numTicks; i++) {

        // Convert tick index to scene space
        float x = map(i, 0, numTicks, sceneRect.x(),
                      sceneRect.x() + sceneRect.width());

        // Create tick line
        QGraphicsLineItem *line = new QGraphicsLineItem(x, sceneRect.height(),
                x, -sceneRect.height());
        line->setPen(QPen(Qt::lightGray));
        line->setZValue(-1.0f);

        // Map x into world space
        float value = map(i, 0, numTicks, 0.0f, getDocument()->getTMax());

        // Create a label
        text = new QGraphicsTextItem(QString::number(value, 'g', 2));
        text->setFont(font);

        // Position text at the top of tick line
        textRect = text->boundingRect();
        text->setPos(x - (textRect.width() / 2), -sceneRect.height() / 2 - 5);

        // Create a white box that will be behind the text
        QGraphicsRectItem *rectangle = new QGraphicsRectItem(0, 0,
                textRect.width(),
                textRect.height());
        rectangle->setPos(text->scenePos());
        rectangle->setPen(Qt::NoPen);
        rectangle->setBrush(QBrush(Qt::white));

        m_labelHeight = rectangle->rect().height();

        QGraphicsItemGroup *group = new QGraphicsItemGroup();
        group->addToGroup(rectangle);
        group->addToGroup(text);
        group->setZValue(-0.75f);
        scene->addItem(group);
        scene->addItem(line);
    }
}

void LineplotShotlineView::updateYAxisLabels(const QString &parameterName,
        const QList<float> &parameterRange)
{
    // Create a scene for the bottom graphics view
    int h = ui->yLabelView->height();
    int w = ui->yLabelView->width();

    QGraphicsScene *scene = new QGraphicsScene(this);
    scene->setSceneRect(-w/2, -h/2, w, h);
    ui->yLabelView->setScene(scene);

    // Create the y label. We rotate by 270 degress so that the text starts
    // at the top and goes straight down.
    QGraphicsTextItem *text = new QGraphicsTextItem(parameterName);
    QRectF textRect = text->boundingRect();
    text->setPos(0 - (textRect.width() / 2), 0);
    text->setTransformOriginPoint(textRect.center());
    text->setRotation(270);
    scene->addItem(text);

    // Now we're drawing in the center scene that actually contains the lineplot
    scene = ui->lineplotView->scene();

    // Get the bounds of the scene.
    QRectF sceneRect = scene->sceneRect();
    h = sceneRect.height();
    w = sceneRect.width();

    QFont font = text->font();
    font.setPixelSize(8);

    //TODO: make this adjustable.
    const uint numTicks = 5;

    // Create tick marks and labels
    for (uint i = 1; i < numTicks; i++) {

        // Convert tick index to scene space
        float y = map(i, 0, numTicks, h/2, -h/2 + m_labelHeight);

        // Create tick line
        QGraphicsLineItem *line = new QGraphicsLineItem(-w/2, y, w/2, y);
        line->setPen(QPen(Qt::lightGray));

        // Put it behind everything else. All the shotlines will have
        // positive z values.
        line->setZValue(-1.0f);

        // Map tick index to parameter space
        float value = map(i, 0, numTicks, parameterRange[0], parameterRange[1]);

        // Create the label
        text = new QGraphicsTextItem(QString::number(value, 'g', 2));
        text->setFont(font);
        textRect = text->boundingRect();
        text->setPos(w/2 - textRect.width(), y - (textRect.height() / 2));

        // Create a white box that will be behind the text
        QGraphicsRectItem *rectangle = new QGraphicsRectItem(0, 0,
                textRect.width(),
                textRect.height());
        rectangle->setPos(text->scenePos());
        rectangle->setPen(Qt::NoPen);
        rectangle->setBrush(QBrush(Qt::white));

        QGraphicsItemGroup *group = new QGraphicsItemGroup();
        group->addToGroup(rectangle);
        group->addToGroup(text);

        // group should be in front of the line but behind shotlines.
        // in other words: 1.0f < groupZ < 0.0f.
        group->setZValue(line->zValue() + 0.25f);

        scene->addItem(group);
        scene->addItem(line);
    }
}

QGraphicsView *LineplotShotlineView::getGraphicsView() const
{
    return ui->lineplotView;
}

void LineplotShotlineView::resizeEvent(QResizeEvent *event)
{
    graphicsShotlinesChanged();

    QWidget::resizeEvent(event);
}

QToolBar *LineplotShotlineView::createToolBar()
{
    QHBoxLayout *layout = new QHBoxLayout();
    layout->setMargin(0);

    QLabel *label = new QLabel("Parameter:");
    label->setAlignment(Qt::AlignRight);
    layout->addWidget(label);
    layout->addWidget(ui->comboBox);

    QWidget *widget = new QWidget();
    widget->setLayout(layout);

    QToolBar *toolBar = new QToolBar();
    toolBar->setObjectName("Lineplot Shotline ToolBar");
    toolBar->addWidget(widget);
    return toolBar;
}

void LineplotShotlineView::setCurrentThreatParameter(const QString &parameterName)
{
    int index = ui->comboBox->findText(parameterName);
    ui->comboBox->setCurrentIndex(index);
    m_parameterName = parameterName;
    graphicsShotlinesChanged();
}

void LineplotShotlineView::updateShotlines()
{
    IRDocument *model = getDocument();
    QList<int> aimPoints = model->getAimPoints();
    if (!aimPoints.isEmpty()) {

        // Assumes all aimPoints will have the same threat packets.
        IRTrace *trace = model->getThreat(aimPoints.at(0))->traces[0];
        QStringList parameters = getTPNames(trace);

        // Initialize combo box.
        ui->comboBox->clear();
        ui->comboBox->addItems(parameters);

        // By default, show an interesting value.
        if (parameters.contains("respen")) {
            setCurrentThreatParameter("respen");
        } else if (parameters.size() > 0) {
            setCurrentThreatParameter(parameters[0]);
        }
    }
}

void LineplotShotlineView::setMouseHoverHighlight(
    const QMap<int, QList<int> > &map,
    const int &traceIdx,
    const bool &highlight,
    const int &aimPoint)
{
    foreach(GraphicsShotline *line, *m_lines) {
        LineplotLine *lineplotLine = dynamic_cast<LineplotLine*>(line);
        if (lineplotLine) {
            lineplotLine->setMouseHoverAimPoint(highlight ? aimPoint : -1);
        }
    }
    GraphicsShotlineView::setMouseHoverHighlight(map, traceIdx, highlight, aimPoint);
}

void LineplotShotlineView::attachDocument(ApplicationDocument *doc)
{
    GraphicsShotlineView::attachDocument(doc);

    if(dynamic_cast<IRDocument*>(doc)) {

        // Update internal state
        updateShotlines();

        // Setup the graphics view holding line plots
        QGraphicsView *view = ui->lineplotView;
        view->setRenderHints(QPainter::Antialiasing);
        view->setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Expanding);

        // draw shotlines and labels
        graphicsShotlinesChanged();

        connect(ui->comboBox, SIGNAL(currentIndexChanged(const QString &)),
                this, SLOT(setCurrentThreatParameter(const QString &)));

        QString fileName = doc->getCurrentOpenFileName();
        QStringList s = fileName.split("/");
        fileName = s[s.size()-1];

        setWindowTitle("Lineplot Shotline View - " + fileName);
    }
}
