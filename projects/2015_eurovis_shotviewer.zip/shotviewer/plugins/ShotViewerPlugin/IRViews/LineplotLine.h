#ifndef LINEPLOTLINE_H
#define LINEPLOTLINE_H

#include <QGraphicsItemGroup>
#include <QPen>
#include "LineplotShotlineView.h"
#include "GraphicsShotline.h"

/** This class creates the graphics items used in the LineplotShotlineView.
 *
 * In addition to plotting paramaters in a lineplot, this handles mouse hover
 * events that are unique to the LineplotShotlineView. Particularly, when
 * the user mouses over an aimPoint, the LineplotLine representing that aimpoint
 * gets moved to the front of all the other LineplotLines. This is performed by
 * setMouseHoverAimPoint(...) which calls updateChildrenAndPenDepth(...).
 *
 * This also hides some ugliness of the QGraphicsItem mouse hover events when
 * dealing with lines. Particularly, QGraphicsItem uses shape() method to define
 * for collision detection. By default, shape() returns an axis-aligned
 * bounding box of the item. In the case of diagonal lines this overestimates
 * line size, resulting in odd mouse interactions. To overcome this problem, we
 * override the shape() method to define a tighter shape used for detecting
 * mouse hover events.
 */
class LineplotLine : public GraphicsShotline
{
public:

    /// Create a lineplot representation of the given shotline threat.
    /// -threat is used for the trace names (TODO: replace it with string list)
    /// -xValues are the start and end points of each component
    /// -yValues are the start and end attributes of each component
    /// -color is the color assigned to this shotline
    /// -aimPoint is the shotline being drawn
    /// -view is the view displaying this item (used for communicating events)
    explicit LineplotLine(const IRShotlineThreat *threat,
                          QList<float> xValues,
                          QList<float> yValues,
                          QColor color,
                          int aimPoint,
                          LineplotShotlineView *view,
                          QGraphicsItem *parent = 0);

    /// This is called after we've created all the children. It updates the
    /// member m_painterPath which is returned by the shape() method.
    void updateShape();

    /// Returns the shape created by updateShape(). See description above.
    virtual QPainterPath shape() const;

    /// When the user mouses over an aim point, the LineplotLine representing
    /// that aimpoint gets moved to the front. This gets called with the aim
    /// point being moused over and it moves this line to the front if it
    /// is the one being moused over.
    void setMouseHoverAimPoint(const int &);

    /// This is called by setMouseHoverAimPoint(...), if hovered is true then
    /// move this group to the front and make it bold. Otherwise, move this back
    /// its default position.
    virtual void updateChildrenPenAndDepth(const bool &hovered);

protected:
    /// Bounding region of the line segments.
    QPainterPath m_painterPath;

    /// True only if the mouse is currently over this aimPoint. This is used
    /// to prevent highlighting LineplotLines multiple times.
    bool m_hovered;

    /// Pen used to draw this item.
    QPen m_defaultPen;

    /// The depth of this item in the scene. This is used for resetting the
    /// state of this pen, but it could probably be removed.
    qreal m_defaultDepth;
};
#endif // LINEPLOTLINE_H
