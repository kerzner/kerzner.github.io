#include "SegmentRectItem.h"

SegmentRectItem::SegmentRectItem()
    : SegmentItemGroup()
{
}

void SegmentRectItem::setMainRect(QGraphicsRectItem *rect)
{
    m_rect = rect;
    m_rect->setAcceptHoverEvents(true);
    m_color = m_rect->pen().color();
    addToGroup(m_rect);
}

void SegmentRectItem::setHighlighting(const bool &highlight)
{
    // Conditionally highlight this item by making its pen thicker and changing
    // the color to black.
    QPen itemPen = m_rect->pen();
    QBrush itemBrush = m_rect->brush();
    if (highlight && !m_highlighted) {
        itemPen.setWidthF(itemPen.widthF());
        itemPen.setColor(Qt::black);
        itemBrush.setColor(Qt::black);
    } else if (!highlight) {
        itemPen.setWidth(0.0f);
        itemPen.setColor(m_color);
        itemBrush.setColor(m_color);
    }

    m_rect->setPen(itemPen);
    m_rect->setBrush(itemBrush);
    SegmentItemGroup::setHighlighting(highlight);
}
