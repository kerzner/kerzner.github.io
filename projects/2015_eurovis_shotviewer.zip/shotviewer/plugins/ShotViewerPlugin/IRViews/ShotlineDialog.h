#ifndef SHOTLINEDIALOG_H
#define SHOTLINEDIALOG_H

#include <QDialog>
#include <QStringList>

namespace Ui
{
class ShotlineDialog;
}

class QListWidgetItem;

class ShotlineDialog : public QDialog
{
    Q_OBJECT

public:

    ShotlineDialog(QStringList aimpoints,
                   QStringList threats,
                   QStringList qualifiers,
                   QWidget *parent = 0);
    ~ShotlineDialog();

    void setDefaultAimpoints(QStringList defaults);
    void setDefaultThreat(QString defaultThreat);
    void setDefaultQualifier(QString defaultQualifier);

    QStringList getAimpoints();
    QString     getThreat();
    QString     getQualifier();

private slots:

    void on_threatComboBox_currentIndexChanged(const QString &t);

    void on_qualifierComboBox_currentIndexChanged(const QString &q);

    void on_aimpointsListWidget_itemClicked(QListWidgetItem *item);

private:

    Ui::ShotlineDialog *ui;

    QStringList m_aimpoints;
    QString m_threat;
    QString m_qualifier;
};

#endif // SHOTLINEDIALOG_H
