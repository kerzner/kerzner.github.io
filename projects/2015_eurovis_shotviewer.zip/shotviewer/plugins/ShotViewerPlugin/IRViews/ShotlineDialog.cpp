#include "ShotlineDialog.h"
#include "ui_ShotlineDialog.h"

#include <QDebug>

ShotlineDialog::ShotlineDialog(QStringList aimpoints,
                               QStringList threats,
                               QStringList qualifiers,
                               QWidget *parent) :
    QDialog(parent),
    ui(new Ui::ShotlineDialog)
{
    ui->setupUi(this);

    foreach (QString aimpoint, aimpoints) {
        ui->aimpointsListWidget->addItem(new QListWidgetItem(aimpoint));
    }

    foreach (QString threat, threats) {
        ui->threatComboBox->addItem(threat);
    }

    // By default set the current qualifier to pk_main.
    int defaultQualifierIndex = 0;
    foreach (QString qualifier, qualifiers) {
        if(qualifier.contains("pk_main")) {
            defaultQualifierIndex = ui->qualifierComboBox->count();
        }
        ui->qualifierComboBox->addItem(qualifier);
    }

    ui->aimpointsListWidget->item(0)->setSelected(true);
    m_aimpoints.append(ui->aimpointsListWidget->item(0)->text());

    m_threat = ui->threatComboBox->itemText(0);
    m_qualifier = ui->qualifierComboBox->itemText(defaultQualifierIndex);
    ui->qualifierComboBox->setCurrentIndex(defaultQualifierIndex);
}

ShotlineDialog::~ShotlineDialog()
{
    delete ui;
}

void ShotlineDialog::setDefaultAimpoints(QStringList defaults)
{
    if (!defaults.empty()) {
        m_aimpoints.clear();
        ui->aimpointsListWidget->item(0)->setSelected(0);
        for (int i = 0; i < ui->aimpointsListWidget->count(); ++i) {
            if (defaults.contains(ui->aimpointsListWidget->item(i)->text())) {
                ui->aimpointsListWidget->item(i)->setSelected(true);
                m_aimpoints.append(ui->aimpointsListWidget->item(i)->text());
            }
        }
    }
}

void ShotlineDialog::setDefaultThreat(QString defaultThreat)
{
    for (int i = 0; i < ui->threatComboBox->count(); ++i) {
        if (ui->threatComboBox->itemText(i) == defaultThreat) {
            ui->threatComboBox->setCurrentIndex(i);
            break;
        }
    }
}

void ShotlineDialog::setDefaultQualifier(QString defaultQualifier)
{
    for (int i = 0; i < ui->qualifierComboBox->count(); ++i) {
        if (ui->qualifierComboBox->itemText(i) == defaultQualifier) {
            ui->qualifierComboBox->setCurrentIndex(i);
            break;
        }
    }
}

QStringList ShotlineDialog::getAimpoints()
{
    return m_aimpoints;
}

QString ShotlineDialog::getThreat()
{
    return m_threat;
}

QString ShotlineDialog::getQualifier()
{
    return m_qualifier;
}

void ShotlineDialog::on_threatComboBox_currentIndexChanged(const QString &t)
{
    m_threat = t;
}

void ShotlineDialog::on_qualifierComboBox_currentIndexChanged(const QString &q)
{
    m_qualifier = q;
}

void ShotlineDialog::on_aimpointsListWidget_itemClicked(QListWidgetItem *item)
{
    QList<QListWidgetItem*> selected = ui->aimpointsListWidget->selectedItems();
    if (selected.size() > 4)
        item->setSelected(false);
    else if (selected.empty() && !item->isSelected())
        item->setSelected(true);

    selected = ui->aimpointsListWidget->selectedItems();

    m_aimpoints.clear();
    foreach (QListWidgetItem* item, selected)
    m_aimpoints.append(item->text());
}
