#include "SegmentItemGroup.h"

#include "../GraphItems/NodeItem.h"
#include "GraphicsShotline.h"

#include <QGraphicsSceneHoverEvent>
#include <QDebug>

SegmentItemGroup::SegmentItemGroup()
    : QGraphicsItemGroup()
    , m_highlighted(false)
{
    setHandlesChildEvents(true);
}

void SegmentItemGroup::setName(const QString &name)
{
    /// m_node used to appear when the user moused over a component.
    /// It is no longer used since we show component names another way.
    /// TODO: delete this.
    m_node = new NodeItem(0, 0, 0, 0, this);
    m_node->setText(name);
    m_node->setVisible(false);
    m_node->setZValue(zValue() + 5.0f);
}

QString SegmentItemGroup::getName() const
{
    return m_node->toQString();
}

void SegmentItemGroup::setHighlighting(const bool &highlight)
{
    m_highlighted = highlight;
}

void SegmentItemGroup::hoverEnterEvent(QGraphicsSceneHoverEvent *event)
{
    m_shotline->hoverEnterEvent(event);
}

void SegmentItemGroup::hoverLeaveEvent(QGraphicsSceneHoverEvent *event)
{
    m_shotline->hoverLeaveEvent(event);
}

void SegmentItemGroup::hoverMoveEvent(QGraphicsSceneHoverEvent *event)
{
    m_shotline->hoverMoveEvent(event);
}

void SegmentItemGroup::mouseDoubleClickEvent(QGraphicsSceneMouseEvent *event)
{
    m_shotline->mouseDoubleClickEvent(event);
}

void SegmentItemGroup::setGraphicsShotline(GraphicsShotline *parent)
{
    m_shotline = parent;
}
