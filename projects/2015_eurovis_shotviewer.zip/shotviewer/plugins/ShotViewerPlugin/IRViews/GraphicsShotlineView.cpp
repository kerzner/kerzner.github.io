#include "GraphicsShotlineView.h"

#include <QVector3D>
#include <QMenu>
#include <QDebug>

#include "IfrHelpers.h"
#include "ShotlineView.h"

#include "IRDocument.h"
#include "GraphicsShotline.h"

GraphicsShotlineView::GraphicsShotlineView(QWidget *parent)
    : ShotlineView(parent)
    , m_lines(new QList<GraphicsShotline*>())
{
    /*no-op*/
}

float GraphicsShotlineView::mapFromSceneToShotline(const float &x) const
{
    QRectF rectangle = getGraphicsView()->sceneRect();
    float xMin = rectangle.x();
    float xMax = rectangle.x() + rectangle.width();
    float tMax = getDocument()->getTMax();
    return map(x, xMin, xMax, 0.0f, tMax);
}

float GraphicsShotlineView::mapFromShotlineToScene(const float &x) const
{
    QRectF rectangle = getGraphicsView()->sceneRect();
    float xMin = rectangle.x();
    float xMax = rectangle.x() + rectangle.width();
    float tMax = getDocument()->getTMax();
    return map(x, 0.0f, tMax, xMin, xMax);
}

float GraphicsShotlineView::scaleFromShotlineToScene(const float &x) const
{
    QRectF rectangle = getGraphicsView()->sceneRect();
    float xMin = rectangle.x();
    float xMax = rectangle.x() + rectangle.width();
    float range = xMax - xMin;
    float ratio = range / getDocument()->getTMax();
    return ratio * x;
}

float GraphicsShotlineView::scaleFromSceneToShotline(const float &x) const
{
    QRectF rectangle = getGraphicsView()->sceneRect();
    float xMin = rectangle.x();
    float xMax = rectangle.x() + rectangle.width();
    float range = xMax - xMin;
    float ratio = getDocument()->getTMax() / range;
    return ratio * x;
}

void GraphicsShotlineView::updateShotlines()
{
    graphicsShotlinesChanged();
}

void GraphicsShotlineView::setMouseHoverHighlight(
    const QMap<int, QList<int> > &map,
    const int &traceIdx,
    const bool &highlight,
    const int &aimPoint)
{
    Q_UNUSED(traceIdx);
    Q_UNUSED(aimPoint);

    // For each line being displayed, tell it to highlight individual components.
    foreach (GraphicsShotline *line, *m_lines) {
        int lineAimPoint = line->getAimPoint();
        if (map.contains(lineAimPoint)) {
            line->setMouseOverComponents(map[lineAimPoint], highlight);
        } else {
            line->setMouseOverComponents(QList<int>(), highlight);
        }
    }
}

void GraphicsShotlineView::clearShotlines()
{
    m_lines->clear();
}

void GraphicsShotlineView::addShotline(GraphicsShotline *shotline)
{
    m_lines->append(shotline);
}

QList<QMenu*> GraphicsShotlineView::createMenus()
{
    QList<QMenu*> menus = ShotlineView::createMenus();
    return menus;
}
