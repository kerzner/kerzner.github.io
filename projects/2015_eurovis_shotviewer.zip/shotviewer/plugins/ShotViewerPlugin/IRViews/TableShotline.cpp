#include "TableShotline.h"

#include <QHeaderView>
#include <QAbstractItemView>
#include <QDebug>
#include <QMouseEvent>

#include "IfrHelpers.h"
#include "TableShotlineView.h"
#include "TableHighlightDelegate.h"

TableShotline::TableShotline(IRShotlineThreat *threat,
                             int aimPoint,
                             IRDocument *model,
                             TableShotlineView *view,
                             QWidget *parent)
    : QTableWidget(parent)
    , m_document(model)
    , m_view(view)
    , m_aimPoint(aimPoint)
    , m_mousedOverTraceIdx(-1)
{
    setMouseTracking(true);

    // Setup column labels
    QStringList columns = getExtendedTPNames(threat->traces[0]);
    columns.append(getTGNames());
    setColumnCount(columns.size());
    setHorizontalHeaderLabels(columns);
    setRowCount(threat->traces.size());

    // pK list of all components along the shotline
    QList<float> pkList = model->getPkList(aimPoint);

    int row = 0;
    QString itemText;

    // Add items to the table by row
    foreach (IRTrace *trace, threat->traces) {
        int col = 0;

        addItem(row, col++, trace->compName);

        // Add items from the TP line
        foreach (QString name, columns) {
            itemText = "n/a";
            if (trace->threatName != "FLAG") {
                QVariant v = trace->threatPackets[0]->parameterList.value(name);
                if (v.isValid()) {
                    itemText = v.toString();
                } else {
                    continue;
                }
            } else {
                itemText = QString("n/a");
            }
            addItem(row, col++, itemText);
        }

        // Add pk item
        float pk = pkList.at(row);
        addItem(row, col++, pk == -1 ? "n/a" : QString::number(pk));

        // Add material item
        addItem(row, col++, trace->material);

        // Add items from TG line
        addItem(row, col++, QString::number(trace->geom.norm));
        addItem(row, col++, QString::number(trace->geom.obliq));
        addItem(row, col++, QString::number(trace->geom.wtLos));
        addItem(row, col++, QString::number(trace->geom.wtLos));
        row++;
    }
    setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Minimum);
    correctColumnSize();
    // Disable editing
    setEditTriggers(QAbstractItemView::NoEditTriggers);
}

TableShotline::~TableShotline()
{
    clearContents();
}

void TableShotline::updateTable(QList<int> traceIdxs)
{
    // Only show rows that match the traceIndices
    QList<int>::iterator itr;
    for (itr = traceIdxs.begin(); itr != traceIdxs.end(); ++itr) {
        for (int i = 0; i < rowCount(); i++) {
            QTableWidgetItem *cell = item(i, 0);
            if (i == *itr) {
                showRow(cell->row());
            }
        }
    }

    update();
}

void TableShotline::updateTableAllVisible()
{
    QList<int> traceIndex;
    for (int row = 0; row < rowCount(); row++) {
        traceIndex << row;
    }

    updateTable(traceIndex);
}

void TableShotline::updateHighlight(QList<int> traceIdxs)
{
    // Turn on highlighting
    QColor lightGray(240, 240, 240);
    QList<int>::iterator itr;
    for (itr = traceIdxs.begin(); itr != traceIdxs.end(); ++itr) {
        for (int i = 0; i < rowCount(); i++) {
            if (i == *itr) {
                for (int j = 0; j < columnCount(); j++) {
                    QTableWidgetItem *cell = item(i, j);
                    if (cell) {
                        cell->setBackground(lightGray);
                        scrollToItem(cell);
                    }
                }
            }
        }
    }

    update();
}

void TableShotline::clearHighlights()
{
    // Clear all highlighting
    for (int i = 0; i < rowCount(); i++) {
        for (int j = 0; j < columnCount(); j++) {
            QTableWidgetItem *cell = item(i, j);
            if (cell) {
                cell->setBackground(QBrush(Qt::white));
            }
        }
    }
}

void TableShotline::hideRows()
{
    // Hide all rows in the table
    for (int i = 0; i < rowCount(); i++) {
        hideRow(i);
    }
}

void TableShotline::correctColumnSize()
{
    QHeaderView *header = horizontalHeader();
    header->setResizeMode(0, QHeaderView::Stretch);
    for (int i = 1; i < columnCount(); i++) {
        header->setResizeMode(i, QHeaderView::ResizeToContents);
        header->setMovable(true);
    }
    setHorizontalHeader(header);
}

void TableShotline::addItem(int row, int col, QString text)
{
    QTableWidgetItem *item = new QTableWidgetItem(text);
    item->setFlags(Qt::NoItemFlags | Qt::ItemIsEnabled | Qt::ItemIsDragEnabled);
    setItem(row, col, item);
}

void TableShotline::setVisibleColumns(const QStringList &columns)
{
    // Start at index 1 b/c we always want to show the name
    for (int i = 1; i < columnCount(); i++) {
        QTableWidgetItem *item = horizontalHeaderItem(i);
        if (columns.contains(item->text())) {
            showColumn(i);
        } else {
            hideColumn(i);
        }
    }
    correctColumnSize();
}

int TableShotline::getAimPoint() const
{
    return m_aimPoint;
}

void TableShotline::mouseMoveEvent(QMouseEvent *event)
{
    QTableWidgetItem *item = itemAt(event->pos());
    if (item) {
        m_mousedOverTraceIdx = item->row();
    } else {
        m_mousedOverTraceIdx = -1;
    }
    m_view->mouseOverComponentEvent(m_aimPoint, m_mousedOverTraceIdx, m_mousedOverTraceIdx != -1);
}

void TableShotline::setMouseOverComponents(const QList<int> &traceIdxs, const bool &highlight)
{
    for (int i = 0; i < rowCount(); i++) {
        for (int j = 0; j < columnCount(); j++) {
            QTableWidgetItem *cell = item(i, j);
            if (cell) {
                QFont font = cell->font();
                if (traceIdxs.contains(i) && highlight) {
                    font.setBold(true);
                } else {
                    font.setBold(false);
                }
                cell->setFont(font);
            }
        }
    }
    update();
}
