#ifndef COMPARESHOTLINE_H
#define COMPARESHOTLINE_H

#include "GraphicsShotline.h"
#include "IrData.h"

class IRDocument;
class CompareShotlineView;

/** This class draws shotlines used by the CompareShotlineView. It represents
 * a shotline as a series of SegmentRectItems (QGraphicsRectItems). Each of
 * these corresponds to a trace or interval along the line.
 *
 * This class was written as part of the initial technology probe that I
 * intended to throw away. I would suggest rewriting this entirely rather than
 * trying to support it.
 *
 * This also draws pk glyphs above the damaged traces on a shotline. The main
 * way for doing this is the addPkGlyphNoOverlap( ) method. This method will
 * space out pk glyphs so that they do not overlap, even when dealing with
 * extremely small components.
 */
class CompareShotline : public GraphicsShotline
{

public:

    /// Constructor.
    /// -threat: shotline being drawn
    /// -aimPoint: aimPoint of the threat
    /// -tMax: farthest distance in world space for all loaded aimPoints
    ///     used for the projection from world space to scene space
    /// -model: the document being drawn -- used to get at pk values
    /// -scene: scene that this will be displayed in
    /// -pkWidth: width of glyphs in scene space
    /// -parent: parent of this item in the scene (not used).
    /// -view: view used to communicate mouse hover events
    CompareShotline(IRShotlineThreat *threat, int aimPoint, float tMax,
                    IRDocument *model, QGraphicsScene *scene, float pkWidth,
                    QGraphicsItem *parent, CompareShotlineView *view);

    /// Adds a pk glyph to this-- will result in overlap if used with
    ///     small components. It is not currently used and should be removed.
    /// x0, y0, width, height: define scene space rectangle of this glyph
    /// fillHeight: pk value mapped into scene space expressed as bar height.
    /// fillBrush: brush used to color the filled bar
    void addPKGlyph(float x0, float y0, float width, float height,
                    float fillHeight, QBrush fillBrush);

    /// Adds a pk glyph to this. It will avoid overlap of glyphs when dealing
    /// with small components. This is done in a dumb way: just move the glyph
    /// to the right of the component until it can be drawn without overlap
    /// anything.
    /// -x0, y0, width, height: define scene space rectangle of this glyph
    /// -fillHeight: pk value mapped into scene space expressed as bar height.
    /// -fillBrush: brush used to color the filled bar
    void addPKGlyphNoOverlap(float x0, float y0, float width, float height,
                             float fillHeight, QBrush fillBrush,
                             QGraphicsScene *scene, QPointF center);

private:

    /// Alpha value used to draw threatened components.
    const float m_threatenedAlpha;

    /// Used to identify pk glyphs by their data(). This is used when we are
    /// trying to draw pk glyphs without overlap.
    enum {
        PK_GLYPH_INDEX = 0
    };
};

#endif // COMPARESHOTLINE_H
