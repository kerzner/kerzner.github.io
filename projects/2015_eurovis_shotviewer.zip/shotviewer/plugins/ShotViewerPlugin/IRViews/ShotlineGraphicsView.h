#ifndef SHOTLINEGRAPHICSVIEW_H
#define SHOTLINEGRAPHICSVIEW_H

#include <QGraphicsView>
class QListWidget;

/** This class is used by LinePlotShotlineView and the CompareShotlineView
 * to draw shotlines inside a QGraphicsView.
 *
 * This is the class responsible for updating the QListWidget on mouse events.
 */
class ShotlineGraphicsView : public QGraphicsView
{
    Q_OBJECT
public:

    /// Constructor--creates m_listWidget that gets manipulated on mouse events.
    explicit ShotlineGraphicsView(QWidget *parent = 0);

signals:

public slots:

    /// Populate listWidget with items under mouse.
    virtual void mouseMoveEvent(QMouseEvent *event);

    /// Hide the list widget.
    virtual void leaveEvent(QEvent *event);

protected:

    /// List widget displayed on mouse over.
    QListWidget *m_listWidget;
};

#endif // SHOTLINEGRAPHICSVIEW_H
