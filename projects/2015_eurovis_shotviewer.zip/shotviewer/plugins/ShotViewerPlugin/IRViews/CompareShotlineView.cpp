#include "CompareShotlineView.h"
#include "ui_CompareShotlineView.h"

#include <QGraphicsScene>
#include <QVector3D>
#include <QDebug>
#include <QMap>
#include <QSlider>
#include <QScrollBar>
#include <QGraphicsSceneWheelEvent>
#include <QMouseEvent>
#include <QMenu>
#include "IfrHelpers.h"
#include "CompareShotline.h"
#include "ShotlineView.h"
#include "CompareShotlineLabel.h"
#include "IRDocument.h"

CompareShotlineView::CompareShotlineView(QWidget *parent)
    : GraphicsShotlineView(parent)
    , ui(new Ui::CompareShotlineView)
    , m_showPk(false)
{
    ui->setupUi(this);

    // This graphics view will hold the shotlines.
    QGraphicsView *view = ui->compareView;
    view->setVerticalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
    view->setHorizontalScrollBarPolicy(Qt::ScrollBarAlwaysOn);
    view->setRenderHints(QPainter::Antialiasing);
    view->setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Expanding);

    // This scene will display the shotlines.
    QGraphicsScene *scene = new QGraphicsScene(this);
    scene->installEventFilter(this);
    view->setScene(scene);

    // This view will hold the legend for shotlines.
    QGraphicsView *labelView = ui->labelView;
    labelView->setVerticalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
    labelView->setHorizontalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
}

void CompareShotlineView::updateShotlineLabels(float yStride)
{
    IRDocument *model = getDocument();
    QList<int> aimPoints = getDocument()->getAimPoints();

    int w = ui->labelView->width();
    int h = ui->labelView->height();

    QGraphicsScene *labelScene = new QGraphicsScene(this);
    labelScene->setSceneRect(-w/2, -h/2, w, h);
    labelScene->installEventFilter(this);

    // Create a text item that says "aim points"
    QGraphicsTextItem *text = new QGraphicsTextItem("AimPoints");
    QFont font = text->font();
    font.setPointSize(10);
    text->setFont(font);

    // Center the text item in the scene
    float space = w - text->boundingRect().width();
    text->setPos(-w/2 + space/2, -h/2);
    labelScene->addItem(text);

    // Create text items and colored boxes for all aimpoints
    int y = yStride;
    int i = 0;
    foreach (int point, aimPoints) {
        // Create a label group
        QColor color = model->getThreatColor(point);
        CompareShotlineLabel *label = new CompareShotlineLabel(point,
                color,
                font,
                w);
        // Find position of the label group
        float yPos = y - (text->boundingRect().height() / 2);
        yPos = map(yPos, 0, h, -h/2, h/2);
        float leftMargin = w - text->boundingRect().width();
        float xPos = -w/2 + leftMargin;

        labelScene->addItem(label);
        label->setPos(xPos, yPos);

        // Advance to next aim point
        y = y + yStride;
        i = i + 1;
    }

    ui->labelView->setScene(labelScene);
}

void CompareShotlineView::graphicsShotlinesChanged()
{
    IRDocument *model = getDocument();
    QList<int> aimPoints = model->getAimPoints();
    QList<IRShotlineThreat*> threats = model->getThreats();
    clearShotlines();

    // Set the area of the scene to the size of the compareView widget
    int h = ui->compareView->height();

    // -10 is for clean margins around the shotlines
    int w = ui->compareView->width() - 10;

    // Used for computing between shotlines
    int numShotlines = aimPoints.size();
    int stride = h / (numShotlines + 1);

    // Create the scene to hold shotlines.
    QGraphicsScene *scene = ui->compareView->scene();
    scene->clear();
    scene->setSceneRect(-w/2, -h/2, w, h);

    // Find the max t value for all shotlines
    float tMax = model->getTMax();

    int y = stride;
    int i = 0;
    foreach (int point, aimPoints) {
        float yPos = map(y, 0, h, -h/2, h/2);
        CompareShotline *shot;
        float pkWidth = scaleFromSceneToShotline(5.0);
        shot = new CompareShotline(threats.at(i), point, tMax,
                                   model, scene, pkWidth, NULL, this);
        shot->setPos(0, yPos);
        y = y + stride;
        i = i+1;
        addShotline(shot);
    }

    updateShotlineLabels(stride);
}

QGraphicsView *CompareShotlineView::getGraphicsView() const
{
    return ui->compareView;
}

bool CompareShotlineView::eventFilter(QObject *object, QEvent *event)
{
    // Intercept events of child objects to do various functionality.
    // 1. Prevent the compareView's scene from automatically scrolling on wheel
    //      events, instead do zoom.
    // 2. Handle mouse clicks on the labelView's scene for closing aimpoints.

    // 1. Prevent the compareView's scene from automatically scrolling on wheel
    //      events.
    if (object == ui->compareView->scene() &&
        event->type() == QEvent::GraphicsSceneWheel) {

        // Convert event into a wheel event.
        QGraphicsSceneWheelEvent *wheel =
            static_cast<QGraphicsSceneWheelEvent*>(event);

        // Find scale factor based on wheel movement.
        qreal scaleFactor = wheel->delta() > 0 ? 1.25f : 0.8f;

        // Update scene center and scaling.
        ui->compareView->centerOn(wheel->scenePos().x(), 0.0f);
        ui->compareView->scale(scaleFactor, 1.0f);

        // Check that we did not zoom too far out.
        qreal existingScale = ui->compareView->transform().m11();
        if (existingScale < 1.0f) {
            ui->compareView->scale(1.0f / existingScale, 1.0f);
        }

        event->ignore();

        // 2. Handle mouse clicks on the labelView's scene for closing aimpoints.
    } else if (object == ui->labelView->scene()
               && event->type() == QEvent::GraphicsSceneMousePress) {

        QGraphicsSceneMouseEvent *press
            = static_cast<QGraphicsSceneMouseEvent*>(event);

        QList<QGraphicsItem*> items
            = ui->labelView->scene()->items(press->scenePos());

        foreach (QGraphicsItem *item, items) {

            CompareShotlineLabel *label
                = dynamic_cast<CompareShotlineLabel*>(item);

            if (label && label->mouseOverXText(press)) {
                emit(closeAimPoint(label->getAimpoint()));
            }
        }
    } else {
        return false;
    }

    event->accept();
    return true;
}

bool CompareShotlineView::getShowPkGlyphs() const
{
    return m_showPk;
}

void CompareShotlineView::resizeEvent(QResizeEvent *event)
{
    graphicsShotlinesChanged();
    QWidget::resizeEvent(event);
}

void CompareShotlineView::paintEvent(QPaintEvent *event)
{
    QWidget::paintEvent(event);
}

void CompareShotlineView::setShowPkGlyphs(bool value)
{
    m_showPk = value;
    updateShotlines();
}

QList<QMenu *> CompareShotlineView::createMenus()
{
    // Let the base classes create any menus.
    QList<QMenu*> menus = GraphicsShotlineView::createMenus();

    // Create menu for this.
    QMenu *menu = new QMenu("Graphics", this);

    // There are two types of actions here: actions which impact only this, and
    // actions that impact other views.

    // The show pk checkable action only changes this, so we connect it to one
    // of this's slots.
    QAction *action = menu->addAction("Show Pk in Compare View",
                                      this, SLOT(setShowPkGlyphs(bool)));
    action->setCheckable(true);

    // Actions which change other views will be connected to the data model.
    IRDocument *irDoc = (IRDocument*) m_appDoc;
    menu->addAction("Select Pk Colors", irDoc, SLOT(showPkColorMapDialog()));
    menu->addSeparator();

    action = menu->addAction("Use wtLos", (IRDocument*) m_appDoc,
                             SLOT(setUseWtLos(bool)));
    action->setCheckable(true);

    menus.push_back(menu);

    return menus;
}

void CompareShotlineView::attachDocument(ApplicationDocument *doc)
{
    GraphicsShotlineView::attachDocument(doc);

    if(dynamic_cast<IRDocument*>(doc)) {
        // draw shotlines and labels
        graphicsShotlinesChanged();

        QString fileName = doc->getCurrentOpenFileName();
        QStringList s = fileName.split("/");
        fileName = s[s.size()-1];

        setWindowTitle("Compare Shotline View - " + fileName);
    }
}
