#include "TableHighlightDelegate.h"

#include <QPainter>

TableHighlightDelegate::TableHighlightDelegate(QObject *parent)
    : QStyledItemDelegate(parent)
{
    // no op
}

void TableHighlightDelegate::paint(QPainter *painter, const QStyleOptionViewItem &option, const QModelIndex &index) const
{
    // Paint the rest of this item using the default delegate
    QStyledItemDelegate::paint(painter, option, index);

    // Cache a pen for restoring painter state.
    QPen cachedPen = painter->pen();

    // New pen is bolded.
    QPen newPen = painter->pen();
    newPen.setWidthF(3.0f);
    newPen.setColor(Qt::black);
    painter->setPen(newPen);
    float newPenWidth = newPen.widthF() / 2.0f;

    // Draw boundary.
    const QRect rect(option.rect);
    painter->drawLine( rect.topLeft().x(), rect.topLeft().y() + newPenWidth,
                       rect.topRight().x(), rect.topRight().y() + newPenWidth);
    painter->drawLine( rect.bottomLeft().x(), rect.bottomLeft().y() - newPenWidth,
                       rect.bottomRight().x(), rect.bottomRight().y() - newPenWidth);

    // Draw left edge of left-most cell
    if (index.column() == 0) {
        painter->drawLine(rect.topLeft(), rect.bottomLeft());
    }

    // Draw right edge of right-most cell
    if (index.column() == index.model()->columnCount() - 1) {
        painter->drawLine( rect.topRight(), rect.bottomRight());
    }

    painter->setPen(cachedPen);
}
