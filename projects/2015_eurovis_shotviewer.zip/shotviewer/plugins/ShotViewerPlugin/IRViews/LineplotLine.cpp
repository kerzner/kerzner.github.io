#include "LineplotLine.h"

#include <QColor>
#include <QGraphicsScene>
#include <QDebug>
#include <QPainter>
#include <QGraphicsLineItem>
#include <QVariant>
#include <QGraphicsSceneHoverEvent>

#include "SegmentLineItem.h"

LineplotLine::LineplotLine(const IRShotlineThreat *threat,
                           QList<float> xList,
                           QList<float> yList,
                           QColor color,
                           int aimPoint,
                           LineplotShotlineView *view,
                           QGraphicsItem *parent)
    :GraphicsShotline(aimPoint, view, parent)
    ,m_hovered(false)
    ,m_defaultPen(QPen())
{
    float defaultPenWidth = 4.0f;
    m_defaultPen.setWidth(defaultPenWidth);
    m_defaultPen.setColor(color);

    for (int i = 0; i < yList.size() - 1; i++) {

        // Line item for this trace
        QGraphicsLineItem *line = new QGraphicsLineItem(xList[i], yList[i],
                xList[i+1], yList[i+1]);
        line->setPen(m_defaultPen);

        // Segment line item holds the line that actually gets drawn.
        // It also handles mouse events for the line.
        SegmentLineItem *segment = new SegmentLineItem();
        segment->setData(Qt::UserRole, QVariant(i));
        segment->setGraphicsShotline(this);
        segment->setName(threat->traces[i]->compName);
        segment->setMainLine(line);

        addToGroup(segment);
    }

    m_defaultDepth = zValue();
    updateShape();
}

void LineplotLine::updateChildrenPenAndDepth(const bool &hovered)
{
    const qreal deltaWidth = 2.0f;
    const qreal deltaDepth = 2.0f;

    // Get all children. (This assumes we only have line items as children).
    QList<QGraphicsItem *> items = childItems();

    // Create a pen with new width.

    // Update pens for all items.
    foreach (QGraphicsItem *item, items) {
        QGraphicsLineItem *line = ((SegmentLineItem *) item)->getLine();
        QPen pen = line->pen();
        if (m_hovered) {
            pen.setWidthF(m_defaultPen.widthF() + deltaWidth);
        } else {
            pen = m_defaultPen;
        }
        line->setPen(pen);
    }

    // Update depth and redraw.
    setZValue(m_defaultDepth + hovered ? deltaDepth : 0.0f);
    update();
}

void LineplotLine::updateShape()
{
    QPainterPath path;

    // Add all child items to the painter path
    QList<QGraphicsItem *> items = childItems();
    QGraphicsLineItem *line = 0;
    foreach (QGraphicsItem *item, items) {
        line = ((SegmentLineItem *) item)->getLine();
        path.moveTo(QPointF(line->line().x1(), line->line().y1()));
        path.lineTo(QPointF(line->line().x2(), line->line().y2()));
        path.closeSubpath();
    }

    if (!line) {
        return;
    }

    // Set PainterPath width to the same as the lines
    QPainterPathStroker stroker;
    stroker.setWidth(line->pen().width());
    m_painterPath = stroker.createStroke(path);
}

QPainterPath LineplotLine::shape() const
{
    return m_painterPath;
}

void LineplotLine::setMouseHoverAimPoint(const int &aimPoint)
{
    // If the aimpoint is the same as this line, then make this line
    // more salient (same as when mouse is hovering on it).
    if (!m_hovered && aimPoint == m_aimPoint) {
        m_hovered = true;
        // Otherwise, if the mouse is hovering over some other line
        // (or no line at all) then make this line less salient.
    } else if (m_hovered && aimPoint != m_aimPoint) {
        m_hovered = false;
    }
    updateChildrenPenAndDepth(m_hovered);
}

