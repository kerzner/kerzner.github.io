#ifndef SEGMENTLINEITEM_H
#define SEGMENTLINEITEM_H

#include "SegmentItemGroup.h"

#include <QPen>

class QGraphicsLineItem;

/** This class contains a QGraphicsLineItem which is used to show one trace
 * along a LineplotShotline.
 *
 * This implements the setHighlighting method of SegmentItemGroup, allowing the
 * GraphicsShotline to highlight individual components.
 */
class SegmentLineItem : public SegmentItemGroup
{
public:

    /// Constructor.
    SegmentLineItem();

    /// Main line item responds to mouse over and highlight events.
    void setMainLine(QGraphicsLineItem *line);

    /// Pen used to draw the main line.
    void setDefaultPen(QPen pen);

    /// Toggle highlighting.
    virtual void setHighlighting(const bool &highlight);

    /// Return the main line.
    QGraphicsLineItem *getLine() const;

private:

    /// Main line item.
    QGraphicsLineItem *m_line;

    /// Default pen for drawing the line.
    QPen m_defaultPen;
};

#endif // SEGMENTLINEITEM_H
