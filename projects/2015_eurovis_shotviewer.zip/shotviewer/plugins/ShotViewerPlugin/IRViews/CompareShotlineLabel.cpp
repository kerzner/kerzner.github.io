#include "CompareShotlineLabel.h"

#include <QGraphicsScene>
#include <QGraphicsTextItem>
#include <QGraphicsSceneMouseEvent>
#include <QMouseEvent>
#include <QDebug>

CompareShotlineLabel::CompareShotlineLabel(int aimPoint,
        QColor color,
        QFont font,
        int sceneWidth)
    : QGraphicsItemGroup()
    , m_aimPoint(aimPoint)
{
    // Create text box for this label
    QGraphicsTextItem *text = new QGraphicsTextItem(QString::number(aimPoint));
    text->setFont(font);

    // Align this text box against the right side of the scene
    float space = sceneWidth - text->boundingRect().width();
    text->setPos((space + (sceneWidth/4)) / 2, 0);

    // vSize is the height of the legend box
    float vSize = text->boundingRect().height();
    QGraphicsRectItem *rectangle = new QGraphicsRectItem(0, 0, sceneWidth/4, vSize);
    rectangle->setBrush(QBrush(color));
    rectangle->setPos(0, 0);

    m_xText = new QGraphicsTextItem("x");
    m_xText->setFont(font);
    m_xText->setPos(sceneWidth - m_xText->boundingRect().width(), 0);
    m_xText->setVisible(false);

    // Add items to the group
    addToGroup(text);
    addToGroup(rectangle);
    addToGroup(m_xText);

    setHandlesChildEvents(true);
    setAcceptTouchEvents(false);
}

void CompareShotlineLabel::hoverEnterEvent(QGraphicsSceneHoverEvent *event)
{
    Q_UNUSED(event);
    m_xText->setVisible(true);
}

void CompareShotlineLabel::hoverLeaveEvent(QGraphicsSceneHoverEvent *event)
{
    Q_UNUSED(event);
    m_xText->setVisible(false);
}

bool CompareShotlineLabel::mouseOverXText(QGraphicsSceneMouseEvent *event)
{
    QPointF mousePosition = event->scenePos();
    QRectF rectangle = QRectF(mousePosition.x(), mousePosition.y(), 1, 1);
    return m_xText->sceneBoundingRect().intersects(rectangle);
}
