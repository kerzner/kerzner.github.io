#ifndef TABLESHOTLINEVIEW_H
#define TABLESHOTLINEVIEW_H

#include <QWidget>

#include "IrData.h"
#include "ShotlineView.h"

/** This class displays the loaded aim point in a set of TableShotlines. Each
 * TableShotline represents a single aim point.
 *
 * Just like other ShotlineViews, this class uses the setMouseHoverHighlight
 * slot to update its highlighting.
 */
class TableShotlineView : public ShotlineView
{
    Q_OBJECT
public:
    /// Constructor.
    explicit TableShotlineView(QWidget *parent = 0);

    /// Recursively deletes this layout and all of its children.
    void clearLayout(QLayout *layout, bool deleteWidgets = true);

public slots:

    /// Create TableShotlines for all the shotlines.
    virtual void updateShotlines();

    /// Updates the columns that are visibile.
    void setVisibleColumns(const QStringList &);

    /// The initial columns are those which are visible when updateShotlines()
    //      gets called.
    void setInitialColumns(const QStringList &);

    /// Returns a list of columns currently visible.
    QStringList getVisibleColumns() const;

    /// Rearrange columns of TableShotline. This ensures that the column
    ///     ordering of all TableShotlines remains consistent.
    void sectionMoved(int, int, int);

    /// Sometimes the TableShotlines do not correctly register mouse move
    ///     events. This passes mouse move events to chilren.
    ///     TODO: Figure out why this is necessary. It shouldn't be.
    void mouseMoveEvent(QMouseEvent *event);

    /// Updates the highlighting of components in the TableShotlineViews
    /// by making the text in certain rows bold.
    virtual void setMouseHoverHighlight(const QMap<int, QList<int> > &,
                                        const int &,
                                        const bool &,
                                        const int &);

private slots:

    /// The use selected a column that they want to see in the tables. Make
    /// that column visible in all children.
    void tableMenuSelectionChanged();

private:

    // Private functions //////////////////////////////////////////////////////

    /// Create menu items for the camera to be inserted in MainWindow's menus
    QList<QMenu*> createMenus();

    /// Update the table menu to match the current selection.
    void updateTableMenu(QStringList &allColumns,
                         QStringList &currentColumns);

    /// Attach an IRDocument, otherwise does nothing
    void attachDocument(ApplicationDocument *doc);

    // Private data members ///////////////////////////////////////////////////

    /// This is to prevent an infinite loop when rearranging column headers.
    bool m_ignoreSectionMoved;

    /// Keep a pointer to this view's menu to be able to update the checked
    /// state of its items.
    QMenu *m_menu;

    /// List of columns that should be displayed on startup.
    QStringList m_initialColumns;
    QStringList m_visibleColumns;
};
#endif // TABLESHOTLINEVIEW_H
