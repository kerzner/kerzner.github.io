#include "IRDocument.h"

#include <QInputDialog>
#include <QDebug>
#include <limits>
#include <QMessageBox>

#include "IrData.h"
#include "IfrParser.h"
#include "IfrHelpers.h"
#include "IRDocument.h"
#include "ColorMapBuilder.h"
#include "ShotlineDialog.h"

// #define IRDOCUMENT_DEBUG 1
// #define IRDOCUMENT_DEBUG_FUNCTIONS 1
#if defined(IRDOCUMENT_DEBUG_FUNCTIONS)
#define FUNCTION_DEBUG(x) { qDebug() << Q_FUNC_INFO; }
#else
#define FUNCTION_DEBUG(x)
#endif // defined(IRDOCUMENT_DEBUG_FUNCTIONS)


IRDocument::IRDocument(QObject *parent)
    : ApplicationDocument(parent)
    , m_irFile(0)
    , m_threatName(QRegExp("SCJ"))
    , m_qualifier("")
    , m_threatMap(new QMap<int, IRShotlineThreat*>())
    , m_threatColors(new QMap<int, QColor>())
    , m_threatPks(new QMap<int, QList<float> >())
    , m_useWtLos(false)
{
    m_standardColors.append(QColor(55, 126, 184));
    m_standardColors.append(QColor(77, 175, 74));
    m_standardColors.append(QColor(152, 78, 163));
    m_standardColors.append(QColor(255, 127, 0));
    m_standardColors.append(QColor(255, 255, 51));
}

IRDocument::IRDocument(const QList<int>& initialAimPoints,
                       QString threatName,
                       QObject *parent)
    : ApplicationDocument(parent)
    , m_irFile(0)
    , m_threatName(threatName.isEmpty() ? QRegExp("SCJ") : QRegExp(threatName))
    , m_qualifier("")
    , m_threatMap(new QMap<int, IRShotlineThreat*>())
    , m_threatColors(new QMap<int, QColor>())
    , m_threatPks(new QMap<int, QList<float> >())
    , m_useWtLos(false)
{
    m_standardColors.append(QColor(55, 126, 184));
    m_standardColors.append(QColor(77, 175, 74));
    m_standardColors.append(QColor(152, 78, 163));
    m_standardColors.append(QColor(255, 127, 0));
    m_standardColors.append(QColor(255, 255, 51));

    m_aimPoints = initialAimPoints;
}

IRDocument::~IRDocument()
{
    delete m_threatMap;
    delete m_threatColors;
    delete m_threatPks;
}

const IRShotlineThreat *IRDocument::getThreat(int aimPoint) const
{
    return m_threatMap->value(aimPoint);
}

QList<IRShotlineThreat*> IRDocument::getThreats() const
{
    return m_threatMap->values();
}

QList<int> IRDocument::getAimPoints() const
{
    return m_threatMap->keys();
}

QStringList IRDocument::getAimPointsAsStringList() const
{
    QStringList aimPoints;
    foreach (int aimPoint, m_aimPoints)
        aimPoints.append(QString::number(aimPoint));
    return aimPoints;
}

QColor IRDocument::getThreatColor(int aimPoint) const
{
    return m_threatColors->value(aimPoint);
}

QList<float> IRDocument::getPkList(int aimPoint) const
{
    return m_threatPks->value(aimPoint);
}

QList<QPointF> IRDocument::getTList(int aimPoint) const
{
    // point.x = trace start
    // point.y = trace thickness
    QList<QPointF> tList;

    // This is the end of the previous interval. If we are not messing with the
    // interval thickness then prevT is equal to the entry of the current trace.
    float prevT = 0.0f;

    const IRShotlineThreat *threat = getThreat(aimPoint);
    foreach (IRTrace *trace, threat->traces) {
        QPointF interval;

        // Which thickness are we using?
        float los = m_useWtLos ? trace->geom.wtLos : trace->geom.los;

        interval.setX(prevT);
        interval.setY(los);
        tList.append(interval);

        prevT = prevT + los;
    }

    return tList;
}

QMap<QString, float> IRDocument::getDamagedComponentsFromShotline(const int &aimPoint) const
{
    QMap<QString, float> damagedComps;

    // Loop over all shotlines in the irFile.
    // TODO: Why are we not using the threatMap here?
    foreach(IRShotline *shotline, m_irFile->views.front()->shotlines) {

        // Is this the aimPoint we're looking for?
        if (shotline->aimPointIndex == aimPoint) {

            // Get all damaged components from the SA line.
            // This grabs spall damage as well, if it's in the IR file.
            QMap<QString, QString>::iterator itr;
            QMap<QString, QString> summary = shotline->summaryAssessment;

            for (itr = summary.begin(); itr != summary.end(); itr++) {

                QString qualifiedName = itr.key();

                // Hack for adding fake qualifiers to IR files.
// #define IRDOCUMENT_USE_FAKE_QUALIFIERS 1
#if defined(IRDOCUMENT_USE_FAKE_QUALIFIERS)
                qualifiedName.append("[pk_main]");
#endif // defined(IRDOCUMENT_USE_FAKE_QUALIFIERS)
                if (qualifiedName.contains(m_qualifier)) {
                    damagedComps[qualifiedName] = itr.value().remove("(pk)").toFloat();
                }
            }
        }
    }
    return damagedComps;
}

void IRDocument::showPkColorMapDialog() const
{
    m_colorMapBuilder->show();
}

QList<float> IRDocument::getThreatParameterRange(const QString &name) const
{
    float minValue = std::numeric_limits<float>::max();
    float maxValue = std::numeric_limits<float>::min();

    // For each aimpoint...
    QMap<int, IRShotlineThreat*>::const_iterator itr;
    for (itr = m_threatMap->begin(); itr != m_threatMap->end(); ++itr) {
        foreach (IRTrace *trace, (*itr)->traces) {
            foreach (IRThreatPacket *packet, trace->threatPackets) {
                /// Get the variant from the threat packet...
                QVariant v = packet->parameterList[name];
                if (v.isValid()) {
                    float value = v.toFloat();
                    minValue = value < minValue ? value : minValue;
                    maxValue = value > maxValue ? value : maxValue;
                }
            }
        }
    }

    QList<float> values;
    values.append(minValue);
    values.append(maxValue);
    return values;
}

QMap<int, QList<float> > IRDocument::getThreatParameterValues(const QString &name) const
{
    // keys = aim points
    // values = list of parameter[name]'s values
    QMap<int, QList<float> > map;

    QMap<int, IRShotlineThreat*>::const_iterator itr;
    for (itr = m_threatMap->begin(); itr != m_threatMap->end(); ++itr) {
        QList<float> values;
        foreach (IRTrace *trace, (*itr)->traces) {
            foreach (IRThreatPacket *packet, trace->threatPackets) {
                QVariant v = packet->parameterList[name];
                if (v.isValid()) {
                    values.append(v.toFloat());
                }
            }
        }
        map.insert(itr.key(), values);
    }

    return map;
}

QMap<int, QList<int> > IRDocument::getTracesInInterval(const float &x0,
        const float &x1) const
{
    // keys = aim points
    // values = index to shotTraces
    QMap<int, QList<int> > map;

    QMap<int, IRShotlineThreat*>::const_iterator itr;
    for (itr = m_threatMap->begin(); itr != m_threatMap->end(); ++itr) {

        QList<int> traceList;

        // If the interval overlaps with (x0,x1) then add it to the list.
        QList<QPointF> tList = getTList(itr.key());
        for (int i = 0; i < tList.size(); i++) {
            QPointF interval = tList[i];
            float traceStart = interval.x();
            float traceEnd = traceStart + interval.y();
            if (traceStart <= x1 && x0 <= traceEnd) {
                traceList.append(i);
            }
        }

        if (!traceList.isEmpty()) {
            map.insert(itr.key(), traceList);
        }
    }

    return map;
}

QStringList IRDocument::getAvailableAimPoints() const
{
    QStringList aimPoints;
    foreach (IRView *view, m_irFile->views) {
        aimPoints.append(getAimPointsInView(view));
    }
    return aimPoints;
}

QStringList IRDocument::getAvailableQualifiers() const
{
    QStringList qualifiers;
    foreach (IRView *view, m_irFile->views) {
        foreach (IRShotline *shotline, view->shotlines) {

            QMap<QString, QString> &sa = shotline->summaryAssessment;
            QMap<QString, QString>::const_iterator itr;

            for (itr = sa.begin(); itr != sa.end(); ++itr) {
                QString qualifier = getQualifier(itr.key());
                if (!qualifier.isEmpty() && !qualifiers.contains(qualifier)) {
                    qualifiers.append(qualifier);
                }
            }
        }
    }
    return qualifiers;
}

QStringList IRDocument::getAvailableThreatNames() const
{
    QStringList threatTypes;
    foreach (IRView *view, m_irFile->views) {
        foreach (IRShotline *shotline, view->shotlines) {
            foreach(IRShotTrace *trace, shotline->shotTraces) {
                foreach (IRShotlineThreat *threat, trace->threatList) {
                    if (!threatTypes.contains(threat->name)) {
                        threatTypes.append(threat->name);
                    }
                }
            }
        }
    }
    return threatTypes;
}

QMap<int, QList<int> > IRDocument::getCommonTraceIndexes(const int &aimPoint, const int &traceIdx) const
{
    FUNCTION_DEBUG();

    // keys = aimPoints.
    // values = list of traceIndexes with the same name of trace #traceIdx
    //  along the shotline defined by aimPoint.
    QMap<int, QList<int> > map;

    // Name of the shot component.
    QString componentName = "";
    if (traceIdx != -1) {
        componentName = m_threatMap->value(aimPoint)->traces[traceIdx]->compName;
    }

#if defined(IRDOCUMENT_DEBUG)
    qDebug() << "-aimPoint:" << aimPoint;
    qDebug() << "-componentId:" << component;
    qDebug() << "-componentName:" << componentName;
#endif // defiend IRDOCUMENT_DEBUG

    // Loop over all loaded threats...
    QMap<int, IRShotlineThreat*>::const_iterator itr;
    for (itr = m_threatMap->begin(); itr != m_threatMap->end(); ++itr) {

        // Per-aimpoint list of traces that need to be higlighted.
        QList<int> traceList;

        // Trace that we're currently looking at.
        int currentTraceIdx= 0;

        // Compare traces by name...
        QList<IRTrace*> & traces = itr.value()->traces;
        foreach (IRTrace *trace, traces) {
            QString traceName = trace->compName;
            if (traceName == componentName) {
                // We found a match, add it to the list.
                traceList.append(currentTraceIdx);
            }
            currentTraceIdx++;
        }

        // Done with this aimPoint.
        map.insert(itr.key(), traceList);
    }
#if defined(IRDOCUMENT_DEBUG)
    qDebug() << "-final map:" << map;
#endif // defined(IRDOCUMENT_DEBUG)
    return map;
}

QMap<int, QList<int> > IRDocument::getCommonTraceIndexes(const QString &componentName) const
{
    // keys = aimPoints
    // values = list of trace indexes
    QMap<int, QList<int> > map;

    QMap<int, IRShotlineThreat*>::const_iterator itr;
    for (itr = m_threatMap->begin(); itr != m_threatMap->end(); ++itr) {

        // Traces with matches name along this shotline
        QList<int> traceList;

        // If the trace name matches component then add it to the list.
        QList<IRTrace*> & traces = itr.value()->traces;
        int traceIdx = 0;
        foreach (IRTrace *trace, traces) {
            QString traceName = trace->compName;
            if (traceName == componentName) {
                traceList.append(traceIdx);
            }
            traceIdx++;
        }

        map.insert(itr.key(), traceList);
    }
    return map;
}

QString IRDocument::getComponentName(const int &aimPoint, const int &traceIdx) const
{
    return m_threatMap->value(aimPoint)->traces[traceIdx]->compName;
}

QStringList IRDocument::getComponentNames(const QMap<int, QList<int> > &map) const
{
    QStringList componentNames;

    // Loop over all shotlines passed in.
    QMap<int, QList<int> >::const_iterator itr;
    for (itr = map.begin(); itr != map.end(); ++itr) {
        int aimPoint = itr.key();

        // Loop over all components on this shotline.
        QList<int> traceIdxs = itr.value();
        foreach (int traceIdx, traceIdxs) {

            // Get the component name and clean it up.
            QString name = m_threatMap->value(aimPoint)->traces[traceIdx]->compName;

            // Component names should be a list of unique names.
            if (!componentNames.contains(name)) {
                componentNames << name;
            }
        }
    }

    return componentNames;
}

QStringList IRDocument::getComponentNames() const
{
    QStringList componentNames;

    // Loop over all shotlines.
    QMap<int, IRShotlineThreat*>::const_iterator itr;
    for (itr = m_threatMap->begin(); itr != m_threatMap->end(); ++itr) {
        componentNames << getComponentNames(itr.key());
    }

    // Clean up.
    componentNames.removeDuplicates();

    return componentNames;
}

QStringList IRDocument::getComponentNames(const int &aimPoint) const
{
    QStringList componentNames;
    const IRShotlineThreat *threat = m_threatMap->value(aimPoint);
    const QList<IRTrace*> &traces = threat->traces;
    for (int component = 0; component < traces.size(); component++) {
        const IRTrace *trace = traces.at(component);

        // Hanlde paks
        if (trace->isVirtual) {
            foreach (const IRSubTraceGeometry *subTrace, trace->geom.subTraces) {
                if (!componentNames.contains(subTrace->name)) {
                    componentNames << subTrace->name;
                }
            }
        }

        // Get the component name
        QString name = trace->compName;
        if (!componentNames.contains(name)) {
            componentNames << name;
        }

    }
    return componentNames;
}

void IRDocument::setUseWtLos(bool value)
{
    FUNCTION_DEBUG();
    m_useWtLos = value;
    updateTMax();
    emit(changeAllShotlines());
}

void IRDocument::closeAimPoint(const int &aimPoint)
{
    FUNCTION_DEBUG();
    // Do not allow the user to close all aimpoints.
    if (m_threatMap->size() == 1) {
        QString message;
        message = "AimPoint must remain open as I cannot close all AimPoints.";
        emit(warningDialog(message));
        return;
    }

    m_threatMap->remove(aimPoint);
    m_threatPks->remove(aimPoint);
    m_threatColors->remove(aimPoint);

    emit(changeAllShotlines());
}

void IRDocument::updateTMax()
{
    FUNCTION_DEBUG();

    // Reset state.
    m_tMax = 0.0f;

    // Find the longest shotline.
    QMap<int, IRShotlineThreat*>::const_iterator itr;
    for (itr = m_threatMap->begin(); itr != m_threatMap->end(); ++itr) {
        const QList<QPointF> tList = getTList(itr.key());
        float maxT = tList.last().x() + tList.last().y();
        if (m_tMax < maxT) {
            m_tMax = maxT;
        }
    }
}

void IRDocument::setThreatName(const QRegExp &regExp)
{
    FUNCTION_DEBUG();
    m_threatName = regExp;
}

void IRDocument::setPkColorMap(ColorMap *colorMap)
{
    FUNCTION_DEBUG();
    m_pkColorMap = colorMap;
    emit(changeAllShotlines());
}

void IRDocument::setCurrentQualifier(const QString &qualifier)
{
    FUNCTION_DEBUG();
    m_qualifier = qualifier;
}

void IRDocument::updateThreatPks()
{
    FUNCTION_DEBUG();

    m_threatPks->clear();

    // Loop over all shotlines in the irFile.
    foreach(IRShotline *shotline, m_irFile->views.front()->shotlines) {

        // Loop over all threats that we've loaded.
        QMap<int, IRShotlineThreat*>::iterator threatItr;
        for (threatItr = m_threatMap->begin(); threatItr!= m_threatMap->end();
             ++threatItr) {

            // If the shotline's aimPoint is not the same as threat's aimPoint
            // the continue looking for threats.
            int aimPoint = threatItr.key();
            if (shotline->aimPointIndex != aimPoint) {
                continue;
            }

            // If we've already loaded pK values for this threat then continue.
            if (m_threatPks->contains(aimPoint)) {
                continue;
            }

            // SA: line that contains all pK values.
            QMap<QString, QString> summary = shotline->summaryAssessment;

            // pK list that we will populate
            QList<float> pkList;

            // Loop over all traces in the threat
            IRShotlineThreat *threat = threatItr.value();
            foreach (IRTrace *trace, threat->traces) {
                bool found = false;

                // IR parser wraps SA items in quotes
                QString qualifiedCompName = trace->compName;
                qualifiedCompName.append(m_qualifier);

                // Loop over all entires in the SA line looking for a qualified
                // name that matches current component name.
                QMap<QString, QString>::iterator itr;
                for (itr = summary.begin(); itr != summary.end(); itr++) {
                    if (itr.key().contains(qualifiedCompName)) {
                        pkList.append((itr.value().remove("(pk)")).toFloat());
                        found = true;
                    }
                }

                // No pk specified will have value of -1.
                if (!found) {
                    pkList.append(-1.0f);
                }
            }
            m_threatPks->insert(aimPoint, pkList);
        }
    }
}

void IRDocument::showAimPointDialog()
{
    FUNCTION_DEBUG();
#if 0
    // Enfore a max number of aimpoints open at a time.
    if (m_threatMap->values().size() == 4) {
        QString message = QString("Cannot open more than four AimPoints");
        emit warningDialog(message);
        return;
    }

    // Ask the user for an aimpoint to open.
    QStringList aimPoints = getAimPointsInView(m_irFile->views.front());
    bool ok = false;
    int aimPoint = QInputDialog::getItem(0, "Open AimPoint", "AimPoint:",
                                         aimPoints, 0, true, &ok).toInt();

    // If the user pressed cancel then do nothing.
    if (!ok) {
        return;
    }

    // If the aimpoint is already open then do nothing.
    if (m_threatMap->contains(aimPoint)) {
        QString message = QString("Aimpoint: ") + QString::number(aimPoint) +
                          QString(" is already open.");
        emit warningDialog(message);
        return;
    }

    // Try to open the aimpoint.
    if (loadAimPoint(aimPoint)) {
        updateThreatPks();
        emit(changeAllShotlines());
    } else {
        QString message;
        message = "Could not find AimPoint: " + QString::number(aimPoint);
        emit warningDialog(message);
    }
#else
    // Show the shotline dialog and get aimPoints
    ShotlineDialog dialog(getAvailableAimPoints(),
                          getAvailableThreatNames(),
                          getAvailableQualifiers());

    dialog.setDefaultAimpoints(getAimPointsAsStringList());
    dialog.setDefaultQualifier(m_qualifier);
    dialog.setDefaultThreat(m_threatName.pattern());

    if (dialog.exec()) {
        setCurrentQualifier(dialog.getQualifier());
        setThreatName(QRegExp(dialog.getThreat()));

        QStringList aimPoints = dialog.getAimpoints();

        m_aimPoints.clear();

        foreach (QString aimPoint, aimPoints) {
            m_aimPoints.append(aimPoint.toInt());
        }
        m_threatMap->clear();
        m_threatPks->clear();

        updateLoadedAimPoints();
    }
#endif
}

bool IRDocument::loadAimPoint(int aimPoint)
{
    FUNCTION_DEBUG();
    IRShotline *shotline = NULL;
    IRView *irView = m_irFile->views.at(0);

    // Search the irFile for shotlines with this aimpoint
    foreach (IRShotline *shot, irView->shotlines) {
        if (shot->aimPointIndex == aimPoint) {
            shotline = shot;
            break;
        }
    }

    if (!shotline) {
        return false;
    }

    // Pull out the threat we're interested in.
    bool found = false;
    foreach (IRShotlineThreat *t, shotline->shotTraces[0]->threatList) {
        if (t->name.contains(m_threatName)) {
            found = true;
            // If this threat actually hit something then we will show it.
            if (!t->traces.isEmpty()) {
                if (m_threatMap->contains(aimPoint)) {
                    m_threatMap->remove(aimPoint);
                }
                m_threatMap->insert(aimPoint, t);
            }
        }
    }

    if (!found) {
        return false;
    }

    foreach(QColor color, m_standardColors) {
        if (!m_threatColors->values().contains(color)
            && !m_threatColors->keys().contains(aimPoint)) {
            m_threatColors->insert(aimPoint, color);
        }
    }

    return true;
}

void IRDocument::updateLoadedAimPoints()
{
    FUNCTION_DEBUG();

    m_threatMap->clear();

    QStringList failedAimPoints;
    foreach (int aimPoint, m_aimPoints) {
        if (!loadAimPoint(aimPoint)) {
            failedAimPoints.append(QString::number(aimPoint));
            m_aimPoints.removeAt(m_aimPoints.indexOf(aimPoint));
        }
    }

    if (!failedAimPoints.isEmpty()) {

        QString failed;
        for (int i = 0; i < failedAimPoints.size() - 1; i++) {
            failed.append(failedAimPoints.at(i) + ", ");
        }
        failed.append(failedAimPoints.last());

        QMessageBox box;
        box.setText("I could not find aim point(s):" + failed + "\n" +
                    "I searched for the threat named:" + m_threatName.pattern() + "\n" +
                    "They are being ignored.");
        box.exec();
    }

    updateThreatPks();
    updateTMax();

    emit(changeAllShotlines());
}

bool IRDocument::importFileByName(QString fileName)
{
    IfrParser parser;

    // Parse the input file, emit failure if anything goes wrong
    if(!parser.parse(fileName)) {
        emit fileImportFailed();
        return false;
    }

    // Parse of the IR file was successful, create the IRDocument from it
    m_irFile = parser.getIrFile();
    if (m_aimPoints.isEmpty()) {
        showAimPointDialog();
    } else {
        updateLoadedAimPoints();
        emit changeAllShotlines();
    }

    m_colorMapBuilder = new ColorMapBuilder();
    m_pkColorMap      = m_colorMapBuilder->getCurrentColorMap();

    connect(m_colorMapBuilder, SIGNAL(colorMapSelected(ColorMap*)),
            this, SLOT(setPkColorMap(ColorMap*)));

    m_fileName = fileName;
    return true;
}

void IRDocument::saveFile()
{
    saveFileByName(m_fileName);
}

void IRDocument::saveFileByName(QString /*fileName*/)
{
    /*no-op*/
    emit fileSaveCompleted();
}

QString IRDocument::getDocumentType()
{
    return QString("IR");
}
