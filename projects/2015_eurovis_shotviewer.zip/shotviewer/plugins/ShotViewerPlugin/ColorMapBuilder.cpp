#include "ColorMapBuilder.h"
#include <QColorDialog>
#include <QMessageBox>
#include <QFileDialog>
#include <QTextStream>
#include <QDebug>
#include "ui_ColorMapBuilder.h"

#define COLORMAP_BORDER_WIDTH 2

ColorMapBuilder::ColorMapBuilder(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::ColorMapBuilder)
{
    ui->setupUi(this);
    QColor black(0, 0, 0);
    QColor red(255, 0, 0);
    QColor green(0, 255, 0);
    QColor yellow(255, 255, 0);
    QColor white(255, 255, 255);

    QList<QColor> colors;

    //Black body
    colors.append(black);
    colors.append(red);
    colors.append(yellow);
    colors.append(white);
    ColorMap *blackBody = new ColorMap(this, true, false, false, colors,
                                       "Black Body");

    insertColorMap(blackBody);

    //Red Gradiant
    colors.clear();
    colors.append(black);
    colors.append(red);
    ColorMap *redGradient = new ColorMap(this, true, false, false, colors,
                                         "Red Gradient");

    insertColorMap(redGradient);

    //Green Yellow Red
    colors.clear();
    colors.append(green);
    colors.append(yellow);
    colors.append(red);
    ColorMap *greenYellowRed = new ColorMap(this, true, false, false, colors,
                                            "Green Yellow Red");

    insertColorMap(greenYellowRed);

    //Bins
    colors.clear();
    colors.append(QColor("#444196"));
    colors.append(QColor("#4575b4"));
    colors.append(QColor("#91bfdb"));
    colors.append(QColor("#e0f3f8"));
    colors.append(QColor("#ffffbf"));
    colors.append(QColor("#fee090"));
    colors.append(QColor("#fc8d59"));
    colors.append(QColor("#d73027"));
    colors.append(QColor("#ff0000"));
    ColorMap *bins = new ColorMap(this, false, true, true, colors, "Bins");

    insertColorMap(bins);

    colors.clear();
    colors.append("#fee5d9");
    colors.append("#fcae91");
    colors.append("#fb6a4a");
    colors.append("#de2d26");
    colors.append("#a50f15");
    ColorMap *basic = new ColorMap(this, true, false, false, colors, "Default");
    insertColorMap(basic);
    ui->colorMaps->setCurrentIndex(m_colorMaps.size() - 1);

    connect(ui->newColorMap, SIGNAL(clicked()), this, SLOT(insertColorMap()));
    connect(ui->colorMaps, SIGNAL(editTextChanged(QString)),
            this, SLOT(setColorMapName(QString)));

    //Needed so resizing works correctly
    ui->colorMap->setSizePolicy(QSizePolicy::Ignored, QSizePolicy::Ignored);
}

ColorMapBuilder::~ColorMapBuilder()
{
    delete ui;
}

ColorMap *ColorMapBuilder::getCurrentColorMap()
{
    return m_colorMaps.at(ui->colorMaps->currentIndex());
}

void ColorMapBuilder::insertColorMap(ColorMap *colorMap)
{
    int index = m_colorMaps.count();

    if(!colorMap) {
        //Default to an interpolated color map from black to white
        QList<QColor> colors;
        colors.append(QColor(0, 0, 0));
        colors.append(QColor(255, 255, 255));

        QString name = QString("ColorMap_%1").arg(index);

        colorMap = new ColorMap(this, true, false, false, colors, name);
    }

    m_colorMaps.append(colorMap);
    ui->colorMaps->addItem(colorMap->name());
    ui->colorMaps->setCurrentIndex(ui->colorMaps->count() - 1);
}

void ColorMapBuilder::on_colorMaps_currentIndexChanged(int index)
{
    if(index >= m_colorMaps.count())
        return;

    ColorMap *colorMap = m_colorMaps.at(index);

    if(!colorMap)
        return;

    ui->interpolateColors->setChecked(colorMap->interpolated());
    ui->separateMin->setChecked(colorMap->separateMinColor());
    ui->separateMax->setChecked(colorMap->separateMaxColor());

    //Reset colors combo box to hold the colors of this color map
    ui->colors->clear();
    QList<QColor> colors = colorMap->getColors();

    foreach(QColor color, colors) {
        ui->colors->addItem(color.name());
    }

    ui->colors->addItem("<Append>");

    updateColorMapAndScale(colorMap);
}

void ColorMapBuilder::on_ok_clicked()
{
    hide();
    emit(colorMapSelected(getCurrentColorMap()));
}

void ColorMapBuilder::on_insertColor_clicked()
{
    ColorMap *currentColorMap = getCurrentColorMap();

    QColor color = QColorDialog::getColor();

    if(color.isValid()) {
        int index = ui->colors->currentIndex();

        if(!currentColorMap->insertColor(color, index)) {
            QMessageBox::warning(this, "Insert Color Error",
                                 currentColorMap->errorMessage());
            return;
        }

        QString name = color.name();
        ui->colors->insertItem(index, name, QVariant(color));

        updateColorMapAndScale(currentColorMap);
    }
}

void ColorMapBuilder::on_interpolateColors_clicked(bool checked)
{
    ColorMap *currentColorMap = getCurrentColorMap();

    currentColorMap->setInterpolated(checked);

    updateColorMapAndScale(currentColorMap);
}

void ColorMapBuilder::on_load_clicked()
{
    QString fileName = QFileDialog::getOpenFileName(this, "Load Color Map",
                       qApp->property("lastDir").
                       toString());
    loadFile(fileName);
}

void ColorMapBuilder::loadFile(QString fileName)
{
    if(fileName.isEmpty())
        return;

    QFile file(fileName);

    if(!file.open(QFile::ReadOnly)) {
        QString message = QString("Could not open file %1").arg(fileName);
        QMessageBox::warning(this, "Color Map File Error", message);
        return;
    }

    QString fileText = file.readAll();
    QStringList lines = fileText.split("\n", QString::SkipEmptyParts);

    QString name = lines[0];
    bool interpolated = lines[1] == "true";
    bool separateMinColor = lines[2] == "true";
    bool separateMaxColor = lines[3] == "true";
    QStringList colorStrings = lines[4].split(",", QString::SkipEmptyParts);
    QList<QColor> colors;

    foreach(QString colorString, colorStrings) {
        colors.append(QColor(colorString));
    }

    ColorMap *colorMap = new ColorMap(this, interpolated, separateMinColor,
                                      separateMaxColor, colors, name);
    insertColorMap(colorMap);

    emit (colorMapSelected(getCurrentColorMap()));
}

void ColorMapBuilder::on_removeColor_clicked()
{
    ColorMap *currentColorMap = getCurrentColorMap();

    int index = ui->colors->currentIndex();

    if(!currentColorMap->removeColor(index)) {
        QMessageBox::warning(this, "Remove Color Error",
                             currentColorMap->errorMessage());
        return;
    }

    ui->colors->removeItem(index);

    updateColorMapAndScale(currentColorMap);
}

void ColorMapBuilder::on_save_clicked()
{
    QString fileName = QFileDialog::getSaveFileName(this, "Save Color Map",
                       qApp->property("lastDir").
                       toString());

    if(fileName.isEmpty())
        return;

    QFile file(fileName);

    if(!file.open(QFile::WriteOnly)) {
        QString message = QString("Could not open file %1").arg(fileName);
        QMessageBox::warning(this, "Color Map File Error", message);
        return;
    }

    QTextStream stream(&file);
    QString trueStr = "true";
    QString falseStr = "false";
    ColorMap *currentColorMap = getCurrentColorMap();

    //Get values from the current color map
    QString name = currentColorMap->name();
    bool interpolated = currentColorMap->interpolated();
    bool separateMinColor = currentColorMap->separateMinColor();
    bool separateMaxColor = currentColorMap->separateMaxColor();
    QList<QColor> colors = currentColorMap->getColors();

    //Write them to a text file
    stream << name << "\n";

    if(interpolated)
        stream << trueStr << "\n";
    else
        stream << falseStr << "\n";

    if(separateMinColor)
        stream << trueStr << "\n";
    else
        stream << falseStr << "\n";

    if(separateMaxColor)
        stream << trueStr << "\n";
    else
        stream << falseStr << "\n";

    int colorCount = colors.count();

    for(int i = 0; i < colorCount; i++) {
        if(i == 0)
            stream << colors[i].name();
        else
            stream << "," << colors[i].name();
    }

    file.close();
}

void ColorMapBuilder::on_separateMax_clicked(bool checked)
{
    ColorMap *currentColorMap = getCurrentColorMap();

    if(!currentColorMap->setSeparateMaxColor(checked)) {
        QMessageBox::warning(this, "Color Map Error",
                             currentColorMap->errorMessage());
        ui->separateMax->setChecked(!checked);
        return;
    }

    updateColorMapAndScale(currentColorMap);
}

void ColorMapBuilder::on_separateMin_clicked(bool checked)
{
    ColorMap *currentColorMap = getCurrentColorMap();

    if(!currentColorMap->setSeparateMinColor(checked)) {
        QMessageBox::warning(this, "Color Map Error",
                             currentColorMap->errorMessage());
        ui->separateMin->setChecked(!checked);
        return;
    }

    updateColorMapAndScale(currentColorMap);
}

void ColorMapBuilder::resizeEvent(QResizeEvent *event)
{
    ColorMap *currentColorMap = getCurrentColorMap();

    QWidget::resizeEvent(event);

    updateColorMapAndScale(currentColorMap);
}

void ColorMapBuilder::setColorMapName(QString name)
{
    ColorMap *currentColorMap = getCurrentColorMap();

    currentColorMap->setName(name);
    ui->colorMaps->setItemText(ui->colorMaps->currentIndex(), name);
}

void ColorMapBuilder::showEvent(QShowEvent *event)
{
    QWidget::showEvent(event);

    updateColorMapAndScale();
}

void ColorMapBuilder::updateColorMapAndScale(ColorMap *colorMap)
{
    if(!colorMap)
        colorMap = getCurrentColorMap();

    ui->colorMap->setPixmap(
        QPixmap::fromImage(colorMap->getColorMapImage(
                               ui->colorMap->width() -
                               COLORMAP_BORDER_WIDTH)));

    //The width of the scale image will vary to show the minimum and maximum
    //values on the edges
    ui->scale->setPixmap(
        QPixmap::fromImage(colorMap->getScaleImage(
                               ui->colorMap->width() -
                               COLORMAP_BORDER_WIDTH,
                               palette().background().color())));
}
