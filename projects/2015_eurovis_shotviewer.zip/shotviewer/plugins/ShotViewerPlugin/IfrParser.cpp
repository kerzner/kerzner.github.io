#include "IfrParser.h"

#include <QString>
#include <QFile>
#include <QRegExp>
#include <QDebug>
#include <QStringList>
#include <QProgressDialog>

#include "IrData.h"

IfrParser::IfrParser(QObject *parent)
    : QObject(parent)
    , mostRecentTrace(NULL)
    , mostRecentShotlineThreat(NULL)
{
}

void IfrParser::setNVP(QHash<QString, QVariant> &h, QString str)
{
    QStringList nvp = str.trimmed().split('=');
    if (nvp.size() == 0)
        return;
    else if (nvp.size() == 1)
        h[nvp.at(0)] = true;
    if (nvp.size() == 2) {
        if (nvp.at(1).indexOf(',') == -1) {
            h[nvp.at(0)] = nvp.at(1);
        } else {
            // array of values
            QStringList arrayTokens = nvp.at(1).split(',');
            QList<QVariant> v;

            foreach (QString tok, arrayTokens) {
                v.push_back(tok);
            }
            h[nvp.at(0)] = QVariant(v);
        }
    }
}

int IfrParser::vFunc(const QString s)
{
    double az, el, d1, d2, d3;

    if (sscanf(qPrintable(s), " az %lg el %lg dir < %lg %lg %lg >", &az, &el, &d1, &d2, &d3) != 5) {
        return -1;
    }

    IRView *view = new IRView(az, el, d1, d2, d3);

    bool viewFound = false;

    // Search for view that matches these parameters.
    // This happens when analysts cat together IR files from the same view.
    foreach (IRView *oldView, irFile->views) {
        if (oldView->hasSameAzElDir(*view)) {
            viewFound = true;
            mostRecentView = oldView;
            break;
        }
    }

    if (viewFound) {
        delete view;
    } else {
        irFile->views.push_back(view);
        mostRecentView = view;
    }

    return 0;
}

int IfrParser::apFunc(const QString s)
{
    IRShotline *shotLine = new IRShotline;
    mostRecentView->shotlines.push_back(shotLine);

    QStringList tokens = s.trimmed().split(' ');
    shotLine->aimPointIndex = tokens.at(0).toInt();

    if (tokens.size() == 3 && !tokens.at(1).compare("FP:")) {
        shotLine->firingPointIndex = tokens.at(2).toInt();
    }
    return 0;
}

int IfrParser::bFunc(const QString s)
{
    double x, y, z;
    if (sscanf(qPrintable(s), "%lg %lg %lg", &x, &y, &z) != 3)
        return -1;

    IRShotTrace *trace = new IRShotTrace;

    trace->isBurst = true;
    trace->coords[0] = x;
    trace->coords[1] = y;
    trace->coords[2] = z;

    IRShotline *sl = mostRecentView->shotlines.last();
    sl->shotTraces.push_back(trace);

    return 0;
}

int IfrParser::sFunc(const QString s)
{
    double x, y, a, b;
    if (sscanf(qPrintable(s), "%lg %lg C: %lg %lg", &x, &y, &a, &b) != 4)
        return -1;

    IRShotTrace *trace = new IRShotTrace;

    trace->isBurst = false;
    trace->coords[0] = x;
    trace->coords[1] = y;
    trace->coords[2] = a;
    trace->coords[3] = b;
    IRShotline *sl = mostRecentView->shotlines.last();
    sl->shotTraces.push_back(trace);

    return 0;
}

int IfrParser::stFunc(const QString str)
{
    QString sline = str.trimmed();
    QRegExp stmt("([\\S]+[\\s]+)*\\{([^}]*)\\}");

    if ( stmt.indexIn(sline) == -1) {
        qDebug() << str;
        return -1;
    }
    QRegExp spaces("[\\s]+");
    QStringList preTokens = stmt.cap(1).trimmed().split(spaces);
    QStringList params = stmt.cap(2).trimmed().split(spaces);


    IRShotlineThreat *slt = new IRShotlineThreat;
    IRShotTrace *shotTrace = mostRecentView->shotlines.last()->shotTraces.last();

    shotTrace->threatList.push_back(slt);

    if (preTokens.size() == 2) {
        slt->name = preTokens.at(0);
        slt->shortName = preTokens.at(1);
    } else {
        slt->name = stmt.cap(1).trimmed();
        slt->shortName = preTokens.last();
    }

    for (int i=1 ; i < params.size() ; i++) {
        if (!params.at(i).compare("payload") ||
            !params.at(i).compare("product")) {
            // the = sign is missing
            slt->parameters[params.at(i)] = QVariant(params.at(i+1));
            i++;
        } else {
            setNVP(slt->parameters, params.at(i));
        }
    }

    return 0;
}

int IfrParser::tFunc(const QString s)
{
    stashedQuotedString.clear(); // XXX ugh. wish IR files had reasonable syntax

    static QRegExp spaces("[\\s]+");
    QStringList tokens = s.trimmed().split(spaces);

    IRTrace *trace = new IRTrace;
    mostRecentTrace = trace;

    if (s.indexOf("(virtual component)") != -1) {
        trace->isVirtual = true;
    } else {
        trace->isVirtual = false;
    }

    trace->threatName = tokens.at(0);
    trace->compName   = quotedString(tokens.at(1));

    if (tokens.size() >= 3) {
        trace->material = quotedString(tokens.at(2));
    }

    // need to look through the recent ShotlineThreats to find the right "parent"
    // for thie trace.

    IRShotTrace *shotTrace = mostRecentView->shotlines.last()->shotTraces.last();

    if (!trace->threatName.compare("FLAG") || !trace->threatName.compare("FF")) {
        // just stash with the last one
        if (mostRecentShotlineThreat) {
            mostRecentShotlineThreat->traces.push_back(trace);
        }
    } else {
        foreach (IRShotlineThreat *slt, shotTrace->threatList) {
            if (!slt->shortName.compare(trace->threatName)) {
                mostRecentShotlineThreat = slt;
                slt->traces.push_back(trace);
                goto found;
            }
        }

        qDebug("did not find ShotlineThreat %s", qPrintable(trace->threatName));
        qDebug() << tokens;
        return -1;
found:
        ;
    }
    return 0;
}

int IfrParser::tgFunc(const QString s)
{
    QRegExp p("[^=]+=< ([^ ]+) ([^ ]+) ([^ ]+) >");
    int pos = 0;

    if (p.indexIn(s, pos) == -1)
        return -1;

    IRTraceGeometry *tg = &mostRecentTrace->geom;

    tg->entry[0] = p.cap(1).toDouble();
    tg->entry[1] = p.cap(2).toDouble();
    tg->entry[2] = p.cap(3).toDouble();

    pos += p.cap(0).size();

    if (p.indexIn(s, pos) == -1)
        return -1;

    tg->normal[0] = p.cap(1).toDouble();
    tg->normal[1] = p.cap(2).toDouble();
    tg->normal[2] = p.cap(3).toDouble();

    pos += p.cap(0).size();

    if (p.indexIn(s, pos) == -1)
        return -1;
    tg->dir[0] = p.cap(1).toDouble();
    tg->dir[1] = p.cap(2).toDouble();
    tg->dir[2] = p.cap(3).toDouble();

    pos += p.cap(0).size();

    QString remainder = s.right(s.size() - pos).trimmed();
    if (remainder.size() > 0) {
        int count =
            sscanf(qPrintable(remainder), "los=%lg  norm=%lg  obliq=%lg wtlos=%lg wtnorm=%lg",
                   &tg->los,
                   &tg->norm,
                   &tg->obliq,
                   &tg->wtLos,
                   &tg->wtNorm
                  );
        if (count != 5) {
            qDebug("only saw %d", count);
            return -1;
        }
    }

    return 0;
}

int IfrParser::saFunc(const QString s)
{
    static QRegExp p("[\\s]+");
    QStringList tokens = s.trimmed().split(p);

    QMap<QString, QString> & sa = mostRecentView->shotlines.last()->summaryAssessment;

    foreach (QString tok, tokens) {
        QStringList nvp = tok.split('=');
        if (nvp.size() == 2) {
            // Scrub quotes from component name in SA line.
            QString name = nvp.at(0);
            name.remove("\"");
            sa[name] = nvp.at(1);
        }
    }

    return 0;
}

int IfrParser::tdFunc(QString s)
{
    QRegExp p("([^=]+)=<([^>]+)>");

    if (p.indexIn(s.trimmed()) == -1) {
        return -1;
    }

    IRTraceDamage *td = new IRTraceDamage;

    td->name = p.cap(1);

    static QRegExp spaces("[\\s]+");
    QStringList tokens = p.cap(2).trimmed().split(spaces);

    bool ok;
    double v;
    foreach (QString token, tokens) {
        v = token.toDouble(&ok);
        if (ok) {
            td->values.push_back(v);
        } else {
            return -1;
        }
    }

    mostRecentTrace->traceDamage.push_back(td);
    return 0;
}

int IfrParser::tpFunc(const QString s)
{
    QRegExp p("[\\s]*([\\S]+)\\s([\\S]+)\\s\\{([^}]+)");
    QRegExp spaces("[\\s]+");

    if ( p.indexIn(s) != -1 && p.captureCount() == 3) {
        IRThreatPacket *tp = new IRThreatPacket;

        tp->name = p.cap(1);
        tp->shortName = p.cap(2);

        QStringList tokens = p.cap(3).trimmed().split(spaces);

        foreach (QString token, tokens) {
            setNVP(tp->parameterList, token);
        }
        mostRecentTrace->threatPackets.push_back(tp);
        return 0;
    }

    QRegExp nn("[\\s]*\\{([^}]*)\\}");

    if (nn.indexIn(s) != -1) {
        IRThreatPacket *tp = new IRThreatPacket;
        QStringList tokens = nn.cap(1).trimmed().split(spaces);

        foreach (QString token, tokens) {
            setNVP(tp->parameterList, token);
        }
        mostRecentTrace->threatPackets.push_back(tp);
        return 0;
    }
    return -1;
}

int IfrParser::stgFunc(const QString s)
{

    IRSubTraceGeometry *stg = new IRSubTraceGeometry;

    QRegExp p("[^=]+=< ([^ ]+) ([^ ]+) ([^ ]+) >");
    int pos = 0;

    if (p.indexIn(s, pos) == -1)
        return -1;

    IRTraceGeometry *tg = &mostRecentTrace->geom;

    stg->entry[0] = p.cap(1).toDouble();
    stg->entry[1] = p.cap(2).toDouble();
    stg->entry[2] = p.cap(3).toDouble();

    pos += p.cap(0).size();

    if (p.indexIn(s, pos) == -1)
        return -1;

    stg->normal[0] = p.cap(1).toDouble();
    stg->normal[1] = p.cap(2).toDouble();
    stg->normal[2] = p.cap(3).toDouble();

    pos += p.cap(0).size();

    QString remainder = s.right(s.size() - pos).trimmed();
    if (remainder.size() > 0) {
        int count =
            sscanf(qPrintable(remainder), "los=%lg  obliq=%lg",
                   &stg->los,
                   &stg->obliq
                  );
        if (count != 2) {
            qDebug("error only saw %d", count);
            return -1;
        }
    } else {
        qDebug("error no los or obliq on STG:");
        return -1;
    }

    stg->name = stashedQuotedString;
    tg->subTraces.push_back(stg);
    stashedQuotedString.clear();

    return 0;
}

QString IfrParser::quotedString(const QString s)
{
    QRegExp quotedStr("\"([^\"]*)\"");

    if (quotedStr.indexIn(s) == -1)
        return QString("");

    return quotedStr.cap(1);

}

void IfrParser::processLine(const QString lline, const int lineNumber)
{
    // A pattern that is: capture(anything not a colon)
    // which is followed by a colon
    // which is followed by capture(zero or more characters)
    static QRegExp p("([^:]+):(.*)");

    QString line = lline.trimmed();
    if (line.length() == 0)
        return;

    if (p.indexIn(line) == -1) {
        // not a line of the form "text:text"
        // if we just finished a "TP:" line this might be a
        // line of a single quoted string for an object which makes up
        // a virtual component

        QString s = quotedString(line);
        if (s.length() > 0) {
            stashedQuotedString = s;
        } else {
            qDebug("error at %d Not a key:value or quoted string \"%s\"", lineNumber, qPrintable(lline));
        }
        return;
    }

    if (p.captureCount() != 2) {
        qDebug("error at %d (key with no value) %s", lineNumber, qPrintable(lline));
        return;
    }

    if (!p.cap(1).compare("MUVES Version", Qt::CaseInsensitive)) versionFunc(p.cap(2));
    else if (!p.cap(1).compare("View Units")) viewUnitsFunc(p.cap(2));
    else if (!p.cap(1).compare("Title")) titleFunc(p.cap(2));
    else if (!p.cap(1).compare("Approx")) approxFunc(p.cap(2));
    else if (!p.cap(1).compare("Target")) targetFunc(p.cap(2));
    else if (!p.cap(1).compare("Modkey", Qt::CaseInsensitive)) modkeyFunc(p.cap(2));
    else if (!p.cap(1).compare("V")) vFunc(p.cap(2));
    else if (!p.cap(1).compare("AP")) apFunc(p.cap(2));
    else if (!p.cap(1).compare("ST")) stFunc(p.cap(2));
    else if (!p.cap(1).compare("T")) tFunc(p.cap(2));
    else if (!p.cap(1).compare("TG")) tgFunc(p.cap(2));
    else if (!p.cap(1).compare("TP")) tpFunc(p.cap(2));
    else if (!p.cap(1).compare("TD")) tdFunc(p.cap(2));
    else if (!p.cap(1).compare("SA")) saFunc(p.cap(2));
    else if (!p.cap(1).compare("S")) sFunc(p.cap(2));
    else if (!p.cap(1).compare("STG")) stgFunc(p.cap(2));
    else if (!p.cap(1).compare("B")) bFunc(p.cap(2));
    else {
        qDebug("parse error at %d:\n   %s", lineNumber, qPrintable(lline));
    }
}

bool IfrParser::parse(const QString &fileName)
{
    QFile file(fileName);
    if (!file.open(QIODevice::ReadOnly | QIODevice::Text)) {
        return 0;
    }

    irFile = QSharedPointer<IRFile>(new IRFile);
    int lineNumber = 1;

    QProgressDialog dialog("Loading ir file...", "", 0, file.size());
    dialog.setCancelButton(NULL);
    dialog.setWindowTitle("Loading ir file...");
    int progress = 0;
    dialog.show();

    while (!file.atEnd()) {
        QString line = file.readLine();
        line = line.trimmed();

        // Skip comments
        if (line.startsWith('#') || line.size() == 0) {
            continue;
        }

        processLine(line, lineNumber++);

        // Update progress bar dialog.
        progress = progress + line.size();
        dialog.setValue(progress);
    }
    return true;
}

