#include "ColorMap.h"
#include <QPainter>
#include <QPalette>
#include <QStaticText>
#include <QFile>
#include <QMessageBox>

#define SEPARATE_MIN_MAX_BAR_WIDTH 10

ColorMap::ColorMap(QObject *parent, bool interpolated, bool separateMinColor,
                   bool separateMaxColor, QList<QColor> colors, QString name) :
    QObject(parent),
    m_colors(colors),
    m_interpolated(interpolated),
    m_separateMinColor(separateMinColor),
    m_separateMaxColor(separateMaxColor),
    m_name(name)
{
    if(colors.isEmpty()) {
        //Default to a color map from black to white
        m_colors.append(QColor(0, 0, 0));
        m_colors.append(QColor(255, 255, 255));
    }
}

QColor ColorMap::getColor(float normalizedValue)
{
    //Normalized value is out of range
    if(normalizedValue > 1.0 || normalizedValue < 0.0) {
        m_errorMessage = "Normalized value has to be between 0.0 and 1.0";
        return QColor();
    }

    //If the normalized value is 1.0, return the last color in the list
    if(normalizedValue == 1.0)
        return m_colors.last();

    //If the normalized value is 0.0, return the first color in the list
    if(normalizedValue == 0.0)
        return m_colors.first();

    int numColors = m_colors.count();

    if(m_separateMinColor) {
        //If there is a separate color for the minimum value, reduce the number
        //of colors used in the map
        numColors--;
    }

    //Is there a separate color for the maximum value?
    if(m_separateMaxColor) {
        //If there is a separate color for the maximum value, reduce the number
        //of colors used in the map
        numColors--;
    }

    if(m_interpolated && numColors > 1) {
        //The width of each color band
        float bandWidth = 1.0 / (float)(numColors - 1);

        //The index of the color
        int colorIndex = normalizedValue / bandWidth;

        //The index of the color band the normalized value falls into
        int bandIndex = colorIndex;

        //If there is a separate color for the minimum value, ignore the first
        //color in the list
        if(m_separateMinColor)
            colorIndex++;

        //The values below and above the normalized value
        float bottomValue = (float)bandIndex * bandWidth;
        float topValue = (float)(bandIndex + 1) * bandWidth;

        //The interpolation values for the colors at and above colorIndex
        float topInterpValue = (normalizedValue - bottomValue) /
                               (topValue - bottomValue);
        float bottomInterpValue = 1.0 - topInterpValue;

        int red = (m_colors.at(colorIndex).red() * bottomInterpValue) +
                  (m_colors.at(colorIndex + 1).red() * topInterpValue);

        int green = (m_colors.at(colorIndex).green() * bottomInterpValue) +
                    (m_colors.at(colorIndex + 1).green() * topInterpValue);

        int blue = (m_colors.at(colorIndex).blue() * bottomInterpValue) +
                   (m_colors.at(colorIndex + 1).blue() * topInterpValue);

        return QColor(red, green, blue);
    } else {
        float colorWidth = 1.0 / (float)numColors;
        int colorIndex = normalizedValue / colorWidth;

        if(m_separateMinColor)
            colorIndex++;

        return m_colors.at(colorIndex);
    }
}

QImage ColorMap::getColorMapImage(int width)
{
    QImage colorMapImage(width, 1, QImage::Format_RGB32);
    QColor black(0, 0, 0);

    int adjustedWidth = width;
    int firstPixel = 0;

    //If there is a separate color for the minimum value, draw the minimum value
    //color in the first SEPARATE_MIN_MAX_BAR_WIDTH - 1 pixels followed by a
    //black pixel for separation
    if(m_separateMinColor) {
        adjustedWidth -= SEPARATE_MIN_MAX_BAR_WIDTH;
        firstPixel = SEPARATE_MIN_MAX_BAR_WIDTH;

        for(int i = 0; i < SEPARATE_MIN_MAX_BAR_WIDTH - 1; i++) {
            colorMapImage.setPixel(i, 0, m_colors.first().rgb());
        }

        colorMapImage.setPixel(SEPARATE_MIN_MAX_BAR_WIDTH - 1, 0, black.rgb());
    }

    //If there is a separate color for the maximum value, draw the maximum value
    //color in the first SEPARATE_MIN_MAX_BAR_WIDTH - 1 pixels followed by a
    //black pixel for separation
    if(m_separateMaxColor) {
        adjustedWidth -= SEPARATE_MIN_MAX_BAR_WIDTH;
        int startIndex = width - SEPARATE_MIN_MAX_BAR_WIDTH;

        colorMapImage.setPixel(startIndex, 0, black.rgb());

        for(int i = startIndex + 1; i < width; i++) {
            colorMapImage.setPixel(i, 0, m_colors.last().rgb());
        }
    }

    int startIndex = 0;

    //Passing 0.0 into getColor returns the first color in the list, so this is
    //to avoid having the first color be the first pixel after the separation
    //line in the case of having a separate color for the minimum value.
    if(m_separateMinColor) {
        startIndex++;
        float value = 1.0 / (float)adjustedWidth / 2.0;

        colorMapImage.setPixel(firstPixel, 0, getColor(value).rgb());
    }

    for(int i = startIndex; i < adjustedWidth; i++) {
        colorMapImage.setPixel(firstPixel + i, 0,
                               getColor((float)i / (float)adjustedWidth).rgb());
    }

    return colorMapImage;
}

QImage ColorMap::getScaleImage(int width, QColor backgroundColor)
{
    int horizontalCenter = (SCALE_HEIGHT / 2) + 1;
    QColor black(0, 0, 0);

    //Figure out the width of the scale image
    QStaticText min = QStaticText(QString("%1").arg(0.0, 0, 'f', 2));
    QStaticText max = QStaticText(QString("%1").arg(1.0, 0, 'f', 2));

    //Half widths of min and max texts used to determine positioning and extra
    //pixels needed on the end(s) of the scale image
    int minHalfWidth = (min.size().width() / 2) + 1;
    int maxHalfWidth = (max.size().width() / 2) + 1;

    //Width of the color map excluding separate min and max colors.  Will equal
    //width if there are not separate min or max colors
    int colorMapWidth = width;
    //The first and last pixels of the scale.
    int firstPixel = 0;
    int lastPixel = width;
    //The start of the color map excluding a separate minimum color
    int colorMapStartPoint = 0;
    //The amount of pixels to tack onto the end(s) of the scale image
    int extraPixels;

    if(m_separateMinColor) {
        extraPixels = minHalfWidth - (SEPARATE_MIN_MAX_BAR_WIDTH / 2) + 1;

        colorMapWidth -= SEPARATE_MIN_MAX_BAR_WIDTH;
        colorMapStartPoint = SEPARATE_MIN_MAX_BAR_WIDTH;
    } else {
        extraPixels = min.size().width() / 2 + 1;
    }

    if(extraPixels > 0) {
        //Adjust values and reset extraPixels to be reused
        width += extraPixels;
        colorMapStartPoint += extraPixels;
        firstPixel = extraPixels;
        lastPixel += extraPixels;
        extraPixels = 0;
    }

    if(m_separateMaxColor) {
        extraPixels = maxHalfWidth - (SEPARATE_MIN_MAX_BAR_WIDTH / 2) + 1;

        colorMapWidth -= SEPARATE_MIN_MAX_BAR_WIDTH;
    } else {
        extraPixels = max.size().width() / 2 + 1;
    }

    if(extraPixels > 0) {
        width += extraPixels;
        lastPixel -= extraPixels;
    }

    QImage scale(width, SCALE_HEIGHT, QImage::Format_RGB32);
    scale.fill(backgroundColor);
    QPainter painter(&scale);

    int numColors = m_colors.count();

    if(m_separateMinColor) {
        numColors--;

        for(int i = firstPixel; i <= SEPARATE_MIN_MAX_BAR_WIDTH + firstPixel; i++) {
            //Upward facing vertical lines at the beginning and end of the
            //separate min color section of the scale
            if(i == firstPixel ||
               i == SEPARATE_MIN_MAX_BAR_WIDTH + firstPixel) {
                scale.setPixel(i, horizontalCenter - 1, black.rgb());
                scale.setPixel(i, horizontalCenter - 2, black.rgb());
            }

            //Horizontal line in the center
            scale.setPixel(i, horizontalCenter, black.rgb());
        }

        //Min value drawn above the horizontal line
        painter.drawStaticText(0, 0, min);
    }

    if(m_separateMaxColor) {
        numColors--;

        int startIndex = width - SEPARATE_MIN_MAX_BAR_WIDTH - extraPixels;

        for(int i = startIndex; i <= width - extraPixels; i++) {
            //Upward facing vertical lines at the beginning and end of the
            //separate max color section of the scale
            if(i == startIndex || i == width - extraPixels) {
                scale.setPixel(i, horizontalCenter - 1, black.rgb());
                scale.setPixel(i, horizontalCenter - 2, black.rgb());
            }

            //Horizontal line in the center
            scale.setPixel(i, horizontalCenter, black.rgb());
        }

        float textWidth = max.size().width();
        int textStart = width - textWidth - 1;

        //Max value drawn above the horizontal line
        painter.drawStaticText(textStart, 0, max);
    }

    //The next index that's value needs to be drawn
    float nextValue = 0.0;
    float incrementValue = 1.0 / (float)numColors;

    for(int i = 0; i <= colorMapWidth; i++) {
        //Horizontal line in the center
        scale.setPixel(colorMapStartPoint + i, horizontalCenter, black.rgb());

        float value = (float)i / (float)colorMapWidth;

        if(value >= nextValue) {
            //Downward facing vertical lines at each step in the color map
            scale.setPixel(colorMapStartPoint + i, horizontalCenter + 1,
                           black.rgb());
            scale.setPixel(colorMapStartPoint + i, horizontalCenter + 2,
                           black.rgb());

            QStaticText valueText(QString("%1").arg(nextValue, 1, 'f', 2));
            int valueHalfWidth = (valueText.size().width() / 2) + 1;

            //Value drawn below the horizontal line
            painter.drawStaticText(colorMapStartPoint + i - valueHalfWidth,
                                   horizontalCenter + 4, valueText);

            nextValue += incrementValue;
        }
    }

    return scale;
}

bool ColorMap::insertColor(QColor color, int index)
{
    if(index == -1 || index > m_colors.count())
        m_colors.append(color);
    else if(index >= 0)
        m_colors.insert(index, color);

    return true;
}

bool ColorMap::removeColor(int index)
{
    int colorCount = m_colors.count();

    if(colorCount == 2) {
        m_errorMessage = "You must have at least two colors in the color map";
        return false;
    } else if(colorCount == 3) {
        if(m_separateMaxColor && m_separateMinColor) {
            m_errorMessage = "To have separate minimum and maximum colors, "
                             "there must be at least 3 colors in the color map.";
            return false;
        }
    }

    if(index >= colorCount) {
        m_errorMessage = QString("Index %1 is greater than the number of"
                                 "colors").arg(index);
        return false;
    }

    if(index == -1)
        m_colors.removeLast();
    else if(index >= 0)
        m_colors.removeAt(index);

    return true;
}

bool ColorMap::setSeparateMaxColor(bool separateMaxColor)
{
    if(separateMaxColor) {
        if(m_separateMinColor) {
            if(m_colors.count() <= 2) {
                m_errorMessage = "To have separate minimum and maximum colors, "
                                 "there must be at least 3 colors in the color map.";
                return false;
            }
        } else {
            if(m_colors.count() <= 1) {
                m_errorMessage = "To have a separate maximum color, there must "
                                 "be at least 2 colors in the color map.";
                return false;
            }
        }
    }

    m_separateMaxColor = separateMaxColor;

    return true;
}

bool ColorMap::setSeparateMinColor(bool separateMinColor)
{

    if(separateMinColor) {
        if(m_separateMaxColor) {
            if(m_colors.count() <= 2) {
                m_errorMessage = "To have separate minimum and maximum colors, "
                                 "there must be at least 3 colors in the color map.";
                return false;
            }
        } else {
            if(m_colors.count() <= 1) {
                m_errorMessage = "To have a separate minimum color, there must "
                                 "be at least 2 colors in the color map.";
                return false;
            }
        }
    }

    m_separateMinColor = separateMinColor;

    return true;
}
