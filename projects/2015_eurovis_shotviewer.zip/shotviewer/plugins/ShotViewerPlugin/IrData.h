#ifndef IRDATA_H
#define IRDATA_H

#include <QHash>
#include <QMap>
#include <QVariant>

/// OP: ORCA operational requirements
struct IRORCAOperationalRequirement {
    QString orcaPersonnel;
    QString opReqType;
    QString opReqFile;
};

/// STG:  Sub-Traces that represent hit geometry which has been combined
/// to create a virtual component (as a result of a pack)
struct IRSubTraceGeometry { // real component from virtual one
    QString name;
    double entry[3];
    double normal[3];
    double los;
    double obliq;
};

/// TG:  trace geometry (really hit information)
struct IRTraceGeometry {
    double entry[3];
    double normal[3];
    double dir[3];
    double los;
    double norm;
    double obliq;
    double wtLos;
    double wtNorm;
    // If this is a virtual component trace then the sub-traces
    // of the "real" components are stashed here.
    QList <IRSubTraceGeometry *> subTraces;
};

/// TP: Trace Threat Packet
struct IRThreatPacket {
    QString name;
    QString shortName;
    QHash<QString, QVariant> parameterList;
};

/// TD: Trace Damage
struct IRTraceDamage {
    QString name;
    QList<double> values;
};

/// T: Trace information
struct IRTrace {
    QString threatName;
    QString compName;
    QString material;

    // If this is a virtual component resulting from a pack
    // then the geometry will have sub-traces which reprensent the
    // actual components and their entry points.
    bool isVirtual;

    IRTraceGeometry geom;
    QList <IRThreatPacket *> threatPackets;
    QList <IRTraceDamage *> traceDamage;
};

/// A shotline threat consists of the ST: followed by one or more T:, where each
/// T: (trace) represents another component being penetrated or perforated.
struct IRShotlineThreat {
    QString name;
    QString shortName;
    QHash<QString, QVariant> parameters;

    /// Each component penetrated/perforated gets its own trace.
    QList<IRTrace *> traces;
};

/** This represents either a Burst (B:) or a Shot (S:)
 *
 *  In the case of the Burst, the first 3 values of coords stores x, y, z
 *    of the burst location
 *  In the case of the Shot, the first 2 values are the shot coordinates
 *   and the second two are the cell coordinates.
 *
 *  The isBurst flag is set to indicate which was used.
 */
struct IRShotTrace {
    bool isBurst; // true = B, false = S:
    double coords[4]; // B: x, y, z, S: x y C: a b

    /// Many shotline threat initial conditions (ST:) first from the source
    /// threat, then from spall. This will be empty when threat misses target.
    QList<IRShotlineThreat *> threatList;
};

/**
 * A shotline starts with an initial source (e.g., SCJ) which is likely to
 * result in more shotlines in the form of spall. All of these shotlines
 * start from the initial shotline source and are grouped in that way in
 * the IR file.
 */
struct IRShotline {
    IRShotline()
        : aimPointIndex(0)
        , firingPointIndex(0)
        , opReq(NULL) {
    }

    /// One AP: per shotline
    /// Zero or more S: and C: line per shotline
    /// Zero or more B: per view

    /// One AP: per shotline
    int aimPointIndex;
    int firingPointIndex;

    /// Lists of shots (S:) or bursts (B:)
    QList <IRShotTrace *> shotTraces;

    /// OP: one per shotline
    IRORCAOperationalRequirement * opReq;

    /// SA: one per shotline
    QMap<QString, QString> summaryAssessment;
};

/// V: View information
struct IRView {
    IRView(double a, double e, double x, double y, double z)
        : az(a)
        , el(e) {
        dir[0] = x;
        dir[1] = y;
        dir[2] = z;
    }

    bool hasSameAzElDir(const IRView &other) {
        return qFuzzyCompare(this->az, other.az) &&
               qFuzzyCompare(this->el, other.el) &&
               qFuzzyCompare(this->dir[0], other.dir[0]) &&
               qFuzzyCompare(this->dir[1], other.dir[1]) &&
               qFuzzyCompare(this->dir[2], other.dir[2]);
    }

    /// Azimuth
    double az;
    /// Elevation
    double el;
    /// Direction
    double dir[3];
    QString groupLabel;

    /// Every V: restarts the AP: # counter. Put a new shotline on this list
    /// every time an AP: is encountered. Each view is likely to contain
    /// multiple shotlines.
    QList<IRShotline *> shotlines;
};

///  This is the top level struct. It represents the entire IrFile
struct IRFile {
    QString muvesVersion;
    QString viewUnits;
    QString title;
    QString approx;
    QString target;

    QHash<QString, QVariant> modKeys;
    QList<IRView *> views;
};

#endif // IRDATA_H
