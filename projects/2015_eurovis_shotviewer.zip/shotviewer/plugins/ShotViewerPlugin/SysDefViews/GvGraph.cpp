#include "GvGraph.h"
#include "GvWrapper.h"
#include <QDebug>
#include <QFile>

/// Dot uses a 72 DPI value for converting its position coordinates from points
/// to pixels while we display at 96 DPI on most operating systems.
const qreal GvGraph::DotDefaultDPI=72.0;

GvGraph::GvGraph(QString input, QFont font, qreal node_size) :
    m_context(gvContext())
{
    // Read contents of the QString as input.
    m_graph = _agmemread(input);

    // Setup graph attributes
    _agset(m_graph, "overlap", "prism");
    _agset(m_graph, "splines", "ortho");
    _agset(m_graph, "pad", "1,0");
    _agset(m_graph, "dpi", "96,0");
    _agset(m_graph, "nodesep", "0,25");
    _agnodeattr(m_graph, "shape", "plaintext");

    // GV uses , instead of . for the separator in floats
    _agnodeattr(m_graph, "width", toGVFormat(node_size / 96.0f));

    font.setPointSize(12);
    setFont(font);
}

GvGraph::~GvGraph()
{
    gvFreeLayout(m_context, m_graph);
    agclose(m_graph);
    gvFreeContext(m_context);
}

void GvGraph::renderToPng(const QString &name)
{
    gvRenderFilename(m_context, m_graph, "png", qPrintable(name));
}

void GvGraph::setFont(QFont font)
{
    m_font = font;

    _agset(m_graph, "fontname", font.family());
    _agset(m_graph, "fontsize", QString("%1").arg(font.pointSizeF()));

    _agnodeattr(m_graph, "fontname", font.family());
    _agnodeattr(m_graph, "fontsize", QString("%1").arg(font.pointSizeF()));

    _agedgeattr(m_graph, "fontname", font.family());
    _agedgeattr(m_graph, "fontsize", QString("%1").arg(font.pointSizeF()));
}

void GvGraph::setNodeSep(float nodeSep)
{
    _agset(m_graph, "nodesep", QString::number(nodeSep));
}

void GvGraph::applyLayout(bool expandComponents)
{
    if (!expandComponents) {
        Agnode_t *node;
        for (node = agfstnode(m_graph); node; node = agnxtnode(m_graph, node)) {
            if (nodeIsLeaf(node) && nodeDegreeIn(node) <= 1) {
                nodeSetAttr(node, "shape", "point");
            }
        }
    }

    gvFreeLayout(m_context, m_graph);
    _gvLayout(m_context, m_graph, "dot");
}

QRectF GvGraph::boundingRect() const
{
    qreal dpiScale = graphDpi() / DotDefaultDPI;
    return QRectF(m_graph->u.bb.LL.x * dpiScale,
                  m_graph->u.bb.LL.y * dpiScale,
                  m_graph->u.bb.UR.x * dpiScale,
                  m_graph->u.bb.UR.y * dpiScale);
}

QList<GvNode> GvGraph::nodes() const
{
    QList<GvNode> nodes;
    qreal dpi = graphDpi();
    qreal dpiScale = dpi / DotDefaultDPI;
    Agnode_t *node;

    for (node = agfstnode(m_graph); node; node = agnxtnode(m_graph, node)) {

        GvNode object;
        object.name = node->name;

        // Fetch the X coordinate
        // apply the DPI conversion rate (actual DPI / 72, used by dot)
        qreal x = node->u.coord.x * dpiScale;

        // Translate the Y coordinate from bottom-left to top-left corner
        qreal y = (m_graph->u.bb.UR.y - node->u.coord.y) * dpiScale;
        object.centerPos = QPoint(x, y);

        // Transform the width and height from inches to pixels
        object.height = node->u.height * dpi;
        object.width = node->u.width * dpi;
        object.outDegree = nodeDegree(node, 0, 1);
        object.inDegree = nodeDegree(node, 1, 0);
        object.node = node;
        nodes << object;
    }
    return nodes;
}

QList<GvEdge> GvGraph::edges() const
{
    QList<GvEdge> edges;
    qreal dpiScale = graphDpi() / DotDefaultDPI;
    Agnode_t *node;
    Agedge_t *edge;
    // TODO: These two loops may put duplicate edges in the list. Look into it.

    // Loop over all nodes and all edges
    for (node = agfstnode(m_graph); node; node = agnxtnode(m_graph, node)) {
        for (edge = agfstedge(m_graph, node); edge; edge = agnxtedge(m_graph, edge, node)) {

            // We use the head and tail to uniquely identify an edge
            GvEdge object;
            object.head = edge->head;
            object.tail = edge->tail;

            // Check that we have not already added edges for this node.
            bool found = false;
            foreach (GvEdge gvEdge, edges) {
                if (gvEdge.tail == edge->tail && gvEdge.head == edge->head) {
                    found = true;
                }
            }

            if (found) {
                continue;
            }

            object.source = edge->tail->name;
            object.target = edge->head->name;
            object.edge = edge;

            // Calculate the path from the spline (only one spline, as the graph is strict. If it
            // wasn't, we would have to iterate over the first list too)
            // Calculate the path from the spline (only one as the graph is strict)
            if ((edge->u.spl->list != 0) && (edge->u.spl->list->size%3 == 1)) {
                // If there is a starting point, draw a line from it to the first curve point
                if (edge->u.spl->list->sflag) {
                    object.path.moveTo(edge->u.spl->list->sp.x * dpiScale,
                                       (m_graph->u.bb.UR.y - edge->u.spl->list->sp.y) * dpiScale);
                    object.path.lineTo(edge->u.spl->list->list[0].x * dpiScale,
                                       (m_graph->u.bb.UR.y - edge->u.spl->list->list[0].y) * dpiScale);
                } else {
                    object.path.moveTo(edge->u.spl->list->list[0].x * dpiScale,
                                       (m_graph->u.bb.UR.y - edge->u.spl->list->list[0].y) * dpiScale);
                }

                // Loop over the curve points
                for (int i = 1; i < edge->u.spl->list->size; i += 3) {
                    object.path.cubicTo(edge->u.spl->list->list[i].x * dpiScale,
                                        (m_graph->u.bb.UR.y - edge->u.spl->list->list[i].y) * dpiScale,
                                        edge->u.spl->list->list[i+1].x * dpiScale,
                                        (m_graph->u.bb.UR.y - edge->u.spl->list->list[i+1].y) * dpiScale,
                                        edge->u.spl->list->list[i+2].x * dpiScale,
                                        (m_graph->u.bb.UR.y - edge->u.spl->list->list[i+2].y) * dpiScale);
                }

                // If there is an ending point, draw a line to it
                if (edge->u.spl->list->eflag) {
                    object.path.lineTo(edge->u.spl->list->ep.x * dpiScale,
                                       (m_graph->u.bb.UR.y - edge->u.spl->list->ep.y) * dpiScale);
                }
                edges << object;
            }
        }
    }
    return edges;
}

qreal GvGraph::graphDpi() const
{
    return _agget(m_graph, "dpi", "96,0").replace(",", ".").toDouble();
}

int GvGraph::nodeDegree(Agnode_t *node, bool useInEdges, bool useOutEdges) const
{
    int degree = 0;
    Agedge_t *edge = 0;
    if (useInEdges) {
        for (edge = agfstin(m_graph, node); edge; edge = agnxtin(m_graph, edge)) {
            degree++;
        }
    }
    if (useOutEdges) {
        for (edge = agfstout(m_graph, node); edge; edge = agnxtout(m_graph, edge)) {
            degree++;
        }
    }
    return degree;
}

int GvGraph::nodeDegreeIn(Agnode_t *node) const
{
    return nodeDegree(node, true, false);
}

int GvGraph::nodeDegreeOut(Agnode_t *node) const
{
    return nodeDegree(node, true, false);
}

bool GvGraph::nodeIsLeaf(Agnode_t *node) const
{
    int degree = nodeDegree(node, 0, 1);
    return degree == 0;
}

void GvGraph::nodeSetAttr(Agnode_t *node, QString attr, QString value)
{
    Agsym_t *sym = _agfindattr(node, attr);
    if (!sym) {
        sym = _agnodeattr(m_graph, attr, "");
    }
    _agxset(node, sym->index, value);
}

QList<Agnode_t *> GvGraph::nodeParents(Agnode_t *node)
{
    QList<Agnode_t *> parents;
    Agedge_t *edge = 0;
    for (edge = agfstin(m_graph, node); edge; edge = agnxtin(m_graph, edge)) {
        parents << edge->tail;
    }
    return parents;
}
