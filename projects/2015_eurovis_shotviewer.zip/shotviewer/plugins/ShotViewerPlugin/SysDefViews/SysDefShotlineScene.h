#ifndef SYSDEFSHOTLINESCENE_H
#define SYSDEFSHOTLINESCENE_H

#include <QGraphicsScene>

class QKeyEvent;

/// QGraphicsScene that allows scrolling on mouse wheel events.
class SysDefShotlineScene : public QGraphicsScene
{
    Q_OBJECT

public:

    explicit SysDefShotlineScene(QObject *parent = 0);

signals:

public slots:

    virtual void wheelEvent(QGraphicsSceneWheelEvent *event);

    virtual void keyPressEvent(QKeyEvent *event);

    virtual void keyReleaseEvent(QKeyEvent *event);

private:
    bool m_controlHeld;
};

#endif // SYSDEFSHOTLINESCENE_H
