#ifndef SYSDEFVISITORS_H
#define SYSDEFVISITORS_H

#include "../../plugins/SystemEvaluation/SysDefDocument.h"
#include "../../plugins/SystemEvaluation/SysDef/SeVisitors.h"

/** This class creates part of a GraphViz input string from the MUVES sysdef
 * data structures.
 *
 * This is meant to visit each system in the sysdef file. The current system it
 * is visiting is called the "parent." For each of the parent's damaged children
 * this creates an entry in its result "parent -> child." This tells GraphViz to
 * create two nodes with an edge between them. After visiting a system, the
 * getResult() contains the part of the GraphViz input string for the parent
 * system.
 */
class GraphVizVisitor : public SysdefVisitor
{
public:
    /// If onlyDamagedNodes is true then this will only create graphviz inputs
    /// for the nodes contained in m_damgedList.
    GraphVizVisitor(SysDefDocument *doc, bool onlyDamagedNodes);

    /// Returns the input to graphviz
    QString getResult(void) const;

    /// Sets the name of the current system being traversed.
    void setParentName(QString parentQualified);

    /// Sets the list of damaged components and systems.
    void setDamagedList(QStringList list);

    //// Methods inhereted from SysDefVisitor /////////////////////////////////
    virtual void visitSysNameNode(SeSysDef *sysdefp, int qualIndex);

    virtual void visitQualSysNode(SeSysDef *sysdefp, int qualIndex);

    virtual void visitCompNameNode(SeSysDef *sysdefp, int qualIndex);

    virtual void visitQualCompNode(SeSysDef *sysdefp, int qualIndex);

    virtual void visitBinaryOpNode(SeSysDef *sysdefp, int qualIndex);

    virtual void visitOtherNode(SeSysDef *sysdefp, int qualIndex);

private:
    /// String of sysdef as graphviz input.
    QString m_result;

    /// Name of the system whose children we are traversing.
    QString m_parentName;

    /// True only if we will display only damaged components.
    bool m_filtered;

    /// List is damaged components and systems with non-zero pk and lof values.
    QStringList m_damagedList;
};
#endif // SYSDEFVISITORS_H
