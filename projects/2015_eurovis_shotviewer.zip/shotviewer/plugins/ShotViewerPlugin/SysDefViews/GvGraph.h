#ifndef GVGRAPH_H
#define GVGRAPH_H

#include <Qt>
#include <QString>
#include <QStringList>
#include <QFont>
#include <QMap>
#include <QPair>
#include <QRectF>

#include <gvc.h>

#include "GvStructs.h"

/**GvGraph - A C++ wrapper for the GraphViz context and graph. This class takes
 * a GraphViz-formatted input string, computes a hierarchical graph layout,
 * and returns a representation of nodes and edges that can be displayed in a
 * QGraphicsView.
 *
 * This class uses the internal GraphViz API to get at things like node and edge
 * positions. It has only been tested with GraphViz v. 2.26.3. Newer
 * versions of GraphViz do not work with it as they use a new internal API.
 *
 * Using this class involves the following steps:
 *      1. Construct this with a GraphViz-formatted input string.
 *      2. Optional: set the node sep -- minimum spacing between nodes.
 *      3. applyLayout()  -- tell graphviz to compute the layout
 *      4. Get at the graph representation using nodes() and edges().
 *
 * This class relies on the GraphViz functions provided by GvWrapper.h.
 *
 * This class was inspired by a blog post here:
 *      http://www.mupuf.org/blog/2010/07/08/how_to_use_graphviz_to_draw_graphs_in_a_qt_graphics_scene/
 *
 * This is not particularly robust and it does not support newer versions of
 * GraphViz. I recommend looking at newer GraphViz + Qt combinations, if this is
 * going be continued. See: https://code.google.com/p/qgv/
 */
class GvGraph
{
public:

    /// Default DPI value used by dot (in points instead of pixels).
    static const qreal DotDefaultDPI;

    /// Construct a Graphviz graph object.
    /// input is the GraphViz-formatted input string.
    /// font is the font to use for the graph
    /// node_size is the size in pixels of each node.
    GvGraph(QString input, QFont font=QFont(), qreal node_size=50);

    /// Optionally change the graph font.
    void setFont(QFont font);

    /// Change the minimum spacing between nodes in this graph.
    void setNodeSep(float nodeSep);

    /// This is where graphViz actually computes the layout. If expandComponents
    /// then draw leaves as full nodes. Otherwise draw them as bubbles under
    /// their parents.
    void applyLayout(bool expandComponents);

    /// Cleans up the graphviz context.
    ~GvGraph();

    /// Render graph to png file. name must end with png.
    void renderToPng(const QString &name);

    /// Methods for accessing graph layout. All coordinates are in graph space.
    QRectF boundingRect() const;

    QList<GvNode> nodes() const;

    QList<GvEdge> edges() const;

    qreal graphDpi() const;

    QFont font() const
    {
        return m_font;
    }

    /// Methods for getting information about node degrees.
    int nodeDegree(Agnode_t *node, bool useInEdges=true, bool useOutEdges=true) const;

    int nodeDegreeIn(Agnode_t *node) const;

    int nodeDegreeOut(Agnode_t *node) const;

    bool nodeIsLeaf(Agnode_t *node) const;

    /// Returns a list of node parents.
    QList<Agnode_t*> nodeParents(Agnode_t *node);

    /// Used to set attributes about specific nodes.
    /// TODO: Move this to GvWrapper.h
    void nodeSetAttr(Agnode_t *node, QString attr, QString value);

private:

    /// Graphviz internal context
    GVC_t *m_context;

    /// Graphviz internal graph
    Agraph_t *m_graph;

    /// Font used in the graph
    QFont m_font;
};

#endif // GVGRAPH_H
