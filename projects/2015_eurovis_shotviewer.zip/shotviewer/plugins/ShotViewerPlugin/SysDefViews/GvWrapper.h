#ifndef GVWRAPPER_H
#define GVWRAPPER_H

#include <QString>
#include <QDebug>

/** Global function wrappers for GraphViz library. GraphViz expects strings to
 * be passed as "char *" instead of "const char *." Functions in this file
 * cast away const-ness when converting QString to char*.
 *
 * See GvGraph.h for the caveats and credits of these functions.
 */

inline QString toGVFormat(QString str)
{
    return str.replace('.', ',');
}

inline QString toGVFormat(float value)
{
    return toGVFormat(QString::number(value));
}

inline qreal fromGVFormat(QString str)
{
    return str.replace(',', '.').toFloat();
}

inline Agraph_t* _agopen(QString name, int kind)
{
    return agopen(const_cast<char *>(qPrintable(name)), kind);
}

inline QString _agget(void *object, QString attr, QString alt=QString())
{
    QString str=agget(object, const_cast<char *>(qPrintable(attr)));

    if (str==QString()) {
        return alt;
    } else {
        return str;
    }
}

inline int _agset(void *object, QString attr, QString value)
{
    return agsafeset(object, const_cast<char *>(qPrintable(attr)),
                     const_cast<char *>(qPrintable(value)),
                     const_cast<char *>(qPrintable(value)));
}

inline Agsym_t *_agnodeattr(void *object, QString attr, QString value)
{
    return agnodeattr((Agraph_t *)object, const_cast<char *>(qPrintable(attr)),
                      const_cast<char *>(qPrintable(value)));
}

inline Agsym_t *_agedgeattr(void *object, QString attr, QString value)
{
    return agedgeattr((Agraph_t *) object, const_cast<char *>(qPrintable(attr)),
                      const_cast<char *>(qPrintable(value)));
}

inline Agnode_t *_agnode(void *object, QString attr)
{
    return agnode((Agraph_t *) object, const_cast<char *>(qPrintable(attr)));
}

inline int _gvLayout(void *context, void *graph, QString layout)
{
    return gvLayout((GVC_t *) context, (graph_t*) graph, qPrintable(layout));
}

inline Agsym_t *_agfindattr(void *object, QString attr)
{
    return agfindattr((Agnode_t *) object, const_cast<char *>(qPrintable(attr)));
}

inline void _agxset(void *object, int index, QString value)
{
    agxset(object, index, const_cast<char *>(qPrintable(value)));
}

inline Agraph_t *_agmemread(QString value)
{
    return agmemread(const_cast<char *>(qPrintable(value)));
}
#endif // GVWRAPPER_H
