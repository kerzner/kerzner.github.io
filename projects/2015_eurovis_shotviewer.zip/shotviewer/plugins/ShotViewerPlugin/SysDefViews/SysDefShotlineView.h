#ifndef SYSDEFSHOTLINEVIEW_H
#define SYSDEFSHOTLINEVIEW_H

#include "ShotlineView.h"
#include <QMap>

class SysDefDocument;
class QGraphicsView;
class GvGraph;
class QGraphicsItem;
class FilterItem;
class GraphItem;
class QToolButton;
class QDoubleSpinBox;
class QSplitter;
class QPlainTextEdit;

#define SYSDEFSHOTLINEVIEW_DEBUG 1

/** This view creates a node-link diagram to show the systemic impact of
 * shotline damage. It computes damage by pulling the list of *qualified*
 * damaged components from the SA line of the IRDocument. It then computes the
 * systemic impact of this damage and displays it as a node-link diagram using
 * GraphViz for the layout.
 *
 * Required documents - their purpose:
 *  1. IRDocument - per-aimpoint list of damage components and current qualifier
 *  2. SysDefDocument - compute system damage from components
 *
 * This view computes damage using only qualified component and system names,
 * but it displays unqualified names to reduce visual clutter. When it uses the
 * name of a component in the view (such as on a click event) it re-adds the
 * qualifier in order to look it up in the SysDefDocument. Here are the basic
 * rules, followed by one corner case:
 *  1. compute damage using qualified names
 *  2. display unqualified names to the user (the qualifier is implied for all)
 *  3. re-add qualifiers to the unqualified names when needed for computation
 *
 * The corner case and how we handle it. Suppose the user has selected "pk_main"
 * as the current qualifier. Some sysdef files will have systems like this:
 * "mobility = Engine[pk_main] | ..." Here, this view shows the mobility system
 * without a qualifier. But when the user clicks on mobility, we cannot just
 * re-add [pk_main] to it b/c there is no mobility[pk_main] in the
 * SysDefDocument. To get around this, we only re-add the qualifier if the
 * qualified system name actually exists in the SysDefFile file.
 */
class SysDefShotlineView : public ShotlineView
{
    Q_OBJECT
public:

    SysDefShotlineView(QWidget *parent = 0);

    ~SysDefShotlineView();

    void settingsLoad();

    void settingsSave();

    /// Inherited from ShotlineView ///////////////////////////////////////////

    QWidget *getImageWidget() const;

    //// Inherited from ApplicationView ///////////////////////////////////////

    bool isConnectedToDoc(ApplicationDocument *doc);

public slots:

    /// Called when IRDocument's shotlines have been changed. It clears the
    /// existing representation then creates a visualization for the new
    /// shotlines.
    virtual void updateShotlines();

    /// Called when the user mouses over a component in any view.
    virtual void setMouseHoverHighlight(const QMap<int, QList<int> > &,
                                        const int &, const bool &, const int &);

    /// Called when the user clicks on a node in this view's graph. This will
    /// display the system's string representation in its text edit.
    virtual void setSelectedItemInTextEdit(QString name);

    /// TODO: we may be able to remove this...
    virtual void showAimPointDialog();

private slots:

    /// Called when user changes which top-level systems are selected from the
    /// "Systems" menu.
    void topLevelSystemsChanged();

    /// Called when the user selects all top-level systems in the Systems menu.
    void showAllTopLevelSystems();

    /// Called when the user selects no top-level systems in the Systems menu.
    void showNoTopLevelSystems();

    /// Called when the node spacing is changed. This calls updateShotlines() to
    /// create a new GraphViz representation.
    void nodeSpacingTriggered();

    /// Toggles whether leaf components are shown as proper nodes or collapsed
    /// bubbles. This calls updateShotlines() to create a new GraphViz
    /// representation.
    void setExpandComponents(bool);

private:

    /// Attach an IRDocument or a SysDefDocument, otherwise does nothing
    void attachDocument(ApplicationDocument *doc);

    /// The main method for converting IRDocument and SysDefDocument data into
    /// a node-link diagram.
    void create();

    /// Updates m_damagedMaps based on the current aimpoints. After calling this
    /// m_damagedMaps contains a list of qualified components and systems with
    /// non-zero pk or lof values.
    void evaluateDamage();

    /// Returns GraphViz-formatted input of entire SysDefDocument. This is not
    /// currently used b/c GraphViz seems to stall when computing layout of
    /// entire sysdef files. For instance, it cannot the nissan.
    QString documentAsGraphVizInput();

    /// Returns graphviz formatted input of only damaged components.
    QString documentAsFilteredGraphVizInput();

    /// Transform graphviz representation into a scene representation.
    void graphicsViewAddNodes();
    void graphicsViewAddEdges();

    /// Populates combo box with top level system names.
    void initializeSystemsMenu();

    /// Look up item by various keys.
    GraphItem *graphicsViewItem(qulonglong userData);
    GraphItem *graphicsViewItem(QString name);

    /// Conditionally readd the qualifier to this system name. See the corner
    /// case above for an explanation of why we use this.
    QString reAddQualifier(QString name);

    /// Creates toolBar populated with combo box.
    QList<QMenu*> createMenus();

    IRDocument *m_irDoc;

    SysDefDocument *m_sysDefDoc;

    /// Main graphics view holding the node-link diagram.
    QGraphicsView *m_graphicsView;

    /// This filter intercepts events on m_graphicsView's items in order to
    /// handle mouse hover and click events. This is needed b/c items in
    /// m_graphicsView do not inherit from QObject--they have no way to
    /// communicate with this class.
    FilterItem *m_filterItem;

    /// GraphViz wrapper class.
    GvGraph *m_graph;

    /// Representation of component and system damaged.
    /// key = aim point
    /// value = map(key = qualified name, vaue = pk or lof value)
    QMap<int, QMap<QString, float> > m_damagedMaps;

    /// True only if the scene has already been created.
    bool m_sceneCreated;

    /// Current spacing between nodes in the sysdef graph.
    float m_nodeSpacing;

    /// Menu that contains the systems for users to filter the graph.
    QMenu *m_systemsMenu;

    /// True only if components should be drawn as nodes, otherwise they will
    /// be drawn as bubbles.
    bool m_expandComponents;

    /// Separates m_text from m_graphicsView.
    QSplitter *m_splitter;

    /// Displays the textual representation of the user-selected system.
    QPlainTextEdit *m_text;

#if defined(SYSDEFSHOTLINEVIEW_DEBUG)
    bool m_verbose;
#endif // defined(SYSDEFSHOTLINEVIEW_DEBUG
};

#endif // SYSDEFSHOTLINEVIEW_H
