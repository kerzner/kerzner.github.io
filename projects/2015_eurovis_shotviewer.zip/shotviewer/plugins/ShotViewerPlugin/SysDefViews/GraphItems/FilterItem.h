#ifndef FILTERITEM_H
#define FILTERITEM_H

#include <QGraphicsObject>

#include "SysDefShotlineView.h"

class GraphItem;

/** This class handles some events for SysDefShotlineScene's items. Initially
 * I used this filter to handle mouse events because it could inherit from
 * QObject and therefore use signals and slots. But we no longer use
 * signals and slots for the mouse events, so this class should probably be
 * removed. Removing it will require putting the functions of the method
 * sceneEventFilter into individual GraphItems.
 *
 * The most useful part of this class is the sceneEventFilter. This filter
 * enables highlighting for GraphItems that get moused over. It also sends these
 * mouse over events to the SysDefShotlineView, which in turn send them to all
 * the other shotline views.
 *
 * Even though this class inherits from QGraphicsObject it does not have a
 * graphical representation. Its paint() method is a no-op.
 *
 * This class makes an assumption about its scene: all items must inherit from
 * the class GraphItem. If this assumption is false then this class will break  .
 */
class FilterItem : public QGraphicsObject
{
    Q_OBJECT

public:

    FilterItem(QGraphicsItem *parent = 0);

    /// The FilterItem's view is what gets told when components get moused over
    /// or clicked on.
    void setView(SysDefShotlineView *view);

    /// Methods required to inherit from QGraphicsObject. //////////////////////

    /// Returns an empty rectangle.
    virtual QRectF boundingRect() const;

    /// No-op
    virtual void paint(QPainter*, const QStyleOptionGraphicsItem*, QWidget *) { }

protected:

    /// Handles three kinds of mouse events:
    ///     1. hover enter events enable highlighting.
    ///     2. hover leave events disable highlighting
    ///     3. mouse release events tells the view to display a component
    ///         in its text edit.
    virtual bool sceneEventFilter(QGraphicsItem *watched, QEvent *event);

    /// Recursively traverse up the graph to highlight all parents.
    /// TODO: remove this. It is not currently used.
    void highlightParentItems(GraphItem *item, bool highlight);

    /// Pointer to the view containing this item.
    SysDefShotlineView *m_view;
};
#endif // FILTERITEM_H
