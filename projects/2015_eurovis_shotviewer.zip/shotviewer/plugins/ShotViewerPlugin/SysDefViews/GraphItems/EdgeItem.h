#ifndef EDGEITEM_H
#define EDGEITEM_H

#include <QGraphicsPathItem>
#include <QPen>
#include "GraphItem.h"

class QPainterPath;

/** This class represents edges between nodes in the SysDefShotlineView's graph.
 *
 */
class EdgeItem : public QGraphicsPathItem, public GraphItem
{
public:

    /// Constructor sets this path to the argument "path."
    EdgeItem(QPainterPath &path);

    /// Returns a string representation of this edge.
    /// It is of the format "EdgeItem: parentName, childName" where the names
    /// correspond to the GraphItem definitions of parent and child.
    /// This assumes that edges have at most one parent and one child.
    QString toQString() const;

    /// Toggle highlighting of this edge by changing pen width.
    void setHighlighting(bool highlight);

    /// Toggle salience of this edge by changing alpha.
    void setSalient(bool salient);
};
#endif // EDGEITEM_H
