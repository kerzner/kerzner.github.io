#include "NodeItem.h"

#include "LeafItem.h"
#include "FilterItem.h"
#include "PkItem.h"

#include <QList>
#include <QFont>
#include <QPen>
#include <QDebug>
#include <QBrush>
#include <QGraphicsScene>

NodeItem::NodeItem(float x, float y, float width, float height, QGraphicsItem *parent)
    : QGraphicsRectItem(x, y, width, 0, parent)
    , m_text(NULL)
    , m_pkGlyphs(new QList<QGraphicsItem*>)
    , m_leaves(new QList<LeafItem*>)
    , m_outerRect(new QGraphicsRectItem(x, y, width, height, this))
    , m_lofGroup(new QGraphicsItemGroup(this))
{
    // By default: black pen, white brush.
    QPen pen;
    pen.setWidthF(1.5);
    setPen(pen);

    QBrush brush(Qt::white);
    setBrush(brush);

    pen.setWidthF(pen.widthF() + m_highlightPenDelta);
    m_outerRect->setPen(pen);
    m_outerRect->setVisible(false);
    m_outerRect->setZValue(1.0f);
}

void NodeItem::addPk(float pk, QColor color)
{
    // Create a pk glyph and put it at the far right of this node.
    QRectF r = rect();
    PkItem *glyph = new PkItem(0, 0, pkGlyphWidth, r.height(), this);

    float glyphPosX = 0.0f;
    if (m_pkGlyphs->size() == 0) {
        glyphPosX = boundingRect().x() + boundingRect().width();
    } else {
        glyphPosX = m_pkGlyphs->last()->pos().x() + pkGlyphWidth;
    }

    glyph->setPos(glyphPosX, r.y());
    glyph->setPk(pk);
    glyph->setFillColor(color);
    m_pkGlyphs->append(glyph);
    updateOuterRect();

    // Create a text item that will appear during mouse hover events.
    QGraphicsTextItem *textItem = new QGraphicsTextItem("lof = " + QString::number(pk, 'f', 2));
    QFont font = textItem->font();
    font.setPixelSize(10);
    textItem->setFont(font);
    textItem->update();
    textItem->setPos(0, boundingRect().height() + textItem->boundingRect().height() * m_lofGroup->childItems().size() / 2);
    textItem->setDefaultTextColor(color);
    textItem->setAcceptHoverEvents(false);

    QGraphicsRectItem *backgroundRect = new QGraphicsRectItem(textItem->boundingRect());
    backgroundRect->setPos(0, boundingRect().height() + textItem->boundingRect().height() * m_lofGroup->childItems().size() / 2);
    backgroundRect->setPen(Qt::NoPen);
    backgroundRect->setBrush(Qt::white);
    backgroundRect->setAcceptHoverEvents(false);
    m_lofGroup->addToGroup(backgroundRect);
    m_lofGroup->addToGroup(textItem);
    m_lofGroup->setVisible(false);

    // The position of text items depends on the number of pk glyphs.
    // Update position for all text items here.
    foreach (QGraphicsItem *item, m_lofGroup->childItems()) {
        float xPos = glyphPosX + pkGlyphWidth - textItem->boundingRect().width();
        item->setPos(xPos, item->pos().y());
    }
}

void NodeItem::setCenterPos(QPointF point)
{
    QRectF rect = boundingRect();
    setPos(point.x() - rect.width() / 2, point.y() - rect.height() / 2);
}

void NodeItem::setText(QString text, QFont font)
{
    m_text = new QGraphicsTextItem(text, this, scene());
    m_text->setFont(font);

    QRectF rect = boundingRect();
    QRectF textRect = m_text->boundingRect();
    setRect(rect.x(), rect.y(), textRect.width(), textRect.height());
    updateOuterRect();
}

void NodeItem::addLeafComponent(QString name, int hitCount, FilterItem *filter)
{
    const qreal leafBaseSize = 10.0f;
    const qreal leafShotScale = 0.10f;

    // Keep the components sorted by number of hits.
    int insertAtPos = m_leaves->size();
    for (int leafIdx = 0; leafIdx < m_leaves->size(); leafIdx++) {
        if (hitCount >= m_leaves->at(leafIdx)->getHitCount()) {
            insertAtPos = leafIdx;
            break;
        }
    }

    // Create and insert the leaf item.
    LeafItem *leaf = new LeafItem(0, 0, leafBaseSize + (leafBaseSize * (hitCount - 1) * leafShotScale),
                                  leafBaseSize + (leafBaseSize * (hitCount - 1) * leafShotScale), this);
    leaf->setName(name);
    leaf->setAcceptHoverEvents(true);
    leaf->addParentPtr(this);
    addChildPtr(leaf);

    leaf->installSceneEventFilter(filter);
    m_leaves->insert(insertAtPos, leaf);

    // Next, we'll position components in rows along the bottom of this rectangle.
    QRectF rect = boundingRect();

    // Top left corner of position for the next leaf.
    QPointF nextLeafPos = QPointF(rect.x(), rect.y() + rect.height());

    // Height of the component for when we need to shift down to the next row.
    qreal componentHeight = nextLeafPos.x() + m_leaves->first()->rect().height();

    for (int leafIdx = 0; leafIdx < m_leaves->size(); leafIdx++) {

        // Position current child
        LeafItem *leaf = m_leaves->at(leafIdx);
        leaf->setPos(nextLeafPos);

        // Update position based on the size of current child.
        QRectF leafRect = leaf->rect();
        nextLeafPos = QPointF(nextLeafPos.x() + leafRect.width(), nextLeafPos.y());

        // If we cross the right edge of this rectangle then shift down to the next row.
        // TODO: Check how robust this really is...
        if (nextLeafPos.x() > rect.x() + rect.width()) {
            nextLeafPos = QPointF(rect.x(), rect.y() + rect.height() + componentHeight);
            componentHeight =- m_leaves->last()->rect().height();
        }
    }
}

void NodeItem::addPkToLeafComponent(QString name, float pK, QColor color)
{
    foreach (QGraphicsItem *item, *m_leaves) {
        LeafItem *component = dynamic_cast<LeafItem*>(item);
        if (component->toQString() == name) {
            component->addPk(pK, color);
        }
    }
}

QString NodeItem::toQString() const
{
    return m_text->toPlainText();
}

void NodeItem::setHighlighting(bool highlight)
{
    if ((!highlight && !m_highlighted)
        || (highlight && m_highlighted)) {
        return;
    } else if (highlight && !m_highlighted) {
        m_outerRect->setVisible(true);
    } else if (!highlight && m_highlighted) {
        m_outerRect->setVisible(false);
    }

    m_highlighted = highlight;
    GraphItem::setHighlighting(highlight);
}

void NodeItem::setSalient(bool salient)
{
    if (salient) {
        setOpacity(1.0);
    } else {
        setOpacity(m_nonSalientOpacity);
    }
    GraphItem::setSalient(salient);
}

void NodeItem::hoverEnterEvent(QGraphicsSceneHoverEvent *event)
{
    Q_UNUSED(event);
    if (m_outerRect->isUnderMouse()) {
        m_lofGroup->setVisible(true);
    }
}

void NodeItem::hoverLeaveEvent(QGraphicsSceneHoverEvent *event)
{
    Q_UNUSED(event);
    m_lofGroup->setVisible(false);
}

void NodeItem::updateOuterRect()
{
    // Expand the rectangle only if there are pk glyphs.
    // With no glyphs the default rectangle is correct.
    if (m_pkGlyphs->size() > 0) {
        QRectF newRect = this->rect();

        float glyphEdge = m_pkGlyphs->last()->pos().x() + pkGlyphWidth;
        newRect.setWidth(glyphEdge + (m_outerRect->pen().widthF() / 2.0f));
        m_outerRect->setRect(newRect);

        newRect.setWidth(glyphEdge + pen().widthF() / 2.0f);
        setRect(newRect);
    }
}

int NodeItem::getHitCount() const
{
    return m_pkGlyphs->size();
}
