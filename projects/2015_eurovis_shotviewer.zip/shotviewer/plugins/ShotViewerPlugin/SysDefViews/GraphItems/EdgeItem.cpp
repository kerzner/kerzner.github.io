#include "EdgeItem.h"

#include <QTextStream>
#include <QDebug>

EdgeItem::EdgeItem(QPainterPath &path)
    : QGraphicsPathItem()
    , GraphItem()
{
    setPath(path);

    // TODO: this can probably be removed.
    setZValue(-1);
}

QString EdgeItem::toQString() const
{
    QString string;
    QTextStream stream(&string);
    stream << "EdgeItem:";

    // If either the parent of children of this edge are undefined then put an
    // "n/a" in the returned string.
    stream << (getParentPtrs()->size() > 0 ? getParentPtrs()->at(0)->toQString() : "n/a") << ", ";
    stream << (getChildPtrs()->size() > 0 ? getChildPtrs()->at(0)->toQString() : "n/a");

    return string;
}

void EdgeItem::setHighlighting(bool highlight)
{
    // We will change the pen width by this  amount.
    qreal penWidthDelta;

    // We need to handle three cases in this order:
    //  1. This matches the state of "highlight." So do nothing.
    //  2. This needs to be highlighted.
    //  3. This needs to be unhighlighted.
    if ((!highlight && !m_highlighted)
        || (highlight && m_highlighted)) {
        return;
    } else if (highlight && !m_highlighted) {
        penWidthDelta = m_highlightPenDelta;
    } else if (!highlight && m_highlighted) {
        penWidthDelta = -m_highlightPenDelta;
    }

    // Update highlighting by changing the pen's width.
    QPen qPen = pen();
    qPen.setWidthF(qPen.widthF() + penWidthDelta);
    setPen(qPen);
    m_highlighted = highlight;

    // Recursively highlight parents.
    GraphItem::setHighlighting(highlight);
}

void EdgeItem::setSalient(bool salient)
{
    // Update opacity based on the "salient" variable.
    if (salient) {
        setOpacity(1.0);
    } else {
        setOpacity(m_nonSalientOpacity);
    }
    GraphItem::setSalient(salient);
}
