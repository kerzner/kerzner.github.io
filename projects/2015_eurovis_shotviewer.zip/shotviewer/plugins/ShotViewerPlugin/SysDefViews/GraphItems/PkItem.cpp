#include "PkItem.h"
#include "IfrHelpers.h"

#include <QGraphicsScene>

#include <QBrush>
#include <QPen>
#include <QDebug>

PkItem::PkItem(float x, float y, float width, float height, QGraphicsItem *parent)
    : QGraphicsRectItem(x, y, width, height, parent)
{
    // TODO: Make this user-specified.
    QPen pen;
    pen.setWidthF(1.5f);
    setPen(pen);
}

void PkItem::setPk(float pk)
{
    // Compute the height of pk bar within this glyph.
    QRectF r = boundingRect();

    // Top and of the rectangle
    float topY = r.y();
    float bottomY = r.y() + r.height();

    // Get the parent item. This is so we can adjust for the parent's pen width.
    QGraphicsRectItem *parent = dynamic_cast<QGraphicsRectItem*>(parentItem());

    // A pk of one has the following properties:
    // -start at this's bottom + parent's pen width.
    // -end at this's top - parent's pen width
    float fillTopY = map(pk, 0.0f, 1.0f, bottomY, topY + parent->pen().widthF());
    float fillHeight = fillTopY - bottomY;;

    // Create the rectangle that will encode pk. TODO: I don't think the else
    // case ever gets called. It should probably be removed.
    if (parent) {
        m_fill = new QGraphicsRectItem(0, 0, r.width() - parent->pen().widthF(), -fillHeight, this);
    } else {
        m_fill = new QGraphicsRectItem(0, 0, r.width(), -fillHeight, this);
    }

    m_fill->setPos(0, fillTopY);
    m_fill->setPen(Qt::NoPen);

    // Qt draws parents first followed by children. This flag tells Qt to draw
    // the child (m_fill) first, followed by the this (the outline).
    m_fill->setFlags(QGraphicsItem::ItemStacksBehindParent);
}

void PkItem::setFillColor(QColor color)
{
    m_fill->setBrush(QBrush(color));
}
