#ifndef PKITEM_H
#define PKITEM_H

#include <QGraphicsRectItem>

/** This class encodes the damage for nodes as a vertical bar. The bar height
 * is computed by the setPk method which taks a float in the range (0, 1) -- 0
 * is no bar height and 1 is full bar height.
 *
 * This is a QGraphicsRectItem with a white fill--it is the outline of the pk
 * glyph. This has a QGraphicsRectItem called m_fill which actually encodes the
 * pk value.
 */
class PkItem : public QGraphicsRectItem
{
public:

    /// Constructor initializes this but does not set any pk values.
    PkItem(float x, float y, float width, float height, QGraphicsItem *parent);

    /// Sets height of bar encoding pk value. Expects a pk in the range (0, 1).
    void setPk(float pk);

    /// Sets color of bar encoding pk value.
    void setFillColor(QColor color);

private:

    /// Rectangle item that encodes pk with its height.
    QGraphicsRectItem *m_fill;

};

#endif // PKITEM_H
