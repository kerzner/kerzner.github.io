#include "FilterItem.h"

#include "GraphItem.h"
#include "NodeItem.h"
#include <QDebug>
#include <QEvent>
#include <QList>

//#define FILTERITEM_DEBUG 1

FilterItem::FilterItem(QGraphicsItem *parent)
    : QGraphicsObject(parent)
{
}

QRectF FilterItem::boundingRect() const
{
    return QRectF();
}

void FilterItem::setView(SysDefShotlineView *view)
{
    m_view = view;
}

bool FilterItem::sceneEventFilter(QGraphicsItem *watched, QEvent *event)
{
    // Here is where we assume that all items in the scene inherit from the
    // class GraphItem. This could probably be made more robust.
    GraphItem *graphItem = dynamic_cast<GraphItem*>(watched);
    QString itemName = graphItem->toQString();

    if (event->type() == QEvent::GraphicsSceneHoverEnter) {
        // Hover enter events enable highlighting.
#if defined(FILTERITEM_DEBUG)
        qDebug() << itemName;
        qDebug() << "Hover enter event!";
#endif // defined(FILTERITEM_DEBUG)

        // We use a -1 as the aimPoint because this view does not per-aimPoint
        // representations of shot components.
        m_view->mouseOverComponentEvent(itemName, true, -1);
        graphItem->setHighlighting(true);

    } else if (event->type() == QEvent::GraphicsSceneHoverLeave) {
        // Hover leave events disable highlighting.

#if defined(FILTERITEM_DEBUG)
        qDebug() << itemName;
        qDebug() << "Hover leave event";
#endif // defined(FILTERITEM_DEBUG)

        // We use a -1 as the aimPoint because this view does not per-aimPoint
        // representations of shot components.
        m_view->mouseOverComponentEvent(itemName, false, -1);
        graphItem->setHighlighting(false);

    } else if (event->type() == QEvent::GraphicsSceneMouseRelease) {
        // Use the QGraphicsItem state of selected to decide which components
        // get shown in the text edit.
        if (watched->isSelected()) {
            m_view->setSelectedItemInTextEdit(itemName);
        }

    }

    // Allow items to handle their own events.
    return false;
}

void FilterItem::highlightParentItems(GraphItem *item, bool highlight)
{
    item->setHighlighting(highlight);

    QList<GraphItem*> *parents= item->getParentPtrs();
    if (parents->size() == 0) {
#if defined(FILTERITEM_DEBUG)
        qDebug() << "Item: " << item->toQString() << "has no parents";
#endif // defined(FILTERITEM_DEBUG)
        return;
    }

    foreach (GraphItem *parent, *parents) {
#if defined(FILTERITEM_DEBUG)
        qDebug() << "Item: " << item->toQString() << "has parent: " << parent->toQString();
#endif // defined(FILTERITEM_DEBUG)
        highlightParentItems(parent, highlight);
    }
}
