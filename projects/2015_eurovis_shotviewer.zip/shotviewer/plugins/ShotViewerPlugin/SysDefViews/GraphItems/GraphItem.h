#ifndef GRAPHITEM_H
#define GRAPHITEM_H

#include <QGraphicsObject>

/** Base class for items used in the SysDefShotlineScene. The main features of
 * this class are its parent and child pointers. These pointers represent
 * relationships in the sysdef graph.
 *
 * Suppose we have a graph of one root, one leaf, and an edge between them. In
 * this case, the root's child is the edge between it and the leaf. The edge's
 * child is the leaf. Similarly, the leaf's parent is the edge between it and
 * the root. The edge's parent is the root. We use these pointers for traversing
 * both up and down the graph structure.
 *
 * When the user mouses over one of these, the setHighlighting method gets
 * called. This recursively calls setHighlighting on each of the parents, which
 * results in the highlighting propagating up the graph. A similar method is
 * used for top-down filtering--setSalient() moves damage down the tree.
 *
 * This probably needs a destructor.
 */
class GraphItem
{
public:

    /// Constructor initializes member lists.
    GraphItem();

    /// Returns a list of parent pointers used for traversing the graph.
    QList<GraphItem*> *getParentPtrs() const;

    /// Returns a list of child pointers used for traversing the graph.
    QList<GraphItem*> *getChildPtrs() const;

    /// Add item to the parent pointers.
    void addParentPtr(GraphItem *item);

    /// Additem to the child pointers.
    void addChildPtr(GraphItem *item);

    /// Return a string representation of this item. Nodes and edges have
    /// different naming conventions so this is pure-virtual.
    virtual QString toQString() const = 0;

    /// Sets highlighting of all parents. Subclasses implement this function
    /// to change their own highlighting.
    virtual void setHighlighting(bool highlight);

    /// Set saliency of all children. Subclasses implement this to change their
    /// own salience.
    virtual void setSalient(bool);

    /// Returns highlighting state of this item. This is used to prevent us from
    /// highlighting something that is already highlighted.
    bool isHighlighted() const;

protected:

    /// List of parents.
    QList<GraphItem*> *m_parentPtrs;

    /// List of chidlren.
    QList<GraphItem*> *m_childPtrs;

    /// True only if currently highlighted.
    bool m_highlighted;

    /// When highlighting is enabled, we increase the size of this's pen by
    /// this value.
    const qreal m_highlightPenDelta;

    /// When this is set to be not salient then we set its alpha to this value.
    const qreal m_nonSalientOpacity;
};
#endif // GRAPHITEM_H
