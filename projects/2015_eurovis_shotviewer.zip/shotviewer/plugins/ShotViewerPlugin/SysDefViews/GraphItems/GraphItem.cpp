#include "GraphItem.h"

#include <QDebug>
#include <QEvent>

GraphItem::GraphItem()
    : m_highlighted(false)
    , m_highlightPenDelta(3.0f)
    , m_nonSalientOpacity(0.25f)
{
    m_parentPtrs = new QList<GraphItem*>();
    m_childPtrs = new QList<GraphItem*>();
}

QList<GraphItem *> *GraphItem::getParentPtrs() const
{
    return m_parentPtrs;
}

QList<GraphItem *> *GraphItem::getChildPtrs() const
{
    return m_childPtrs;
}

void GraphItem::addParentPtr(GraphItem *item)
{
    m_parentPtrs->append(item);
}

void GraphItem::addChildPtr(GraphItem *item)
{
    m_childPtrs->append(item);
}

void GraphItem::setHighlighting(bool highlight)
{
    QList<GraphItem*> *parents = getParentPtrs();

    foreach (GraphItem *parent, *parents) {
        parent->setHighlighting(highlight);
    }

    m_highlighted = highlight;
}

bool GraphItem::isHighlighted() const
{
    return m_highlighted;
}

void GraphItem::setSalient(bool salient)
{
    QList<GraphItem*> *children = getChildPtrs();
    foreach (GraphItem *child, *children) {
        child->setSalient(salient);
    }
}
