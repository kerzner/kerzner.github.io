#ifndef NODEITEM_H
#define NODEITEM_H

#include <QGraphicsRectItem>
#include <QFont>
#include <QPen>

#include "GraphItem.h"

class QGraphicsTextItem;
class QGraphicsItem;
class LeafItem;
class FilterItem;
class QGraphicsSceneHoverEvent;

/** This is a rectangle item representing components or systems in the
 * SysDefShotline View. It also handles mouse hover events for highlighting
 * and setSalient events for top-down filtering.
 *
 * Basic usage of this requires setting its: text (i.e., name), pk values,
 * position, and parent and child pointers as defined by GraphItem.
 *
 * This handles highlighting with a so-called outer rectangle on the perimeter
 * of this object. We use an outer rectangle (instead of messing with the pen
 * width) because it is easier to control. For instance, the pen width increases
 * edge size both inside and outside the rectangle. This can occlude text in
 * some cases. When highlighted the outer rectangle is visible.
 *
 * Advanced usage of this can set the leaf components. This is only for cases
 * when we are drawing leaves as circles--not individual nodes in the graph. By
 * default, this is turned off.
 */
class NodeItem : public QGraphicsRectItem, public GraphItem
{

public:

    /// Constructor. Note: the width and height don't really matter here b/c
    /// they get overridden by setText.
    NodeItem(float x, float y, float width, float height,
             QGraphicsItem *parent = 0);

    //// Basic usage requires setting these three properties. //////////////////

    /// Position this node at point.
    void setCenterPos(QPointF point);

    /// Set the text displayed inside this node.
    void setText(QString text, QFont font = QFont());

    /// Adds a pkItem at the right side of the rectangle.
    void addPk(float pk, QColor color);

    //// Advanced usage can assign leaves to this node. ////////////////////////

    /// Inserts a child component underneath this item.
    void addLeafComponent(QString name, int hitCount, FilterItem *filter);

    /// Adds a pk value to the leaf component. Searches by component name.
    void addPkToLeafComponent(QString name, float pK, QColor color);

    /// Returns number of pk glyphs assigned to this node.
    int getHitCount() const;

    /// Methods used for highlighting and filtering. ///////////////////////////

    /// Recomputes rectangle used for mouse over highlight
    void updateOuterRect();

    /// Returns the name of this node.
    QString toQString() const;

    /// Enables highlighting by turning on the outer rectangle.
    void setHighlighting(bool highlight);

    /// Make this salient (or not) by changing its alpha value.
    virtual void setSalient(bool);

    /// Turn on the details-on-demand for this node.
    virtual void hoverEnterEvent(QGraphicsSceneHoverEvent *event);

    /// Turn off the details-on-demand for this node.
    virtual void hoverLeaveEvent(QGraphicsSceneHoverEvent *event);

    /// Width of vertical bars that represent pk values.
    static const qreal pkGlyphWidth = 7.5f;

private:

    /// Text displayed inside this node.
    QGraphicsTextItem *m_text;

    /// List of pk bars displayed on the right side.
    QList<QGraphicsItem *> *m_pkGlyphs;

    /// List of leaves displayed below this.
    QList<LeafItem *> *m_leaves;

    /// The outerRect wraps entire node and its pk glyphs
    QGraphicsRectItem *m_outerRect;

    /// Group containing lof data.
    QGraphicsItemGroup *m_lofGroup;
};

#endif // NODEITEM_H
