#include "LeafItem.h"

#include <QPen>
#include <QBrush>
#include <QGraphicsSceneHoverEvent>
#include <QDebug>

#include "NodeItem.h"
#include "PkItem.h"

LeafItem::LeafItem(qreal x, qreal y, qreal width, qreal height, QGraphicsItem *parent)
    : QGraphicsEllipseItem(x, y, width, height, parent)
    , GraphItem()
    , m_pkGroup(new QGraphicsItemGroup(this))
{
    QBrush brush(Qt::white);
    setBrush(brush);
    setZValue(1.0f);
}

void LeafItem::setName(QString &name)
{
    m_node = new NodeItem(0, 0, 0, 0, this);
    m_node->addParentPtr(this);
    addChildPtr(m_node);
    m_node->setText(name);
    m_node->setVisible(false);
}

void LeafItem::hoverEnterEvent(QGraphicsSceneHoverEvent *event)
{
    m_node->setPos(event->pos().x() + (10 * 2), event->pos().y());
    setHighlighting(true);
}

void LeafItem::hoverLeaveEvent(QGraphicsSceneHoverEvent *event)
{
    Q_UNUSED(event);
    m_node->setPos(0, 0);
    setHighlighting(false);
}

void LeafItem::hoverMoveEvent(QGraphicsSceneHoverEvent *event)
{
    m_node->setPos(event->pos().x() + (10 * 2), event->pos().y());
    m_pkGroup->setPos(m_node->pos().x(), m_node->pos().y() + m_node->rect().height());
}

QString LeafItem::toQString() const
{
    return m_node->toQString();
}

void LeafItem::setHighlighting(bool highlight)
{
    m_pkGroup->setPos(m_node->pos().x(), m_node->pos().y() + m_node->rect().height());
    m_node->setVisible(highlight);
    m_node->setHighlighting(highlight);
    setBrush(QBrush(highlight ? Qt::darkGray : Qt::white));
    m_pkGroup->setVisible(highlight);
    GraphItem::setHighlighting(highlight);
}

void LeafItem::setSalient(bool salient)
{
    if (salient) {
        setOpacity(1.0f);
    } else {
        setOpacity(m_nonSalientOpacity);
    }
    GraphItem::setSalient(salient);
}

void LeafItem::addPk(float pk, QColor color)
{
    // Add pk value to the node that appears on mouse over.
    m_node->addPk(pk, color);

    // Create a text item to show the pk.
    QGraphicsTextItem *textItem = new QGraphicsTextItem("pk = " + QString::number(pk, 'f', 2));

    QFont font = textItem->font();
    font.setPixelSize(10);
    textItem->setFont(font);

    // Get a list of child items before adding the new one.
    QList<QGraphicsItem *> items = m_pkGroup->childItems();

    m_pkGroup->addToGroup(textItem);

    // Position the text item depending on number of children.
    float xPos = m_node->boundingRect().width() - textItem->boundingRect().width();
    textItem->setPos(xPos, textItem->boundingRect().height() * items.size());

    // Align all text to the right side of this object.
    foreach (QGraphicsItem *item, items) {
        item->setPos(xPos, item->pos().y());
    }

    // Use consistent color and font for pks.
    textItem->setDefaultTextColor(color);

    m_pkGroup->setVisible(false);
}

NodeItem *LeafItem::nodeItem() const
{
    return m_node;
}

int LeafItem::getHitCount() const
{
    return m_node->getHitCount();
}
