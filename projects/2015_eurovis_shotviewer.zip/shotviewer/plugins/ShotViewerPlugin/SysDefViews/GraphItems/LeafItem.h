#ifndef LEAFITEM_H
#define LEAFITEM_H

#include "GraphItem.h"
#include "NodeItem.h"
#include <QPen>
#include <QGraphicsEllipseItem>

/** This item represents components with one parent in the SysDefShotlineView.
 * It is only used when the user decides not to expand components. In these
 * cases, componetns are drawn as little cicles underneath their parents.
 *
 * When the user mouses over one of these items a NodeItem appears. This
 * NodeItem acts as a details-on-demand.
 */
class LeafItem : public QGraphicsEllipseItem, public GraphItem
{
public:

    LeafItem(qreal x, qreal y, qreal width, qreal height, QGraphicsItem *parent = 0);

    /// Name appears during text mouse over.
    void setName(QString &name);

    /// Returns the node item that appears during mouse over.
    NodeItem *nodeItem() const;

    /// Returns number of shotlines that hit its component.
    int getHitCount() const;

    void addPk(float pk, QColor color);

    //// Methods implements from GraphItem /////////////////////////////////////

    /// Returns a string representation of this.
    QString toQString() const;

    /// Make text visible and fill in this bubble.
    void setHighlighting(bool highlight);

    virtual void setSalient(bool salient);

    //// Method implemented from QGraphicsEllipseItem //////////////////////////

    /// On mouse hover events make m_pkGroup and m_node visible.
    virtual void hoverEnterEvent(QGraphicsSceneHoverEvent *event);

    /// Make m_pkGroup and m_node invisible.
    virtual void hoverLeaveEvent(QGraphicsSceneHoverEvent *event);

    /// Move text to remain under the cursor.
    virtual void hoverMoveEvent(QGraphicsSceneHoverEvent *event);

private:

    /// On mouse over a full node item appears.
    NodeItem *m_node;

    /// A group of pk details appears under the node.
    QGraphicsItemGroup *m_pkGroup;
};
#endif // LEAFITEM_H
