#include "GraphVizVisitor.h"
#include <QDebug>

GraphVizVisitor::GraphVizVisitor(SysDefDocument *doc, bool onlyDamagedNodes)
    : SysdefVisitor(doc)
    , m_filtered(onlyDamagedNodes)
{
}

void GraphVizVisitor::visitSysNameNode(SeSysDef *sysdefp, int qualIndex)
{
    // Add an entry to the result for this system node:
    // 1. Get the qualified system name.
    // 2. If we are creating a filtered (i.e., damaged stuff only) string then
    // check that this is indeed damaged.
    // 3. Do not add duplicate entries for the same system.
    // 4. Strip the qualifier and add this system to the GraphViz input.

    // 1. Get the qualified system name.
    QString sysName = qPrintable(m_doc->getSystemName(sysdefp->c.index));
    if (qualIndex > -1) {
        sysName = m_doc->qualifiedName(sysName, qualIndex);
    }

    // 2. If we are creating a filtered (i.e., damaged stuff only) string then
    //      check that this is indeed damaged.
    if (m_filtered && !m_damagedList.contains(sysName)) {
        return;
    }

    // 3. Do not add duplicate entries for the same system.
    if (m_result.contains(sysName)) {
        return;
    }

    // 4. Strip the qualifier and add this system to the GraphViz input.
    if (sysName.isNull()) {
        m_result.append(QString("<BUG: bad system (%1) index (%2)>")
                        .arg(QString(sysdefp->core.text)).arg(sysdefp->c.index));
    } else {
        m_result.append(m_parentName + " -> \"" +
                        m_doc->baseName(sysName) + "\"\n");
    }
}

void GraphVizVisitor::visitQualSysNode(SeSysDef *sysdefp, int qualIndex)
{
    visitSysNameNode(sysdefp, qualIndex);
}

void GraphVizVisitor::visitCompNameNode(SeSysDef *sysdefp, int qualIndex)
{
    // Create a GraphViz entry for this component.
    // 1. Get the qualified component name.
    // 2. Check that we're only adding damaged components.
    // 3. Add this component the the result.

    // 1. Get the qualified component name.
    QString compName = m_doc->getComponentName(sysdefp->c.index);
    if (qualIndex > -1) {
        compName = m_doc-> qualifiedName(compName, qualIndex);
    }

    // 2. Check that we're only adding damaged components.
    if (m_filtered && !m_damagedList.contains(compName)) {
        return;
    }

    // 3. Add this component the the result.
    m_result.append(m_parentName + " -> \""
                    + m_doc->baseName(compName) + "\"\n");
}

void GraphVizVisitor::visitQualCompNode(SeSysDef *sysdefp, int qualIndex)
{
    visitCompNameNode(sysdefp, qualIndex);
}

void GraphVizVisitor::visitBinaryOpNode(SeSysDef *sysdefp, int qualIndex)
{
    // Traverse both sides of binary op nodes.
    switch (sysdefp->type) {
    default:
        sysdefTraverse(sysdefp->o.lhsp, qualIndex);
        sysdefTraverse(sysdefp->o.rhsp, qualIndex);
        break;
    }
}

void GraphVizVisitor::visitOtherNode(SeSysDef *sysdefp, int qualIndex)
{
    if (sysdefp->core.type == SeNT_UNSET) {
        m_result.append("<unset node type>");
    } else {
        m_result.append(QString("<BUG: invalid node type (%1)>")
                        .arg(SeCvtToStr(sysdefp->type)));
    }
}

QString GraphVizVisitor::getResult() const
{
    return m_result;
}

void GraphVizVisitor::setParentName(QString parentQualified)
{
    // Strip the qualifier from parentQualified. Then wrap it with quotes for
    // GraphViz to handle symbols in the name.
    m_parentName = m_doc->baseName(parentQualified).append("\"").prepend("\"");
}

void GraphVizVisitor::setDamagedList(QStringList list)
{
    m_damagedList = list;
}
