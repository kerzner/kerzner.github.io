#include "SysDefShotlineScene.h"

#include <QGraphicsSceneWheelEvent>
#include <QGraphicsView>
#include <QKeyEvent>

SysDefShotlineScene::SysDefShotlineScene(QObject *parent)
    : QGraphicsScene(parent)
    , m_controlHeld(false)
{
}

void SysDefShotlineScene::wheelEvent(QGraphicsSceneWheelEvent *event)
{
    qreal scaleFactor;

    // Control causes the zoom to change at a slower pace.
    if (m_controlHeld) {
        scaleFactor = event->delta() > 0 ? 1.05 : 0.95;
    } else {
        scaleFactor = event->delta() > 0 ? 1.25f : 0.8f;
    }

    foreach (QGraphicsView *view, views()) {
        view->centerOn(event->scenePos());
        view->scale(scaleFactor, scaleFactor);
    }
}

void SysDefShotlineScene::keyPressEvent(QKeyEvent *event)
{
    if (event->key() == Qt::Key_Control) {
        m_controlHeld = true;
    }
}

void SysDefShotlineScene::keyReleaseEvent(QKeyEvent *event)
{
    if (event->key() == Qt::Key_Control) {
        m_controlHeld = false;
    }
}
