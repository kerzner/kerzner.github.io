#include "SysDefShotlineView.h"

#include "IRDocument.h"
#include "SysDefDocument.h"
#include "SysDefEvaluator.h"
#include "GraphVizVisitor.h"
#include "GvGraph.h"
#include "IfrHelpers.h"
#include "NodeItem.h"
#include "FilterItem.h"
#include "EdgeItem.h"
#include "GraphItem.h"
#include "SysDefShotlineScene.h"

#include <QDebug>
#include <QGraphicsView>
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QLabel>
#include <QToolBar>

#include <math.h>

#include <QDoubleSpinBox>
#include <QToolButton>
#include <QAction>
#include <QPushButton>
#include <QSpacerItem>
#include <QMenu>
#include <QInputDialog>
#include <QSettings>
#include <QVariant>
#include <QApplication>
#include <QSplitter>
#include <QPlainTextEdit>

SysDefShotlineView::SysDefShotlineView(QWidget *parent)
    : ShotlineView(parent)
    , m_irDoc(NULL)
    , m_sysDefDoc(NULL)
    , m_graphicsView(NULL)
    , m_graph(NULL)
    , m_sceneCreated(false)
    , m_systemsMenu(new QMenu("Systems", this))
    , m_expandComponents(false)
{
    m_graphicsView = new QGraphicsView(this);
    m_graphicsView->setRenderHint(QPainter::Antialiasing);
    m_graphicsView->setDragMode(QGraphicsView::ScrollHandDrag);

    m_splitter = new QSplitter(Qt::Vertical);
    m_text = new QPlainTextEdit();
    m_text->setReadOnly(true);

    m_splitter->addWidget(m_graphicsView);
    m_splitter->addWidget(m_text);

#if defined(SYSDEFSHOTLINEVIEW_DEBUG)
    m_verbose = qApp->arguments().contains("--verbose",Qt::CaseInsensitive);
#endif // defined(SYSDEFSHOTLINEVIEW_DEBUG)

    settingsLoad();

    QVBoxLayout *layout = new QVBoxLayout();
    layout->addWidget(m_splitter);
    setLayout(layout);
}

SysDefShotlineView::~SysDefShotlineView()
{
    settingsSave();
}

bool SysDefShotlineView::isConnectedToDoc(ApplicationDocument *doc)
{
    return doc == m_irDoc || doc == m_sysDefDoc;
}

void SysDefShotlineView::settingsLoad()
{
    QSettings settings(qApp->organizationName(), qApp->applicationName());
    QVariant variant;

    // Load the nodeSpacing.
    variant = settings.value("nodeSpacing", QVariant(0.50f));
    m_nodeSpacing = variant.toFloat();

    // Load m_expandComponents.
    variant = settings.value("expandComponents", QVariant(true));
    m_expandComponents = variant.toBool();

    m_splitter->restoreState(settings.value("sysDefSplitter").toByteArray());
}

void SysDefShotlineView::updateShotlines()
{
    // Clean up saved data before updating shotlines.
    delete m_graph;
    m_graphicsView->scene()->clear();
    m_damagedMaps.clear();
    create();
}

void SysDefShotlineView::showAimPointDialog()
{
    m_irDoc->showAimPointDialog();
}

void SysDefShotlineView::setMouseHoverHighlight(const QMap<int, QList<int> > &map, const int &component, const bool &highlight, const int &)
{
    // Disable all highlighting
    foreach (QGraphicsItem *item, m_graphicsView->scene()->items()) {
        GraphItem *graphItem = dynamic_cast<GraphItem*>(item);
        if (graphItem) {
            graphItem->setHighlighting(false);
        }
    }

    // Enable select highlighting
    QStringList componentNames = m_irDoc->getComponentNames(map);

    foreach (QString componentName, componentNames) {
        GraphItem *graphItem = graphicsViewItem(componentName);
        if (graphItem) {
            graphItem->setHighlighting(highlight);
        }
    }
}

void SysDefShotlineView::setSelectedItemInTextEdit(QString name)
{
    name = reAddQualifier(name);
    m_text->setPlainText(m_sysDefDoc->getSystemString(name));
}

void SysDefShotlineView::topLevelSystemsChanged()
{
    QList<qulonglong> itemData;
    foreach (QAction *action, m_systemsMenu->actions()) {
        if (action->isChecked()) {
            itemData << action->data().toULongLong();
        }
    }

    // set all items as not salient
    foreach (QGraphicsItem *item, m_graphicsView->scene()->items()) {
        GraphItem *graphItem = dynamic_cast<GraphItem*>(item);
        if (graphItem) {
            graphItem->setSalient(false);
        }
    }

    // set the selected items as salient
    foreach (qulonglong item, itemData) {
        GraphItem *graphItem = graphicsViewItem(item);
        graphItem->setSalient(true);
    }
}

void SysDefShotlineView::showAllTopLevelSystems()
{
    foreach (QAction *action, m_systemsMenu->actions()) {
        action->setChecked(true);
    }
    topLevelSystemsChanged();
}

void SysDefShotlineView::showNoTopLevelSystems()
{
    foreach (QAction *action, m_systemsMenu->actions()) {
        action->setChecked(false);
    }
    topLevelSystemsChanged();
}

void SysDefShotlineView::nodeSpacingTriggered()
{
    bool ok;
    double d = QInputDialog::getDouble(this, QString("Enter node spacing"),
                                       QString("Node spacing:"), m_nodeSpacing, 0.0, 5.0, 3, &ok);
    if (ok) {
        m_nodeSpacing = (float) d;
        updateShotlines();
    }
}

void SysDefShotlineView::setExpandComponents(bool value)
{
    m_expandComponents = value;
    updateShotlines();
}

void SysDefShotlineView::attachDocument(ApplicationDocument *doc)
{
    IRDocument *irDoc = dynamic_cast<IRDocument*>(doc);
    SysDefDocument *sysDefDoc = dynamic_cast<SysDefDocument*>(doc);

    if (irDoc) {
        QString fileName = doc->getCurrentOpenFileName();
        QStringList s = fileName.split("/");
        fileName = s[s.size()-1];
        setWindowTitle("SysDef Shotline View - " + fileName);

        m_irDoc = irDoc;

        connect(m_irDoc, SIGNAL(changeAllShotlines()),
                this, SLOT(updateShotlines()));

        m_appDoc = m_irDoc;
    } else if (sysDefDoc) {

        m_sysDefDoc = sysDefDoc;

        QString fileName = doc->getCurrentOpenFileName();
        QStringList s = fileName.split("/");
        fileName = s[s.size()-1];
        setWindowTitle("SysDef Shotline View - " + fileName);
    }

    if (!m_sceneCreated && m_sysDefDoc && m_irDoc) {
        create();
        m_sceneCreated = true;
    }
}

QString SysDefShotlineView::documentAsGraphVizInput()
{
    QString graph;
    QTextStream stream(&graph);
    stream << "digraph G {\n";

    for (int sysIdx = SeSyDStart; sysIdx < m_sysDefDoc->getNumSystems(); sysIdx++) {
        GraphVizVisitor visitor(m_sysDefDoc, false);

        QString parentName = "\"";
        parentName.append(m_sysDefDoc->getSystemName(sysIdx));
        parentName.append("\"");

        visitor.setParentName(parentName);
        visitor.visitSystem(sysIdx);

        stream << visitor.getResult();
    }

    stream << "}";
    return graph;
}

QString SysDefShotlineView::documentAsFilteredGraphVizInput()
{
    // This method converts the damaged components and systems into a string
    // that we can feed to GraphViz.

    // 1. Get a list of all damaged components and systems with qualifiers
    // 2. Prepare a string of GraphViz input to be populated.
    // 3. Loop over all systems and components.
    // 4. For each system, use a GraphVizVisitor to get its representation.
    // 5. Append that representation to the GraphViz input.

    // 1. Get a list of all damaged components and systems with qualifiers
    QStringList damagedQualified;
    QMapIterator<int, QMap<QString, float> > itr(m_damagedMaps);
    while (itr.hasNext()) {
        itr.next();
        damagedQualified.append(itr.value().keys());
    }

    // 2. Prepare a string of GraphViz input to be populated.
    QString graphVizInput;
    QTextStream stream(&graphVizInput);
    stream << "digraph G {\n";

#if defined(SYSDEFSHOTLINEVIEW_DEBUG)
    if (m_verbose) {
        qDebug() << Q_FUNC_INFO;
        qDebug() << "-looping over " << m_sysDefDoc->getNumSystems() << "systems:";
    }
#endif // defined(SYSDEFSHOTLINEVIEW_DEBUG)

    // 3. Loop over all systems and components. Here it seems like we could loop
    // over just the damaged systems and components, instead of searching all
    // of them. At first we did not filter by damaged components, which is where
    // this loop came from.
    for (int sysIdx = SeSyDStart; sysIdx < m_sysDefDoc->getNumSystems(); sysIdx++) {
        QString sysName = m_sysDefDoc->getSystemName(sysIdx);

        // Parse qualifier from sysName.
        QString qualifier = QString();
        m_sysDefDoc->baseName(sysName, &qualifier);

        // Get qualifier index.
        int qualifierIdx = -1;
        if (!qualifier.isEmpty()) {
            qualifierIdx = m_sysDefDoc->getQualifierIndex(qualifier);
        }

        // 4. For each system, use a GraphVizVisitor to get its representation.
        GraphVizVisitor visitor(m_sysDefDoc, true);
        visitor.setDamagedList(damagedQualified);

        // Is this system damaged?
        if (damagedQualified.contains(sysName)) {
            visitor.setParentName(sysName);
            visitor.visitSystem(sysIdx, qualifierIdx);
        }

#if defined(SYSDEFSHOTLINEVIEW_DEBUG)
        if (m_verbose) {
            qDebug() << "--system searched: " << sysName;
            qDebug() << "---qualifier index " << qualifierIdx;
            qDebug() << "---system string: " << m_sysDefDoc->getSystemString(sysName);
            qDebug() << "---children: " << visitor.getResult();
        }
#endif // defined(SYSDEFSHOTLINEVIEW_DEBUG)

        // 5. Append that representation to the GraphViz input.
        stream << visitor.getResult();
    }

    // Finish the GraphViz input.
    stream << "}";

#if defined(SYSDEFSHOTLINEVIEW_DEBUG)
    if (m_verbose) {
        qDebug() << "-graphviz input string:" << graphVizInput;
    }
#endif // defined(SYSDEFSHOTLINEVIEW_DEBUG)

    return graphVizInput;
}

void SysDefShotlineView::graphicsViewAddNodes()
{
    // This method adds the nodes from m_graph to m_graphicsView.
    // 1. If we're expanding components then treat all nodes as the same.
    // 2. If we're not expanding components then first add leaves with multiple
    //    parents and internal nodes. Then add leaves with only parent.

    QList<int> aimPoints = m_irDoc->getAimPoints();

    // List of nodes that we will add to the scene.
    QList<GvNode> gvNodes = m_graph->nodes();
    QMutableListIterator<GvNode> nodeItr(gvNodes);

    while (nodeItr.hasNext()) {
        nodeItr.next();
        const GvNode &node = nodeItr.value();

        // Is node a leaf with multiple parents or not a leaf?
        // If we're NOT expanding the components, then we don't draw edges
        //      between leaves and their parents.
        // If we're expanding components then draw edges between everything!
        if ((!m_expandComponents && (node.outDegree > 0 || node.inDegree > 1))
            || m_expandComponents) {

            // Create node item. Put it at the origin for now.
            NodeItem *nodeItem = new NodeItem(0, 0, node.width, node.height);
            nodeItem->setText(node.name, m_graph->font());

            // We stripped qualifiers from the nodes when computing the graphviz
            // layout, but we need qualified names to look up damage values.
            QString nameQualified = reAddQualifier(node.name);

            // Add pk glyphs to the node -- requires looking up qualified name
            // in the damage maps.
            foreach (int aimPoint, aimPoints) {
                if (m_damagedMaps[aimPoint].contains(nameQualified)) {
                    nodeItem->addPk(m_damagedMaps[aimPoint][nameQualified], m_irDoc->getThreatColor(aimPoint));
                }
            }

            // Use GraphViz's internal pointer as one key for finding this node.
            nodeItem->setData(Qt::UserRole, QVariant((qulonglong) node.node));

            // Add the node to the scene.
            nodeItem->setCenterPos(node.centerPos);
            m_graphicsView->scene()->addItem(nodeItem);

            // Install event filter for mouse over.
            nodeItem->setAcceptsHoverEvents(true);
            nodeItem->installSceneEventFilter(m_filterItem);

            // Allow user to select items for click-to-see-text-description.
            nodeItem->setFlags(QGraphicsItem::ItemIsSelectable);

            // Finished with this node!
            nodeItr.remove();
        }
    }

    // If we're not expanding components then draw the leaves as bubbles.
    if (!m_expandComponents) {

        // Remaining nodes in gvNodes must be leaves with only one parent.
        nodeItr = QMutableListIterator<GvNode>(gvNodes);
        while (nodeItr.hasNext()) {

            nodeItr.next();
            const GvNode &node = nodeItr.value();

            // Get the node's single parent. Use the GraphViz structure to
            // find node's parents then look them up in the graphicsView.
            QList<Agnode_t*> parents = m_graph->nodeParents(node.node);
            NodeItem *nodeItem = dynamic_cast<NodeItem*>(graphicsViewItem((qulonglong) parents.at(0)));
            QString nameQualified = node.name + m_irDoc->getCurrentQualifier();

            // Count number of aimpoints that hit this node. This is used to
            // compute size of the leaf.
            int hitCount = 0;
            foreach (int aimPoint, aimPoints) {
                if (m_damagedMaps[aimPoint].contains(nameQualified)) {
                    hitCount = hitCount + 1;
                }
            }

            // Add the leaf to the parent node.
            nodeItem->addLeafComponent(node.name, hitCount, m_filterItem);

            // For each leaf component, add the pK values to the view.
            foreach (int aimPoint, aimPoints) {
                if (m_damagedMaps[aimPoint].contains(nameQualified)) {
                    QColor color = m_irDoc->getThreatColor(aimPoint);
                    float pk = m_damagedMaps[aimPoint][nameQualified];
                    nodeItem->addPkToLeafComponent(node.name, pk, color);
                }
            }
        }
    }
}

void SysDefShotlineView::graphicsViewAddEdges()
{
    // 1. Loop over all edges from the GraphViz graph.
    // 2. If expanding components (i.e, not drawing them as bubbles) then add
    //      all edges. Otherwise, draw only edges to non-leaf nodes or leaves
    //      with multiple parents.
    // 3. Only add edges that represent damage flowing up the tree. Do not add
    //      edges for nodes whose parent's are not damaged.
    // 4. For actually creating the edges, *ignore* the GraphViz edge structure.
    //      Just draw edges between the center of head and tail.
    // 5. Adjust edge spacing based on the slop and number of edges.
    // 6. Add graphics items to the scene.
    // 7. Stitch together the graph data structure using edge's head and
    //      tail. This is for mouse-over interaction and top-down filtering.

    // Selectively add GvEdges to the QGraphicsScene.
    // Arbitrary constants. These should probably be user-specified.
    const qreal penWidth = 2.0f;
    const qreal horizontalSpacing = 3.5f;

    // List of all edges produced by GraphViz.
    QList<GvEdge> edges = m_graph->edges();

    // 1. Loop over all edges from the GraphViz graph.
    foreach (GvEdge gvEdge, edges) {

        // 2. If expanding components (i.e, not drawing them as bubbles) then
        // add all edges. Otherwise, draw only edges to non-leaf nodes or leaves
        // with multiple parents
        if (((!m_expandComponents && (!m_graph->nodeIsLeaf(gvEdge.head) || m_graph->nodeDegreeIn(gvEdge.head) > 1)))
            || m_expandComponents) {

            // Track the number of edges parallel to the current edge. Use this
            // number to shift edges so they don't overlap.
            int numPaths = 0;

            // A GraphViz edge between two nodes means that there is atleast one
            // shotline that damages the tail and this damage propagates up to
            // the head. In this loop, we're looking for all the aimpoints that
            // damaged both the head and the tail. We will add an edge for each
            // one of them.
            foreach (int aimPoint, m_damagedMaps.keys()) {

                // 3. Only add edges that represent damage flowing up the tree.
                if (m_damagedMaps[aimPoint].contains(
                        (QString(reAddQualifier(gvEdge.head->name))))) {

                    // 4. For actually creating the edges, *ignore* the GraphViz
                    // edge structure. Just draw edges between the center of
                    // head and tail.
                    QPainterPath path;

                    // Get the head and tail from the scene.
                    QGraphicsRectItem *head = dynamic_cast<QGraphicsRectItem*>(
                                                  graphicsViewItem((qulonglong) gvEdge.head));

                    QGraphicsRectItem *tail = dynamic_cast<QGraphicsRectItem*>(
                                                  graphicsViewItem((qulonglong) gvEdge.tail));

                    // Path goes from the bottom center of the head to the top
                    // center of the tail.
                    path.moveTo(head->scenePos().x() + head->rect().width() / 2.0f,
                                head->scenePos().y());
                    path.lineTo(tail->scenePos().x() + tail->rect().width() / 2.0f,
                                tail->scenePos().y() + tail->rect().height());

                    // Create an edge that will hold the path.
                    EdgeItem *edgeItem = new EdgeItem(path);

                    // Color the path according to the aimpoint.
                    QPen pen(m_irDoc->getThreatColor(aimPoint));
                    pen.setWidthF(penWidth);
                    edgeItem->setPen(pen);

                    // 5. Adjust edge spacing based on the slop and number of edges.
                    // If there are multiple edges between a pair of nodes
                    // then multiple shotlines have damaged them so we need to
                    // space edges to make all of them visible.
                    if (numPaths++ > 0) {

                        // Assumes we're working with straight lines.
                        float slope = edgeItem->path().slopeAtPercent(0);

                        // Vertical lines get shifted only in the x direction.
                        if (!isfinite(slope)) {
                            edgeItem->translate(edgeItem->pen().widthF() + horizontalSpacing * numPaths, 0.0f);
                        } else {
                            // Other lines get shifted by a vector normal to them.
                            QPointF start = edgeItem->path().pointAtPercent(0);
                            QPointF end = edgeItem->path().pointAtPercent(1);

                            // perpStart and perpEnd define a line segment
                            // perpendicular to edgeItem.
                            QPointF perpStart = QPointF(start.x(), end.y());
                            QPointF perpEnd = QPointF(end.x(), start.y());

                            // If the slope is positive we need to reverse the
                            // translation direction. Thie ensures that the
                            // ordering of aim point edges is consistent
                            // regardless of edge direction.
                            QPointF dir = perpStart - perpEnd;
                            if (slope > 0) {
                                dir = -1 * dir;
                            }

                            // Actually do the translation for the edge.
                            dir = dir / sqrt(pow(dir.x(),2) + pow(dir.y(),2));
                            dir = QPointF(dir.x() * (pen.widthF() + horizontalSpacing * numPaths),
                                          dir.y() * (pen.widthF() + horizontalSpacing * numPaths));
                            edgeItem->translate(dir.x(), dir.y());
                        }
                    }

                    // 6. Add graphics items to the scene.
                    edgeItem->setData(Qt::UserRole, (qulonglong) gvEdge.edge);
                    m_graphicsView->scene()->addItem(edgeItem);

                    // 7. Stitch together the graph data structure using
                    // edge's head and tail. This is for mouse-over interaction
                    // and top-down filtering.
                    GraphItem *parent = graphicsViewItem((qulonglong) gvEdge.tail);
                    GraphItem *child = graphicsViewItem((qulonglong) gvEdge.head);

                    parent->addChildPtr(edgeItem);
                    edgeItem->addParentPtr(parent);

                    child->addParentPtr(edgeItem);
                    edgeItem->addChildPtr(child);
                }
            }
        }
    }
}

void SysDefShotlineView::initializeSystemsMenu()
{
    // Clear the button.
    foreach (QAction *action, m_systemsMenu->actions()) {
        m_systemsMenu->removeAction(action);
    }

    // Create push buttons for selecting all and none systems.
    QAction *showAll = new QAction(QString("Show all"), m_systemsMenu);
    connect(showAll, SIGNAL(triggered()),
            this, SLOT(showAllTopLevelSystems()));
    m_systemsMenu->addAction(showAll);

    QAction *showNone = new QAction(QString("Show none"), m_systemsMenu);
    connect(showNone, SIGNAL(triggered()),
            this, SLOT(showNoTopLevelSystems()));
    m_systemsMenu->addAction(showNone);

    m_systemsMenu->addSeparator();

    // Add item for each top level system.
    foreach (QGraphicsItem *item, m_graphicsView->scene()->items()) {
        GraphItem *graphItem = dynamic_cast<GraphItem*>(item);
        if (graphItem) {
            if (graphItem->getParentPtrs()->size() == 0) {
                QString itemName = graphItem->toQString();
                QAction *action = new QAction(m_systemsMenu);
                action->setText(itemName);
                action->setData(item->data(Qt::UserRole));
                action->setCheckable(true);
                action->setChecked(true);
                m_systemsMenu->addAction(action);
                connect(action, SIGNAL(triggered()), this, SLOT(topLevelSystemsChanged()));
            }
        }
    }
}

void SysDefShotlineView::create()
{
    // Main method for creating GraphViz representations from sysdef files.
    // 1. Derive list of all damaged components and systems.
    // 2. Get the damaged components and systems as GraphViz-formatted input.
    // 3. Initialize GraphViz.
    // 4. Tell GraphViz to compute the graph layout.
    // 5. Create a scene to hold the GraphViz node-link diagram.
    // 6. Create an event filter for the scene.
    // 7. Populate the scene with the GraphViz objects.
    // 8. Update the GUI so that user can select specific systems.

    // 1. Derive list of all damaged components and systems.
    evaluateDamage();

    // 2. Get the damaged components and systems as GraphViz-formatted input.
    QString graphVizInput = documentAsFilteredGraphVizInput();

    // 3. Initialize GraphViz.
    m_graph = new GvGraph(graphVizInput);
    m_graph->setNodeSep(m_nodeSpacing);

    // 4. Tell GraphViz to compute the graph layout.
    m_graph->applyLayout(m_expandComponents);

    // 5. Create a scene to hold the GraphViz node-link diagram.
    QGraphicsScene *scene = new SysDefShotlineScene(m_graphicsView);
    scene->setSceneRect(m_graph->boundingRect());
    m_graphicsView->setScene(scene);

    // 6. Create an event filter for the scene.
    // See FilterItem.h for an important note about this class.
    m_filterItem = new FilterItem();
    m_graphicsView->scene()->addItem(m_filterItem);
    m_filterItem->setView(this);

    // 7. Populate the scene with the GraphViz objects.
    graphicsViewAddNodes();
    graphicsViewAddEdges();

    // 8. Update the GUI so that user can select specific systems.
    initializeSystemsMenu();
}

void SysDefShotlineView::evaluateDamage()
{
#if defined(SYSDEFSHOTLINEVIEW_DEBUG)
    if (m_verbose) {
        qDebug() << Q_FUNC_INFO;
    }
#endif // defined(SYSDEFSHOTLINEVIEW_DEBUG)

    // This method evaluates the damage of all selected aimpoints. Its output
    // is the member "m_damagedMaps."
    // 1. Create an evaluator.
    // 2. For all aim points, get the qualified damaged components and compute
    //    the qualified damaged systems.
    // 3. Combine both the components and systems into m_damagedMaps.

    // 1. Create an evaluator.
    SysDefEvaluator evaluator(*m_sysDefDoc);
    QList<int> aimPoints = m_irDoc->getAimPoints();

    // 2. For all aim points, get the qualified damaged components and compute
    //    the qualified damaged systems.
    foreach (int aimPoint, aimPoints) {

        // Qualified components damaged for aimpoint.
        QMap<QString, float> componentsQualified = m_irDoc->getDamagedComponentsFromShotline(aimPoint);

        // Qualified systems damaged from aimpoint.
        QMap<QString, float> systemsQualified = evaluator.evaluateAllSystems(componentsQualified);

#if defined(SYSDEFSHOTLINEVIEW_DEBUG)
        if (m_verbose) {
            qDebug() << "-Aim point: " << aimPoint;
            qDebug() << "--qualified components: " << componentsQualified;
            qDebug() << "--qualified systems:" << systemsQualified;
        }
#endif // defined(SYSDEFSHOTLINEVIEW_DEBUG)

        // 3. Combine both the components and systems into m_damagedMaps.
        // Add the list of damaged systems to the all damage map.
        QMapIterator<QString, float> itr(systemsQualified);
        while (itr.hasNext()) {
            itr.next();
            if (itr.value() > 0.0f) {
                m_damagedMaps[aimPoint].insert(itr.key(), itr.value());
            }
        }

        // Add the list of damaged componetns to the damage map.
        itr = QMapIterator<QString, float>(componentsQualified);
        while (itr.hasNext()) {
            itr.next();
            if (itr.value() > 0.0f) {
                m_damagedMaps[aimPoint].insert(itr.key(), itr.value());
            }
        }
    }
}

GraphItem *SysDefShotlineView::graphicsViewItem(qulonglong userData)
{
    foreach (QGraphicsItem *item, m_graphicsView->scene()->items()) {
        if (item->data(Qt::UserRole) == userData) {
            return dynamic_cast<GraphItem*>(item);
        }
    }
    return NULL;
}

GraphItem *SysDefShotlineView::graphicsViewItem(QString name)
{
    foreach (QGraphicsItem *item, m_graphicsView->scene()->items()) {
        GraphItem *graphItem = dynamic_cast<GraphItem*>(item);
        if (graphItem) {
            if (graphItem->toQString() == name) {
                return graphItem;
            }
        }
    }
    return NULL;
}

QString SysDefShotlineView::reAddQualifier(QString name)
{
    // Some systems do not have qualifiers but their children do. e.g.,
    // mobility = Engine[pk_main] | ...
    // When we look up "mobility" in the damage maps then it should not have a
    // qualifier. But when we look up "Engine" it should have a qualifier.

    // When we display nodes in the graph, we always strip the qualifier. But
    // we need a rule for re-adding qualifiers. Particularly, if a system or
    // component exists with the current qualifier then we will use the
    // qualified name. Otherwise we use the unqualified name.
    QString nameQualified = name + m_irDoc->getCurrentQualifier();

    bool nameQualifiedFound = false;

    foreach (int aimPoint, m_irDoc->getAimPoints()) {
        if (m_damagedMaps[aimPoint].contains(nameQualified)) {
            nameQualifiedFound = true;
        }
    }

    if (!nameQualifiedFound) {
        nameQualified = name;
    }

    return nameQualified;
}

QList<QMenu*> SysDefShotlineView::createMenus()
{
    QList<QMenu*> menus;
    menus << m_systemsMenu;

    QMenu *preferences = new QMenu("Preferences", this);
    QAction *nodeSeperation = new QAction("Node spacing", preferences);

    connect(nodeSeperation, SIGNAL(triggered()), this, SLOT(nodeSpacingTriggered()));
    preferences->addAction(nodeSeperation);

    QAction *action = new QAction("Expand components", preferences);
    action->setCheckable(true);
    connect(action, SIGNAL(toggled(bool)), this, SLOT(setExpandComponents(bool)));
    action->setChecked(m_expandComponents);
    preferences->addAction(action);
    menus << preferences;

    return menus;
}

void SysDefShotlineView::settingsSave()
{
    QSettings settings(qApp->organizationName(), qApp->applicationName());
    settings.setValue("nodeSpacing", m_nodeSpacing);
    settings.setValue("expandComponents", m_expandComponents);
    settings.setValue("sysDefSplitter", m_splitter->saveState());
}

QWidget *SysDefShotlineView::getImageWidget() const
{
    return m_graphicsView;
}
