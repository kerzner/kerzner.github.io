#ifndef GVSTRUCTS_H
#define GVSTRUCTS_H

#include "QPainterPath"

class Agnode_t;
class Agedge_t;

/** A struct containing the information for a GVGraph's node.
 *
 */
struct GvNode {
    /// The unique identifier of the node in the graph
    QString name;

    /// The position of the center point of the node from the top-left corner
    QPoint centerPos;

    /// The size of the node in pixels
    qreal height, width;

    /// Number of edges leaving this node (0 only if leaf)
    int outDegree;

    int inDegree;

    Agnode_t *node;
};

/** A struct containing the information for a GvGraph's edge.
 *
 */
struct GvEdge {
    /// The source and target nodes of the edge
    QString source;

    QString target;

    /// Path of the edge's line
    QPainterPath path;

    Agnode_t *head;

    Agnode_t *tail;

    Agedge_t *edge;
};

#endif // GVSTRUCTS_H
