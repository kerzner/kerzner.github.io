#ifndef SHOTVIEWERPLUGIN_H
#define SHOTVIEWERPLUGIN_H

#include "ShotViewerPlugin_global.h"
#include <QObject>
#include <QMap>
#include "ICommandLinePlugin.h"
#include "IDocPlugin.h"
#include "IViewPlugin.h"
#include "ApplicationDocument.h"
#include "ApplicationView.h"

/**
 * @brief The ShotViewerPlugin class.
 *
 * TODO: document
 */
class SHOTVIEWERPLUGINSHARED_EXPORT ShotViewerPlugin : public QObject,
    public IDocPlugin,
    public IViewPlugin,
    public ICommandLinePlugin
{
    Q_OBJECT
    Q_INTERFACES(ICommandLinePlugin)
    Q_INTERFACES(IDocPlugin)
    Q_INTERFACES(IViewPlugin)

public:

    ShotViewerPlugin(QObject *parent = 0);

    ~ShotViewerPlugin();

    //------------ ICommandLinePlugin -------------

    /// Report command line options for opening IR files
    QStringList getCommandLineOptions();

    /// Handle command line arguments
    void handleArguments(QStringList arguments);

    //---------------- IDocPlugin -----------------

    /// Returns a list of filename extensions the plugin can load
    QStringList getFilenameExtensions();

    /// Get the category of document (eg. "Text" or "Sysdef" or "Geometry")
    /// This must also be the name of the type of application model that is
    /// created.
    QString getDocumentCategory();

    /// Generate a document of the type this plugin supports.
    ApplicationDocument * createDocument();

    /// Returns a human-readable name of the plugin.
    /// This should be indicative of the function(s) provided.
    QString getPluginName();

    /// The list of views that are opened by default when this type of
    /// document is loaded.
    QStringList defaultViews();

    //---------------- IViewPlugin -----------------

    /// Get the category of view (eg. "3D" or "Tree" ).
    /// This is also the name of view type.
    QStringList getViewNames();

    /// Get the type of application model we know how to display.
    QStringList dataModelTypesSupported(const QString viewName);

    /// Generate a view.
    ApplicationView *genView(const QString name);

private:

    /// This variables are filled by command line arguments. They must be cached here until this plugin creates the appropriate document of view.

    /// List of aimpoints to load.
    QList<int> m_aimPoints;

    /// Name of threat to load.
    QString m_threatName;

    /// Columns to be displayed in table view
    QStringList m_initialColumns;
};

#endif // SHOTVIEWERPLUGIN_H
