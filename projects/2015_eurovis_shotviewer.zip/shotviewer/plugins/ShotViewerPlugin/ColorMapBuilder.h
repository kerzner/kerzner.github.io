#ifndef COLORMAPBUILDER_H
#define COLORMAPBUILDER_H

#include <QWidget>
#include "ColorMap.h"

namespace Ui
{
class ColorMapBuilder;
}

class ColorMapBuilder : public QWidget
{
    Q_OBJECT

public:
    explicit ColorMapBuilder(QWidget *parent = 0);
    ~ColorMapBuilder();

    ColorMap *getCurrentColorMap();
    void loadFile(QString name);

private slots:
    void on_insertColor_clicked();

    void on_removeColor_clicked();

    void on_interpolateColors_clicked(bool checked);

    void on_separateMin_clicked(bool checked);

    void on_separateMax_clicked(bool checked);

    void resizeEvent(QResizeEvent *event);

    void showEvent(QShowEvent *event);

    void on_colorMaps_currentIndexChanged(int index);

    void on_ok_clicked();

    void on_save_clicked();

    void on_load_clicked();

    void insertColorMap(ColorMap *colorMap = 0);

    void setColorMapName(QString name);

signals:
    void exceededMaxColors(unsigned maxColors);

    void newColors(QList<QColor> colors, bool interpolated);

    void colorMapSelected(ColorMap *);

private:
    void colorsChanged();
    void updateColorMapAndScale(ColorMap *colorMap = 0);

    Ui::ColorMapBuilder *ui;

    QList<ColorMap *> m_colorMaps;
};

#endif // COLORMAPBUILDER_H
