#ifndef REGMAPAPPLICATIONDOCUMENT_H
#define REGMAPAPPLICATIONDOCUMENT_H

#include "ApplicationDocument.h"
#include <QTextDocument>
#include <QHash>
#include <QTextStream>
class TextApplicationView;

/** The RegmapApplicationDocument is a document that parses MUVES regmap files.
 * It is used for converting MUVES component names into BRLCAD region Ids.
 *
 * This class is based on example regmap files instead of some well-defined
 * grammar. There are 3 types of region definitions that this class can parse:
 * 1. lines in the form: regionName regionId
 * 2. lines in the form: regionName regionIdStart:regionIdEnd
 * 3. lines starting with # are comments
 * Where the regionId is replaced by integers.
 *
 * This class is used mainly by the OsgView which will ask for a list of regions
 * using the getRegions(...) methods.
 *
 * This class recognizes an error has occured when someone looks up a region
 * name that does not exist. An error is added to the start m_errorString which
 * can be accessed by the methods get/clear/hasErrors().
 */
class RegmapApplicationDocument : public ApplicationDocument
{
    Q_OBJECT

public:

    RegmapApplicationDocument(QObject *parent = 0);

    /// Import a file to the document.  This will set the document file name if
    /// the document was previously empty. This method emits "documentLoaded"
    /// when the document is finished loading. (on first import only?)
    bool importFileByName(QString fileName);

    /// Save the document to the current file name.
    /// Left over from TextApplicationDocument (TODO: delete this!)
    void saveFile();

    /// Save the document to an alternate file name.
    /// Sets the current document name
    /// Left over from TextApplicationDocument (TODO: delete this!)
    void saveFileByName(QString fileName);

    /// Gets the text string which indicates the type or category of this
    /// document within the application. (eg "Text" or "SysDef" or "Geometry")
    QString getDocumentType();

    /// Get the underlying Qt text document
    /// XXX: LAYER VIOLATION
    /// Left over from TextApplicationDocument (TODO: delete this!)
    QTextDocument &getData();

    /// Returns a list of regions from unqualified muves names.
    QList<int> getRegions(const QString &muvesName);
    QList<int> getRegions(const QStringList &muvesNames);
    QList<int> getRegions(const QList<QRegExp> &muvesNames);

    QString getMuvesName(const int region) const;

    bool hasErrors() const
    {
        return !m_errorString.isEmpty();
    }

    QString getErrors()
    {
        return m_errorString;
    }

    void clearErrors()
    {
        m_errorString.clear();
    }

private:

    // Helper functions ///////////////////////////////////////////////////////

    /// Left over from TextApplicationDocument (TODO: delete this!)
    void setFileName(const QString &fileName);

    /// Parses the QTextStream into a m_regmap.
    QHash<QString, QList<int> > parseFile(QTextStream &in);

    /// Parses lines in the form "muvesName regionIdStart:regionIdEnd"
    QList<int> parseRange(QString &range);

    // Private data memebers //////////////////////////////////////////////////

    /// This can probably be removed.
    QTextDocument m_document;

    /// keys = muves names, values = regionIds.
    QHash<QString, QList<int> > m_regmap;

    /// keys = regionIds, values = muves names
    QMultiHash<int, QString> m_inverseRegmap;

    /// Error messages resulting from looking up invalid muves names.
    QString m_errorString;
};

#endif // REGMAPAPPLICATIONDOCUMENT_H
