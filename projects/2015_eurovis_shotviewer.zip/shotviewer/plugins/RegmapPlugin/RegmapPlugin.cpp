#include "RegmapPlugin.h"

#include "RegmapApplicationDocument.h"
#include "RegmapApplicationView.h"

RegmapPlugin::RegmapPlugin(QObject *parent) :
    QObject(parent)
{
    /*no-op*/
}

RegmapPlugin::~RegmapPlugin()
{
    /*no-op*/
}

//---------------- IDocPlugin -----------------

QStringList RegmapPlugin::getFilenameExtensions()
{
    QStringList extList;
    extList.append("regmap");
    return extList;
}

QString RegmapPlugin::getDocumentCategory()
{
    return QString("Regmap");
}

ApplicationDocument * RegmapPlugin::createDocument()
{
    return new RegmapApplicationDocument;
}

QString RegmapPlugin::getPluginName()
{
    return QString("RegmapPlugin");
}

QStringList RegmapPlugin::defaultViews()
{
    QStringList views;
    views.append("RegmapView");
    return views;
}

//---------------- IViewPlugin -----------------

QStringList RegmapPlugin::getViewNames()
{
    QStringList viewNames;
    viewNames.append("RegmapView");

    return viewNames;
}

QStringList RegmapPlugin::dataModelTypesSupported(const QString viewName)
{
    QStringList models;

    if (!viewName.compare("RegmapView"))
        models.append("Regmap");

    return models;
}

ApplicationView *RegmapPlugin::genView(const QString name)
{
    if (name.compare("RegmapView"))
        return NULL;

    // XXX construct an ApplicationView here
    return new RegmapApplicationView;
}

#if 0
QMap<QString, ApplicationDocument (*)()> RegmapPlugin::extsToConstruction()
{
    QMap<QString, ApplicationDocument (*)()> mapping;

    return mapping;
}
#endif

#if QT_VERSION < 0x050000
Q_EXPORT_PLUGIN2(RegmapPlugin, RegmapPlugin)
#endif
