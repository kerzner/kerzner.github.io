#include "RegmapApplicationView.h"
#include "RegmapApplicationDocument.h"
#include <QApplication>
#include <QGridLayout>

RegmapApplicationView::RegmapApplicationView()
{
    QGridLayout *gl = new QGridLayout(this);
    gl->setContentsMargins(0, 0, 0, 0);
    gl->addWidget(&m_TextEdit);
    m_TextEdit.setParent(this);
    m_TextEdit.setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Expanding);
    m_TextEdit.setMaximumSize(16777215, 16777215);
    m_TextEdit.setMinimumSize(400, 400);
}

QStringList RegmapApplicationView::getRequiredDocTypes()
{
    QStringList types;
    types.append("Regmap");
    return types;
}

void RegmapApplicationView::attachDocument(ApplicationDocument *doc)
{
    RegmapApplicationDocument *tad = dynamic_cast<RegmapApplicationDocument *>(doc);

    // Set the QTextDocument if it is a valid TextAplicationDocument
    if (tad) {
        m_appDoc = doc;
        m_TextEdit.setDocument(&tad->getData());

        this->setWindowTitle(tad->getCurrentOpenFileName());
    }
}
