#ifndef REGMAPAPPLICATIONVIEW_H
#define REGMAPAPPLICATIONVIEW_H

#include <QWidget>
#include "ApplicationView.h"
#include <QTextEdit>

class RegmapApplicationDocument;

/**
 * @brief The RegmapApplicationView is just a refactored TextApplicationView. It
 * doesn't do very much.
 */
class RegmapApplicationView : public ApplicationView
{
    Q_OBJECT

public:

    RegmapApplicationView();

    QStringList getRequiredDocTypes();

private:

    /// Attach a TextApplicationDocument, otherwise does nothing
    void attachDocument(ApplicationDocument *doc);

    QTextEdit m_TextEdit;
};

#endif // REGMAPAPPLICATIONVIEW_H
