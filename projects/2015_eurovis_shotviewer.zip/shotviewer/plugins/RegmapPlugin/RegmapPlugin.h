#ifndef REGMAPPLUGIN_H
#define REGMAPPLUGIN_H

#include "RegmapPlugin_global.h"
#include <QObject>
#include <QMap>
#include "IDocPlugin.h"
#include "IViewPlugin.h"
#include "ApplicationDocument.h"
#include "ApplicationView.h"

/**
 * @brief The RegmapPlugin class for loading MUVES regmap files.
 */
class REGMAPPLUGINSHARED_EXPORT RegmapPlugin : public QObject,
    public IDocPlugin,
    public IViewPlugin
{
    Q_OBJECT
    Q_INTERFACES(IDocPlugin)
    Q_INTERFACES(IViewPlugin)
#if QT_VERSION >= 0x050000
    Q_PLUGIN_METADATA (IID "mil.army.arl.lee.RegmapPlugin")
#endif

public:

    RegmapPlugin(QObject *parent = 0);

    ~RegmapPlugin();

    //---------------- IDocPlugin -----------------

    /// Returns a list of filename extensions the plugin can load
    QStringList getFilenameExtensions();

    /// Get the category of document (eg. "Regmap" or "Sysdef" or "Geometry")
    /// This must also be the name of the type of application model that is
    /// created.
    QString getDocumentCategory();

    /// Generate a document of the type this plugin supports.
    ApplicationDocument * createDocument();

    /// Returns a human-readable name of the plugin.
    /// This should be indicative of the function(s) provided.
    QString getPluginName();

    /// The list of views that are opened by default when this type of
    /// document is loaded.
    QStringList defaultViews();

    //---------------- IViewPlugin -----------------

    /// Get the category of view (eg. "3D" or "Tree" ).
    /// This is also the name of view type.
    QStringList getViewNames();

    /// Get the type of application model we know how to display.
    QStringList dataModelTypesSupported(const QString viewName);

    /// Generate a view.
    ApplicationView *genView(const QString name);
};

#endif // REGMAPPLUGIN_H
