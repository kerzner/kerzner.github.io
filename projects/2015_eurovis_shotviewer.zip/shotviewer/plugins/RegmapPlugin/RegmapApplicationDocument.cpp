#include "RegmapApplicationDocument.h"

#include <QFile>
#include <QTextStream>
#include <QDebug>
#include <QStringList>

RegmapApplicationDocument::RegmapApplicationDocument(QObject *parent) :
    ApplicationDocument(parent)
{
    /*no-op*/
}

bool RegmapApplicationDocument::importFileByName(QString fileName)
{
    // open the file
    QFile file(fileName);
    if (!file.open(QIODevice::ReadOnly | QIODevice::Text)) {
        emit fileImportFailed();
        return false;
    }

    // read the contents
    // XXX ideally this would be done in a separate thread using QtConcurrent::run()
    QTextStream in(&file);
    QString buffer = in.readAll();

    if (m_document.isEmpty()) {
        // first import
        m_document.setPlainText(buffer);
        setFileName(fileName);
        m_document.setModified(false);
    } else {
        QString preload = m_document.toPlainText();

        preload.append(buffer);

        m_document.setPlainText(preload);
        m_document.setModified(true);
    }

    // Reset to start of file and parse it.
    file.reset();
    m_regmap = parseFile(in);

    emit fileImportCompleted();
    return true;
}

void RegmapApplicationDocument::setFileName(const QString &fileName)
{
    emit fileNameWillChange(m_fileName, fileName);
    m_fileName = fileName;
}

QHash<QString, QList<int> > RegmapApplicationDocument::parseFile(QTextStream &in)
{
    m_inverseRegmap.clear();
    QHash<QString, QList<int> > regmap;
    while (!in.atEnd()) {

        // Cut leading white space off of the line.
        QString line = in.readLine().trimmed();

        // Ignore comment lines
        if (line.startsWith("#")) {
            continue;
        } else {
            // Split on white space of any length.
            QStringList lineList = line.split(QRegExp("\\s+"));

            // Assumes the format is "name regionIds"
            if (lineList.length() > 1) {
                QString muvesName = lineList.takeFirst();

                QList<int> regions;

                foreach (QString item, lineList) {
                    // Ignore everything after the #.
                    if (item.contains("#")) {
                        break;
                    } else if (item.contains(":")) {
                        regions.append(parseRange(item));
                    } else {
                        regions.append(item.toInt());
                    }
                }
                regmap[muvesName] = regions;
                foreach (int region, regions) {
                    m_inverseRegmap.insertMulti(region, muvesName);
                }
            }
        }
    }
    return regmap;
}

QList<int> RegmapApplicationDocument::parseRange(QString &range)
{
    QList<int> regions;
    QStringList list = range.split(":");
    if (list.size() > 1) {
        int start = list.at(0).toInt();
        int end = list.at(1).toInt();
        for(int i = start; i <= end; i++) {
            regions.append(i);
        }
    }
    return regions;
}

void RegmapApplicationDocument::saveFile()
{
    saveFileByName(m_fileName);
}

void RegmapApplicationDocument::saveFileByName(QString fileName)
{
    QFile file(fileName);

    if (!file.open(QIODevice::WriteOnly | QIODevice::Text)) {
        emit fileSaveFailed();
        return;
    }

    // XXX ideally this would be done in a separate thread using QtConcurrent::run()
    QTextStream out(&file);
    out << m_document.toPlainText();

    out.flush();

    m_document.setModified(false);

    if (!m_fileName.compare(fileName)) {
        setFileName(fileName);
    }

    emit fileSaveCompleted();
}

QString RegmapApplicationDocument::getDocumentType()
{
    return QString("Regmap");
}

QTextDocument &RegmapApplicationDocument::getData()
{
    return m_document;
}

QList<int> RegmapApplicationDocument::getRegions(const QString &muvesName)
{
    // Ignore component names with no geometry.
    bool isMuvesGenerated = muvesName.contains("MUVES_target_gap") ||
                            muvesName.contains("MUVES_exit_paint");

    QList<int> list = QList<int>();

    if (!isMuvesGenerated) {
        // Do we have a component with this name?
        if (m_regmap.contains(muvesName)) {
            list = m_regmap[muvesName];
        } else {
            m_errorString.append("Failed to find region for component: " + muvesName + "\n");
        }
    }
    return list;
}

QList<int> RegmapApplicationDocument::getRegions(const QList<QRegExp> &muvesNames)
{
    QList<int> regions;
    QStringList regionNames = m_regmap.keys();

    // Loop over all regions and all muvesNames looking for matches.
    foreach (QString region, regionNames) {
        foreach (QRegExp regExp, muvesNames) {
            if (regExp.indexIn(region) != -1) {
                regions.append(m_regmap[region]);
            }
        }
    }

    // Remove duplicates.
    return regions.toSet().toList();
}

QString RegmapApplicationDocument::getMuvesName(const int region) const
{
    return m_inverseRegmap.value(region);
}

QList<int> RegmapApplicationDocument::getRegions(const QStringList &muvesNames)
{
    QList<int> regions;

    foreach (QString muvesName, muvesNames) {
        regions << getRegions(muvesName);
    }

    // Remove duplicates.
    return regions.toSet().toList();
}
