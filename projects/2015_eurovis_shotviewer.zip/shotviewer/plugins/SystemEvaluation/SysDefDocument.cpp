#include "SysDefDocument.h"

#include <QApplication>
#include <QStringList>
#include <QFileInfo>
#include "../ShotViewerPlugin/IfrHelpers.h"

extern "C" {
#include "Se.h"
#include "Er.h"
#include "Io.h"
#include "Dm.h"

// define name for debug output, hack for full path in __FILE__ (12-03-13 ch3)
#define DEBUG_NAME  "SysDefDocument"

#define DEBUG_ORDLIST   0x00000080
#define DEBUG_ENCODE    0x00000100
#define DEBUG_UNDEF     0x00000200
#define DEBUG_SETSYS    0x00000400
#define DEBUG_LISTS     0x00000800
#define DEBUG_EVAL      0x00001000
#define DEBUG_CODEARR   0x00002000
#define DEBUG_TABLE     0x00004000
#define DEBUG_FINDUSES  0x00008000
#define DEBUG_LOCKSYS   0x00010000

// Register a system to the user interface (called from C)
    void SeWrapperRegisterSystem(int index, void *ptr)
    {
        SysDefDocument *doc = (SysDefDocument *)ptr;
        doc->systemRegister(index);
    }

// Register a component to the user interface (called from C) (11-06-03 ch3)
// 11-06-18 ch3: added system index argument
    void SeWrapperRegisterComponent(int compindex, void *ptr)
    {
        SysDefDocument *doc = (SysDefDocument *)ptr;
        doc->componentRegister(compindex);
    }


// Register a system value changed to the user interface (called from C)
    void SeWrapperRegisterSystemValue(int index, void *ptr, SeTypeID type,
                                      double value)
    {
        //SysDefDocument *doc = (SysDefDocument *)ptr;
        // added value for new lock argument (11-12-13 ch3)
        //doc->systemValueSet(index, type, value, false);
    }

} // extern "C"

#include "SeVisitors.h"

NmPool RtComponents; // name pool required by Se package

SysDefDocument::SysDefDocument(QObject *parent) :
    ApplicationDocument(parent),
    m_seValues(NULL),
    m_SeDataSystem(SeDataSystem)
{
    DqPkgInit();

    ErPkgInit();
    IoPkgInit();

    NmPkgInit();

    SePkgInit();

    NmInit(&RtComponents);

    m_components = nm_namepool(&RtComponents);
    m_qualifiers = nm_namepool(&SeQualifiers);
    m_qualComps = nm_namepool(&SeComponents);
    m_systems = nm_namepool(&SeSystems);
    NmInit(&m_seQualSystems);
    m_qualSystems = nm_namepool(&m_seQualSystems);

    // Imported from SePrivate //////////
    QString sysdef = qApp->applicationDirPath() + "/../share/appCore/plugins/";
    m_vars = SeSysInit(qPrintable(sysdef), mTrue, this);

    // 11-05-04 ch3: added error check from initialization failure
    if (m_vars->error == SeFail2) {
        qDebug("SeSysInit() failed");
        SeSysTerm(m_vars);
        m_vars = NULL;
    }
    // allow #COMP: at begin of file if no components were loaded
    m_vars->allow_comps = NmCount(&RtComponents) == 0;

    // NOTE by default, the m_vars->allow_encode flag is set to false
    //      this flag allows systems when registered to be encoded
    //      somehow this flag will need to get set when systems need
    //      to be encoded, either this flag needs to get set appropriately
    //      here, or the encoding of the systems needs to be delayed
    /////////////////////////////////////
}

SysDefDocument::~SysDefDocument()
{
    SeSysTerm(m_vars);
    if (m_seValues) DmFree(m_seValues);
    NmClear(&RtComponents);
}

// TODO: remove this debugging code at some point
// Uncomment to do a quick test of evaluating the sysdef that was just loaded
//#define TEST_EVALUATION

#ifdef TEST_EVALUATION
# include "SysDefEvaluator.h"
# include <QDebug>
#endif

bool SysDefDocument::importFileByName(QString fileName)
{
    if (!SeSysReadFile(m_vars, qPrintable(fileName))) {
        // FIXME temporary (report to gui)
        //qDebug("ERROR: %s\n", m_priv->varsErrMsg());
        qDebug("ERROR: SysDefDocument::importFileByName");
        emit fileImportFailed();
        return false;  // FIXME for now just return
    }

    systemScanForAllowedSystems();

#if 0 //<--debug the loaded components from the file
    qDebug("------Components:\n");

    int ncomps = m_components->count();
    for (int i = 0; i < ncomps; ++i)
        qDebug("%s", m_components->getName(i));

    qDebug("\n------Systems:\n");

    int nsys = m_systems->count();
    for (int i = 0; i < nsys; ++i)
        qDebug("%s", m_systems->getName(i));

    qDebug("\n------Qualifiers:\n");

    int nqual = m_qualifiers->count();
    for (int i = 0; i < nqual; ++i)
        qDebug("%s", m_qualifiers->getName(i));

    qDebug("\n------Qualified Components:\n");

    int nqualc = m_qualComps->count();
    for (int i = 0; i < nqualc; ++i)
        qDebug("%s", m_qualComps->getName(i));
#endif

#ifdef TEST_EVALUATION//<--do a test evaluation for debugging
    // Get a random set of initial qualified component states
    QMap<QString, float> compVals;
    for (int i = 0; i < m_qualComps->size(); ++i)
        compVals[m_qualComps->getName(i)] = (float) rand() / RAND_MAX;

    // Create a sysdef evaluator
    SysDefEvaluator evaluator(*this);

    QMap<QString, float> sysVals = evaluator.evaluateAllSystems(compVals);

    qDebug() << sysVals;
#endif

    // if the document was previously "untitled"
    if (m_fileName.isEmpty()) {
        this->setFileName(fileName);
    }

    emit fileImportCompleted();
    return true;
}

QString SysDefDocument::getComponentName(int compindex)
{
    return m_components->getName(compindex);
}

QString SysDefDocument::getSystemName(int sysindex)
{
    return m_systems->getName(sysindex);
}

int SysDefDocument::getNumComponents()
{
    return m_components->count();
}

int SysDefDocument::getNumSystems()
{
    return m_systems->count();
}

int SysDefDocument::getNumQualifiers()
{
    return m_qualifiers->count();
}

int SysDefDocument::getNumQualifiedComponents()
{
    return m_qualComps->count();
}

int SysDefDocument::getNumQualifiedSystems()
{
    return m_qualSystems->count();
}

int SysDefDocument::getComponentID(QString componentName)
{
    return m_components->getIndex(qPrintable(componentName));
}

int SysDefDocument::getSystemID(QString systemName)
{
    return m_systems->getIndex(qPrintable(systemName));
}

int SysDefDocument::getQualifiedComponentID(QString componentName)
{
    return m_qualComps->getIndex(qPrintable(componentName));
}

int SysDefDocument::getQualifiedSystemID(QString systemName)
{
    return m_qualSystems->getIndex(qPrintable(systemName));
}

QString SysDefDocument::getQualifiedComponentName(int index)
{
    return m_qualComps->getName(index);
}

QString SysDefDocument::getQualifiedSystemName(int index)
{
    return m_qualSystems->getName(index);
}

void SysDefDocument::setFileName(const QString &fileName)
{
    emit fileNameWillChange(m_fileName, fileName);
    m_fileName = fileName;
}

void SysDefDocument::saveFile()
{
    saveFileByName(m_fileName);
}

void SysDefDocument::saveFileByName(QString fileName)
{
    //TODO: implement saving the geometry
    emit fileSaveCompleted();
}

QString SysDefDocument::getDocumentType()
{
    return QString("SysDef");
}


int SysDefDocument::qualifiedComponentIndex(int compIndex, int qualIndex)
{
    QString qualCompName = QString("%1[%2]")
                           .arg(m_components->getName(compIndex))
                           .arg(m_qualifiers->getName(qualIndex));

    return m_qualComps->addName(qPrintable(qualCompName));
}

int SysDefDocument::qualifiedComponentIndex(const QString qualName)
{
    return m_qualComps->getIndex(qPrintable(qualName));
}

void SysDefDocument::componentRegister(const int compindex)
{
    resizeValueTable(m_components->size());

    QString name = m_components->getName(compindex);
    //emit newComponent(name, compindex);
}

void SysDefDocument::systemRegister(const int index)
{
    if (!m_vars->allow_encode) {
        return;  // don't encode system
    }

    SeSysDef *sysdefp = SeDataSystem[index]->sysdef;
    if (sysdefp == NULL) {
        return;
    }

    // 11-12-06 ch3: resize code vector as needed
    if (index >= (int)m_sysCode.size()) {
        m_sysCode.resize(index + 1);
    }

    // 11-12-06 ch3: encode system
    QString message;
    if (!systemEncode(index, message)) {
        message.prepend(QString("Registering System:\n"
                                "System '%1' Encode Failure\n").arg(m_systems->getName(index)));
        //  QMessageBox::warning(0, tr("VSL-SysDef-Encode"), message,
        //      QMessageBox::Ok);
    }

    // add system index to list of new systems added list
    m_newSysIndexList.append(index);
}

void SysDefDocument::systemScanForAllowedSystems(void)
{
    foreach (int sysIndex, m_newSysIndexList) {
        SystemIsAllowedSysdefVisitor system(this);
        system.traverse(SeDataSystem[sysIndex]->sysdef);
        //emit newDefinedSystem(sysIndex, QString(m_systems->getName(sysIndex)),
        //    system.isAllowed());
    }
    m_newSysIndexList.clear();
}

QString SysDefDocument::qualifiedName(const QString &baseName,
                                      int qualIndex,
                                      const QString &qualifier)
{
    return QString("%1[%2]").arg(baseName).arg(qualIndex == -1
            ? qualifier : m_qualifiers->getName(qualIndex));
}

bool SysDefDocument::hasTable(void)
{
    return false;// !m_tableHash.isEmpty();
}

int SysDefDocument::negateIndex(int index)
{
    return -index - 1;
}

bool SysDefDocument::systemEncode(int index, QString &errmsg)
{
    if (SeDataSystem[index] == NULL) {
        errmsg.append(QString("\nUndefined System (%1)").arg(index));
        return false;
    }

    GetNodesSysdefVisitor getNodes(this);
    getNodes.traverse(SeDataSystem[index]->sysdef);
    SeCodeInfo &sysCode = m_sysCode[index];
    sysCode.codeArray.clear();
    if (getNodes.stopped()) {
        errmsg = getNodes.errorMessage();
        sysCode.qualSystems.clear();
        sysCode.orderList.clear();
        return false;
    }
    // get code size and add two for terminating assignment and index
    int codeSize = getNodes.codeSize() + 2;

    // encode evaluation nodes
    sysCode.qualSystems = getNodes.qualSystems();
    sysCode.codeArray.reserve(codeSize);
    sysCode.stackSize = 0;
    sysCode.frameSize = 0;
    int stackSize = 0;
    int frameSize = 0;
    //vslDebug(ENCODE, "%d-%s(%d):", index, m_systems->getName(index), codeSize);
    foreach (SeEvalNode node, getNodes.nodeList()) {
        sysCode.codeArray.append(node.typeAsInt());
        // get second word for double word types
        switch (node.type()) {
        case SeNT_SYSNAME:
            sysCode.codeArray.append(node.index());
            stackSize++;  // will push one value onto stack
            if (stackSize > sysCode.stackSize) {
                sysCode.stackSize = stackSize;
            }
            //vslDebugCont(ENCODE, " %d-%s", node.index(),
            //    m_systems->getName(node.index()));
            break;
        case SeNT_QUALSYS:
            // this node type will need to be changed to SYSNAME
            sysCode.codeArray.append(node.index());
            stackSize++;  // will push one value onto stack
            if (stackSize > sysCode.stackSize) {
                sysCode.stackSize = stackSize;
            }
            //vslDebugCont(ENCODE, " %d-%s", node.index(),
            // WORK if index is into m_qualSystems, get name from there
            //    qPrintable(m_qualSystems->getName(node.index())));
            break;
        case SeNT_COMPNAME:
            sysCode.codeArray.append(node.index());
            stackSize++;  // will push one value onto stack
            if (stackSize > sysCode.stackSize) {
                sysCode.stackSize = stackSize;
            }
            //vslDebugCont(ENCODE, " @%d-%s", node.index(),
            //    m_components(node.index()));
            break;
        case SeNT_QUALCOMP:
            // this node type will need to be changed to COMPNAME
            sysCode.codeArray.append(node.index());
            stackSize++;  // will push one value onto stack
            if (stackSize > sysCode.stackSize) {
                sysCode.stackSize = stackSize;
            }
            //vslDebugCont(ENCODE, " %d-%s", node.index(),
            //    m_qualComps->getName(node.index()));
            break;
        case SeNT_CONSTANT:
            sysCode.codeArray.append(node.valueAsInt());
            stackSize++;  // will push one value onto stack
            if (stackSize > sysCode.stackSize) {
                sysCode.stackSize = stackSize;
            }
            //vslDebugCont(ENCODE, " %g", node.value());
            break;
        case SeNT_NOT:
        case SeNT_ANOT:
        case SeNT_ABS:
        case SeNT_BOOL:
            // unary operators won't change stack
            //vslDebugCont(ENCODE, " %s", SeTtbl[node.type()].ts);
            break;

        // added support for function calls (12-03-16 ch3)
        case SeNT_FNCALL:
            // add number of arguments - 1 (amount to offset for parameters)
            // (no change to stack size)
            sysCode.codeArray.append(node.index() - 1);
            frameSize++;  // place to put stack pointer frame value
            if (frameSize > sysCode.frameSize) {
                sysCode.frameSize = frameSize;
            }
            //vslDebugCont(ENCODE, " FNBEG,%d", node.index() - 1);
            break;

        case SeNT_PARAM:
            sysCode.codeArray.append(node.index());  // argument number
            stackSize++;  // will push one value onto stack
            if (stackSize > sysCode.stackSize) {
                sysCode.stackSize = stackSize;
            }
            //vslDebugCont(ENCODE, " PARAM,%d", node.index());
            break;

        case SeNT_FUNCNAME:  // end of function call
            // end of functions will pull arguments from stack
            stackSize -= node.index();  // number of arguments
            // (the number of argument is not needed in the code)
            frameSize--;  // value pulled to reset stack pointer
            //vslDebugCont(ENCODE, " FNEND,%d", node.index() - 1);
            break;

        default:
            // binary operators will pull one value from stack
            stackSize--;
            // 12-03-16 ch3: only use SeTtbl[] for binary operators
            //vslDebugCont(ENCODE, " %s", SeIS_BINARY_OP(node.type())
            //    ? SeTtbl[node.type()].ts : SeCvtToStr(node.type()));
            break;
        }
    }

    // now add the assignment and system index (this node type is as
    // good as anything and won't otherwise be seen in an expression)
    sysCode.codeArray.append(SeNT_ASSIGNMENT);
    sysCode.codeArray.append(index);
    //vslDebugCont(ENCODE, " %s {%d,%d}\n", SeTtbl[SeNT_ASSIGNMENT].ts,
    //    sysCode.stackSize, sysCode.frameSize);

    // save order list
    sysCode.orderList = getNodes.orderList();
#ifdef DEBUG_BUILD
    vslDebugIf(ENCODE) {
        if (!sysCode.orderList.empty()) {
            vslPrint(" Order:");
            foreach (int sysIndex, sysCode.orderList) {
                vslPrintCont(" %s", m_systems->getName(sysIndex));
            }
            vslPrintCont("\n");
        }
    }
#endif
    return true;
}

void SysDefDocument::findSubSystems(QVector<bool> &topLevel, int sysIndex)
{
    SeCodeInfo &sysCode = m_sysCode[sysIndex];

    for (int i = 0; i < sysCode.orderList.size(); i++) {
        int index = sysCode.orderList.at(i);
        if (index < 0) {  // qualified system?
            index = negateIndex(index);
            QString sysName = baseName(m_qualSystems->getName(index));
            index = m_systems->getIndex(qPrintable(sysName));
        }
        findSubSystems(topLevel, index);
        // this system is used, so it's not a top-level system
        topLevel[index] = false;
    }
}

QString SysDefDocument::baseName(const QString &qualifiedName, QString *qualifier)
{
    QRegExp re("^([^[]+)\\[([^]]+)\\]$");

    if (re.indexIn(qualifiedName) == -1) {
        return qualifiedName;
    }

    if (qualifier) {
        *qualifier = re.capturedTexts().at(2);
    }

    return re.capturedTexts().at(1);
}

int SysDefDocument::getQualifierIndex(QString qualifierName)
{
    return m_qualifiers->getIndex(qPrintable(qualifierName));
}

#if 0
QList<int> SysDefDocument::componentTableList(const QString &qualCompName,
        int qualIndex)
{
    QList<int> tableList;

    if (hasTable()) {
        tableList = m_tableHash.value(qualCompName);
        if (tableList.isEmpty()) {
            QString qualifier = m_qualifiers->getName(qualIndex);
            if (qualifier.compare("ishit", Qt::CaseInsensitive) == 0
                || qualifier.compare("is_hit", Qt::CaseInsensitive) == 0) {
                tableList.append(SeTableOffsetIsHit);
            } else if (qualifier.compare("isthreatened", Qt::CaseInsensitive)
                       == 0
                       || qualifier.compare("is_threatened", Qt::CaseInsensitive)
                       == 0) {
                tableList.append(SeTableOffsetIsThreatened);
            } else if (qualifier.compare("los", Qt::CaseInsensitive) == 0
                       || qualifier.compare("line_of_sight", Qt::CaseInsensitive)
                       == 0
                       || qualifier.compare("line_of_site", Qt::CaseInsensitive)
                       == 0) {
                tableList.append(SeTableOffsetLineOfSite);
            }
            // else error, return empty table list
        }
    } else {
        tableList.append(SeTableOffsetUnSet);
    }
    return tableList;
}
#endif


void SysDefDocument::resizeValueTable(const int newSize)
{
    int start;

    // do nothing on shrink
    if (newSize < m_tableSize)
        return;

    if (!m_seValues) {  // first allocation
        m_seValues = (SeValue *)DmMalloc(newSize * sizeof(SeValue));
        if (!m_seValues) {
            //vslPrint("malloc failure for seValues\n");
            abort();
            return;
        }
        start = 0;  // clear from the beginning
    } else {  // extend table
        m_seValues = (SeValue *)DmRealloc(m_seValues, newSize * sizeof(SeValue));
        if (!m_seValues) {
            //vslPrint("realloc failure for seValues\n");
            abort();
            return;
        }
        start = m_tableSize;  // clear new entries only
    }
    m_tableSize = newSize;
    clearValues(start);
}

void SysDefDocument::clearValues(int start)
{
    for (int i = start; i < m_tableSize; i++) {
        m_seValues[i].type = SeTypeUnset;
        m_seValues[i].value = 0.0;  // alive
    }
}


bool SysDefDocument::setupQualifiedSystemsAndComps()
{
    if (m_vars->allow_encode) {
        // this function is only intended when using the Se package
        // evaluation functions, not for code array evaluations
        return false;
    }

    if (m_qualComps->size() > 0) {
        // this function has already been called, nothing more to do
        return true;
    }

    // change all undefined systems to components
    for (int sysIndex = SeSyDStart; sysIndex < m_systems->size(); sysIndex++) {
        const char *name = m_systems->getName(sysIndex);
        if (name != NULL && m_SeDataSystem[sysIndex] == NULL) {
            // system not defined, convert to component

            // add name to component pool and get its index
            int compIndex = m_components->addName(qPrintable(name));
            if (compIndex == -1) {
                ErClear();  // failed add name sets error flag
                return false;
            }

            // go through each system and replace system with component
            for (int i = SeSyDStart; i < m_systems->size(); i++) {
                if (m_systems->getName(i) != NULL
                    && m_SeDataSystem[i] != NULL) {
                    ReplaceSystemWithCompSysdefVisitor replace(this, sysIndex,
                            compIndex);
                    replace.traverse(m_SeDataSystem[i]->sysdef);
                    if (replace.modified() && m_vars->allow_encode) {
                        // need to encode system again if it was modified
                        QString message;
                        if (!systemEncode(i, message)) {
                            // TODO may need some sort of error reporting here
                            return false;
                        }
                    }
                }
            }

            // now delete the system name from the system name pool
            m_systems->deleteName(qPrintable(name));
        }
    }

    // start qualified component name pool with unqualified components
    *m_qualComps = *m_components;

    // discover all possible qualified systems and components
    // (qualified systems and components will be added to name pools)
    m_qualSysIndexes.clear();
    for (int i = SeSyDStart; i < m_systems->size(); i++) {
        const char *name = m_systems->getName(i);
        if (name != NULL && m_SeDataSystem[i] != NULL) {
            QualifierSysdefVisitor qualifier(this);
            qualifier.traverse(m_SeDataSystem[i]->sysdef);
        }
    }
    // loop through all new qualified systems
    foreach (int i, m_qualSysIndexes) {
        QString sysName = baseName(m_systems->getName(i));
        int baseIndex = m_systems->getIndex(qPrintable(sysName));
        if (baseIndex == NmNOT_FOUND) {
            return false;
        }
        if (SeDataSystem[i] == NULL) {
            SeDataSystem[i] = (SeSyDat *)DmXalloc(SeSyDat);
            SeSyDat *sydp = SeDataSystem[i];
            sydp->state = SeINVALID; /* initialize system node */
            sydp->sysdef = SeExpCopy(SeDataSystem[baseIndex]->sysdef);
        }
    }
    return true;
}


void SysDefDocument::addQualfiedSysIndex(int sysIndex)
{
    m_qualSysIndexes << sysIndex;
}


bool SysDefDocument::isQualifiedSystem(int sysIndex)
{
    return m_qualSysIndexes.contains(sysIndex);
}

QStringList SysDefDocument::getSystemNames()
{
    QStringList allSystems;
    for (int system = SeSyDStart; system < getNumSystems(); system++) {
        QString name = removeQualifier(getSystemName(system));
        if (!name.isEmpty()) {
            allSystems << name;
        }
    }
    allSystems.removeDuplicates();
    return allSystems;
}

QStringList SysDefDocument::getComponentsInSystem(QString systemName)
{
    ComponentListSysdefVisitor visitor(this);
    QStringList componentList;

    visitor.traverse(SeDataSystem[getSystemID(systemName)]->sysdef);
    componentList << visitor.getComponentList();

    QStringList systemList = visitor.getSystemList();
    while (!systemList.isEmpty()) {
        visitor.reset();

        foreach (QString system, systemList) {
            visitor.traverse(SeDataSystem[getSystemID(system)]->sysdef);
            componentList << visitor.getComponentList();
            systemList << visitor.getSystemList();
            systemList.takeFirst();
        }
    }
    return componentList;
}

QString SysDefDocument::getSystemString(QString systemName)
{
    QString expr;
    int systemIndex = getSystemID(systemName);
    if (systemIndex > -1) {
        if (SeDataSystem[systemIndex] == NULL) {
            expr.append("<undefined>");
        } else {
            GetStringSysdefVisitor getString(this);
            getString.traverse(SeDataSystem[systemIndex]->sysdef);
            expr = getString.result();
        }
        // sanitize system name, will add quotes if needed (11-07-05 ch3)
        return QString("%1 = %2").arg(SysDefSanitizeName(m_systems->getName(systemIndex)),
                                      expr);
    } else {
        return "Not a system";
    }
}
