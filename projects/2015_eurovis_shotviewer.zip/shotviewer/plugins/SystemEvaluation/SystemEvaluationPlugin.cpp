#include "SystemEvaluationPlugin.h"

#include "SysDefDocument.h"

SystemEvaluationPlugin::SystemEvaluationPlugin(QObject *parent) :
    QObject(parent)
{
    /*no-op*/
}

SystemEvaluationPlugin::~SystemEvaluationPlugin()
{
    /*no-op*/
}

//---------------- IDocPlugin -----------------

QStringList SystemEvaluationPlugin::getFilenameExtensions()
{
    QStringList extList;
    extList.append("sysdef");
    return extList;
}

QString SystemEvaluationPlugin::getDocumentCategory()
{
    return QString("SysDef");
}

ApplicationDocument * SystemEvaluationPlugin::createDocument()
{
    return new SysDefDocument;
}

QString SystemEvaluationPlugin::getPluginName()
{
    return QString("SystemEvaluationPlugin");
}

QStringList SystemEvaluationPlugin::defaultViews()
{
    QStringList views;
    views << "SysDef Shotline View";
    return views;
}

#if QT_VERSION < 0x050000
Q_EXPORT_PLUGIN2(SystemEvaluationPlugin, SystemEvaluationPlugin)
#endif
