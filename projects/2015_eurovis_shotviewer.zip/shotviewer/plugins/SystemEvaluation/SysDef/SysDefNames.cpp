// vim:smarttab expandtab sw=4

#include "SysDefNames.h"

QString SysDefSanitizeName(const char *cname)
{
    QString name = cname;
    return SysDefSanitizeName(name);
}

QString SysDefSanitizeName(QString &name)
{
    if (!name.contains(QRegExp("^[A-Za-z0-9_.:]+$"))) {
        // name contains normally invalid characters
        // sanitize name so that it is acceptable
        // first quote any double quotes
        name.replace('"', "\\\"");
        // now surround entire name with double quotes
        name.prepend('"').append('"');
    }
    return name;
}
