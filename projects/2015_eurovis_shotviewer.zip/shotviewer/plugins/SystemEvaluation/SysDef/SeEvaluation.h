// vim:smarttab expandtab sw=4:
#ifndef SEEVALUATION_H
#define SEEVALUATION_H
#ifndef __device__
#define __device__
#endif

#ifndef __host__
#define __host__
#endif

/**
 *  This file contains common definitions used by classes that use the
 *  SeDevice class indirectly through the SeWrapper class for system
 *  definition evaluation, but don't need to include the SeDevice
 *  class.
 **/

#include <QtGlobal>
#include <QByteArray>
#include <QVector>
#include <QStringList>
#include <QRegExp>
#include <QHash>
#include <QPair>

struct SeLockedSystem;

// evaluate expression code return status values (11-12-16 ch3)
// added frame error (12-03-16 ch3)
enum EvaluateStatusEnum {
    EvaluateGood,
    EvaluateDivByZero,
    EvaluateBadCode,
    EvaluateStackErr,
    EvaluateFrameErr,
    EvaluateSentinel
};


class SeQualItem
{
    int m_baseIndex; // base index of item
    int m_qualIndex; // index of qualifier

public:
    SeQualItem(void) :
        m_baseIndex(-1),
        m_qualIndex(-1) {
    }

    SeQualItem(int baseIndex, int qualIndex) :
        m_baseIndex(baseIndex),
        m_qualIndex(qualIndex) {
    }

    int baseIndex(void) const {
        return m_baseIndex;
    }
    int qualIndex(void) const {
        return m_qualIndex;
    }
    void get(int &baseIndex, int &qualIndex) const {
        baseIndex = m_baseIndex;
        qualIndex = m_qualIndex;
    }
};

typedef QHash<int, SeQualItem> SeQualHash;

// expression code information structure (11-12-07 ch3)
// added size of function call fragment to structure (12-03-16 ch3)
// added critical component variables to structure (12-09-12 ch3)
struct SeCodeInfo {  // SeDevice, SeWrapper
    QList<int> codeArray;       // array of encoded nodes
    QList<int> orderList;       // evaluation order of system indexes
    int stackSize;              // size of stack required for system
    int frameSize;              // size of frame required for system
    SeQualHash qualSystems;     // qualifier system information
};

struct SeComponentData {        //FiremanPugh, FiremanPughPenEq.cu, SeDevice
    qint8 critical;             // component is critical flag
    qint8 spalls;               // component spalls flag
    qint16 materialIndex;       // material index for component

    SeComponentData() : spalls(0) {}
};

struct SeCompEvalData {
    int tableOffset;            // offset into table buffer
    int stateIndex;             // index into state arrays
};

// evaluation data
// TODO this will probably need to be a union to save space
struct SeEvalData {  // VLTest, SeDevice, SeWrapper
    int qualifierId;
    int tableOffset;
    float los;
    float threshold;
};

#endif // SEEVALUATION_H
