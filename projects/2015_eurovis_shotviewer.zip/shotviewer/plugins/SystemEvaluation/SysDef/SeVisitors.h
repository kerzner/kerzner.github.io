#ifndef SEVISITORS_H
#define SEVISITORS_H

#include "SysDefDocument.h"
#include "SysDefNames.h"
#include "SeEvaluation.h"
#include "NamePool.h"

extern "C" {
#include <Dm.h>
}

#define DEBUG_ORDLIST   0x00000080

#if 0
enum SeUserType {
    SeSystemUserType = 1000,  // QTreeWidgetItem::UserType
    SeCompUserType
};

struct SeTreeNodeInfo {
    SeUserType type;            // system or component
    int index;                  // system/component index
    QString name;               // name of system or component

    SeTreeNodeInfo(const SeUserType _type, const int _index, const char *_name):
        type(_type),
        index(_index),
        name(_name) {
    }
};
#endif

// single expression evaluation node class (11-12-07 ch3)
class SeEvalNode
{
    SeNodeCategory m_type;          // type of node
    union {
        int m_index;            // index for component and system nodes
        float m_value;          // value of node (constants only)
    };

public:
    SeEvalNode(SeNodeCategory type = SeNT_UNSET, int index = -1):
        m_type(type),
        m_index(index) {
    }
    SeEvalNode(SeNodeCategory type, float value):
        m_type(type),
        m_value(value) {
    }

    // function to return type
    SeNodeCategory type(void) {
        return m_type;
    }
    // function to return type as an integer
    int typeAsInt(void) {
        return (int)m_type;
    }
    // function to return index
    int index(void) {
        return m_index;
    }
    // function to return value as an integer
    float value(void) {
        return m_value;
    }
    // function to return value as an integer
    int valueAsInt(void) {
        return m_index;  // index is integer form of value via union
    }
};

//=============================
//  BASE SYSDEF VISITOR CLASS
//=============================

// base visitor class with default processing for 8 major node types
//  - leaf node types (system, qualified system, component, qualified
//    component, constant, parameter, Se function, and other) contain no
//    default processing (derived classes will supply processing as needed)
//
//  - qualified operator node type passes qualifier index (from right-side)
//    down to node on left-side (a system or component)
//    - the qualop flag is set when a qualified operator node is being processed
//
//  - unary operator node type traverses right-side
//
//  - binary operator node types traverses left-side and if not stopped,
//    the right-side
//
//  - function call node type traverses each argument sysdef (if not stopped)
//    and then the sysdef of the function
//
//  - default processing for qualified operators, unary operators, binary
//    operators, and functions can be reimplemented in derived visitor classes
//    as needed
//
//  - the stop flag is set when a derived visitor class wants to stop traversal
//    of the sysdef
//
//  - the modified flag is set by derived visitor classes that modify the sysdef
//
//  - the error message string can be appended to by derived classes as errors
//    occur (with new line separators between each message)
//
//  - this class also contains a pointer back to the SeWrapper instance so
//    that the traversal function can be called along with other functions
//    (this class is a friend class to SeWrapper so that private members and
//    functions can be called; this class contains access functions for these
//    so that derived classes can access them without requiring additional
//    friend classes be added to SeWrapper)
class SysdefVisitor
{
public:
    SysdefVisitor(SysDefDocument *doc) :
        m_doc(doc),
        m_qualop(false),
        m_modified(false),
        m_stop(false) { }

    virtual void visitSysNameNode(SeSysDef *sysdefp, int qualIndex) { }
    virtual void visitQualSysNode(SeSysDef *sysdefp, int qualIndex) { }
    virtual void visitCompNameNode(SeSysDef *sysdefp, int qualIndex) { }
    virtual void visitQualCompNode(SeSysDef *sysdefp, int qualIndex) { }
    virtual void visitQualOpNode(SeSysDef *sysdefp, int qualIndex) {
        // get qualifier index on right-hand side and pass down left-hand side
        m_qualop = true;
        qualIndex = sysdefp->o.rhsp->c.index;
        traverse(sysdefp->o.lhsp, qualIndex);
        m_qualop = false;
    }
    virtual void visitConstantNode(SeSysDef *sysdefp, int qualIndex) { }
    virtual void visitUnaryOpNode(SeSysDef *sysdefp, int qualIndex) {
        traverse(sysdefp->o.rhsp, qualIndex);
    }
    virtual void visitBinaryOpNode(SeSysDef *sysdefp, int qualIndex) {
        traverse(sysdefp->o.lhsp, qualIndex);
        if (!stopped()) {
            traverse(sysdefp->o.rhsp, qualIndex);
        }
    }
    virtual void visitFnCallNode(SeSysDef *sysdefp, int qualIndex) {
        SeArgExp *np;

        DqEACH(sysdefp->f.argexps, np, SeArgExp) {
            // descend into expression of each argument of function
            traverse(np->expp, qualIndex);
            if (stopped()) {
                return;  // no need to continue
            }
        }
        // finally, descend into expression of function
        traverse(SeFnDfn[sysdefp->f.index]->funcdefp,
                 qualIndex);
    }
    virtual void visitParamNode(SeSysDef *sysdefp, int qualIndex) { }
    virtual void visitSeFuncNode(SeSysDef *sysdefp, int qualIndex) { }
    virtual void visitOtherNode(SeSysDef *sysdefp, int qualIndex) { }

    bool stopped(void) {
        return m_stop;
    }
    bool modified(void) {
        return m_modified;
    }
    bool hasError(void) {
        return !m_errorMessage.isEmpty();
    }
    const QString &errorMessage(void) {
        return m_errorMessage;
    }

    // Function to traverse a sysdef carrying a visitor instance to
    // each node type.
    void traverse(SeSysDef *sysdefp, int qualIndex = -1) {
        switch (sysdefp->type) {
        case SeNT_QUALSYS:
            this->visitQualSysNode(sysdefp, qualIndex);
            break;

        case SeNT_SYSNAME:
            this->visitSysNameNode(sysdefp, qualIndex);
            break;

        case SeNT_QUALCOMP:
            this->visitQualCompNode(sysdefp, qualIndex);
            break;

        case SeNT_COMPNAME:
            this->visitCompNameNode(sysdefp, qualIndex);
            break;

        case SeNT_QUALOP:
            this->visitQualOpNode(sysdefp, qualIndex);
            break;

        case SeNT_CONSTANT:
            this->visitConstantNode(sysdefp, qualIndex);
            break;

        case SeNT_FNCALL:
            this->visitFnCallNode(sysdefp, qualIndex);
            break;

        case SeNT_PARAM:
            this->visitParamNode(sysdefp, qualIndex);
            break;

        case SeNT_MULTOCC:
        case SeNT_EXPR:
        case SeNT_NOT:
        case SeNT_ANOT:
        case SeNT_ABS:
        case SeNT_BOOL:
            this->visitUnaryOpNode(sysdefp, qualIndex);
            break;

        case SeNT_AND:
        case SeNT_XOR:
        case SeNT_OR:
        case SeNT_MIN:
        case SeNT_MAX:
        case SeNT_SUM:
        case SeNT_DIFF:
        case SeNT_PROD:
        case SeNT_QUOT:
        case SeNT_LT:
        case SeNT_GT:
        case SeNT_LTEQ:
        case SeNT_GTEQ:
            this->visitBinaryOpNode(sysdefp, qualIndex);
            break;

        case SeNT_RUNIF:
        case SeNT_RNORM:
        case SeNT_MOFN:
        case SeNT_PKD:
        case SeNT_ORCA:
        case SeNT_EVAL:
            this->visitSeFuncNode(sysdefp, qualIndex);
            break;

        default:
            this->visitOtherNode(sysdefp, qualIndex);
        }
    }


    void visitSystem(int systemID, int qualIndex = -1) {
#if 0
        traverse(m_doc->m_SeDataSystem[systemID]->sysdef, qualIndex);
#else
        traverse(SeDataSystem[systemID]->sysdef, qualIndex);
#endif
    }

protected:

    void errorMessageAppend(QString errorMessage) {
        if (!m_errorMessage.isEmpty()) {
            m_errorMessage.append('\n');
        }
        m_errorMessage.append(errorMessage);
    }

    // access functions to SeWrapper instance
    void sysdefTraverse(SeSysDef *sysdefp, int qualIndex) {
        traverse(sysdefp, qualIndex);
    }
    QString qualifiedName(const char *name, int qualIndex) {
        return m_doc->qualifiedName(name, qualIndex);
    }
    bool hasTable(void) {
        return m_doc->hasTable();
    }
    int addQualifiedSystem(const QString &qualName) {
        return m_doc->m_qualSystems->addName(qPrintable(qualName));
    }
    int addQualifiedSystem(const char *name, int qualIndex) {
        QString qualName = qualifiedName(name, qualIndex);
        return m_doc->m_systems->addName(qPrintable(qualName));
    }
    void addQualifiedComponent(const QString &qualName) {
        m_doc->m_qualComps->addName(qPrintable(qualName));
    }
    int negateIndex(int index) {
        return m_doc->negateIndex(index);
    }

    SysDefDocument *m_doc;  // pointer to caller
    bool m_qualop;          // processing a QualOp node
    bool m_modified;        // sysdef has been modified flag
    bool m_stop;            // set when node wants sysdef processing to stop
    QString m_errorMessage; // error message
};


//===========================
//  COMPONENT VISITOR CLASS
//===========================

// visitor class to determine if component is found in a system definition
//   - once component is found, traversal is stopped
class ComponentSysdefVisitor : public SysdefVisitor
{
public:
    ComponentSysdefVisitor(SysDefDocument *doc, int compIndex) :
        SysdefVisitor(doc),
        m_compIndex(compIndex),
        m_found(false) { }

    virtual void visitCompNameNode(SeSysDef *sysdefp, int qualIndex) {
        if (sysdefp->c.index == m_compIndex) {
            m_found = true;
            m_stop = true;      // found component, no need to continue
        }
    }
    virtual void visitQualCompNode(SeSysDef *sysdefp, int qualIndex) {
        visitCompNameNode(sysdefp, qualIndex);
    }

    bool found(void) {
        return m_found;
    }

private:
    int m_compIndex;
    bool m_found;
};


//========================
//  SYSTEM VISITOR CLASS
//========================

// visitor class to determine if system is found in a system definition
//   - once system is found, traversal is stopped
class SystemSysdefVisitor : public SysdefVisitor
{
public:
    SystemSysdefVisitor(SysDefDocument *doc, int sysIndex) :
        SysdefVisitor(doc),
        m_sysIndex(sysIndex),
        m_found(false) { }

    virtual void visitSysNameNode(SeSysDef *sysdefp, int qualIndex) {
        if (sysdefp->c.index == m_sysIndex) {
            m_found = true;
            m_stop = true;      // found component, no need to continue
        }
    }
    virtual void visitQualSysNode(SeSysDef *sysdefp, int qualIndex) {
        visitSysNameNode(sysdefp, qualIndex);
    }

    bool found(void) {
        return m_found;
    }

private:
    int m_sysIndex;
    bool m_found;
};


//===================================================
//  COUNT SYSTEM AND COMPONENT USAGES VISITOR CLASS
//===================================================

// visitor to count usages of systems and components in a system definition
class UseCountSysdefVisitor : public SysdefVisitor
{
public:
    UseCountSysdefVisitor(SysDefDocument *doc, int systemCount,
                          int compCount = 0) : SysdefVisitor(doc) {
        m_systemUseCount.resize(systemCount);
        m_compUseCount.resize(compCount);
    }

    virtual void visitSysNameNode(SeSysDef *sysdefp, int qualIndex) {
        m_systemUseCount[sysdefp->c.index]++;
    }
    virtual void visitQualSysNode(SeSysDef *sysdefp, int qualIndex) {
        visitSysNameNode(sysdefp, qualIndex);
    }
    virtual void visitCompNameNode(SeSysDef *sysdefp, int qualIndex) {
        if (!m_compUseCount.isEmpty()) {
            m_compUseCount[sysdefp->c.index]++;
        }
    }
    virtual void visitQualCompNode(SeSysDef *sysdefp, int qualIndex) {
        visitCompNameNode(sysdefp, qualIndex);
    }

    int system(int index) {
        return m_systemUseCount.at(index);
    }
    int comp(int index) {
        return m_compUseCount.at(index);
    }

private:
    QVector<int> m_systemUseCount;             // count of system usages
    QVector<int> m_compUseCount;               // count of component usages
};


//===============================================
//  GET STRING VISITOR CLASS
//===============================================

// visitor class to get expression string of a system definition
class GetStringSysdefVisitor : public SysdefVisitor
{
public:
    GetStringSysdefVisitor(SysDefDocument *doc) : SysdefVisitor(doc) {}

    virtual void visitSysNameNode(SeSysDef *sysdefp, int qualIndex) {
        QString name = m_doc->getSystemName(sysdefp->c.index);
        if (name.isNull()) {
            m_string.append(QString("<BUG: bad system (%1) index (%2)>")
                            .arg(QString(sysdefp->core.text)).arg(sysdefp->c.index));
        } else if (name != sysdefp->core.text) {
            m_string.append(QString("<BUG: %1 %2 != %3>")
                            .arg(QString(SeCvtToStr(sysdefp->type)),
                                 QString(sysdefp->core.text), name));
        } else {
            m_string.append(SysDefSanitizeName(name));
        }
    }
    virtual void visitQualSysNode(SeSysDef *sysdefp, int qualIndex) {
        visitSysNameNode(sysdefp, qualIndex);
    }
    virtual void visitCompNameNode(SeSysDef *sysdefp, int qualIndex) {
        QString name = m_doc->getComponentName(sysdefp->c.index);
        if (name.isNull()) {
            m_string.append(QString("<BUG: bad component index (%1)>")
                            .arg(sysdefp->c.index));
        } else if (name != sysdefp->core.text) {
            m_string.append(QString("<BUG: %1 %2 != %3>")
                            .arg(QString(SeCvtToStr(sysdefp->type)),
                                 QString(sysdefp->core.text), name));
        } else {
            m_string.append(SysDefSanitizeName(name));
        }
    }
    virtual void visitQualCompNode(SeSysDef *sysdefp, int qualIndex) {
        visitCompNameNode(sysdefp, qualIndex);
    }
    virtual void visitQualOpNode(SeSysDef *sysdefp, int qualIndex) {
        SysdefVisitor::visitQualOpNode(sysdefp, qualIndex);
        // now append qualifier name
        m_string.append('[').append(sysdefp->o.rhsp->core.text).append(']');
    }
    virtual void visitConstantNode(SeSysDef *sysdefp, int qualIndex) {
        m_string.append(sysdefp->core.text);
    }
    virtual void visitUnaryOpNode(SeSysDef *sysdefp, int qualIndex) {
        if (sysdefp->core.type == SeNT_MULTOCC) {
            m_string.append("MultOcc ");  // should be none of these with VSL
        } else if (sysdefp->core.type == SeNT_EXPR) {
            bool flag = sysdefp->o.rhsp->type != SeNT_FNCALL;
            if (flag) {
                m_string.append(SeTtbl[SeNT_LF_PAREN].ts);
            }
            SysdefVisitor::visitUnaryOpNode(sysdefp, qualIndex);
            if (flag) {
                m_string.append(SeTtbl[SeNT_RT_PAREN].ts);
            }
        } else {  // other unary operator
            m_string.append(SeTtbl[sysdefp->type].ts);
            SysdefVisitor::visitUnaryOpNode(sysdefp, qualIndex);
        }
    }
    virtual void visitBinaryOpNode(SeSysDef *sysdefp, int qualIndex) {
        traverse(sysdefp->o.lhsp, qualIndex);
        m_string.append(' ').append(SeTtbl[sysdefp->type].ts).append(' ');
        traverse(sysdefp->o.rhsp, qualIndex);
    }
    virtual void visitFnCallNode(SeSysDef *sysdefp, int qualIndex) {
        const char *name = NmName(sysdefp->f.index, &SeFunctions);
        if (name == NULL) {
            m_string.append(QString("<BUG: bad function definition index "
                                    "(%1)>").arg(sysdefp->f.index));
        } else {
            SeArgExp *np;

            m_string.append(name);
            QString separator = "(";
            DqEACH(sysdefp->f.argexps, np, SeArgExp) {
                m_string.append(separator);
                traverse(np->expp, qualIndex);
                separator = ", ";
            }
            m_string.append(')');
        }
    }
    virtual void visitParamNode(SeSysDef *sysdefp, int qualIndex) {
        // replace generic parameter number with actual name
        m_string.append(sysdefp->core.text);

        // collect parameter names for later retrieval
        // add to parameter vector if first time seen
        m_param.resize(sysdefp->p.index + 1);
        if (m_param.at(sysdefp->p.index).isEmpty()) {
            m_param[sysdefp->p.index] = sysdefp->core.text;
        }
    }
    virtual void visitSeFuncNode(SeSysDef *sysdefp, int qualIndex) {
        traverse(sysdefp->o.lhsp, qualIndex);
        m_string.append(' ');
        traverse(sysdefp->o.rhsp, qualIndex);
    }
    virtual void visitOtherNode(SeSysDef *sysdefp, int qualIndex) {
        if (sysdefp->core.type == SeNT_UNSET) {
            m_string.append("<unset node type>");
        } else {
            m_string.append(QString("<BUG: invalid node type (%1)>")
                            .arg(SeCvtToStr(sysdefp->type)));
        }
    }

    int paramCount(void) {
        return m_param.count();
    }
    const QString &param(int index) {
        return m_param.at(index);
    }
    const QString &result(void) {
        return m_string;
    }

private:
    QVector<QString> m_param;                   // vector of parameter strings
    QString m_string;                           // string of sysdef
};


//===============================================
//  REPLACE COMPONENT WITH SYSTEM VISITOR CLASS
//===============================================

// visitor class to replace a component with a system in a system definition
//   - sets modified flag is sysdef is modified
class ReplaceCompWithSystemSysdefVisitor : public SysdefVisitor
{
public:
    ReplaceCompWithSystemSysdefVisitor(SysDefDocument *doc, int compIndex,
                                       int sysIndex) : SysdefVisitor(doc),
        m_compIndex(compIndex),
        m_sysIndex(sysIndex) { }

    virtual void visitCompNameNode(SeSysDef *sysdefp, int qualIndex) {
        if (sysdefp->c.index == m_compIndex) {
            // change node to system (qualified if under a QUALOP node)
            sysdefp->type = m_qualop ? SeNT_QUALSYS : SeNT_SYSNAME;
            sysdefp->c.index = m_sysIndex;
            m_modified = true;
        }

    }

private:
    int m_compIndex;                        // from component index
    int m_sysIndex;                         // to system index
};


//===============================================
//  REPLACE SYSTEM WITH COMPONENT VISITOR CLASS
//===============================================

// visitor class to replace a component with a system in a system definition
//   - sets modified flag is sysdef is modified
class ReplaceSystemWithCompSysdefVisitor : public SysdefVisitor
{
public:
    ReplaceSystemWithCompSysdefVisitor(SysDefDocument *doc, int sysIndex,
                                       int compIndex) : SysdefVisitor(doc),
        m_sysIndex(sysIndex),
        m_compIndex(compIndex) { }

    virtual void visitSysNameNode(SeSysDef *sysdefp, int qualIndex) {
        if (sysdefp->c.index == m_sysIndex) {
            sysdefp->type = SeNT_COMPNAME;
            sysdefp->c.index = m_compIndex;
            m_modified = true;
        }
    }
    virtual void visitQualSysNode(SeSysDef *sysdefp, int qualIndex) {
        // just change QUALSYS nodes to COMPNAME nodes
        // if system was qualified, component will be qualified
        visitSysNameNode(sysdefp, qualIndex);
    }

private:
    int m_sysIndex;                         // from system index
    int m_compIndex;                        // to component index
};


//===============================================
//  CHANGE SYSTEM NAME VISITOR CLASS
//===============================================

// visitor class to change the name of system in a system definition
class ChangeSystemNameSysdefVisitor : public SysdefVisitor
{
public:
    ChangeSystemNameSysdefVisitor(SysDefDocument *doc, int sysIndex,
                                  const char *name) : SysdefVisitor(doc),
        m_sysIndex(sysIndex),
        m_name(name) { }

    virtual void visitSysNameNode(SeSysDef *sysdefp, int qualIndex) {
        if (sysdefp->c.index == m_sysIndex) {
            // found system, replace name
            DmFree(sysdefp->core.text);
            sysdefp->core.text = DmStrDup(m_name);
        }
    }
    virtual void visitQualSysNode(SeSysDef *sysdefp, int qualIndex) {
        visitSysNameNode(sysdefp, qualIndex);
    }

private:
    int m_sysIndex;                         // index of system to change
    const char *m_name;                     // name to change system to
};


//===============================================
//  UPDATE NODE TYPES AND INDEXES VISITOR CLASS
//===============================================

// visitor class to update node types and indexes in a system definition
//   - sets modified flag is sysdef is modified
class UpdateNodeCategorysAndIndexesSysdefVisitor : public SysdefVisitor
{
public:
    UpdateNodeCategorysAndIndexesSysdefVisitor(SysDefDocument *doc,
            const QVector<int> &newCompIndex,
            const QVector<int> &sysToCompIndex,
            const QVector<int> &compToSysIndex) : SysdefVisitor(doc),
        m_newCompIndex(newCompIndex),
        m_sysToCompIndex(sysToCompIndex),
        m_compToSysIndex(compToSysIndex) { }

    virtual void visitSysNameNode(SeSysDef *sysdefp, int qualIndex) {
        int index = m_sysToCompIndex.at(sysdefp->c.index);
        if (index != -1) {  // changing to component?
            sysdefp->type = SeNT_COMPNAME;
            sysdefp->c.index = index;
            m_modified = true;
        }
    }
    virtual void visitQualSysNode(SeSysDef *sysdefp, int qualIndex) {
        visitSysNameNode(sysdefp, qualIndex);
    }
    virtual void visitCompNameNode(SeSysDef *sysdefp, int qualIndex) {
        int index = m_newCompIndex.at(sysdefp->c.index);
        if (index != -1) {  // component has new index?
            sysdefp->c.index = index;
            m_modified = true;
        } else {
            index = m_compToSysIndex.at(sysdefp->c.index);
            sysdefp->type = m_qualop ? SeNT_QUALSYS : SeNT_SYSNAME;
            sysdefp->c.index = index;
            m_modified = true;
        }
    }
    virtual void visitQualCompNode(SeSysDef *sysdefp, int qualIndex) {
        visitCompNameNode(sysdefp, qualIndex);
    }

private:
    const QVector<int> &m_newCompIndex;     // old to new comp index map
    const QVector<int> &m_sysToCompIndex;   // system to comp index map
    const QVector<int> &m_compToSysIndex;   // comp to system index map
};


//==========================================
//  GET QUALIFIER COMPONENTS VISITOR CLASS
//==========================================

// visitor class to get qualified components for a system definition
//   - if an error is found, traversal is stopped
//   - error if invalid node type is found (should not happen)
//   - error if unqualified component is found and an EM table is present
//     (should not happen since only systems with all qualified components
//     can be selected)
//   - upon failure, error message is set
//   - upon success, qualified components list updated
class GetQualCompsSysdefVisitor : public SysdefVisitor
{
public:
    GetQualCompsSysdefVisitor(SysDefDocument *doc, SeQualHash &qualComps,
                              int componentCount, bool singleEvaluation) :
        SysdefVisitor(doc),
        m_qualComps(qualComps),
        m_componentCount(componentCount),
        m_singleEvaluation(singleEvaluation) {
    }

    virtual void visitCompNameNode(SeSysDef *sysdefp, int qualIndex) {
        // first check if component index is valid
        if (sysdefp->c.index > m_componentCount) {
            //vslDebug(ORDLIST, "Component index '%d-%s' out of range (%d)\n",
            //    sysdefp->c.index, sysdefp->core.text, m_componentCount);
            // this may not be fatal if components have not been registered yet
            m_stop = true;
        }
        if (qualIndex == -1) {
            if (!m_singleEvaluation && hasTable()) {
                // this should not happen since system has already been
                // determined not to contain unqualified components
                // (systems with unqualified components can't be selected)
                // but return an error just in case
                errorMessageAppend(QString("unqualified component '%1' found")
                                   .arg(sysdefp->core.text));
                m_stop = true;
            }
        } else {
            // apply qualifier and add to the list of qualified components
            QString qualName = qualifiedName(sysdefp->core.text, qualIndex);
            int qualCompIndex = m_doc->qualifiedComponentIndex(qualName);
            if (qualCompIndex < 0) {
                // this should not happen
                errorMessageAppend(QString("qualified component '%1' not found")
                                   .arg(qualName));
                m_stop = true;
            } else {
                m_qualComps.insert(qualCompIndex, SeQualItem(sysdefp->c.index,
                                   qualIndex));
            }
        }
    }
    virtual void visitOtherNode(SeSysDef *sysdefp, int qualIndex) {
        errorMessageAppend(QString("unexpected %1")
                           .arg(SeCvtToStr(sysdefp->type)));
        m_stop = true;
    }
    virtual void visitSeFuncNode(SeSysDef *sysdefp, int qualIndex) {
        visitOtherNode(sysdefp, qualIndex);
    }

private:
    SeQualHash &m_qualComps;                // qual comp to comp, qual index
    int m_componentCount;                   // number of components
    bool m_singleEvaluation;                // processing for single evaluation
};


//==========================================
//  SYSTEM IS ALLOWED VISITOR CLASS
//==========================================

// visitor class to check if system definition contains unqualified components
//   - adds any qualified components found to the SeComponents name pool
class SystemIsAllowedSysdefVisitor : public SysdefVisitor
{
public:
    SystemIsAllowedSysdefVisitor(SysDefDocument *doc) :
        SysdefVisitor(doc),
        m_notAllowed(false) {}

    virtual void visitSysNameNode(SeSysDef *sysdefp, int qualIndex) {
        if (SeDataSystem[sysdefp->c.index] != NULL) {
            traverse(SeDataSystem[sysdefp->c.index]->sysdef, qualIndex);
        }
    }
    virtual void visitQualSysNode(SeSysDef *sysdefp, int qualIndex) {
        visitSysNameNode(sysdefp, qualIndex);
    }
    virtual void visitCompNameNode(SeSysDef *sysdefp, int qualIndex) {
        if (qualIndex == -1) {
            // no qualifer so this component is unqualified,
            // system not allowed unless there is no table
            if (hasTable()) {
                m_notAllowed = true;
            }
        } else {
            // add qualified component name to SeComponents name pool
            // if not already there (don't care about its index)
            addQualifiedComponent(qualifiedName(sysdefp->core.text, qualIndex));
        }
    }

    bool isAllowed(void) {
        return !m_notAllowed;
    }

private:
    bool m_notAllowed;                      // system is not allowed flag
};


//==========================================
//  GET NODES VISITOR CLASS
//==========================================

// visitor class to get nodes for encoding a system definition
class GetNodesSysdefVisitor : public SysdefVisitor
{
public:
    GetNodesSysdefVisitor(SysDefDocument *doc) :
        SysdefVisitor(doc),
        m_codeSize(0) { }

    virtual void visitSysNameNode(SeSysDef *sysdefp, int qualIndex) {
        // note: system index can't be checked here
        //       they may not have been added yet
        //       index will be checked later when building the order list
        int index;

        // check if system is a built-in system (12-03-16 ch3)
        if (sysdefp->c.index < SeSyDStart) {
            // treat built-in sysdefs as expressions
            traverse(SeDataSystem[sysdefp->c.index]->sysdef, qualIndex);
            return;
        }

        if (qualIndex == -1) {
            // implies SeNT_SYSNAME as unqualified system
            // add node to node list
            index = sysdefp->c.index;
            m_nodeList.append(SeEvalNode(SeNT_SYSNAME, index));
        } else {
            // get index of qualified system name (add if not in name pool)
            QString qualName = qualifiedName(sysdefp->core.text, qualIndex);
            index = addQualifiedSystem(qualName);
            // add node to node list
            m_nodeList.append(SeEvalNode(SeNT_QUALSYS, index));
            // add system and qualifier index to hash by qualifier system index
            m_qualSystems.insert(index, SeQualItem(sysdefp->c.index,
                                                   qualIndex));
            // negate index for order list
            index = negateIndex(index);
        }

        // add system to the order list if first time seen
        if (m_orderList.indexOf(index) == -1) {  // not in list?
            m_orderList.append(index);
        }
        m_codeSize += 2;
    }
    virtual void visitQualSysNode(SeSysDef *sysdefp, int qualIndex) {
        visitSysNameNode(sysdefp, qualIndex);
    }
    virtual void visitCompNameNode(SeSysDef *sysdefp, int qualIndex) {
        // note: components index can't be checked here
        //       they may not have been added yet
        //       index will be checked later when building the order list
        SeNodeCategory type;
        int index;

        if (qualIndex == -1) {
            type = SeNT_COMPNAME;
            index = sysdefp->c.index;
        } else {
            // append qualified system name if not already in list
            type = SeNT_QUALCOMP;
            index = m_doc->qualifiedComponentIndex(sysdefp->c.index,
                                                   qualIndex);
        }

        // add node to node list (for now not paying attention to QUALCOMP)
        m_nodeList.append(SeEvalNode(type, index));
        m_codeSize += 2;
    }
    virtual void visitQualOpNode(SeSysDef *sysdefp, int qualIndex) {
        // this node type should only be seen with COMPNAME or QUALSYS
        // in case not, return an error
        if (sysdefp->o.lhsp->type != SeNT_COMPNAME
            && sysdefp->o.lhsp->type != SeNT_QUALSYS) {
            errorMessageAppend("Non COMPNAME/QUALSYS on QUALOP(lhsp)");
            m_stop = true;
        } else if (sysdefp->o.rhsp->type != SeNT_CQUALIFIER) {
            errorMessageAppend("Non CQUALIFIER on QUALOP(rhsp)");
            m_stop = true;
        } else {
            SysdefVisitor::visitQualOpNode(sysdefp, qualIndex);
        }
    }
    virtual void visitConstantNode(SeSysDef *sysdefp, int qualIndex) {
        m_nodeList.append(SeEvalNode(SeNT_CONSTANT, (float)sysdefp->n.value));
        m_codeSize += 2;
    }
    virtual void visitUnaryOpNode(SeSysDef *sysdefp, int qualIndex) {
        SysdefVisitor::visitUnaryOpNode(sysdefp, qualIndex);
        if (stopped()) {
            errorMessageAppend(QString("Get nodes error on %1")
                               .arg(SeTtbl[sysdefp->type].ts));
        } else if (sysdefp->core.type != SeNT_EXPR) {
            // now append non-expression unary operator node
            m_nodeList.append(SeEvalNode(sysdefp->type));
            m_codeSize += 1;
        }
    }
    virtual void visitBinaryOpNode(SeSysDef *sysdefp, int qualIndex) {
        SysdefVisitor::visitBinaryOpNode(sysdefp, qualIndex);
        if (stopped()) {
            errorMessageAppend(QString("Get nodes error on %1")
                               .arg(SeCvtToStr(sysdefp->type)));
        } else {
            // now append binary operator node
            m_nodeList.append(SeEvalNode(sysdefp->type));
            m_codeSize += 1;
        }
    }
    virtual void visitFnCallNode(SeSysDef *sysdefp, int qualIndex) {
        SeArgExp *np;

        int c = 0;
        DqEACH(sysdefp->f.argexps, np, SeArgExp) {
            // descend into expression of each argument of function
            c++;
            traverse(np->expp, qualIndex);
            if (stopped()) {
                errorMessageAppend(QString("Get nodes error with %1 argument "
                                           "#%2").arg(NmName(sysdefp->f.index, &SeFunctions)).arg(c));
                return;  // no need to continue
            }
        }
        m_nodeList.append(SeEvalNode(SeNT_FNCALL, c));
        m_codeSize += 2;
        // add expresion for function next
        traverse(SeFnDfn[sysdefp->f.index]->funcdefp, qualIndex);
        if (stopped()) {
            errorMessageAppend(QString("Get nodes error with %1 expression")
                               .arg(NmName(sysdefp->f.index, &SeFunctions)));
        } else {
            m_nodeList.append(SeEvalNode(SeNT_FUNCNAME, c));
            m_codeSize += 1;
        }
    }
    virtual void visitParamNode(SeSysDef *sysdefp, int qualIndex) {
        m_nodeList.append(SeEvalNode(SeNT_PARAM, sysdefp->p.index));
        m_codeSize += 2;
    }
    virtual void visitSeFuncNode(SeSysDef *sysdefp, int qualIndex) {
        errorMessageAppend(QString("unsupported %1")
                           .arg(SeCvtToStr(sysdefp->type)));
        m_stop = true;
    }
    virtual void visitOtherNode(SeSysDef *sysdefp, int qualIndex) {
        errorMessageAppend(QString("unexpected %1")
                           .arg(SeCvtToStr(sysdefp->type)));
        m_stop = true;
    }

    const QList<SeEvalNode> &nodeList(void) {
        return m_nodeList;
    }
    const QList<int> &orderList(void) {
        return m_orderList;
    }
    int codeSize(void) {
        return m_codeSize;
    }
    const SeQualHash &qualSystems(void) {
        return m_qualSystems;
    }

private:
    QList<SeEvalNode> m_nodeList;           // list of nodes of sysdef
    QList<int> m_orderList;                 // evaluation order of lists
    int m_codeSize;                         // accumulated size of the code
    SeQualHash m_qualSystems;               // qualifier system information
};


//==========================================
//  SCAN FOR QUALIFIERS VISITOR CLASS
//==========================================

// visitor class to scan for qualified systems and components
//   - adds any qualified systems found to the SeSystems name pool
//   - adds indexes of qualified systems passed in set
//   - adds any qualified components found to the SeComponents name pool
class QualifierSysdefVisitor : public SysdefVisitor
{
public:
    QualifierSysdefVisitor(SysDefDocument *doc) :
        SysdefVisitor(doc) {}

    virtual void visitSysNameNode(SeSysDef *sysdefp, int qualIndex) {
        if (qualIndex != -1) {
            // add qualified system name to SeSystems name pool
            // and add qualified system index to document
            m_doc->addQualfiedSysIndex(addQualifiedSystem(sysdefp->core.text,
                                       qualIndex));
        }

        // now traverse system possibly with a qualifier
        if (SeDataSystem[sysdefp->c.index] != NULL) {
            traverse(SeDataSystem[sysdefp->c.index]->sysdef, qualIndex);
        }
    }
    virtual void visitQualSysNode(SeSysDef *sysdefp, int qualIndex) {
        visitSysNameNode(sysdefp, qualIndex);
    }
    virtual void visitCompNameNode(SeSysDef *sysdefp, int qualIndex) {
        if (qualIndex != -1) {
            // add qualified component name to SeComponents name pool
            // if not already there (don't care about its index)
            addQualifiedComponent(qualifiedName(sysdefp->core.text, qualIndex));
        }
    }
};

//==========================================
//  SCAN FOR COMPONENTS CLASS
//==========================================

class ComponentListSysdefVisitor : public SysdefVisitor
{
public:
    ComponentListSysdefVisitor(SysDefDocument *doc) :
        SysdefVisitor(doc) {}


    virtual void visitQualSysNode(SeSysDef *sysdefp, int qualIndex) {
        QString name = sysdefp->core.text;
        if (!m_systemList.contains(name)) {
            m_systemList << name;
        }
    }

    virtual void visitSysNameNode(SeSysDef *sysdefp, int qualIndex) {
        QString name = sysdefp->core.text;
        if (!m_systemList.contains(name)) {
            m_systemList << name;
        }
    }

    virtual void visitCompNameNode(SeSysDef *sysdefp, int qualIndex) {
        m_componentList << sysdefp->core.text;
    }

    QStringList getComponentList() const {
        return m_componentList;
    }

    QStringList getSystemList() const {
        return m_systemList;
    }

    void reset() {
        m_componentList.clear();
        m_systemList.clear();
    }

private:

    QStringList m_componentList;

    QStringList m_systemList;
};
#endif // SEVISITORS_H
