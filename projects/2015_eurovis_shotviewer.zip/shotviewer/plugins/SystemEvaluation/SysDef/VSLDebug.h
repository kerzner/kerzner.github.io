// vim:smarttab expandtab sw=4:
#ifndef VSLDEBUG_H
#define VSLDEBUG_H

/**
 *  This file contains macro definitions for outputting debug to the
 *  console, some of which are only activated when building with
 *  debug information.
 **/

#include <stdio.h>


// console output convenience macros
// to use this macros, the m_debug variable must be defined in the class

// this macro is for outputting errors regardless of debug build/flag
#define vslPrint(format, ...) \
    fprintf(stderr, "%s(%d) " format, DEBUG_NAME, __LINE__ , ## __VA_ARGS__)
#define vslPrintCont(format, ...) \
    fprintf(stderr, format , ## __VA_ARGS__)

// this macro is for outputting messages for all builds only when
// debugging is enabled regardless of its value
#define vslMessage(format, ...) \
    if (m_debug) \
        fprintf(stderr, "%s(%d) " format, DEBUG_NAME, \
            __LINE__ , ## __VA_ARGS__)
#define vslMessageCont(format, ...) \
    if (m_debug) \
        fprintf(stderr, format , ## __VA_ARGS__)

// this macro is for conditionally outputting debug information for the debug
// build only when a bit in the mask is set in the debug flag
#ifdef DEBUG_BUILD
#define vslDebug(mask, format, ...) \
    if (m_debug & DEBUG_ ## mask) \
        fprintf(stderr, "%s(%d) " format, DEBUG_NAME, \
            __LINE__ , ## __VA_ARGS__)
#define vslDebugCont(mask, format, ...) \
    if (m_debug & DEBUG_ ## mask) \
        fprintf(stderr, format , ## __VA_ARGS__)
#else
#define vslDebug(mask, format, ...) ;
#define vslDebugCont(mask, format, ...) ;
#endif

// these macros are for surrounding a section of code for debug build only
// for the specified debug flag (12-04-06 ch3)
#define vslDebugIf(mask)  if (m_debug & DEBUG_ ## mask)


#endif // VSLDEBUG_H
