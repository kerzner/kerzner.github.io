// vim:smarttab expandtab sw=4:
#ifndef SEWRAPPER_H
#define SEWRAPPER_H

#include <QDir>
#include <QObject>
#include <QStringList>
#include <QProcessEnvironment>
#include <QVector>

#include "SeEvaluation.h"
#include "SeSysEvalInfo.h"

#include "NamePool.h"
extern "C" {
#include "Se.h"
#include "SeDefs.h"  // moved here from SeWrapper.cpp (11-12-09 ch3)
}
class SePrivate;
class EvaluationTables;
class SysdefVisitor;

enum SeUserType {
    SeSystemUserType = 1000,  // QTreeWidgetItem::UserType
    SeCompUserType
};

struct SeTreeNodeInfo {
    SeUserType type;            // system or component
    int index;                  // system/component index
    QString name;               // name of system or component

    SeTreeNodeInfo(const SeUserType _type, const int _index, const char *_name):
        type(_type),
        index(_index),
        name(_name) {
    }
};

// single expression evaluation node class (11-12-07 ch3)
class SeEvalNode
{
    SeNodeCategory m_type;          // type of node
    union {
        int m_index;            // index for component and system nodes
        float m_value;          // value of node (constants only)
    };

public:
    SeEvalNode(SeNodeCategory type = SeNT_UNSET, int index = -1):
        m_type(type),
        m_index(index) {
    }
    SeEvalNode(SeNodeCategory type, float value):
        m_type(type),
        m_value(value) {
    }

    // function to return type
    SeNodeCategory type(void) {
        return m_type;
    }
    // function to return type as an integer
    int typeAsInt(void) {
        return (int)m_type;
    }
    // function to return index
    int index(void) {
        return m_index;
    }
    // function to return value as an integer
    float value(void) {
        return m_value;
    }
    // function to return value as an integer
    int valueAsInt(void) {
        return m_index;  // index is integer form of value via union
    }
};

class SeDevice;
class SeSysEvalInfo;

class SeWrapper : public QObject
{
    Q_OBJECT
public:
    // 12-03-14 ch3: added environment argument
    explicit SeWrapper(QObject *parent);
    ~SeWrapper(void);

    bool componentsLoad(const QStringList &compNames);

    void componentAddList(const QStringList &names);

    // get component index from name
    int componentIndexGet(const QString &name);

    // get qualified component index for component and qualifier indexes
    int qualifiedComponentIndex(int compIndex, int qualIndex);

    // get qualified component index from name
    int qualifiedComponentIndex(const QString qualName);

    // get component name from index
    QString componentNameGet(int compindex);

    void componentDelete(int compindex);

    //  register a new component (or replace an existing one) (11-06-03 ch3)
    // 11-06-18 ch3: added system index argument
    void componentRegister(const int compindex);

    bool componentValueGet(int index, SeTypeID &t, float &v);

    // set the value for a component
    // removed QString name argument (11-07-01 ch3)
    void componentValueSet(int index, SeTypeID type, float value);

    // load a system definition file
    bool sysDefOpenFile(QString &fileName);

    // parse a string and add system
    void sysDefParseString(QString systemDefinition);

    QString sysDefPrintAll(const QDir &dir); // Should be const

#   ifdef VSL_USE_CUDA
    // function to check if device is initialized (12-12-24 ch3)
    bool isDeviceInitialized(void);
#   endif

    // get a copy of the current system evaluation info
    // (caller provides allocated memory to copy to)
    bool sysEvalInfo(SeSysEvalInfo *sysEvalInfo);

    bool evaluateSingle(int index);

    // get system index from name
    int systemIndexGet(const QString &name);

    // get system name from index
    QString systemNameGet(int sysindex);  // (11-06-22 ch3)

    // change name for system index
    bool systemNameChange(int sysindex, QString &name);  // (11-06-22 ch3)

    // clear the values for ALL systems (like the name says)
    void systemValueClearAll(void);

    // functions for getting the full text for a system
    // changed argument from name to index (11-06-27 ch3)
    QString systemDefinitionGet(int index);

    // delete currently selected system
    bool systemDelete(const QString &name);

    // determine if system is defined (11-05-25 ch3)
    bool systemIsDefined(int index);

    //  register a new system (or replace an existing one
    void systemRegister(const int index);

    bool systemValueGet(int index, SeTypeID &type, float &value);
    // return system index (11-06-02 ch3)
    // removed name argument, changed index to input (11-06-22 ch3)

    // set the type/value for a single system
    // This will be the value used until it is changed
    // or asked to be recomputed
    // removed systemValueSetByName() (11-07-01 ch3)
    // renamed systemValueSetByIndex() (11-07-01 ch3)
    // added lock argument (11-12-13 ch3)
    void systemValueSet(int index, SeTypeID type, float value, bool lock);

#   ifdef VSL_USE_CUDA
    // get CUDA memory information (12-12-11)
    size_t getDeviceFreeMemory(void);
#   endif

    float geomMMScale(void) {
        return m_geomMMScale;
    }

    void setAvailableThreatMats(QStringList availableThreatMats) {
        m_availableThreatMats = availableThreatMats;
    }

    QStringList qualifierList(void) const {
        return namePoolList(m_qualifiers);
    }

    QStringList qualifiedComponentList(void) const {
        return namePoolList(m_qualComps);
    }

    // return accumulated error string message and then clear it (12-12-05)
    QString errorMessage(bool clear = true) {
        QString message = m_errorMessage;
        if (clear) {
            m_errorMessage.clear();
        }
        return message;
    }

    void setStitchErrorMessage(const QString &string) {
        m_stitchErrorMessage = string;
    }
    bool hasStitchError(void) {
        return !m_stitchErrorMessage.isEmpty();
    }

    // let MdiSysDefWin access private functions
    friend class MdiSysDefWin;

    QMap<QString, float> evaluateSystems(QMap<QString, float> inCompVals);

    void testEvaluateSystem(void);

    QString getAsGraphVizInput();

    QString getAsFilteredGraphVizInput(QStringList);

    QMap<QString, float> compVals();
public slots:
    bool componentCreate(const QString name, int *ptr = (int *)NULL);

    void componentValueClearAll(void); // clear them all

    void setGeomMMScale(float mmScale) {
        m_geomMMScale = mmScale;
    }

signals:
    void wrapperInitialized(void);

    void componentAllValuesCleared(void);

    // removed QString name argument (11-07-01 ch3)
    void componentValueChanged(int);

    //
    void deletedComponent(QString);

    //
    void deletedDefinedSystem(int, QString);

    //
    void deletedUndefinedSystem(QString);

    // a new component has been created
    void newComponent(QString, int);

    // comonent list was cleared
    void clearComponents();

    // a system as be defined/redefined
    // 11-06-13 ch3: now combined with old systemDefined()
    void newDefinedSystem(QList<SeTreeNodeInfo>);
    void newDefinedSystem(int, QString, bool);

    // a system has been discovered but not defined
    // 11-06-20 ch3: added system index argument
    void newUndefinedSystem(QString, int);

    // a system name has changed (11-06-22 ch3)
    void systemNameChanged(int, QString);

    void systemValueChanged(QString, int, int, SeTypeID, float);

    //
    void undefinedSystemIsNowComponent(QString, int, int);

    void componentIsNowUndefinedSystem(QString, int, int);

    void sysEvalInfoChanged();

private:
    bool componentIsUsedAnywhere(int compindex);

    void systemScanForAllowedSystems(void);

    void systemScanForQualifiedComps(void);

    void systemConvertToComponent(const QString &name, int sysIndex,
                                  int compIndex);

    bool systemIsUsedAnywhere(int sysindex);

    // encode a system (11-12-07 ch3)
    bool systemEncode(int index, QString &errmsg);

    bool hasTable(void) {
        return !m_tableHash.isEmpty();
    }

    // generate order of sub-system evaluations (11-12-08 ch3)
    bool systemGenerateOrderList(QList<int> &orderList, SeQualHash &qualSystems,
                                 SeQualHash &qualComps, int index, int qualIndex, bool singleEvaluation);

    // initialize evaluation tables for use
    void initializeTable(EvaluationTables *etbls);

    // generate qualifier component name to table offset list hash
    void generateTableHash(QString fileName, EvaluationTables *etables);

    // return list of names from a name pool
    QStringList namePoolList(NamePool *namePool) const;

    // Evaluate one single system
    // Byproduct:  sets the value in the expression tree
    // 11-06-27 ch3: changed name argument to system index
    // 11-12-21 ch3: removed value, added error message return argument
    // 12-06-17 ch3: added new evaluation type argument
    // 12-08-30 ch3: added temporary shotlines argument
    bool initializeEvaluation(int index = -1, SeSysEvalInfo *sysEvalInfo = NULL,
                              QList<int> *orderList = NULL, QVector<int> *stateQualCompIndex = NULL);

    // traverse a sysdef with a visitor instance
    void sysdefTraverse(SysdefVisitor &visitor, SeSysDef *sysdefp,
                        int qualIndex = -1);
    friend class SysdefVisitor;

    QList<int> componentTableList(const QString &qualCompName, int qualIndex);

    void errorMessageAppend(QString errorMessage);

    void findSubSystems(QVector<bool> &topLevel, int sysIndex);

    int negateIndex(int index) {
        return -index - 1;
    }

    // create qualified name from base name and qualifier name
    QString qualifiedName(const QString &baseName, int qualIndex,
                          const QString &qualifier = QString()) {
        return QString("%1[%2]").arg(baseName).arg(qualIndex == -1
                ? qualifier : m_qualifiers->getName(qualIndex));
    }

    // parse base name from qualified name and optionally the qualifier name
    QString baseName(const QString &qualifiedName, QString *qualifier = NULL) {
        QRegExp re("^([^[]+)\\[([^]]+)\\]$");
        re.indexIn(qualifiedName);
        if (qualifier) {
            *qualifier = re.capturedTexts().at(2);
        }
        return re.capturedTexts().at(1);
    }

    SePrivate *m_priv;

    // coded system expressions (11-12-07 ch3)
    QVector<SeCodeInfo> m_sysCode;

    // holds the last error message
    QString m_errorMessage;

    // holds stitch error message string
    QString m_stitchErrorMessage;

    // debug flag (12-03-14 ch3)
    int m_debug;

    // the geometry millimeter scale
    float m_geomMMScale;

    // list of indexes to newly registered system
    QList<int> m_newSysIndexList;

    //! system evaluation info for currently selected system
    SeSysEvalInfo m_sysEvalInfo;

    // evaluation table qualified component name to table list hash
    QHash<QString, QList<int> > m_tableHash;

    // evaluation table data
    EvaluationTables *m_etables;
    QString m_etableFileName;

    NamePool *m_components;             // pointer to RtComponents
    NamePool *m_qualifiers;             // pointer to SeQualifiers
    NamePool *m_qualComps;              // pointer to SeComponents
    NamePool *m_systems;                // pointer to SeSystems
    NmPool m_seQualSystems;             // qualifier system name pool
    NamePool *m_qualSystems;            // pointer to m_seQualSystems

    QStringList m_availableThreatMats;
};


#endif // SEWRAPPER_H
