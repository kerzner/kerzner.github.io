// vim:smarttab expandtab sw=4
#include <QFileInfo>
#include <QMessageBox>
#include <QSet>
#include <QDebug>
#include <cstdlib>

#include "SeWrapper.h"
#include "SeVisitors.h"
#include "SysDefNames.h"
#ifdef VSL_USE_CUDA
#   include "SeDevice.h"
#endif
#include "SeSysEvalInfo.h"
#include "Table2d.h"
#include "VSLDebug.h"

extern "C" {
#include <Er.h>
#include <Io.h>
#include <Dm.h>
// moved #include "SeDefs.h" to SeWrapper.h (11-12-09 ch3)

// define name for debug output, hack for full path in __FILE__ (12-03-13 ch3)
#define DEBUG_NAME  "SeWrapper"

#define DEBUG_ORDLIST   0x00000080
#define DEBUG_ENCODE    0x00000100
#define DEBUG_UNDEF     0x00000200
#define DEBUG_SETSYS    0x00000400
#define DEBUG_LISTS     0x00000800
#define DEBUG_EVAL      0x00001000
#define DEBUG_CODEARR   0x00002000
#define DEBUG_TABLE     0x00004000
#define DEBUG_FINDUSES  0x00008000
#define DEBUG_LOCKSYS   0x00010000
#define DEBUG_TESTEVAL  0x00020000


// Register a system to the user interface (called from C)
    void SeWrapperRegisterSystem(int index, void *ptr)
    {
        SeWrapper *wrapper = (SeWrapper *)ptr;
        wrapper->systemRegister(index);
    }


// Register a component to the user interface (called from C) (11-06-03 ch3)
// 11-06-18 ch3: added system index argument
    void SeWrapperRegisterComponent(int compindex, void *ptr)
    {
        SeWrapper *wrapper = (SeWrapper *)ptr;
        wrapper->componentRegister(compindex);
    }


// Register a system value changed to the user interface (called from C)
    void SeWrapperRegisterSystemValue(int index, void *ptr, SeTypeID type,
                                      double value)
    {
        SeWrapper *wrapper = (SeWrapper *)ptr;
        // added value for new lock argument (11-12-13 ch3)
        wrapper->systemValueSet(index, type, value, false);
    }


}  // end of extern "C" block


#include "SePrivate.h"  // moved class definition to include file (11-12-20 ch3)


// added environment argument (12-03-14 ch3)
SeWrapper::SeWrapper(QObject *parent) :
    QObject(parent),
    m_priv(new SePrivate),
    m_etables(NULL)
{
    DqPkgInit();

    ErPkgInit();
    IoPkgInit();

    NmPkgInit();

    SePkgInit();

    NmInit(&RtComponents);

    m_components = nm_namepool(&RtComponents);
    m_qualifiers = nm_namepool(&SeQualifiers);
    m_qualComps = nm_namepool(&SeComponents);
    m_systems = nm_namepool(&SeSystems);
    NmInit(&m_seQualSystems);
    m_qualSystems = nm_namepool(&m_seQualSystems);

    initializeEvaluation();

    emit wrapperInitialized();
}


SeWrapper::~SeWrapper(void)
{
    delete m_priv;
    delete m_etables;
}


void SeWrapper::systemValueClearAll(void)
{
    SeSysReset();
}


// return system index (11-06-02 ch3)
// changed to have index input argument and no name (11-06-22)
bool SeWrapper::systemValueGet(int index, SeTypeID &type, float &value)
{
    if (SeDataSystem[index] == NULL) {
        return false;
    }

    if (SeDataSystem[index]->state == SeINVALID) {
        return false;
    }

    value = SeDataSystem[index]->save.value;
    type = SeDataSystem[index]->save.type;

    return true;
}

// removed systemValueSetByName() (11-07-01 ch3)

// added value for new lock argument (11-12-13 ch3)
void SeWrapper::systemValueSet(const int index, const SeTypeID type,
                               const float value, bool lock)
{
    // if type == SeINVALID and lock == true then
    //    system is just being unlocked (and about to be re-evaluated)

    vslDebug(SETSYS, "System %s=%g%s\n", m_systems->getName(index), value,
             lock ? " lock" : "");
    if (type == SeTypeUnset) {
        SeDataSystem[index]->save.value = 0.0;
        SeDataSystem[index]->save.type = type;
        SeDataSystem[index]->state = SeINVALID;
    } else if (lock) {
        // set locked state when requested (11-12-13 ch3)
        SeDataSystem[index]->save.value = value;
        SeDataSystem[index]->save.type = type;
        SeDataSystem[index]->state = SeLOCKED;
    } else {
        SeDataSystem[index]->save.value = value;
        SeDataSystem[index]->save.type = type;
        SeDataSystem[index]->state = SeVALID;
    }
    // don't emit signal if system is just being unlocked (11-12-14)
    if (type != SeTypeUnset || !lock) {
        emit systemValueChanged(QString("%1").arg(m_systems->getName(index)),
                                index, SeDataSystem[index]->state, SeDataSystem[index]->save.type,
                                SeDataSystem[index]->save.value);
    }
}


// determine if system is defined (11-05-25 ch3)
bool SeWrapper::systemIsDefined(int index)
{
    return SeDataSystem[index] != NULL;
}


void SeWrapper::componentRegister(const int compindex)
{
    m_priv->resizeValueTable(m_components->size());

    QString name = m_components->getName(compindex);
    emit newComponent(name, compindex);
}


bool SeWrapper::componentsLoad(const QStringList &compNames)
{
    QVector<int> sysToCompIndex;        // undefined system index to comp index
    QVector<int> newCompIndex;          // new comp index for old comp index
    QVector<int> compToSysIndex;        // comp index to undefined system index

    //****************************
    //  VALIDATE COMPONENT NAMES
    //****************************

    // check and see if component names match RtComponents
    bool match = false;
    if (compNames.count() == m_components->size()) {
        match = true;
        for (int i = 0; i < compNames.count(); i++) {
            if (compNames.at(i) != componentNameGet(i)) {
                match = false;
                break;
            }
        }
    }
    if (match) {
        return true;  // components match exactly, nothing to do
    }

    // make sure there are no duplicate component names
    QSet<QString> compNameSet;
    QStringList nameList;
    foreach (QString compName, compNames) {
        if (compNameSet.contains(compName)) {
            nameList.append(compName);     // add to duplicate list
        } else {
            compNameSet.insert(compName);  // add to set
        }
    }
    compNameSet.clear();  // done with the set
    if (!nameList.isEmpty()) {
        m_errorMessage = "Unable to stitch geometry\n"
                         "These component names are duplicate:\n" + nameList.join(" ");
        return false;
    }

    // make sure none of the new components are defined systems
    if (SeDataSystem != NULL) {
        sysToCompIndex.fill(-1, m_systems->size());
        for (int i = 0; i < compNames.count(); i++) {
            int sysIndex = systemIndexGet(compNames.at(i));
            if (sysIndex >= 0) {
                if (SeDataSystem[sysIndex] != NULL) {
                    nameList.append(compNames.at(i));
                }
                // undefined system is becoming a component
                sysToCompIndex[sysIndex] = i;
            }
        }
        if (!nameList.isEmpty()) {
            m_errorMessage = "Unable to stitch geometry\n"
                             "These component names are defined systems:\n"
                             + nameList.join(" ");
            return false;
        }
    }

    //***************************************
    //  FINISH GENERATING CONVERSION TABLES
    //***************************************

    // make list of old component names
    QStringList oldCompNames;
    for (int i = 0; i < m_components->size(); i++) {
        oldCompNames.append(componentNameGet(i));  // may be blank
    }
    // clear name pool and emit signal to clear component list
    m_components->clear();
    emit clearComponents();

    // add new component names to RtComponents
    m_priv->resizeValueTable(compNames.count());
    for (int i = 0; i < compNames.count(); i++) {
        const char *compName = qPrintable(compNames.at(i));
        int compIndex = m_components->addName(compName);
        emit newComponent(compNames.at(i), compIndex);
    }

    // delete names of undefined systems becoming components (may be empty)
    for (int i = 0; i < sysToCompIndex.count(); i++) {
        if (sysToCompIndex.at(i) != -1) {
            const QString &name = m_systems->getName(i);
            m_systems->deleteName(qPrintable(name));
            emit undefinedSystemIsNowComponent(name, i, sysToCompIndex.at(i));
        }
    }

    // generate new indexes for old component indexes
    // (if old component doesn't exist anymore, convert to undefined systtem)
    newCompIndex.fill(-1, oldCompNames.count());
    compToSysIndex.fill(-1, oldCompNames.count());
    for (int i = 0; i < oldCompNames.count(); i++) {
        newCompIndex[i] = componentIndexGet(oldCompNames.at(i));
        if (newCompIndex[i] < 0) {  // component no longer there?
            compToSysIndex[i] = SeSysInsert(qPrintable(oldCompNames.at(i)));
            if (compToSysIndex.at(i) == -1) {
                // this should not happen
                qFatal("Could not add new undefined system '%s'",
                       qPrintable(oldCompNames.at(i)));
            }
            emit newUndefinedSystem(oldCompNames.at(i), compToSysIndex.at(i));
        }
    }

    // go through each system and update for changes
    // - convert undefined systems to components
    // - renumber component indexes
    // - convert components into undefined systems
    for (int i = SeSyDStart; i < m_systems->size(); i++) {
        const char *name = m_systems->getName(i);
        if (name != NULL && SeDataSystem[i] != NULL) {
            UpdateNodeCategorysAndIndexesSysdefVisitor updateNodeCategorysAndIndexes(
                this, newCompIndex, sysToCompIndex, compToSysIndex);
            sysdefTraverse(updateNodeCategorysAndIndexes, SeDataSystem[i]->sysdef);
            if (updateNodeCategorysAndIndexes.modified()) {
                // need to re-encode system
                QString message;
                if (!systemEncode(i, message)) {
                    message.prepend(QString("Loading Components:\n"
                                            "System '%1' Encode Failure\n").arg(name));
                    QMessageBox::warning(0, tr("VSL-SysDef-Encode "), message,
                                         QMessageBox::Ok);
                }
            }
        }
    }
    return true;
}


void SeWrapper::componentValueClearAll(void)
{
    m_priv->clearValues();
    emit componentAllValuesCleared();
}


// get a component index from a component name (11-05-23 ch3)
int SeWrapper::componentIndexGet(const QString &name)
{
    int index = m_components->getIndex(qPrintable(name));

    // clear error flag in case name not found by NmIndex() (12-08-30 ch3)
    ErClear();

    return index;
}


// get a component index from a component name (11-05-23 ch3)
int SeWrapper::qualifiedComponentIndex(int compIndex, int qualIndex)
{
    QString qualCompName = QString("%1[%2]")
                           .arg(m_components->getName(compIndex))
                           .arg(m_qualifiers->getName(qualIndex));

    return m_qualComps->addName(qPrintable(qualCompName));
}


// get qualified component index from name
int SeWrapper::qualifiedComponentIndex(const QString qualName)
{
    return m_qualComps->getIndex(qPrintable(qualName));
}


// get a component name from a component index (11-05-23 ch3)
QString SeWrapper::componentNameGet(int compindex)
{
    return m_components->getName(compindex);
}


// set a component value at component index (11-05-23 ch3)
// removed QString name argument (11-07-01 ch3)
void SeWrapper::componentValueSet(int index, SeTypeID type, float value)
{
    m_priv->setComponentValue(index, type, value);
    emit componentValueChanged(index);
}


// get a component value for component index (11-05-23 ch3: from name)
bool SeWrapper::componentValueGet(int index, SeTypeID &type, float &value)
{
    return m_priv->getComponentValue(index, type, value);
}


bool SeWrapper::componentCreate(const QString name, int *ptr)
{
    // not a known system, just add component
    // add name to component pool and get its index
    int compindex = m_components->addName(qPrintable(name));

    if (ptr != NULL) {
        *ptr = compindex;
    }

    if (compindex == -1) {
        ErClear();
        vslMessage("Component name '%s' could not be added\n",
                   qPrintable(name));
        return false;
    }
    m_priv->resizeValueTable(m_components->size());

    emit newComponent(name, compindex);
    return true;
}


// Add a list of components (replacing undefined systems)
void SeWrapper::componentAddList(const QStringList &names)
{
    foreach (QString name, names) {
        int sysindex = m_systems->getIndex(qPrintable(name));
        // Is this name a known system?
        if (sysindex < 0) {
            ErClear();
            // name not in SeSystems, just define component
            componentCreate(name);
        } else {
            // Name is in SeSystems
            // Is this name defined/undefined?
            if (SeDataSystem[sysindex] == NULL) {
                // System not defined, convert to component
                int compindex;
                if (componentCreate(name, &compindex)) {
                    systemConvertToComponent(name, sysindex, compindex);
                    // 11-06-18 ch3: moved signal to function
                } else {
                    // report error
                    // FIXME temporary (report to gui)
                    vslPrint("ERROR: cannot create component <%s>\n",
                             qPrintable(name));
                }
            } else {
                // was a defined system, cannot be made into component
                continue;
            }
        }
    }
}


// this function is called when unstitching component (deleted in geometry)
void SeWrapper::componentDelete(int compindex)
{
    // get name of component and delete from component name pool
    QString compName = componentNameGet(compindex);
    const char *name = qPrintable(compName);
    m_components->deleteName(name);

    // FLAG also need to delete from qualified component name pool

    // check if component is currently used in a system
    if (!componentIsUsedAnywhere(compindex)) {
        // tell sysdef window that component has been deleted
        emit deletedComponent(componentNameGet(compindex));
    } else {  // component is used, changed to undefined system
        // add component as new system (which is undefined)
        int sysindex = SeSysInsert(name);
        if (sysindex == -1) {
            qFatal("componentDelete: could not insert system '%s'", name);
        }

        // resize code vector as needed
        if (sysindex >= (int)m_sysCode.size()) {
            m_sysCode.resize(sysindex + 1);
        }

        // go through each system and replace system with component
        for (int i = SeSyDStart; i < m_systems->size(); i++) {
            name = m_systems->getName(i);
            if (name != NULL && SeDataSystem[i] != NULL) {
                ReplaceCompWithSystemSysdefVisitor replace(this, compindex,
                        sysindex);
                sysdefTraverse(replace, SeDataSystem[i]->sysdef);
                if (replace.modified()) {
                    // need to encode system again if changed
                    QString message;
                    if (!systemEncode(i, message)) {
                        message.prepend(QString("Converting Component To "
                                                "System:\nSystem '%1' Encode Failure\n").arg(name));
                        QMessageBox::warning(0, tr("VSL-SysDef-Encode"),
                                             message, QMessageBox::Ok);
                    }
                }
            }
        }
        // tell sysdef window component is now an undefined system
        emit componentIsNowUndefinedSystem(compName, compindex, sysindex);
    }
}


// Reports if a component (by index) is currently used in any system definition
bool SeWrapper::componentIsUsedAnywhere(int compindex)
{
    // go through each system and check if system is used
    for (int i = SeSyDStart; i < m_systems->size(); i++) {
        if (m_systems->getName(i) != NULL && SeDataSystem[i] != NULL) {
            ComponentSysdefVisitor component(this, compindex);
            sysdefTraverse(component, SeDataSystem[i]->sysdef);
            if (component.found()) {
                return true;  // component is used, no need to check further
            }
        }
    }
    return false;  // not found
}


// Delete a system definition including its name and expression
// along with any undefined and unused systems in its expression
//
//   Arguments:
//     name          - name of system to delete
//     errmsg        - error message string if an error occurs
//
//   Returns:
//     true  - system was successfully deleted
//     false - error occurred, nothing deleted (error string in errmsg)
bool SeWrapper::systemDelete(const QString &name)
{
    int index = m_systems->getIndex(qPrintable(name));
    if (index < 0) {
        ErClear();
        m_errorMessage = QString("System name '%1' unknown").arg(name);
        return false;
    }
    if (SeDataSystem[index] == NULL) {
        m_errorMessage = QString("System '%1' not defined").arg(name);
        return false;
    }

    // get a list of components used in system definition before deleting it
    UseCountSysdefVisitor useCount(this, m_systems->size());
    sysdefTraverse(useCount, SeDataSystem[index]->sysdef);

    // first delete the system definition expression and array element
    SeExpFree(SeDataSystem[index]->sysdef);
    DmFree(SeDataSystem[index]);
    SeDataSystem[index] = NULL;

    // delete from defined list, and delete all children from system
    // Note that this will blow away the QString we were passed
    // This is why we DmStrDup at the beginning
    emit deletedDefinedSystem(index, name);
    // check if the system being deleted is no longer used
    if (systemIsUsedAnywhere(index)) {
        // name is still use, so add name to undefined list
        // 11-06-20 ch3: added system index argument
        emit newUndefinedSystem(name, index);

        // emit signal to reset system's value (11-06-20 ch3)
        emit systemValueChanged(name, index, SeINVALID, SeTypeUnset, -1.0);
    } else {
        // system not used, so name can be deleted from system name pool
        m_systems->deleteName(qPrintable(name));
    }

    // check if sub-systems used by the deleted system are no longer used
    for (int i = SeSyDStart; i < m_systems->size(); i++) {
        if (useCount.system(i) > 0 // was used by deleted system
            && SeDataSystem[i] == NULL  // is not defined
            && !systemIsUsedAnywhere(i)) { // is not used anywhere (else)
            // sub-system no longer used anywhere,
            // so it too can be deleted from name pool
            const char *ssname = m_systems->getName(i);
            if (ssname) {
                QString deletedSys(ssname);

                emit deletedUndefinedSystem(deletedSys);

                m_systems->deleteName(ssname);
            } else {
                abort();
            }
        }
    }
    return true;
}


// get a system index from a component name (11-06-07 ch3)
int SeWrapper::systemIndexGet(const QString &name)
{
    int index = m_systems->getIndex(qPrintable(name));

    // clear error flag in case name not found by NmIndex() (11-06-27 ch3)
    ErClear();

    return index;
}


// get a system name from a system index (11-06-22 ch3)
QString SeWrapper::systemNameGet(int sysindex)
{
    return m_systems->getName(sysindex);
}


// Reports if a system (by index) is currently used in any system definition
bool SeWrapper::systemIsUsedAnywhere(int sysindex)
{
    // go through each system and check if system is used
    for (int i = SeSyDStart; i < m_systems->size(); i++) {
        if (m_systems->getName(i) != NULL && SeDataSystem[i] != NULL) {
            SystemSysdefVisitor system(this, sysindex);
            sysdefTraverse(system, SeDataSystem[i]->sysdef);
            if (system.found()) {
                return true;  // system is used, no need to check further
            }
        }
    }
    return false;  // not found
}


// Replace system with component in all system definitions
// (system must be undefined)
//
//   Arguments:
//     name      - name of system to change to a component
//     sysindex  - index of system being replaced
//     compindex - index of component to replace
//
//   Returns:
//     true  - system was successfully changes to a component
//     false - error occurred, nothing deleted (error string in errmsg)
//
//   Note:
//     Component names are added to the RtComponents.  The SeCompile
//     code will convert a QUALOP (QUALSYS, CQUALIFIER) node to a
//     QUALOP (COMPNAME, CQUALIFIER) node if the QUALSYS name is in
//     the RtComponent name pool.

void SeWrapper::systemConvertToComponent(const QString &name, int sysindex,
        int compindex)
{
    // go through each system and replace system with component
    for (int i = SeSyDStart; i < m_systems->size(); i++) {
        const char *name = m_systems->getName(i);
        if (name != NULL && SeDataSystem[i] != NULL) {
            ReplaceSystemWithCompSysdefVisitor replace(this, sysindex,
                    compindex);
            sysdefTraverse(replace, SeDataSystem[i]->sysdef);
            if (replace.modified()) {
                // need to encode system again if changed
                QString message;
                if (!systemEncode(i, message)) {
                    message.prepend(QString("Converting System To Component:\n"
                                            "System '%1' Encode Failure\n").arg(name));
                    QMessageBox::warning(0, tr("VSL-SysDef-Encode"), message,
                                         QMessageBox::Ok);
                }
            }
        }
    }

    // now delete the system name from the system name pool
    // (something weird inside Nm changes cname, so give it a copy)
    m_systems->deleteName(qPrintable(name));

    // discover and add any new qualified components
    systemScanForQualifiedComps();

    // 11-06-18 ch3: moved signal to here, name was deleted here
    emit undefinedSystemIsNowComponent(name, sysindex, compindex);
}


// change the name of a system (11-06-22 ch3)
bool SeWrapper::systemNameChange(int sysindex, QString &name)
{
    // first check that new name is not already used
    if (systemIndexGet(name) >= 0) {
        name = QString("'%1' is already a system name").arg(name);
        return false;
    }
    if (componentIndexGet(name) >= 0) {
        name = QString("'%1' is already a component name").arg(name);
        return false;
    }

    // change the name in the system name pool
    const char *oldname = m_systems->getName(sysindex);
    char *newname = DmStrDup(qPrintable(name));
    if (m_systems->changeName(oldname, newname) < 0) {
        DmFree(newname);
        name = QString("Failure changing system name to '%1'").arg(name);
        return false;
    }

    // go through each system and change name of system
    for (int i = SeSyDStart; i < m_systems->size(); i++) {
        const char *name = m_systems->getName(i);
        if (name != NULL && SeDataSystem[i] != NULL) {
            ChangeSystemNameSysdefVisitor change(this, sysindex, newname);
            sysdefTraverse(change, SeDataSystem[i]->sysdef);
        }
    }

    DmFree(newname);

    // let it be known that system has a new name
    emit systemNameChanged(sysindex, name);
    return true;
}


// Return a string with the definition of the names system
// formatting is nice but not important now
//
// changed argument from name to index (11-06-27 ch3)
QString SeWrapper::systemDefinitionGet(int index)
{
    QString expr;
    if (SeDataSystem[index] == NULL) {
        expr.append("<undefined>");
    } else {
        GetStringSysdefVisitor getString(this);
        sysdefTraverse(getString, SeDataSystem[index]->sysdef);
        expr = getString.result();
    }
    // sanitize system name, will add quotes if needed (11-07-05 ch3)
    return QString("%1 = %2").arg(SysDefSanitizeName(m_systems->getName(index)),
                                  expr);
}


QString SeWrapper::sysDefPrintAll(const QDir &dir)
{
    QString FullSysDef;

    // output evaluation table file name if precent as "#TABLE:xxxxx"
    if (m_etables) {
        QFileInfo fileInfo(m_etableFileName);
        FullSysDef.append(QString("#TABLE:%1\n").arg(fileInfo.dir() == dir
                          ? fileInfo.fileName() : m_etableFileName));
    }

    // output components as "#COMP:xxxxx" (11-06-03 ch3)
    bool comps = false;
    for (int i = 0; i < m_components->size(); i++) {
        const char *name = m_components->getName(i);
        if (name != NULL) {
            // sanitize component name, will add quotes if needed (11-07-04 ch3)
            FullSysDef.append(QString("#COMP:%1\n")
                              .arg(SysDefSanitizeName(name)));
            comps = true;
        }
    }
    if (comps) {
        FullSysDef.append("\n");
    }

    // go through each user-defined function (12-04-02 ch3)
    for (int i = SeFnDStart; i < NmSize(&SeFunctions); i++) {
        const char *name = NmName(i, &SeFunctions);
        if (name != NULL && SeFnDfn[i] != NULL) {
            // sanitize system name, will add quotes if needed
            FullSysDef.append(QString("%1(").arg(SysDefSanitizeName(name)));

            // get expression and make a list of parameters
            GetStringSysdefVisitor getString(this);
            sysdefTraverse(getString, SeFnDfn[i]->funcdefp);

            // append parameter names found for arguments of the function
            for (int i = 0; i < getString.paramCount(); i++) {
                if (i > 0) {
                    FullSysDef.append(QString(", "));
                }
                FullSysDef.append(getString.param(i));
            }

            // now added the expression for the function
            FullSysDef.append(QString(") = %2\n\n").arg(getString.result()));
        }
    }

    // go through each system and check if system is used
    for (int i = SeSyDStart; i < m_systems->size(); i++) {
        const char *name = m_systems->getName(i);
        if (name != NULL && SeDataSystem[i] != NULL) {
            GetStringSysdefVisitor getString(this);
            sysdefTraverse(getString, SeDataSystem[i]->sysdef);

            // sanitize system name, will add quotes if needed (11-07-05 ch3)
            FullSysDef.append(QString("%1 = %2\n\n")
                              .arg(SysDefSanitizeName(name), getString.result()));
        }
    }
    return FullSysDef;
}


// Open a file an parse it
// - this will only be called with a fresh sysdef window
// - components will be loaded if there is geometry
// - if there was a evaluation curve table in sysdef
//   then its file name is returned in fileName else fileName is cleared
// This should emit newSystems(QStringList) with a list of systems discovered
bool SeWrapper::sysDefOpenFile(QString &fileName)
{
    SeParseVars *vars = m_priv->vars(this);
    if (!SeSysReadFile(vars, qPrintable(fileName))) {
        // FIXME temporary (report to gui)
        vslPrint("ERROR: %s\n", m_priv->varsErrMsg());
        return false;  // FIXME for now just return
    }
    systemScanForAllowedSystems();

    QString workFileName = vars->etable;
    if (!workFileName.isEmpty()) {
        QFileInfo fileInfo(workFileName);
        if (fileInfo.isRelative()) {
            fileInfo.setFile(fileName);
            QDir dir = fileInfo.dir();
            fileInfo.setFile(dir, workFileName);
            workFileName = fileInfo.filePath();
        }
    }
    fileName = workFileName;

#ifdef DEBUG_BUILD
    vslDebugIf(LISTS) {
        // access and output list of qualifiers and qualified componets
        QStringList list = namePoolList(m_components);
        vslPrint("Components:");
        foreach (QString name, list) {
            vslPrintCont(" %s", qPrintable(name));
        }
        vslPrintCont("\n");
        list = qualifierList();
        vslPrint("Qualifiers:");
        foreach (QString name, list) {
            vslPrintCont(" %s", qPrintable(name));
        }
        vslPrintCont("\n");
        list = qualifiedComponentList();
        vslPrint("Qualified Components:");
        foreach (QString name, list) {
            vslPrintCont(" %s", qPrintable(name));
        }
        vslPrintCont("\n");
    }
#endif
    return true;
}

// Parse a single string
// This needs to emit newSystems(QStringList) with a list of systems discovered
// (as in defined or merely referred to)
void SeWrapper::sysDefParseString(QString systemDefinition)
{
    char *sysdef = DmStrDup(qPrintable(systemDefinition));
    if (!SeSysAdd(m_priv->vars(this), sysdef)) {
        QString message;
        if (m_priv->hasVarsErrMsg()) {
            message = QString("ERROR: %1\n").arg(m_priv->varsErrMsg());
        }
        if (ErIsSet()) {
            if (ErIndex != SeSYSRECURSIVE) {
                message.append(QString("ERROR CODE: %1\n").arg(ErIndex));
            }
            ErClear();
        }
        message.append("\nSystem definition rejected!");
        QMessageBox::warning(0, tr("VSL-SysDef"), message, QMessageBox::Ok);
    } else {  // emit all currently known systems
        systemScanForAllowedSystems();
    }
    DmFree(sysdef);
}


void SeWrapper::systemRegister(const int index)
{
    SeSysDef *sysdefp = SeDataSystem[index]->sysdef;
    if (sysdefp == NULL) {
        return;
    }

    QList<SeTreeNodeInfo> list;
    list.append(SeTreeNodeInfo(SeSystemUserType, index,
                               m_systems->getName(index)));

    const char *name;

    UseCountSysdefVisitor useCount(this, m_systems->size(),
                                   m_components->size());
    sysdefTraverse(useCount, sysdefp);
    for (int i = SeSyDStart; i < m_systems->size(); i++) {
        if (useCount.system(i) > 0) {
            if ((name = m_systems->getName(i)) == NULL) {
                name = "<bad sys index>";
            }
            list.append(SeTreeNodeInfo(SeSystemUserType, i, name));
        }
    }
    for (int i = 0; i < m_components->size(); i++) {
        if (useCount.comp(i) > 0) {
            if ((name = m_components->getName(i)) == NULL) {
                name = "<bad comp index>";
            }
            list.append(SeTreeNodeInfo(SeCompUserType, i, name));
        }
    }

    // 11-12-06 ch3: resize code vector as needed
    if (index >= (int)m_sysCode.size()) {
        m_sysCode.resize(index + 1);
    }

    // 11-12-06 ch3: encode system
    QString message;
    if (!systemEncode(index, message)) {
        message.prepend(QString("Registering System:\n"
                                "System '%1' Encode Failure\n").arg(m_systems->getName(index)));
        QMessageBox::warning(0, tr("VSL-SysDef-Encode"), message,
                             QMessageBox::Ok);
    }

    // add system index to list of new systems added list
    m_newSysIndexList.append(index);

    // 11-06-13 ch3: now combined with old systemDefined()
    // NOTE v/l eval dock widget only uses first item in the list
    emit newDefinedSystem(list);
}


// function to scan new systems and report if systems are allowed
// (allowed systems have only qualified components and no undefined systems)
void SeWrapper::systemScanForAllowedSystems(void)
{
    foreach (int sysIndex, m_newSysIndexList) {
        SystemIsAllowedSysdefVisitor system(this);
        sysdefTraverse(system, SeDataSystem[sysIndex]->sysdef);
        emit newDefinedSystem(sysIndex, QString(m_systems->getName(sysIndex)),
                              system.isAllowed());
    }
    m_newSysIndexList.clear();
}


// function to scan all systems and find qualified components
// (allowed systems have only qualified components and no undefined systems)
void SeWrapper::systemScanForQualifiedComps(void)
{
    for (int sysIndex = SeSyDStart; sysIndex < m_systems->size(); sysIndex++) {
        if (SeDataSystem[sysIndex] != NULL) {
            // just add previously undiscovered qualified components
            SystemIsAllowedSysdefVisitor system(this);
            sysdefTraverse(system, SeDataSystem[sysIndex]->sysdef);
        }
    }
}


// function to encode sysdefinition to rpn format (11-12-07 ch3)
bool SeWrapper::systemEncode(int index, QString &errmsg)
{
    if (SeDataSystem[index] == NULL) {
        errmsg.append(QString("\nUndefined System (%1)").arg(index));
        return false;
    }

    GetNodesSysdefVisitor getNodes(this);
    sysdefTraverse(getNodes, SeDataSystem[index]->sysdef);
    SeCodeInfo &sysCode = m_sysCode[index];
    sysCode.codeArray.clear();
    if (getNodes.stopped()) {
        errmsg = getNodes.errorMessage();
        sysCode.qualSystems.clear();
        sysCode.orderList.clear();
        return false;
    }
    // get code size and add two for terminating assignment and index
    int codeSize = getNodes.codeSize() + 2;

    // encode evaluation nodes
    sysCode.qualSystems = getNodes.qualSystems();
    sysCode.codeArray.reserve(codeSize);
    sysCode.stackSize = 0;
    sysCode.frameSize = 0;
    int stackSize = 0;
    int frameSize = 0;
    vslDebug(ENCODE, "%d-%s(%d):", index, m_systems->getName(index), codeSize);
    foreach (SeEvalNode node, getNodes.nodeList()) {
        sysCode.codeArray.append(node.typeAsInt());
        // get second word for double word types
        switch (node.type()) {
        case SeNT_SYSNAME:
            sysCode.codeArray.append(node.index());
            stackSize++;  // will push one value onto stack
            if (stackSize > sysCode.stackSize) {
                sysCode.stackSize = stackSize;
            }
            vslDebugCont(ENCODE, " %d-%s", node.index(),
                         m_systems->getName(node.index()));
            break;
        case SeNT_QUALSYS:
            // this node type will need to be changed to SYSNAME
            sysCode.codeArray.append(node.index());
            stackSize++;  // will push one value onto stack
            if (stackSize > sysCode.stackSize) {
                sysCode.stackSize = stackSize;
            }
            vslDebugCont(ENCODE, " %d-%s", node.index(),
                         // WORK if index is into m_qualSystems, get name from there
                         qPrintable(m_qualSystems->getName(node.index())));
            break;
        case SeNT_COMPNAME:
            sysCode.codeArray.append(node.index());
            stackSize++;  // will push one value onto stack
            if (stackSize > sysCode.stackSize) {
                sysCode.stackSize = stackSize;
            }
            vslDebugCont(ENCODE, " @%d-%s", node.index(),
                         m_components(node.index()));
            break;
        case SeNT_QUALCOMP:
            // this node type will need to be changed to COMPNAME
            sysCode.codeArray.append(node.index());
            stackSize++;  // will push one value onto stack
            if (stackSize > sysCode.stackSize) {
                sysCode.stackSize = stackSize;
            }
            vslDebugCont(ENCODE, " %d-%s", node.index(),
                         m_qualComps->getName(node.index()));
            break;
        case SeNT_CONSTANT:
            sysCode.codeArray.append(node.valueAsInt());
            stackSize++;  // will push one value onto stack
            if (stackSize > sysCode.stackSize) {
                sysCode.stackSize = stackSize;
            }
            vslDebugCont(ENCODE, " %g", node.value());
            break;
        case SeNT_NOT:
        case SeNT_ANOT:
        case SeNT_ABS:
        case SeNT_BOOL:
            // unary operators won't change stack
            vslDebugCont(ENCODE, " %s", SeTtbl[node.type()].ts);
            break;

            // added support for function calls (12-03-16 ch3)
        case SeNT_FNCALL:
            // add number of arguments - 1 (amount to offset for parameters)
            // (no change to stack size)
            sysCode.codeArray.append(node.index() - 1);
            frameSize++;  // place to put stack pointer frame value
            if (frameSize > sysCode.frameSize) {
                sysCode.frameSize = frameSize;
            }
            vslDebugCont(ENCODE, " FNBEG,%d", node.index() - 1);
            break;

        case SeNT_PARAM:
            sysCode.codeArray.append(node.index());  // argument number
            stackSize++;  // will push one value onto stack
            if (stackSize > sysCode.stackSize) {
                sysCode.stackSize = stackSize;
            }
            vslDebugCont(ENCODE, " PARAM,%d", node.index());
            break;

        case SeNT_FUNCNAME:  // end of function call
            // end of functions will pull arguments from stack
            stackSize -= node.index();  // number of arguments
            // (the number of argument is not needed in the code)
            frameSize--;  // value pulled to reset stack pointer
            vslDebugCont(ENCODE, " FNEND,%d", node.index() - 1);
            break;

        default:
            // binary operators will pull one value from stack
            stackSize--;
            // 12-03-16 ch3: only use SeTtbl[] for binary operators
            vslDebugCont(ENCODE, " %s", SeIS_BINARY_OP(node.type())
                         ? SeTtbl[node.type()].ts : SeCvtToStr(node.type()));
            break;
        }
    }

    // now add the assignment and system index (this node type is as
    // good as anything and won't otherwise be seen in an expression)
    sysCode.codeArray.append(SeNT_ASSIGNMENT);
    sysCode.codeArray.append(index);
    vslDebugCont(ENCODE, " %s {%d,%d}\n", SeTtbl[SeNT_ASSIGNMENT].ts,
                 sysCode.stackSize, sysCode.frameSize);

    // save order list
    sysCode.orderList = getNodes.orderList();
#ifdef DEBUG_BUILD
    vslDebugIf(ENCODE) {
        if (!sysCode.orderList.empty()) {
            vslPrint(" Order:");
            foreach (int sysIndex, sysCode.orderList) {
                vslPrintCont(" %s", m_systems->getName(sysIndex));
            }
            vslPrintCont("\n");
        }
    }
#endif
    return true;
}


// generate reverse system evaluation order list (11-12-07 ch3)
//
//   - a system with an empty order list indicates either the system
//     calls no other systems or is not defined (later is okay)
//   - builds order list recursively by prepending order list of each
//     system called
//   - qualified systems found are appended to the info qualified
//     systems list
// possible errors:
//   system not defined (unlikely)
//   system not encoded (possibly due to system containing undefined systems)
//   null sysdef pointer (unlikely)
//   invalid system index (incomplete)
//   invalid component index (incomplete)
//   unexpected sysdef type node (unlikely should have been caught when encoded)

bool SeWrapper::systemGenerateOrderList(QList<int> &orderList,
                                        SeQualHash &qualSystems, SeQualHash &qualComps, int index, int qualIndex,
                                        bool singleEvaluation)
{
    if (SeDataSystem[index] == NULL) {  // is system not defined?
        // this is not a fatal error (this system will be set to an unset
        // value and when evaluated, a type appropriate value will be used)
        vslDebug(UNDEF, "System (%d) undefined\n", i);
    } else {
        SeCodeInfo &sysCode = m_sysCode[index];

        // get each system's order list
        for (int i = 0; i < sysCode.orderList.size(); i++) {
            int sysIndex;
            int sysQualIndex;

            // get qualifier and base system index if qualified system
            int index = sysCode.orderList.at(i);
            if (index >= 0) {  // unqualified system?
                sysIndex = index;
                sysQualIndex = qualIndex;
            } else {  // qualified system
                // QUALIFIER ON SYSTEM OVERRIDES INCOMING QUALIFIER

                // get actual system index for stored list index
                index = negateIndex(index);
                sysCode.qualSystems.value(index).get(sysIndex, sysQualIndex);
            }

            // check and add to order list for system with qualifier
            if (!systemGenerateOrderList(orderList, qualSystems, qualComps,
                                         sysIndex, sysQualIndex, singleEvaluation)) {
                return false;
            }
        }

        if (SeDataSystem[index]->sysdef == NULL) {
            errorMessageAppend("Null sysdef pointer");
            return false;
        }
        // apply qualifier and add any new qualified components to list
        GetQualCompsSysdefVisitor getQualComps(this, qualComps,
                                               m_priv->getTableSize(), singleEvaluation, m_debug);
        sysdefTraverse(getQualComps, SeDataSystem[index]->sysdef, qualIndex);
        if (getQualComps.hasError()) {
            errorMessageAppend(getQualComps.errorMessage());
            return false;
        }
    }

    // add this system to end of order list
    if (qualIndex >= 0) {
        // apply qualifier to system name and get negated system index
        QString qualName = qualifiedName(m_systems->getName(index), qualIndex);
        int qualSysIndex = m_qualSystems->addName(qPrintable(qualName));
        qualSystems.insert(qualSysIndex, SeQualItem(index, qualIndex));
        index = negateIndex(qualSysIndex);
    }
    orderList.append(index);
    return true;
}


// function to setup master component table info
void SeWrapper::generateTableHash(QString fileName, EvaluationTables *etables)
{
    QStringList compNameList = etables->componentMap.keys();
    foreach (QString compName, compNameList) {
        // get vector of table IDs for component name
        QVector<int> tableIdVector = etables->componentMap.value(compName);

        // loop through each table ID in vector
        // (vector will be empty if component not found)
        for (int j = 0; j < tableIdVector.count(); j++) {
            // get table ID and qualifier name for table
            int tableId = tableIdVector.at(j);
            QString qualifier = etables->qualName(tableId);

            // add table offset to qualified component name to table list
            m_tableHash[qualifiedName(compName, -1, qualifier)]
            .append(etables->tableOffsets.at(tableId));
        }
    }

    // save pointer to evaluation tables
    delete m_etables;
    m_etables = etables;
    m_etableFileName = fileName;
}


#ifndef VSL_USE_CUDA
#   include <math.h>
#   define  EVALUATESYSDEFS_H
#   include "EvaluateSysDefs.h"
#endif

// setup system evaluation information
// - function should only be called by MdiSysDefWin when top-level sys changes
// - use sysEvalInfo() to obtain a copy of the system evaluation information
// - when sysEvalInfo == NULL then m_sysEvalInfo is setup
// - when orderList == NULL then local order list used
// - also used by SeWrapper for single evaluation
//   (uses its own sysEvalInfo and also requires orderList)
bool SeWrapper::initializeEvaluation(int index, SeSysEvalInfo *sysEvalInfo,
                                     QList<int> *orderList, QVector<int> *stateQualCompIndex)
{
    int compTotalCount;
    int compCount;
    SeQualHash qualSystems;
    SeQualHash qualComps;

    m_errorMessage.clear();

    if (sysEvalInfo == NULL) {
        sysEvalInfo = &m_sysEvalInfo;
    }

    sysEvalInfo->topIndex = index;
    if (index == -1) {
        sysEvalInfo->topName = "<invalid>";
        return false;  // no system currently selected (evaluation disabled)
    }
    sysEvalInfo->topName = systemNameGet(index);

    // only check if top level system is undefined (12-03-21 ch3)
    if (SeDataSystem[index] == NULL) {
        m_errorMessage = "System not defined";
        vslPrint("Undefined System (%d)", index);
        return false;
    }

    compTotalCount = m_priv->getTableSize();
    // check if components have been registered yet
    if (compTotalCount < m_components->size()) {
        vslDebug(UNDEF, "Unregistered components (%d < %d)\n",
                 compTotalCount, m_components->size());
        compTotalCount = m_components->size();
        m_priv->resizeValueTable(compTotalCount);
        // note: new components will be unset
    }

    //************************************
    //  GENERATE SYSTEM EVALUATION ORDER
    //************************************

    QList<int> localOrderList;
    bool singleEvaluation;
    if (orderList == NULL) {
        singleEvaluation = false;
        orderList = &localOrderList;
        compCount = hasTable() ? m_qualComps->size() : compTotalCount;
    } else {
        singleEvaluation = true;
        compCount = compTotalCount;
    }

    // XXX only need to do this if system has changed XXX [S]
    // generate order list for system if not already generated (11-12-09 ch3)
    int nSystems = m_systems->size();
    if (!systemGenerateOrderList(*orderList, qualSystems, qualComps, index, -1,
                                 singleEvaluation)) {
        // TODO this may not be a fatal error situation
        // TODO main errors that can occur are bad system/component indexes
        // TODO mostly due to incomplete system definitions
        // check if error is fatal, i.e. there is a message (12-03-14 ch3)
        if (!m_errorMessage.isEmpty()) {
            QMessageBox::warning(0, tr("Evaluation Initialization Error"),
                                 QString("System '%1' contains errors:\n\n%2")
                                 .arg(systemNameGet(index)).arg(m_errorMessage),
                                 QMessageBox::Ok);
            return false;
        } else {
            vslDebug(UNDEF, "Cannot evaluate system (%d-%s), contains "
                     "undefined elements\n", index, m_systems->getName(index));
        }
        return true;  // not a fatal error, silently ignore problem
    }

    //**********************************************
    //  DETERMINE SIZES / GET LOCKED SYSTEM VALUES
    //**********************************************

    int totalCount = nSystems + m_qualSystems->size();
    // reallocate for maximum number of systems as needed
    sysEvalInfo->locked.clear();

    // XXX need to do this if system or view has changed XXX [SV]
    // get total code size of systems to evaluate (11-12-15 ch3)
    int codeSize = 1;  // allow one for terminator
    sysEvalInfo->stackSize = 0;  // maximum stack size that will be needed
    sysEvalInfo->frameSize = 0;  // maximum frame size that will be needed
    vslDebug(EVAL, "Evaluation Order:");
    foreach (int index, *orderList) {
        int sysIndex;  // base system index of system
        if (index < 0) {  // qualified system?
            // convert to a system index after regular systems
            index = negateIndex(index);
            sysIndex = qualSystems.value(index).baseIndex();
            vslDebugCont(EVAL, " %s", m_qualSystems->getName(index));
            index += nSystems;  // index of system into evaluation arrays
        } else {  // unqualified system
            sysIndex = index;
            vslDebugCont(EVAL, " %s", m_systems->getName(index));
        }

        // ignore undefined systems
        if (SeDataSystem[sysIndex] == NULL) {
            continue;
        }

        // only count code for unlocked systems
        // FLAG can qualifier systems by locked?
        if (SeDataSystem[sysIndex]->state != SeLOCKED) {
            codeSize += m_sysCode[sysIndex].codeArray.size();
            if (sysEvalInfo->stackSize < m_sysCode[sysIndex].stackSize) {
                sysEvalInfo->stackSize = m_sysCode[sysIndex].stackSize;
            }
            // calculate frame size needed for function calls (12-03-16 ch3)
            if (sysEvalInfo->frameSize < m_sysCode[sysIndex].frameSize) {
                sysEvalInfo->frameSize = m_sysCode[sysIndex].frameSize;
            }
        } else {
            // for locked systems, save locked value
            SeLockedSystem lockedSystem;
            lockedSystem.index = index;
            lockedSystem.value = SeDataSystem[sysIndex]->save;
            sysEvalInfo->locked.append(lockedSystem);
        }
    }
    vslDebugCont(EVAL, " (stack=%d frame=%d)\n", sysEvalInfo->stackSize,
                 sysEvalInfo->frameSize);

    //********************
    //  SETUP CODE ARRAY
    //********************

    // XXX only need to do this if system has changed XXX [S]
    sysEvalInfo->code.resize(codeSize);
    sysEvalInfo->index.fill(-1, totalCount);
    sysEvalInfo->count = 0;
    sysEvalInfo->compCount = 0;
    QVector<int> compStateIndex;            // indexed by code index
    compStateIndex.fill(-1, compCount);
    QVector<QList<int> > stateTableList;    // indexed by state index
    QVector<int> localStateQualCompIndex;   // indexed by state index
    if (stateQualCompIndex == NULL) {
        stateQualCompIndex = &localStateQualCompIndex;
    }
    QVector<QList<int> > compStateIndexList(compTotalCount);  // by compIndex
    int *code = sysEvalInfo->code.data();
    int i = 0;
    foreach (index, *orderList) {
        int qualIndex;          // index of qualifier to apply to unqual comps
        int sysIndex;           // actual system index

        if (index >= 0) {  // unqualified system?
            sysIndex = index;
            if (SeDataSystem[sysIndex] == NULL
                || SeDataSystem[sysIndex]->state == SeLOCKED) {
                continue;  // skip undefined and locked unqualified systems
            }
            qualIndex = -1;
        } else {  // qualified system
            // convert to a system index after regular systems
            index = negateIndex(index);
            qualSystems.value(index).get(sysIndex, qualIndex);
        }
        // copy code for each non-locked system to code array
        // convert qualified systems/comps to absolute systems/comps
        // apply qualifier for a qualified system
        SeCodeInfo &sysCode = m_sysCode[sysIndex];
        QList<int> &sysCodeArray = sysCode.codeArray;
        for (int j = 0; j < sysCodeArray.size(); j++) {
            int codeWord = sysCodeArray[j];
            int codeIndex;
            int compIndex;
            int stateIndex;
            int tmpQualIndex;
            QString qualName;
            switch (codeWord) {
            case SeNT_QUALSYS:
                // CONVERT NODE TYPE AND GENERATE GLOBAL INDEX
                // get qualified system index and
                // change to a global system index (qualified systems at end)
                codeIndex = sysCodeArray.at(++j) + nSystems;

                if (!singleEvaluation) {
                    // get translated index (next index if not seen before)
                    if (sysEvalInfo->index.at(codeIndex) == -1) {
                        sysEvalInfo->index.replace(codeIndex,
                                                   sysEvalInfo->count++);
                    }
                    codeIndex = sysEvalInfo->index.at(codeIndex);
                }

                // change node type to SYSNAME and copy system index
                *code++ = SeNT_SYSNAME;
                *code++ = codeIndex;
                break;

            case SeNT_QUALCOMP:
                // CONVERT NODE TYPE AND GENERATE GLOBAL INDEX
                // get qualified component index
                codeIndex = sysCodeArray.at(++j);
                qualComps.value(codeIndex).get(compIndex, tmpQualIndex);
                if (singleEvaluation) {
                    // ignore qualifiers, use base component index
                    codeIndex = compIndex;
                } else {
                    int qualCompIndex = codeIndex;
                    if (hasTable()) {
                        qualName = m_qualComps->getName(codeIndex);
                    } else {
                        // ignore qualifiers, use base component index
                        codeIndex = compIndex;
                    }
                    // get state index
                    stateIndex = compStateIndex.at(codeIndex);
                    if (stateIndex == -1) {  // not seen before?
                        // assign to next state index
                        stateIndex = sysEvalInfo->compCount++;
                        compStateIndex.replace(codeIndex, stateIndex);
                        // get table list for qualifier component
                        // (table list will have unset if no table)
                        stateTableList.append(componentTableList(qualName,
                                              tmpQualIndex));
                        stateQualCompIndex->append(qualCompIndex);
                        // add to list of state for component
                        compStateIndexList[compIndex].append(stateIndex);
                    }
                    codeIndex = stateIndex;
                }
                // change node type to COMPNAME and set component index
                *code++ = SeNT_COMPNAME;
                *code++ = codeIndex;
                break;

                // two word instructions
            case SeNT_COMPNAME:
                compIndex = sysCodeArray.at(++j);
                if (singleEvaluation) {
                    codeIndex = compIndex;
                } else {
                    int qualCompIndex;

                    // only apply qualifer when not single evaluation
                    if (hasTable()) {
                        if (qualIndex == -1) {
                            errorMessageAppend(QString("unallowed unqualified "
                                                       "component '%1'")
                                               .arg(m_components->getName(compIndex)));
                            break;  // will catch at end
                        }
                        qualName = qualifiedName(
                                       m_components->getName(compIndex), qualIndex);
                        codeIndex = m_qualComps->getIndex(qPrintable(qualName));
                        if (codeIndex < 0) {
                            // this should not happen (something is not working)
                            errorMessageAppend(QString("qualified component "
                                                       "'%1' not present").arg(qualName));
                            break;  // will catch at end
                        }
                        qualCompIndex = codeIndex;
                    } else {
                        // ignore qualifiers, use base component index
                        codeIndex = compIndex;
                    }

                    // get state index
                    stateIndex = compStateIndex.at(codeIndex);
                    if (stateIndex == -1) {  // not seen before?
                        // assign to next state index
                        stateIndex = sysEvalInfo->compCount++;
                        compStateIndex.replace(codeIndex, stateIndex);
                        // get table list for qualifier component
                        stateTableList.append(componentTableList(
                                                  qualName, qualIndex));
                        stateQualCompIndex->append(qualCompIndex);
                        // add to list of state for component
                        compStateIndexList[compIndex].append(stateIndex);
                    }
                    codeIndex = stateIndex;
                }
                *code++ = codeWord;
                *code++ = codeIndex;
                break;

            case SeNT_SYSNAME:
            case SeNT_ASSIGNMENT:
                codeIndex = sysCodeArray.at(++j);
                if (qualIndex >= 0) {
                    qualName = qualifiedName(m_systems->getName(codeIndex),
                                             qualIndex);
                    codeIndex = m_qualSystems->getIndex(qPrintable(qualName));
                    if (codeIndex < 0) {
                        // this should not happen (something is not working)
                        errorMessageAppend(QString("qualified system '%1' not "
                                                   "present").arg(qualName));
                        break;  // will catch at end
                    }
                    // change to a global system index
                    codeIndex += nSystems;
                }
                if (!singleEvaluation) {
                    // get state index (next index if not seen before)
                    if (sysEvalInfo->index.at(codeIndex) == -1) {
                        sysEvalInfo->index.replace(codeIndex,
                                                   sysEvalInfo->count++);
                    }
                    codeIndex = sysEvalInfo->index.at(codeIndex);
                }
                *code++ = codeWord;
                *code++ = codeIndex;
                break;

            case SeNT_CONSTANT:
            case SeNT_FNCALL:
            case SeNT_PARAM:
                *code++ = codeWord;  // copy instruction
                // copy second word of instruction
                *code++ = sysCodeArray.at(++j);
                break;

                // one word instructions
            default:
                *code++ = codeWord;  // copy instruction
                break;
            }
        }
    }
    // lastly copy code terminator word
    code[i] = SeNT_UNSET;  // expression code terminator word

    if (!singleEvaluation) {
        QList<int> evalTableList;  // tables needed for this evaluation
        QList<int> evalCompList;   // component for table (for error reporting)

        sysEvalInfo->compEvalStart.clear();
        sysEvalInfo->compEvalData.clear();
        sysEvalInfo->compEvalStart.append(0);
        for (int compIndex = 0; compIndex < compTotalCount; compIndex++) {
            foreach (int stateIndex, compStateIndexList.at(compIndex)) {
                QList<int> tableList = stateTableList.at(stateIndex);
                if (tableList.isEmpty()) {
                    errorMessageAppend(QString("no table for '%1'")
                                       .arg(m_qualComps->getName(stateQualCompIndex
                                               ->at(stateIndex))));
                } else {
                    foreach (int tableOffset, tableList) {
                        SeCompEvalData evalData;
                        evalData.tableOffset = tableOffset;
                        evalData.stateIndex = stateIndex;
                        sysEvalInfo->compEvalData.append(evalData);
                        if (tableOffset >= 0
                            && evalTableList.indexOf(tableOffset) == -1) {
                            // make of list of unique tables for evaluation
                            evalTableList.append(tableOffset);
                            evalCompList.append(compIndex);
                        }
                    }
                }
            }
            sysEvalInfo->compEvalStart.append(sysEvalInfo->compEvalData.size());
        }

        if (hasTable()) {
            // initialize evaluation table (from a copy)
            sysEvalInfo->evalTableBuffer = m_etables->tableBuffer;

            // FLAG temporary hack for penetration equation names
            QStringList penEqNames = QStringList() << "LineOfSite"
                                     << "FiremanPugh" << "Thor";

            // loop though each table offset for evaluation
            for (int i = 0; i < evalTableList.count(); i++) {
                QString string;
                const char *name;
                int index;
                Table2d *table = (Table2d *)(sysEvalInfo->evalTableBuffer.data()
                                             + evalTableList.at(i));

                // translate table material id
                index = table->mtlId();
                if (index != -1) {  // does table have material?
                    string = m_etables->mtlNames.at(index);
                    bool stringFound = false;

                    //Perform a case insensitive search
                    int numAvailableMats = m_availableThreatMats.count();

                    for(int j = 0; j < numAvailableMats; j++) {
                        QString threatMat = m_availableThreatMats[j];
                        if(threatMat.compare(string, Qt::CaseInsensitive) == 0) {
                            stringFound = true;
                            index = j;
                            break;
                        }
                    }

                    if (!stringFound) {
                        errorMessageAppend(QString("component '%1': material "
                                                   "name '%2' not found")
                                           .arg(m_components->getName(evalCompList.at(i)))
                                           .arg(string));
                        continue;  // ignore this table
                    }
                    table->setMtlId(index);
                }

                // translate table penentration equation id
                index = table->penEqId();
                string = m_etables->validPenEqNames.at(index);
                index = penEqNames.indexOf(string);
                if (index == -1) {
                    errorMessageAppend(QString("component '%1': pen eq name "
                                               "'%2' not found")
                                       .arg(m_components->getName(evalCompList.at(i)))
                                       .arg(string));
                    continue;  // ignore this table
                }
                table->setPenEqId(index);

                // translate table qualifier name id
                index = table->qualId();
                name = qPrintable(m_etables->qualNames.at(index));
                index = m_qualifiers->getIndex(name);
                if (index < 0) {
                    errorMessageAppend(QString("component '%1': qualifier '%2' "
                                               " not found")
                                       .arg(m_components->getName(evalCompList.at(i)))
                                       .arg(name));
                    continue;  // ignore this table
                }
                table->setQualId(index);
            }

            // translate locked system indexes (12-12-22 ch3)
            for (int i = 0; i < sysEvalInfo->locked.count(); i++) {
                sysEvalInfo->locked[i].index
                = sysEvalInfo->index.at(sysEvalInfo->locked.at(i).index);
            }
        }
    }

    if (!m_errorMessage.isEmpty()) {
        QMessageBox::warning(0, tr("Evaluation Initialization Error"),
                             QString("System '%1' contains errors:\n\n%2")
                             .arg(systemNameGet(index)).arg(m_errorMessage),
                             QMessageBox::Ok);
        return false;
    }

#ifdef DEBUG_BUILD
    vslDebugIf(CODEARR) {
        vslPrint("Code Array (%d/%d):", i + 1, codeSize);
        for (i = 0; i < codeSize; i++)
            vslPrintCont(" %d", sysEvalInfo->code.at(i));
        vslPrintCont("\n");
    }
#endif

#ifdef DEBUG_BUILD
    vslDebugIf(LOCKSYS) {
        vslPrint("Locked Systems (%d):", sysEvalInfo->locked.count());
        for (i = 0; i < m_sysLocked.count(); i++)
            vslPrintCont(" %d (%g)", sysEvalInfo->locked.at(i).index,
                         sysEvalInfo->locked.at(i).value.value);
        vslPrintCont("\n");
    }
#endif

    emit sysEvalInfoChanged();
    return true;  // memory is setup so done here
}


// function to traverse a sysdef carrying a visitor instance to each node type
void SeWrapper::sysdefTraverse(SysdefVisitor &visitor, SeSysDef *sysdefp,
                               int qualIndex)
{
    switch (sysdefp->type) {
    case SeNT_QUALSYS:
        visitor.visitQualSysNode(sysdefp, qualIndex);
        break;

    case SeNT_SYSNAME:
        visitor.visitSysNameNode(sysdefp, qualIndex);
        break;

    case SeNT_QUALCOMP:
        visitor.visitQualCompNode(sysdefp, qualIndex);
        break;

    case SeNT_COMPNAME:
        visitor.visitCompNameNode(sysdefp, qualIndex);
        break;

    case SeNT_QUALOP:
        visitor.visitQualOpNode(sysdefp, qualIndex);
        break;

    case SeNT_CONSTANT:
        visitor.visitConstantNode(sysdefp, qualIndex);
        break;

    case SeNT_FNCALL:
        visitor.visitFnCallNode(sysdefp, qualIndex);
        break;

    case SeNT_PARAM:
        visitor.visitParamNode(sysdefp, qualIndex);
        break;

    case SeNT_MULTOCC:
    case SeNT_EXPR:
    case SeNT_NOT:
    case SeNT_ANOT:
    case SeNT_ABS:
    case SeNT_BOOL:
        visitor.visitUnaryOpNode(sysdefp, qualIndex);
        break;

    case SeNT_AND:
    case SeNT_XOR:
    case SeNT_OR:
    case SeNT_MIN:
    case SeNT_MAX:
    case SeNT_SUM:
    case SeNT_DIFF:
    case SeNT_PROD:
    case SeNT_QUOT:
    case SeNT_LT:
    case SeNT_GT:
    case SeNT_LTEQ:
    case SeNT_GTEQ:
        visitor.visitBinaryOpNode(sysdefp, qualIndex);
        break;

    case SeNT_RUNIF:
    case SeNT_RNORM:
    case SeNT_MOFN:
    case SeNT_PKD:
    case SeNT_ORCA:
    case SeNT_EVAL:
        visitor.visitSeFuncNode(sysdefp, qualIndex);
        break;

    default:
        visitor.visitOtherNode(sysdefp, qualIndex);
    }
}


// get a list of table offsets for a qualified component
// - arguments not used if there is no table
QList<int> SeWrapper::componentTableList(const QString &qualCompName,
        int qualIndex)
{
    QList<int> tableList;

    if (hasTable()) {
        tableList = m_tableHash.value(qualCompName);
        if (tableList.isEmpty()) {
            QString qualifier = m_qualifiers->getName(qualIndex);
            if (qualifier.compare("ishit", Qt::CaseInsensitive) == 0
                || qualifier.compare("is_hit", Qt::CaseInsensitive) == 0) {
                tableList.append(SeTableOffsetIsHit);
            } else if (qualifier.compare("isthreatened", Qt::CaseInsensitive)
                       == 0
                       || qualifier.compare("is_threatened", Qt::CaseInsensitive)
                       == 0) {
                tableList.append(SeTableOffsetIsThreatened);
            } else if (qualifier.compare("los", Qt::CaseInsensitive) == 0
                       || qualifier.compare("line_of_sight", Qt::CaseInsensitive)
                       == 0
                       || qualifier.compare("line_of_site", Qt::CaseInsensitive)
                       == 0) {
                tableList.append(SeTableOffsetLineOfSite);
            }
            // else error, return empty table list
        }
    } else {
        tableList.append(SeTableOffsetUnSet);
    }
    return tableList;
}


// append another line to error message (add a line break if not empty)
void SeWrapper::errorMessageAppend(QString errorMessage)
{
    if (!m_errorMessage.isEmpty()) {
        m_errorMessage.append('\n');
    }
    m_errorMessage.append(errorMessage);
}


// make a copy of the current system evaluation info
// if a valid system is currently selected
bool SeWrapper::sysEvalInfo(SeSysEvalInfo *sysEvalInfo)
{
    if (m_sysEvalInfo.topIndex == -1) {
        if (m_stitchErrorMessage.isEmpty()) {
            m_errorMessage = "No top level system selected";
        } else {
            m_errorMessage = m_stitchErrorMessage;
        }
        return false;
    }
    *sysEvalInfo = m_sysEvalInfo;
    return true;
}


bool SeWrapper::evaluateSingle(int index)
{
    QList<int> orderList;
    SeSysEvalInfo sysEvalInfo;

    if (!initializeEvaluation(index, &sysEvalInfo, &orderList)) {
        return false;
    }

    // perform the evaluation and get the results
    // made evaluation status an array (12-06-17 ch3)
    qint8 evalStatus;
    QVector<qint8> sysTypes(sysEvalInfo.totalCount());
    QVector<float> sysValues(sysEvalInfo.totalCount());

    // HOST EVALUATION
    // allocate component arrays
    QVector<qint8> compTyps(m_priv->getTableSize());
    QVector<float> compVals(m_priv->getTableSize());
    // copy component value array from m_priv
    m_priv->getValueTable(compTyps, compVals);

    // allocate host memory for the evaluation
    QVector<float> stack(sysEvalInfo.stackSize);
    QVector<qint16> frame(sysEvalInfo.frameSize);

    // for locked systems, copy locked value to system types/values array
    sysEvalInfo.setLockedSystemStates(sysTypes, sysValues);

    // evaluation the current code array on the host
    evaluateSysDefs(sysEvalInfo.code.data(), sysTypes.data(),
                    sysValues.data(), compTyps.data(), compVals.data(), stack.data(),
                    frame.data(), &evalStatus);

    //*******************
    //  PROCESS RESULTS
    //*******************

    // check status and set displayed values from system values array
    // modified to only append error message once (12-03-16 ch3)

    // get status of first (maybe only) evaluation (12-06-17 ch3)
    foreach (int sysIndex, orderList) {
        // ignore qualified, undefined and locked systems
        if (sysIndex > 0 && SeDataSystem[sysIndex] != NULL
            && SeDataSystem[sysIndex]->state != SeLOCKED) {
            // check for evaluation error (invalidate systems)
            if (evalStatus == EvaluateGood) {
                // evaluation good, set system value
                // XXX for now just get values from first set of system values
                systemValueSet(sysIndex, (SeTypeID)sysTypes[sysIndex],
                               sysValues[sysIndex], false);
            } else {
                SeDataSystem[sysIndex]->state = SeINVALID;
            }
        }
    }
    switch (evalStatus) {
    case EvaluateGood:
        // evaluation good, no error
        break;

    case EvaluateDivByZero:
        m_errorMessage = "Divide by zero";
        break;

    case EvaluateBadCode:
        m_errorMessage = "Bad code found";
        break;

    case EvaluateStackErr:
        m_errorMessage = "Stack error";
        break;

    case EvaluateFrameErr:  // added frame error (12-03-16 ch3)
        m_errorMessage = "Frame error";
        break;

    default:  // this shouldn't happen
        m_errorMessage = "Unknown error";
        break;
    }

    return evalStatus == EvaluateGood;
}


void SeWrapper::findSubSystems(QVector<bool> &topLevel, int sysIndex)
{
    SeCodeInfo &sysCode = m_sysCode[sysIndex];

    for (int i = 0; i < sysCode.orderList.size(); i++) {
        int index = sysCode.orderList.at(i);
        if (index < 0) {  // qualified system?
            index = negateIndex(index);
            QString sysName = baseName(m_qualSystems->getName(index));
            index = m_systems->getIndex(qPrintable(sysName));
        }
        findSubSystems(topLevel, index);
        // this system is used, so it's not a top-level system
        topLevel[index] = false;
    }
}


QMap<QString, float> SeWrapper::evaluateSystems(QMap<QString, float> inCompVals)
{
    QHash<QString, QList<int> > saveTableHash;
    bool haveTmpEtables = false;
    QMap<QString, float> outSysValues;

    // create a new table hash only for components present
    QHash<QString, QList<int> > tmpTableHash;
    for (int i = 0; i < m_qualComps->size(); i++) {
        tmpTableHash[m_qualComps->getName(i)] = QList<int>()
                                                << SeTableOffsetUnSet;
    }

    // make a temporary table has and evaluation tables
    if (hasTable()) {
        // save current table
        saveTableHash = m_tableHash;
    }

    // replace with temporary table until the end of this function
    m_tableHash = tmpTableHash;

    // make sure there is a dummy evaluation tables
    // (any table will work for code below, but there needs to be a table)
    if (m_etables == NULL) {
        m_etables = new EvaluationTables;
        haveTmpEtables = true;
    }

    // assume all systems are top-level unless determined otherwised
    QVector<bool> topLevel(m_systems->size(), true);

    // make of list of top-level systems
    for (int sysIndex = SeSyDStart; sysIndex < m_systems->size(); sysIndex++) {
        if (SeDataSystem[sysIndex] == NULL) {
            topLevel[sysIndex] = false;  // system not defined
        } else {
            findSubSystems(topLevel, sysIndex);
        }
    }

    // evaluate all the top-level systems
    for (int sysIndex = SeSyDStart; sysIndex < m_systems->size(); sysIndex++) {
        if (topLevel[sysIndex]) {
            SeSysEvalInfo sysEvalInfo;
            QVector<int> qualCompIndexByStateIndex;

            if (!initializeEvaluation(sysIndex, &sysEvalInfo, NULL,
                                      &qualCompIndexByStateIndex)) {
                m_tableHash = saveTableHash;
                if (haveTmpEtables) {
                    m_etables = NULL;
                }
                return outSysValues;
            }

            // build translation from state index to qualified component index
            QVector<int> stateIndexByQualCompIndex(m_qualComps->size(), -1);
            for (int i = 0; i < sysEvalInfo.compCount; i++) {
                stateIndexByQualCompIndex[qualCompIndexByStateIndex.at(i)] = i;
            }

            // create vector of component states and fill them from input values
            QVector<qint8> compTyps(sysEvalInfo.compCount);
            QVector<float> compVals(sysEvalInfo.compCount);
            QMapIterator<QString, float> i(inCompVals);
            bool haveCompValues = false;
            while (i.hasNext()) {
                i.next();
                int qualCompIndex = m_qualComps->getIndex(qPrintable(i.key()));
                if (qualCompIndex != NmNOT_FOUND) {
                    int stateIndex = stateIndexByQualCompIndex
                                     .at(qualCompIndex);
                    if (stateIndex >= 0) {
                        compVals[stateIndex] = i.value();
                        haveCompValues = true;
                    }
                }
            }

            if (!haveCompValues) {
                continue;  // no component values, move to next system
            }
            // create vectors for system states, stack and frame
            qint8 evalStatus;
            QVector<qint8> sysTypes(sysEvalInfo.count);
            QVector<float> sysValues(sysEvalInfo.count);
            QVector<float> stack(sysEvalInfo.stackSize);
            QVector<qint16> frame(sysEvalInfo.frameSize);

            // evaluate the current code array on the host
            evaluateSysDefs(sysEvalInfo.code.data(), sysTypes.data(),
                            sysValues.data(), compTyps.data(), compVals.data(),
                            stack.data(), frame.data(), &evalStatus);

            if (evalStatus != EvaluateGood) {
                m_errorMessage = QString("error evaluating system '%1' "
                                         "status: %2").arg(m_systems->getName(sysIndex))
                                 .arg(evalStatus);
                outSysValues.clear();
                break;
            }

            // collect system value results
            int nSystems = m_systems->size();
            for (int i = 0; i < sysEvalInfo.totalCount(); i++) {
                int index = sysEvalInfo.index.at(i);
                if (index >= 0) {  // system present?
                    float sysValue = sysValues.at(index);
                    if (sysValue > 0) {  // non-zero Pk?
                        QString sysName;
                        if (i < nSystems) {  // unqualified system?
                            sysName = m_systems->getName(i);
                        } else {  // qualified system
                            sysName = m_qualSystems->getName(i - nSystems);
                            // note: a qualified system may occur more than
                            //       once in different top-level systesm,
                            //       but it will have the same value
                        }
                        outSysValues.insert(sysName, sysValue);
                    }
                }
            }
        }
    }
    m_tableHash = saveTableHash;
    if (haveTmpEtables) {
        m_etables = NULL;
    }
    return outSysValues;
}


// function to return list of names in name pool
// - some names in list may be blank
QStringList SeWrapper::namePoolList(NamePool *namePool) const
{
    QStringList list;

    for (int i = 0; i < namePool->size(); i++) {
        list << namePool->getName(i);
    }
    return list;
}

QMap<QString, float> SeWrapper::compVals(void)
{
    QMap<QString, float> compVals;


    /* compVals["commander_head"] = 1;
    compVals["commander_neck"] = 0.661;
    compVals["commander_thorax"] = 0.544;
    compVals["commander_abdomen"] = 0.198;
    compVals["commander_pelvis"] = 0.565;
    compVals["commander_leg"] = 0.211;
    compVals["crew_air[respen]"] = 369;
    compVals["armor_turring[hits]"] = 700;
    compVals["fuel_inttank_midrack[hits]"] = 1;
    compVals["carrousel_celllift_lt[hits]"] = 1;
    compVals["carrousel_celllift_rt[hits]"] = 10;
    compVals["prop4_fuze[hits]"] = 1;
    compVals["prop4_cartridge[hits]"] = 1;
    compVals["prop38_cartridge[hits]"] = 9;
    compVals["prop39_cartridge[hits]"] = 9;
    compVals["prop42_cartridge[hits]"] = 1;
    compVals["dvr_ctl_brakelinkage[hits]"] = 4;
    compVals["dvr_ctl_gslinkage[hits]"] = 3;
    compVals["dvr_ctl_rthblinkage[hits]"] = 4;
    compVals["telec_distbox1wire[hits]"] = 6;
    compVals["telec_ringwire[hits]"] = 33;
    compVals["telec_laser_powersup[hits]"] = 1;
    compVals["tint_comradio_wire_a1[hits]"] = 1;
    compVals["text_cdrsight[hits]"] = 1;
    compVals["tint_gungyro[hits]"] = 1;
    compVals["commander_head[hits]"] = 3;
    compVals["commander_neck[hits]"] = 2;
    compVals["commander_thorax[hits]"] = 1;
    compVals["commander_abdomen[hits]"] = 6;
    compVals["commander_pelvis[hits]"] = 8;
    compVals["commander_leg[hits]"] = 8; */
    srand(1);
    compVals["text_cdrsight[hit]"] = (float) rand() / RAND_MAX;
    compVals["commander_head[hit]"] = (float) rand() / RAND_MAX;
    compVals["commander_neck[hit]"] = (float) rand() / RAND_MAX;
    compVals["commander_thorax[hit]"] = (float) rand() / RAND_MAX;
    compVals["commander_abdomen[hit]"] = (float) rand() / RAND_MAX;
    compVals["commander_pelvis[hit]"] = (float) rand() / RAND_MAX;
    compVals["commander_leg[hit]"] = (float) rand() / RAND_MAX;
    compVals["dvr_ctl_brakelinkage[hit]"] = (float) rand() / RAND_MAX;
    compVals["dvr_ctl_rthblinkage[hit]"] = (float) rand() / RAND_MAX;
    compVals["dvr_ctl_gslinkage[hit]"] = (float) rand() / RAND_MAX;
    compVals["telec_ringwire[hit]"] =(float) rand() / RAND_MAX;
    compVals["telec_laser_powersup[hit]"] = (float) rand() / RAND_MAX;
    compVals["telec_distbox1wire[hit]"] = (float) rand() / RAND_MAX;
    compVals["carrousel_celllift_lt[hit]"] = (float) rand() / RAND_MAX;
    compVals["carrousel_celllift_rt[hit]"] = (float) rand() / RAND_MAX;
    compVals["tint_gungyro[hit]"] = (float) rand() / RAND_MAX;
    compVals["armor_turring[hit]"] = (float) rand() / RAND_MAX;
    compVals["prop4_fuze[hit]"] = (float) rand() / RAND_MAX;
    compVals["prop4_cartridge[hit]"] = (float) rand() / RAND_MAX;
    compVals["prop38_cartridge[hit]"] = (float) rand() / RAND_MAX;
    compVals["prop39_cartridge[hit]"] = (float) rand() / RAND_MAX;
    compVals["prop42_cartridge[hit]"] = (float) rand() / RAND_MAX;
    compVals["tint_comradio_wire_a1[hit]"] = (float) rand() / RAND_MAX;
    compVals["dvr_ctl_brakelinkage[hit]"] = (float) rand() / RAND_MAX;
    compVals["dvr_ctl_rthblinkage[hit]"] = (float) rand() / RAND_MAX;
    compVals["dvr_ctl_gslinkage[hit]"] = (float) rand() / RAND_MAX;
    return compVals;
}

void SeWrapper::testEvaluateSystem(void)
{
    QMap<QString, float> sysValues =  evaluateSystems(compVals());

    if (sysValues.empty()) {
        QMessageBox::warning(0, tr("Test Evaluation Systems"),
                             QString("Error occured:\n\n%1").arg(m_errorMessage),
                             QMessageBox::Ok);
    } else {
        QMessageBox::information(0, tr("Test Evaluation Systems"),
                                 QString("Test complete, see application output")
                                 .arg(m_errorMessage), QMessageBox::Ok);

        QMapIterator<QString, float> i(sysValues);
        while (i.hasNext()) {
            i.next();
            qDebug("system %s = %g", qPrintable(i.key()), i.value());
        }
    }
}

// 14-4-25 ebk: temporary, for understanding sydef visitors
QString SeWrapper::getAsGraphVizInput()
{
    QString graphVizInput;
    QTextStream out(&graphVizInput);
    out << "digraph G {\n";

    for (int system = SeSyDStart; system < m_systems->size(); system++) {
        GraphVizVisitor visitor(this);
        if (m_systems->getName(system) != NULL && SeDataSystem[system] != NULL) {

            QString parentName = "\"";
            parentName.append(m_systems->getName(system));
            parentName.append("\"");
            visitor.setParentName(parentName);

            sysdefTraverse(visitor, SeDataSystem[system]->sysdef);
            out << visitor.result();
        }
    }

    out << "}";
    return graphVizInput;
}

QString SeWrapper::getAsFilteredGraphVizInput(QStringList damageList)
{
    QString graphVizInput;
    QTextStream out(&graphVizInput);
    out << "digraph G {\n";

    QStringList unqualifiedDamageList;
    foreach (QString qualified, damageList) {
        unqualifiedDamageList << qualified.remove(QRegExp("\\[.*\\]"));
    }

    qDebug() << unqualifiedDamageList;
    for (int system = SeSyDStart; system < m_systems->size(); system++) {
        FilteredGraphVizVisitor visitor(this);
        visitor.setDamagedList(unqualifiedDamageList);
        if (m_systems->getName(system) != NULL && SeDataSystem[system] != NULL) {
            if (unqualifiedDamageList.contains(m_systems->getName(system))) {
                QString parentName = "\"";
                parentName.append(m_systems->getName(system));
                parentName.append("\"");
                visitor.setParentName(parentName);
                sysdefTraverse(visitor, SeDataSystem[system]->sysdef);
                out << visitor.result();
            }
        }
    }

    out << "}";
    return graphVizInput;
}
