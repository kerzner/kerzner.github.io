/*
	MUVES_assert() -- support function for replacement <assert.h>

	created:	91/07/14	D A Gwyn

	complies with the following standards:
		ANSI X3.159-1989
		IEEE Std 1003.1-1988
		SVID Issue 3
		X/Open Portability Guide Issue 3
*/
#ifndef lint
static char RCSid[] = "$Id: assert.c,v 1.2 1999/04/28 19:00:36 mjo Exp $";
#endif

#include	<stdio.h>

extern void	abort();

#ifndef	__STDC__
#define	const	/* nothing */
#endif

void
MUVES_assert( expression, filename, line_num )
	const char	*expression,
			*filename;
	int		line_num;
	{
	(void)fprintf( stderr, "assertion failed: %s, file %s, line %d\n",
		       expression, filename, line_num
		     );
	(void)fflush( stderr );

	abort();
	/* NOTREACHED */
	}
