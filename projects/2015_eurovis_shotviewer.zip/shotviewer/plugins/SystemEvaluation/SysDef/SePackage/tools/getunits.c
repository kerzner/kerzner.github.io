/*
	getunits.c --	returns the units used in a BRLCAD geometry file

	created:	2010/02/11	Adam Ross
 */
 
 #ifndef lint
static char RCSid[] = "$Id: getunits.c,v 1.1 2010/05/28 14:10:14 aross Exp $";
#endif

#include <stdio.h>
#include "wdb.h"

int
main(int argc, char **argv)
{
	struct db_i	*dbip;
	const char	*u;

	if (argc != 2) {
		fprintf(stderr, "No database specified!\n");
	}

	if ((dbip = db_open(argv[1], "rb")) == NULL) {
		bu_exit(4, "Unable to db_open() file '%s', aborting\n", argv[1]);
	}
	RT_CK_DBI(dbip);

	u = bu_units_string(dbip->dbi_local2base);
	if (!u) {
		u = "none";
	}
	fprintf(stdout, "%s\n", u);

	bu_exit(0, NULL);
}