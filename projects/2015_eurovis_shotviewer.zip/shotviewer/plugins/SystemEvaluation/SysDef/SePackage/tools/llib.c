/*LINTLIBRARY*/
/*PROTOLIB1*/
/*
	llib.c -- MUVES "lint library" source

	created:	89/01/05	D A Gwyn
	edited:		01/07/12	C Hunt
			added pkadjust argument to CdWrite()

	Usage:	"lint -DXxLINT XxTest.c Xx.c $MUVES/lib/llib.c"
		for each package "Xx".
*/
#ifndef lint
static char RCSid[] = "$Id: llib.c,v 1.22 2010/06/23 19:55:21 geoffs Exp $";
#endif

#ifndef lint
#include	"ERROR -- NOT TO BE COMPILED"
#endif

#include	<ctype.h>		/* for <Se.h> */
#include	<stdio.h>

#include	<std.h>

#if STD_C
#include	<stdarg.h>
#else
#include	<varargs.h>
#endif

#include	<Ap.h>
#include	<At.h>
#include	<Cd.h>
#include	<Cp.h>
#include	<Dd.h>
#include	<Dq.h>
#include	<Dx.h>
#include	<Em.h>
#include	<Er.h>
#include	<Fa.h>
#include	<Fr.h>
#include	<Im.h>
#include	<In.h>
#include	<Io.h>
#include	<Ir.h>
#include	<Lk.h>
#include <stdio.h>
#include <common.h>   /* BRL-CAD 7.2.4+ no longer use config.h (SCR670) */
#include <Dm.h>
#include	<Mp.h>
#include	<Nm.h>
#include	<Pi.h>
#include	<Rn.h>
#include	<Rt.h>
#include	<Rt.h>
#include	<Sa.h>
#include	<Sc.h>
#include	<Se.h>
#include	<Ti.h>
#include	<Vm.h>
#include	<Vu.h>

/* Possible libMUVES.a function when our replacement <assert.h> is used: */
/*ARGSUSED*/
void		MUVES_assert( expression, filename, line_num )
			const char *expression, *filename; int line_num; { }

#ifndef ApLINT
MuvesBool		ApRead( PmtrFile ) const char *PmtrFile;
			{ return PmtrFile != NULL; }
/*ARGSUSED*/
DqNode *	ApShots( action ) int action; { return (DqNode *)0; }
int		ApNShots() { return 0; }
const char *	ApLabel() { return (const char *)0; }
int		ApAnalysisID = 0;
int		ApRunNumber = 0;
/*ARGSUSED*/
const char *	ApApprox( action ) int action; { return (const char *)0; }
int		ApNApprox() { return 0; }
/*ARGSUSED*/
ApStSpec *	ApVector( action ) int  action; { return (ApStSpec *)0; }
int		ApNVector() { return 0; }
const char *	ApInter() { return (const char *)0; }
NmPool *	ApModKeys = (NmPool *)0;
char **		ApModValues = (char **)0;
const char *	ApRayfile() { return (const char *)0; }
const char *	ApResults() { return (const char *)0; }
/*ARGSUSED*/
const char *	ApTarget( action ) int action; { return (const char *)0; }
int		ApNTarget() { return 0; }
/*ARGSUSED*/
const char *	ApProperty( action ) int action; { return (const char *)0; }
int		ApNProperty() { return 0; }
/*ARGSUSED*/
const char *	ApCategory( action ) int action; { return (const char *)0; }
int		ApNCategory() { return 0; }
/*ARGSUSED*/
const char *	ApSystem( action ) int action; { return (const char *)0; }
int		ApNSystem() { return 0; }
/*ARGSUSED*/
const char *	ApAssess( action ) int action; { return (const char *)0; }
int		ApNAssess() { return 0; }
/*ARGSUSED*/
const char *	ApEval( action ) int action; { return (const char *)0; }
int		ApNEval() { return 0; }
/*ARGSUSED*/
const char *	ApInCurve() { return (const char *)0; }
/*ARGSUSED*/
const char *	ApEvCurve() { return (const char *)0; }
/*ARGSUSED*/
const char *	ApThreat( action ) int action; { return (const char *)0; }
double		ApRange() { return 0.0; }
int		ApNThreat() { return 0; }
const char *	ApUnits() { return (const char *)0; }
double		ApFactor = 0.0;
/*ARGSUSED*/
void		ApFree( complete ) MuvesBool complete; { }
#endif

#ifndef AtLINT
/*ARGSUSED*/
SeValue *	AtDmgVector() { return (SeValue *)0; }
void		AtCleanUp() { }
#endif

#ifndef CdLINT
MuvesBool		CdInitialize() { return mFalse; }
/* 01-07-12 ch3: added pkadjust argument */
/*ARGSUSED*/
MuvesBool		CdWrite( comp_id, packet_type, pkadjust, n_params, params )
			int comp_id, packet_type, n_params;
 			double pkadjust;
			const double params[]; { return params != NULL; }
MuvesBool		CdSort( file_name ) const char *file_name;
			{ return file_name != NULL; }
CdDamage *	CdRead() { return (CdDamage *)0; }
MuvesBool		CdDiscard( damage_info ) CdDamage *damage_info;
			{ return damage_info != NULL; }
MuvesBool		CdRewind() { return mFalse; }
MuvesBool		CdCleanUp() { return mFalse; }
#endif

#ifndef DdLINT
FILE *		DdDATfp = (FILE *)0;
NmPool		DdCatNam = { 0 };
NmPool		DdDamNam = { 0 };
NmPool		DdProNam = { 0 };
NmPool		DdThrNam = { 0 };
NmPool		DdTpkNam = { 0 };
int		DdNCats = 0;
int		DdNComps = 0;
int		DdNDams = 0;
int		DdNPros = 0;
int		DdNThrs = 0;
int		DdNTpks = 0;
char **		DdTpkPTypes = (char **)0;
DqNode **	DdPropertyList = (DqNode **)0;
short *		DdCCMap = (short *)0;
char *		DdIsCritical = (char *)0;
char *		DdMayBeCritical = (char *)0;
char *		DdCatCritical = (char *)0;
char **		DdRelevant = (char **)0;
DdEntry		DdApprox = { 0 };
ImEntry ***	DdIMFunc = (ImEntry ***)0;
EmEntry **	DdEMFunc = (EmEntry **)0;
MuvesBool		DdIMInit( phase ) int phase; { return phase == ImPHS_SHOT; }
/*ARGSUSED*/
void		DdIMTerm( phase ) int phase; { }
/*ARGSUSED*/
MuvesBool		DdEMInit( phase, envir, mission ) int phase;
			const char *envir, *mission;
			{ return phase == EmPHS_SHOT; }
/*ARGSUSED*/
void		DdEMTerm( phase ) int phase; { }
void		DdClear() { }
/*ARGSUSED*/
MuvesBool		DdDepend( methodList )
			DdPair *methodList;
			{ return methodList != NULL; }
#endif

#ifndef DqLINT
DqNode *	DqOpen() { return (DqNode *)0; }
/*ARGSUSED*/
void		DqClose( dq ) DqNode *dq; { }
/*ARGSUSED*/
void		DqPush( dq, d ) DqNode *dq, *d; { }
DqNode *	DqPop( dq ) DqNode *dq; { return dq; }
/*ARGSUSED*/
void		DqAppend( dq, d ) DqNode *dq, *d; { }
/*ARGSUSED*/
void		DqL_Insert( d, p ) DqNode *d, *p; { }
/*ARGSUSED*/
void		DqR_Insert( d, p ) DqNode *d, *p; { }
/*ARGSUSED*/
DqNode *	DqDetach( dq, d ) DqNode *dq, *d; { return d; }
/*ARGSUSED*/
DqNode *	DqL_Detach( dq, d ) DqNode *dq, *d; { return d; }
/*ARGSUSED*/
DqNode *	DqR_Detach( dq, d ) DqNode *dq, *d; { return d; }
MuvesBool		DqIsEmpty( dq ) DqNode *dq; { return dq != NULL; }
/*ARGSUSED*/
DqNode *	DqPred( dq, d ) DqNode *dq, *d; { return d; }
/*ARGSUSED*/
DqNode *	DqNext( dq, d ) DqNode *dq, *d; { return d; }
#endif

#ifndef DxLINT
/*ARGSUSED*/
DxChannel *	DxOpen( command, timeout )
			const char *command; unsigned timeout;
			{ return (DxChannel *)0; }
/*ARGSUSED*/
MuvesBool		DxReopen( channel_pointer, timeout )
			DxChannel *channel_pointer; unsigned timeout;
			{ return timeout == 0; }
/*ARGSUSED*/
MuvesBool		DxTimeout( channel_pointer, input_timeout, output_timeout )
			DxChannel *channel_pointer;
			unsigned input_timeout, output_timeout;
			{ return output_timeout == 0; }
MuvesBool		DxClose( channel_pointer ) DxChannel *channel_pointer;
			{ return channel_pointer != NULL; }
/*ARGSUSED*/
MuvesBool		DxOutBoolean( channel_pointer, boolean )
			DxChannel *channel_pointer; MuvesBool boolean;
			{ return boolean; }
/*ARGSUSED*/
MuvesBool		DxInBoolean( channel_pointer, boolean )
			DxChannel *channel_pointer; MuvesBool *boolean;
			{ return boolean != NULL; }
/*ARGSUSED*/
MuvesBool		DxOutCharacter( channel_pointer, character )
			DxChannel *channel_pointer; char character;
			{ return character == 0; }
/*ARGSUSED*/
MuvesBool		DxInCharacter( channel_pointer, character )
			DxChannel *channel_pointer; char *character;
			{ return character != NULL; }
/*ARGSUSED*/
MuvesBool		DxOutString( channel_pointer, string )
			DxChannel *channel_pointer; const char *string;
			{ return string != NULL; }
/*ARGSUSED*/
MuvesBool		DxInString( channel_pointer, string, maximum_length )
			DxChannel *channel_pointer; char *string;
			int maximum_length; { return maximum_length > 0; }
/*ARGSUSED*/
MuvesBool		DxOutInteger( channel_pointer, integer )
			DxChannel *channel_pointer; long integer;
			{ return integer == 0L; }
/*ARGSUSED*/
MuvesBool		DxInInteger( channel_pointer, integer )
			DxChannel *channel_pointer; long *integer;
			{ return integer != NULL; }
/*ARGSUSED*/
MuvesBool		DxOutReal( channel_pointer, real ) DxChannel *channel_pointer;
			double real; { return real == 0.0; }
/*ARGSUSED*/
MuvesBool		DxInReal( channel_pointer, real ) DxChannel *channel_pointer;
			double *real; { return real != NULL; }
/*ARGSUSED*/
MuvesBool		DxOutVector( channel_pointer, vector, count )
			DxChannel *channel_pointer; const double vector[];
			int count; { return count > 0; }
/*ARGSUSED*/
MuvesBool		DxInVector( channel_pointer, vector, count )
			DxChannel *channel_pointer; double vector[]; int count;
			{ return count > 0; }
/*ARGSUSED*/
MuvesBool		DxOutFile( channel_pointer, file_name )
			DxChannel *channel_pointer; const char *file_name;
			{ return file_name != NULL; }
/*ARGSUSED*/
MuvesBool		DxInFile( channel_pointer, file_name )
			DxChannel *channel_pointer; const char *file_name;
			{ return file_name != NULL; }
MuvesBool		DxForceOut( channel_pointer ) DxChannel *channel_pointer;
			{ return channel_pointer != NULL; }
MuvesBool		DxFlushIn( channel_pointer ) DxChannel *channel_pointer;
			{ return channel_pointer != NULL; }
#endif

#ifndef EmLINT
EmEntry		Em0 = { 0 };
EmEntry		Em1 = { 0 };
EmEntry		Em2 = { 0 };
#endif

#ifndef ErLINT
long		ErIndex = 0L;
/*ARGSUSED*/
void		ErSet( index ) long index; { }
void		ErClear() { }
MuvesBool		ErIsSet() { return mFalse; }
/*ARGSUSED*/
void		ErAuxText( message_file ) const char *message_file; { }
const char *	ErString() { return (const char *)0; }
MuvesBool		ErFile( error_log ) const char *error_log;
			{ return error_log != NULL; }
#if STD_C
MuvesBool		ErLog( const char *format, ... ) { return format != NULL; }
#else
/*VARARGS1*/
MuvesBool		ErLog( format ) const char *format; { return format != NULL; }
#endif
/*ARGSUSED*/
MuvesBool		ErVLog( format, argument_pointer )
			const char *format; va_list argument_pointer;
			{ return format != NULL; }
#if STD_C
/*ARGSUSED*/
void		ErPLog( const char *format, ... ) { }
#else
/*ARGSUSED*/
/*VARARGS1*/
void		ErPLog( format ) const char *format; { }
#endif
/*ARGSUSED*/
void		ErPVLog( format, argument_pointer )
			const char *format; va_list argument_pointer;
			{ }
/*ARGSUSED*/
void		ErPrefix( prefix ) const char *prefix; { }
const char *	ErSimple( pathname ) const char *pathname;
			{ return pathname; }
void		ErPrint() { }
#endif

#ifndef FrLINT
MuvesBool		FrPutDate( frp ) FILE *frp; { return frp != NULL; }
MuvesBool		FrWriteQueues( frp ) FILE *frp; { return frp != NULL; }
MuvesBool		FrBeginView( frp ) FILE *frp; { return frp != NULL; }
/*ARGSUSED*/
MuvesBool		FrRecordShot( frp, shotid, ray, nctx, util )
			FILE *frp; int shotid; RtRay *ray;
			int nctx; double *util;
			{ return util != NULL; }
/*ARGSUSED*/
FrTag		FrHeader( final, units )
			FILE *final; char *units; { return (FrTag)0; }
/*ARGSUSED*/
void		FrCleanHdr( foo ) FrTag foo; { }
/*ARGSUSED*/
FrNode		FrMethod( foo, last, method )
			FrTag foo; FrNode last; char *method; { return last; }
/*ARGSUSED*/
FrNode		FrTarget( foo, last, target )
			FrTag foo; FrNode last; char *target; { return last; }
/*ARGSUSED*/
FrNode		FrThreat( foo, last, threat, range )
			FrTag foo; FrNode last; char *threat; double *range;
			{ return last; }
/*ARGSUSED*/
FrNode		FrDirection( foo, last, dir, group )
			FrTag foo; FrNode last; VmVect *dir; MuvesBool *group;
			{ return last; }
/*ARGSUSED*/
FrNode		FrView( foo, last, az, el, group )
			FrTag foo; FrNode last; double *az, *el; MuvesBool *group;
			{ return last; }
int		FrNView( tag ) FrTag tag; { return (int)tag; }
/*ARGSUSED*/
SaPattern *	FrPattern( last ) FrNode last; { return (SaPattern *)0; }
/*ARGSUSED*/
char *		FrGroup( last ) FrNode last; { return (char *)0; }
/*ARGSUSED*/
FrNode		FrContext( foo, last, mis, env )
			FrTag foo; FrNode last; char *mis, *env;
			{ return last; }
int		FrNCont( foo ) FrTag foo; { return (int)foo; }
/*ARGSUSED*/
MuvesBool		FrFindView( foo, param ) FrTag foo; FrSpec *param;
			{ return param != NULL; }
/*ARGSUSED*/
MuvesBool		FrProject( ncells, shot, vdir, MuvesBool usea )
			int ncells; FrShotResult *shot;
			VmVect *vdir; MuvesBool usea; { return vdir != NULL; }
#endif


#ifndef ImLINT
ImEntry		Im0 = { 0 };
ImEntry		Im1 = { 0 };
ImEntry		Im2 = { 0 };
#endif

#ifndef InLINT
#if STD_C
/*ARGSUSED*/
InHandle	InOpen( const char *table_tag, int dimensionality, ... )
#else
/*ARGSUSED*/
/*VARARGS3*/
InHandle	InOpen( table_tag, dimensionality, path_comp_0 )
			const char *table_tag; int dimensionality;
			const char *path_comp_0;
#endif
			{ return (InHandle)0; }
/*ARGSUSED*/
double		Intp1d( handle, x, bit_flag ) InHandle handle; double x;
			int bit_flag; { return x; }
/*ARGSUSED*/
double		Intp2d( handle, x, y, bit_flag ) InHandle handle; double x, y;
			int bit_flag; { return y; }
/*ARGSUSED*/
void		InFree( handle ) InHandle handle; { }
void		InClean() { }
void		InFlush() { }
#endif

#ifndef IoLINT
/*ARGSUSED*/
void		IoDeblank( b ) char *b; { }
/*ARGSUSED*/
void		IoDecomment( b ) char *b; { }
/*ARGSUSED*/
bs_type		IoGetLine( line_buffer, size, fp ) char *line_buffer; int size;
			FILE *fp; { return bs_bad; }
/*ARGSUSED*/
bs_type		IoGetTrim( line_buffer, size, fp ) char *line_buffer; int size;
			FILE *fp; { return bs_bad; }
/*ARGSUSED*/
bs_type		IoGetNonempty( line_buffer, size, fp ) char *line_buffer;
			int size; FILE *fp; { return bs_bad; }
/*ARGSUSED*/
const char *	IoCharStr( c ) int c; { return (const char *)0; }
const char *	IoStrStr( string ) const char *string; { return string; }
/*ARGSUSED*/
const char	*IoInsert( template, substitute )
			const char *template, *substitute;
			{ return substitute; }
MuvesBool		IoSafeName( pathname ) const char *pathname;
			{ return pathname != NULL; }
const char *	IoMUVES() { return (const char *)0; }
#if STD_C
/*ARGSUSED*/
FILE *		IoOpenFile( const char *mode, long errnum, ... )
#else
/*ARGSUSED*/
/*VARARGS3*/
FILE *		IoOpenFile( mode, errnum, path_comp_0 )
			const char *mode; long errnum; const char *path_comp_0;
#endif
			{ return (FILE *)0; }
const char *	IoVersion() { return (char *)0; }
MuvesBool		IoPending( fd ) int fd; { return fd != 0; }
/*ARGSUSED*/
void		IoNap( usec ) long usec; { }
#endif

#ifndef LkLINT
MuvesBool		LkAcquire( lock_file_name ) const char *lock_file_name;
			{ return lock_file_name != NULL; }
void		LkRelease() { }
/*ARGSUSED*/
void		LkIncArcCount( resource_name ) const char *resource_name; { }
/*ARGSUSED*/
void		LkDecArcCount( resource_name ) const char *resource_name; { }
/*ARGSUSED*/
void		LkClrArcCount( resource_name ) const char *resource_name; { }
MuvesBool		LkArcIsZero( resource_name ) const char *resource_name;
			{ return resource_name != NULL; }
/*ARGSUSED*/
void		LkIncUseCount( resource_name ) const char *resource_name; { }
/*ARGSUSED*/
void		LkDecUseCount( resource_name ) const char *resource_name; { }
/*ARGSUSED*/
void		LkClrUseCount( resource_name ) const char *resource_name; { }
MuvesBool		LkUseIsZero( resource_name ) const char *resource_name;
			{ return resource_name != NULL; }
/*ARGSUSED*/
void		LkDump( header, trailer ) const char *header, *trailer; { }
MuvesBool		LkSqueeze( lock_file_name ) const char *lock_file_name;
			{ return lock_file_name != NULL; }
#endif

#if 0
#ifndef MmLINT
MuvesBool		MmLogFlag = mFalse;
int		MmDebug( level ) int level; { return level; }
/*ARGSUSED*/
void		MmInit( cache_maximum ) unsigned cache_maximum; { }
char *		DmStrDup(string ) const char *string;
			{ return (char *)string; }
/*ARGSUSED*/
void		DmFree((genptr_t)string ) char *string; { }

/*
void     	MmLogOut( ptr, nbytes, file, line)
		const void *ptr; unsigned nbytes; const char *file; int line;{}
void     	MmLogIn( ptr, nbytes, file, line)
		const void *ptr; unsigned nbytes; const char *file; int line;{}
*/
#endif
#endif

#ifndef NmLINT
/*ARGSUSED*/
void		NmInit( pool ) NmPool *pool; {}
/*ARGSUSED*/
void		NmClear( pool ) NmPool *pool; {}
/*ARGSUSED*/
MuvesBool		NmDup( old, new ) const NmPool *old; NmPool *new;
			{ return new != NULL; }
/*ARGSUSED*/
int		NmIndex( name, pool, enter ) const char *name; NmPool *pool;
			MuvesBool enter; { return 0; }
/*ARGSUSED*/
const char *	NmName( index, pool ) int index; const NmPool *pool;
			{ return (const char *)0; }
int		NmCount( pool ) const NmPool *pool; { return pool->count; }
#endif

#ifndef PiLINT	
void		PiClean() {}
/*ARGSUSED*/
MuvesBool		PiEfpPen( trace, no_pen_id, kin_pen ) register RtTrace *trace;
			int no_pen_id; MuvesBool kin_pen; { return mTrue; }
#endif

#ifndef RnLINT
int		RnRand() { return 0; }
/*ARGSUSED*/
void		RnSeed( seed ) unsigned long seed; { }
unsigned long	RnState() { return (unsigned long)0; }
void		RnInit() { }
double		RnUnif() { return 0.0; }
/*ARGSUSED*/
double		RnFlt( min, max ) double min, max; { return max; }
/*ARGSUSED*/
int		RnInt( min, max ) int min, max; { return max; }
/*ARGSUSED*/
double		RnNorm( mu, sigma ) double mu, sigma; { return sigma; }
/*ARGSUSED*/
void		RnDir( xp, yp, zp ) double *xp, *yp, *zp; { }
#endif

#ifndef RtLINT
/*ARGSUSED*/
RtTrace *	RtSwap( current_node, next_node )
			RtTrace *current_node, *next_node; { return next_node; }
/*ARGSUSED*/
MuvesBool		RtInitialize( target, info_needed )
			const char *target; int info_needed;
			{ return info_needed == RtFIRST; }
NmPool		RtComponents = { 0 };
double		RtSize() { return 0.0; }
/*ARGSUSED*/
MuvesBool		RtBox( minima, maxima ) VmPoint *minima, *maxima;
			{ return maxima != NULL; }
/*ARGSUSED*/
RtHandle	RtShoot( shot, info_needed ) const RtRay *shot;
			int info_needed; { return (RtHandle)0; }
/*ARGSUSED*/
RtTrace *	RtGetPath( handle ) RtHandle handle; { return (RtTrace *)0; }
/*ARGSUSED*/
void		RtFree( threat_path ) RtTrace *threat_path; { }
/*ARGSUSED*/
RtGroup		RtBatch( group, shot, seedinfo, info_needed ) RtGroup group;
			const RtRay *shot; SaSeedInfo seedinfo;
			int info_needed; { return group; }
long		RtNiceSize() { return 0L; }
/*ARGSUSED*/
RtTrace *	RtGetAny( group, shot ) RtGroup group; RtRay *shot;
			{ return (RtTrace *)0; }
/*ARGSUSED*/
void		RtDiscard( group ) RtGroup group; { }
MuvesBool		RtTerminate() { return mFalse; }
#endif

#ifndef SaLINT
/*ARGSUSED*/
SaArray *	SaSetup( shots ) DqNode *shots; { return (SaArray *)0; }
/*ARGSUSED*/
MuvesBool		SaNext( sas, next ) SaArray *sas; RtRay *next;
			{ return next != NULL; }
/*ARGSUSED*/
int		SaNshots( array ) SaArray *array; { return 0; }
/*ARGSUSED*/
void		SaDiscard( array ) SaArray *array; { }
#endif

#ifndef ScLINT
MuvesBool		ScInit( fp ) FILE *fp; { return fp != NULL; }
char *		ScAL = (char *)0;
char *		ScBC = (char *)0;
char *		ScCE = (char *)0;
char *		ScCL = (char *)0;
char *		ScCM = (char *)0;
char *		ScCS = (char *)0;
char *		ScDL = (char *)0;
char *		ScHO = (char *)0;
char *		ScPC = (char *)0;
char *		ScSE = (char *)0;
char *		ScSF = (char *)0;
char *		ScSO = (char *)0;
char *		ScSR = (char *)0;
char *		ScTI = (char *)0;
char *		ScUP = (char *)0;
int		ScCO = 0;
int		ScLI = 0;
MuvesBool		ScClrEOL() { return mFalse; }
MuvesBool		ScClrRegScrl() { return mFalse; }
MuvesBool		ScClrStandout() { return mFalse; }
MuvesBool		ScClrText() { return mFalse; }
MuvesBool		ScDeleteLn() { return mFalse; }
MuvesBool		ScDnScroll() { return mFalse; }
MuvesBool		ScHmCursor() { return mFalse; }
MuvesBool		ScInsertLn() { return mFalse; }
MuvesBool		ScMvCursor( x, y ) int x, y; { return x > y; }
MuvesBool		ScSetRegScrl( top, btm ) int top, btm; { return top > btm; }
MuvesBool		ScSetStandout() { return mFalse; }
MuvesBool		ScUpScroll() { return mFalse; }
char		ScTcap[ScTCAPSIZ] = { 0 };
char		ScTerm[ScTBUFSIZ] = { 0 };
int		ScX = 0;
int		ScY = 0;
int		ScPutStr( str ) const char *str; { return (int)str[0]; }
#endif

#ifndef SeLINT
/*ARGSUSED*/
const DqNode *	SeGetQualList( comp_index ) int comp_index; 
			{ return (DqNode *)0; }
/*ARGSUSED*/
NmPool *	SeSysOpen( sysdef_file,optimize ) const char *sysdef_file; 
			MuvesBool optimize; { return (NmPool *)0; }
/*ARGSUSED*/
double		SeSysEval( sys_index, frf ) int sys_index;
			const float frf[]; { return (double)frf[0]; }
/*ARGSUSED*/
FILE *		SeCtxOpen( file ) const char *file; { return (FILE *)0; }
/*ARGSUSED*/
MuvesBool		SeCntxCompile( fp, environp, missionp, iscriticalp ) FILE *fp;
			const char *environp, *missionp; char *iscriticalp;
			{ return iscriticalp != NULL; }
/*ARGSUSED*/
double		SeCtxEval( environp, missionp, frf )
			const char *environp, *missionp; const float frf[];
			{ return (double)frf[0]; }
/*ARGSUSED*/
int		SeCtxParse( fp, environp, missionp ) FILE *fp;
			char *environp, *missionp; { return 0; }
void		SeSysReset() { }
/*ARGSUSED*/
void		SeCtxClose( fp ) FILE *fp; { }
MuvesBool		SeSysClose() { return mFalse; }
MuvesBool		SeCtxFree() { return mFalse; }
NmPool		SeSystems = { 0 };
#endif


/*ARGSUSED*/
MuvesBool		TiAttach( trace, ti ) RtTrace *trace; int ti;
			{ return ti == 0; }
MuvesBool		TiCons( trace ) RtTrace *trace; { return trace != NULL; }
/*ARGSUSED*/
MuvesBool		TiPrev( trace, pktype ) RtTrace *trace; int pktype;
			{ return pktype == 0; }

#ifndef VmLINT
const VmVect	*Vm_Xaxis = (const VmVect *)0;
const VmVect	*Vm_Yaxis = (const VmVect *)0;
const VmVect	*Vm_Zaxis = (const VmVect *)0;
/*ARGSUSED*/
void		VmAdd( A, B ) VmVect *A; const VmVect *B; { }
/*ARGSUSED*/
void		VmDAdd( A, B, C ) VmVect *A; const VmVect *B, *C; { }
/*ARGSUSED*/
double		VmAngle( A, B ) const VmVect *A, *B; { return B->x; }
/*ARGSUSED*/
void		VmCopy( A, B ) VmVect *A; const VmVect *B; { }
/*ARGSUSED*/
void		VmCross( A, B, C ) VmVect *A; const VmVect *B, *C; { }
/*ARGSUSED*/
void		VmDiff( A, B ) VmVect *A; const VmVect *B; { }
/*ARGSUSED*/
void		VmDDiff( A, B, C ) VmVect *A; const VmVect *B, *C; { }
/*ARGSUSED*/
double		VmDist( A, B ) const VmPoint *A, *B; { return B->x; }
/*ARGSUSED*/
void		VmDiv( A, s ) VmVect *A; double s; { }
/*ARGSUSED*/
void		VmDDiv( A, B, s ) VmVect *A; const VmVect *B; double s; { }
/*ARGSUSED*/
double		VmDot( A, B ) const VmVect *A, *B; { return B->x; }
double		VmMag( A ) const VmVect *A; { return A->x; }
/*ARGSUSED*/
MuvesBool		VmNearEqual( A, B, tolerance )
			const VmVect *A, *B; double tolerance;
			{ return tolerance > 0.0; }
/*ARGSUSED*/
MuvesBool		VmZeroLenVec( A, tolerance )
			const VmVect *A; double tolerance;
			{ return tolerance > 0.0; }
/*ARGSUSED*/
void		VmNorm( A ) VmVect *A; { }
/*ARGSUSED*/
void		VmPrint( A, l ) const VmVect *A; const char *l; { }
/*ARGSUSED*/
void		VmErPrint( A, l ) const VmVect *A; const char *l; { }
/*ARGSUSED*/
void		VmScale( A, s ) VmVect *A; double s; { }
/*ARGSUSED*/
void		VmDScale( A, B, s ) VmVect *A; const VmVect *B; double s; { }
/*ARGSUSED*/
void		VmSet( A, a, b, c ) VmVect *A; double a, b, c; { }
/*ARGSUSED*/
void		VmAzElConvert( az, el, dir ) double az, el; VmVect *dir; { }
/*ARGSUSED*/
void		VmDirConvert( dir, az, el ) VmVect *dir; double *az, *el; { }
/*ARGSUSED*/
void		VmFindOrthog( view, horiz, vert ) const VmVect *view;
			VmVect *horiz, *vert; { }
#endif

#ifndef VuLINT
MuvesBool		VuTarget( frp ) FILE *frp; { return frp != NULL; }
int		VuRayID = 0;
#endif
