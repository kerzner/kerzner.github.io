: # requires a Bourne shell

#	muves_bug -- MUVES "fillin"-based bug reporting procedure

#	created:	08/02/89	D A Gwyn
#	RCSid:  	$Id: muves_bug.sh,v 1.3 2003/03/31 15:34:29 karen Exp $

#	The following should not be altered:
SUBJECT='MUVES bug report'

#	The following must be configured as appropriate:
#MUVES=Muves	# edited during installation from source (only)
: ${EDITOR:=/bin/ed}
MAIL=/bin/mail
MAINT='muves-bug@arl.army.MIL'	# muves-bug@BRL.MIL for BRL test sites ONLY!
MAILCMD="$MAIL '$MAINT' -s '$SUBJECT'"
: ${PAGER:=/bin/cat}
TMPDIR=/usr/tmp

#	The following should not normally require alteration:
FILLIN=$MUVES/bin/fillin
PATH=$MUVES/bin:/usr/5bin:/bin:/usr/bin:/usr/ucb:/usr/brl/bin
TEMPLATE=$MUVES/lib/bug.tem
TMP=$TMPDIR/mbug$$

export EDITOR MUVES PAGER PATH TMPDIR

trap 'rm -f $TMP' 0 1 2 15

# First, conduct an interactive dialogue with the user to fill in the form:

$FILLIN $TEMPLATE > $TMP

# Then, let the user play with the filled-in form:
while :
do	echo 'Specify disposition of form (view, edit, send, or cancel): \c'
	read disp
	case "$disp" in
	[vV]*)	eval "$PAGER $TMP"
		;;
	[eE]*)	eval "$EDITOR $TMP"
		;;
	[sS]*)	eval "$MAILCMD" < $TMP
		rm -f $TMP
	     echo 'Thanks for your cooperation.'
	     echo 'You should receive a preliminary response within a few days.'
		exit
		;;
	[cC]*)	rm -f $TMP
		exit 1
		;;
	esac
done
