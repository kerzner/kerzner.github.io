/*
	<sys/dirent.h> -- file system independent directory entry (SVR3)

	created:	25-Apr-1987	D A Gwyn
	RCSid:  	$Id: sys_dirent.h,v 1.2 1999/04/28 19:00:41 mjo Exp $

	Prerequisite:	<sys/types.h>
*/

#ifndef	SYS_DIRENT_H_INCLUDED
#define	SYS_DIRENT_H_INCLUDED

/*
 * The following structure defines the filesystem-independent directory entry.
 */

struct dirent {			/* data from getdents()/readdir() */
    long		d_ino;		/* inode number of entry */
#ifdef sun	/* Sun-3 SunOS 4.0 */
    short		d_off;		/* offset of disk directory entry */
#else		/* usually */
    off_t		d_off;		/* offset of disk directory entry */
#endif
    unsigned short	d_reclen;	/* length of this record */
    char		d_name[1];	/* name of file */	/* non-ANSI */
};

/* The following nonportable ugliness could have been avoided by defining
   DIRENTSIZ and DIRENTBASESIZ to also have (struct dirent *) arguments.
   There shouldn't be any problem if you avoid using the DIRENTSIZ() macro. */

#define	DIRENTBASESIZ		(((struct dirent *)0)->d_name \
				- (char *)&((struct dirent *)0)->d_ino)

#define	DIRENTSIZ( namlen )	((DIRENTBASESIZ + sizeof(long) + (namlen)) \
				/ sizeof(long) * sizeof(long))

/* DAG -- the following was moved from <dirent.h>, which was the wrong place */
#define	MAXNAMLEN	512		/* maximum filename length */

#ifndef NAME_MAX
#define	NAME_MAX	(MAXNAMLEN - 1)	/* DAG -- added for POSIX */
#endif

#endif	/* SYS_DIRENT_H_INCLUDED */
