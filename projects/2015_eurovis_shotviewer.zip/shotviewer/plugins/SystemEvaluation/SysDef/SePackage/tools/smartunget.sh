#!/bin/sh
#
#	smartunget -- clean up files checked out of CVS archives
#
#	created:	93/01/26	G S Moss
#	RCSid:  	$Id: smartunget.sh,v 1.2 1999/04/28 19:00:40 mjo Exp $
#
#	If files have been checked out for editing, but not changed
#	an 'unget' is performed, otherwise they are left alone and
#	a message is issued.
#
#	If files have NOT been checked out for editing, but they HAVE
#	been edited an error is printed and the files are left alone,
#	otherwise they are removed and a message is issued.
#
#	Usage: smartunget
	
trap '/bin/rm -f xxx' 1 2 3 15
for i in *
do      if test -f p.$i
        then    get -p -k s.$i > xxx 2> /dev/null
		if diff $i xxx > /dev/null
		then	unget s.$i
		else	echo $i has been changed
		fi
		rm -f xxx
	else
	if test -f s.$i
	then	get -p s.$i > xxx 2> /dev/null
                if diff $i xxx > /dev/null
                then    echo $i not checked out for editing, removing.
			/bin/rm $i
                else    echo \*\*\* $i has been changed, but is not checked out for editing!
                fi
                rm -f xxx
        fi
	fi
done
