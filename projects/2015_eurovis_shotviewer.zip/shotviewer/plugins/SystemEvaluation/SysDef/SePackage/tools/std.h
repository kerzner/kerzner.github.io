/*
	std.h -- Douglas A. Gwyn's standard C programming definitions

	Prerequisites:	<math.h> (if you invoke Round())
			<string.h> (if you invoke StrEq())

	RCSid:  	$Id: std.h,v 1.11 2010/06/23 19:55:21 geoffs Exp $

	The master source file is to be modified only by Douglas A. Gwyn
	<Gwyn@BRL.MIL>.  When installing a VLD/VMB software distribution,
	this file may need to be tailored slightly to fit the target system.
	Usually this just involves enabling some of the "kludges for deficient
	C implementations" at the end of this file.
*/

#ifndef	VLD_STD_H_
#define	VLD_STD_H_			/* once-only latch */

/* Extended data types */
enum _MuvesBool { mFalse=0, mTrue=1 }; /* Boolean data */
typedef int  MuvesBool;	/*MUVES bools were often treated as ints - enforce it*/



typedef int	bs_type;		/* 3-way "bug/status" result type */
#define 	bs_good	1
#define 	bs_bad	0
#define 	bs_ugly	(-1)

/* ANSI C definitions */

/* Defense against some silly systems defining __STDC__ to random things. */
#ifdef STD_C
#undef STD_C
#endif
#ifdef __STDC__
#if __STDC__ > 0
#define	STD_C	__STDC__		/* use this instead of __STDC__ */
#endif
#endif

#ifdef STD_C
typedef void	*pointer;		/* generic pointer */
#else
typedef char	*pointer;		/* generic pointer */
#define	const		/* nothing */	/* ANSI C type qualifier */
/* There really is no substitute for the following, but these might work: */
#define	signed		/* nothing */	/* ANSI C type specifier */
#define	volatile	/* nothing */	/* ANSI C type qualifier */
#endif

#ifndef EXIT_SUCCESS
#define	EXIT_SUCCESS	0
#endif

#ifndef EXIT_FAILURE
#define	EXIT_FAILURE	1
#endif

#ifndef NULL
#define NULL	0			/* null pointer constant, all types */
#endif

/* Universal constants */

#define DEGRAD	57.2957795130823208767981548141051703324054724665642
/* degrees per radian */
#define	E	2.71828182845904523536028747135266249775724709369996
/* base of natural logs */
#define	GAMMA	0.57721566490153286061
/* Euler's constant */
#define LOG10E	0.43429448190325182765112891891660508229439700580367
/* log of e to the base 10 */
#define PHI	1.618033988749894848204586834365638117720309180
/* golden ratio */
#ifdef PI
#undef PI
#endif
#define PI	3.14159265358979323846264338327950288419716939937511
/* ratio of circumf. to diam. */

/* Useful macros */

/*
	The comment "UNSAFE" means that the macro argument(s) may be evaluated
	more than once, so the programmer must realize that the macro doesn't
	quite act like a genuine function.  This matters only when evaluating
	an argument produces "side effects".
*/

/* arbitrary numerical arguments and value: */
#ifndef Abs
#define Abs( x )	((x) < 0 ? -(x) : (x))			/* UNSAFE */
#endif
#ifndef Max
#define Max( a, b )	((a) > (b) ? (a) : (b))			/* UNSAFE */
#endif
#ifndef Min
#define Min( a, b )	((a) < (b) ? (a) : (b))			/* UNSAFE */
#endif

/* floating-point arguments and value: */
/* Note tolerance added to 0.5 to fix floating point noise under
   IRIX 4.0.5. (XXX) */
#define RoundingOffset	0.50000000001
#define Round( d )	floor( (d) + RoundingOffset ) /* requires <math.h> */

/* floating-point comparison macros */
#define NearZero( a, tol )	\
			(Abs(a) < tol )
#define NearEqual( a, b, tol ) \
		( Abs( (a) - (b) ) < tol )

/* arbitrary numerical arguments, integer value: */
#define	Sgn( x )	((x) == 0 ? 0 : (x) > 0 ? 1 : -1)	/* UNSAFE */

/* string arguments, boolean value: */
#ifdef gould	/* UTX-32 2.0 compiler has problems with "..."[] */
#define	StrEq( a, b )	(strcmp( a, b ) == 0)
#else
#define	StrEq( a, b )	(*(a) == *(b) && strcmp( a, b ) == 0)	/* UNSAFE */
#endif

/* array argument, integer value: */
#define	Elements( a )	(sizeof a / sizeof a[0])

/* integer (or character) arguments and value: */
#define fromhostc( c )	(c)		/* map host char set to ASCII */
#define tohostc( c )	(c)		/* map ASCII to host char set */
#define tonumber( c )	((c) - '0')	/* convt digit char to number */
#define todigit( n )	((n) + '0')	/* convt digit number to char */

/* to permit a single declaration to provide a prototype or not, depending: */
/* Example usage:	extern int myfunc PARAMS((int a, char *b));	*/
#ifdef STD_C
#define	PARAMS( a )	a
#else
#define	PARAMS( a )	()
#endif

/* weird macros for special tricks with source code symbols: */
#ifdef STD_C
#define	PASTE( a, b )	a ## b
/* paste together two token strings */
#else
/* Q8JOIN is for internal <std.h> use only: */
#define	Q8JOIN( s )	s
/* paste together two token strings */
/* WARNING:  This version of PASTE may expand its arguments
   before pasting, unlike the Standard C version. */
#define	PASTE( a, b )	Q8JOIN(a)b
#endif

/* Kludges for deficient C implementations */
#ifdef BSD42
#define	strchr	index		/* 7th Edition UNIX, 4.2BSD */
#define	strrchr	rindex		/* 7th Edition UNIX, 4.2BSD */
#define	void	int		/* K&R Appendix A followers */
#endif

#if defined(sgi) && defined(mips)	/* missing from <signal.h>: */
extern void	(*signal(int, void (*)(int)))(int);
#endif

#if defined(__linux__)
#ifndef SIGEMT
#define SIGEMT SIGUNUSED
#endif
#ifndef SIGSYS
#define SIGSYS SIGUNUSED
#endif
#ifndef MAXNAMLEN
#include <linux/limits.h>
#define MAXNAMLEN NAME_MAX
#endif /* MAXNAMELEN */
#endif /* __linux__ */



#endif	/* VLD_STD_H_ */
