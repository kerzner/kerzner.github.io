/**
	makedoc -- extract user documentation from MUVES source files
**/
/*
	created:	87/08/10	D A Gwyn
	edited:		03/06/02	K Bowman
			added include for string.h so that correct definitions
			are included (corrected for SCR380)

	This utility extracts "documentation lines" from C source code
	that it reads on the standard input; extracted lines are written
	to the standard output.  Documentation lines begin immediately
	after the sequence <beginning of line> `/' `*' `*' <newline> and
	end immediately before the sequence <beginning of line> `*' `*'
	`/' <newline>.  All lines in that range are documentation lines.

	The intention is for designated C comments to be extracted
	directly from source code, for accurate software interface or
	functional documentation.  MUVES "package interface specs" are
	produced this way from the installed package headers.

	Two blank lines are added to separate different blocks.
**/
/**	The above line, this one, and the next are for testing only.
**/ /** These three test lines should not be extracted by makedoc. **/
/**

	Usage:	$ cat source_files | makedoc > user_documentation
**/
#ifndef lint
static char RCSid[] = "$Id: makedoc.c,v 1.5 2010/06/23 19:55:21 geoffs Exp $";
#endif

#include	<stdio.h>

#include	<std.h>			/* VLD/VMB standard C extensions */
#include	<string.h>		/* 03-06-02 kb: added */

#define	BEGIN		"/**\n"		/* marks beginning of documentation */
#define	END		"**/\n"		/* marks end of documentation */
#define	MAX_LINE	80		/* max # chars in line (including NL) */

static char	line[MAX_LINE + 1];	/* text line buffer */

static MuvesBool
GetLine()
	{
	return fgets( line, MAX_LINE, stdin ) != NULL;
	}

static MuvesBool
PutLine()
	{
	return fputs( line, stdout ) != EOF;
	}

static void
Err( mess )
	const char	*mess;		/* error message */
	{
	(void)fputs( "makedoc: ", stderr );
	(void)fputs( mess, stderr );
	(void)putc( '\n', stderr );
	}

int
main()
	{
	while ( GetLine() )
		{
		if ( StrEq( line, BEGIN ) )
			{
			sprintf(line,"\n\n");
			PutLine();
			while ( GetLine() )
				{
				if ( StrEq( line, END ) )
					goto next;

				if ( !PutLine() )
					{
					Err( "output failed" );
					return EXIT_FAILURE;
					}
				}

			Err( "EOF within documentation block" );
			return EXIT_FAILURE;
			}
    next:
		;
		}

	return EXIT_SUCCESS;
	}
