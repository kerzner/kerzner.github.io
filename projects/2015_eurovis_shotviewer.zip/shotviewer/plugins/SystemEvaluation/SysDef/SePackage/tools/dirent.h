/*
	<dirent.h> -- definitions for SVR3 directory access routines

	created:	27-Oct-1988	D A Gwyn
	RCSid:		$Id: dirent.h,v 1.2 1999/04/28 19:00:36 mjo Exp $

	Prerequisite:	<sys/types.h>
*/

#ifndef	DIRENT_H_INCLUDED
#define	DIRENT_H_INCLUDED

#include	<dirent.h>

#define	DIRBUF		8192		/* buffer size for fs-indep. dirs */
/* must in general be larger than the filesystem buffer size */

typedef struct {
    int	dd_fd;			/* file descriptor */
    int	dd_loc;			/* offset in block */
    int	dd_size;		/* amount of valid data */
    char	*dd_buf;		/* -> directory block */
}	DIR;			/* stream data from opendir() */

typedef struct dirent {
    ino_t          d_ino;       /* inode number */
    off_t          d_off;       /* offset to the next dirent */
    unsigned short d_reclen;    /* length of this record */
    unsigned char  d_type;      /* type of file; not supported
                                 by all file system types */
    char           d_name[256]; /* filename */
} dirent;

extern DIR		*opendir();
extern struct dirent	*readdir();
extern off_t		telldir();
extern void		seekdir();
extern void		rewinddir();
extern int		closedir();

#ifndef NULL
#define	NULL	0			/* DAG -- added for convenience */
#endif

#endif	/* DIRENT_H_INCLUDED */
