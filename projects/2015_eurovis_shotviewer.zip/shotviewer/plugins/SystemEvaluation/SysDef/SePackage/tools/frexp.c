/*
	created:	90/12/10	S L Henry
*/
#ifndef lint
static char RCSid[] = "$Id: frexp.c,v 1.2 1999/04/28 19:00:39 mjo Exp $";
#endif

/*
	It may be necessary to install this copy of frexp()
	in libMUVES.a to correct a BUG on sun4's running SUNOS4.0.
	The sun4 bug prevents the Dx pkg from installing.

	This code suppled by D A Gwyn.
*/
double
frexp( x, eptr )
	double		x;
	register int	*eptr;
	{
	register double	abs_x;

	*eptr = 0;

	if ( x == 0.0 )
		return 0.0;

	abs_x = x >= 0.0 ? x : -x;

	while ( abs_x >= 1.0 )
		{
		++*eptr;
		abs_x *= 0.5;
		}

	while ( abs_x < 0.5 )
		{
		--*eptr;
		abs_x *= 2.0;
		}

	return x >= 0.0 ? abs_x : -abs_x;
	}
