#!/bin/perl
#ident  "$CVSid$"
#
#programmer: Alex Breuer
#version: 1.0
#date 021120
#####################################################################
#
# first of all, a little stuff in case the arguments don't seem right
if( length( $ARGV[4] ) == 0 ) {
    print $ARGV[4];
    print "indiff: proper usage:\n";
    print "\t[referenceSessionStart] [referenceIndexStart]\n";
    print "\t[testSessionStart] [testIndexStart]\n";
    die "\t[pathToFiles]\n";

}


# now, grab values from input line.  The reference files are the ones against
# which we'll test the test files.

$referenceName = $ARGV[0];
$referenceIndex = $ARGV[1];
$testName = $ARGV[2];
$testIndex = $ARGV[3];
$path = $ARGV[4];

# now, initialize some vaiables for the file finding loop
$openfailed = 0;
$numFilesProcessed = 0;
$lastNameSuccess = $referenceName;
$lastIndexSuccess = $referenceIndex;
$i = 0;


print "\n\nusing path $path\n";
print "looking for reference files...\n";

# The file-finding loop first looks for the reference files.  It searches
# exhaustively through the sub index, until it has missed 25 times in a row, 
# e.g. it looks for x.y.fr and then x.y+1.fr.  Suppose x.z.fr is the last
# file it found, then it will keep trying all the way up to x.z+25.fr before 
# it looks for x+1.0.fr.  It always starts looking for x+1.0.fr after
# x.z+25.fr.  The reference-finding loop looks for all files up to just 
# before the start of the test files, e.g., suupose the test files start at
# u.w.fr, then the loop will look all the way up to u-1.z+25.fr. The 
# file-finding loop for the test files works similarly.

while( $referenceName < $ARGV[2] ) {
    $referenceIndex = $ARGV[1];
    while( ( $referenceIndex - $lastIndexSuccess) <= 25 ) {
	open( referenceFile, "$path/$referenceName.$referenceIndex.fr" ) or   $openfailed = 1;
	
	if( $openfailed == 0 ) {
	    print "found $referenceName.$referenceIndex.fr successfully\n";
	    $listOfReferenceFileNames[$i] = "$referenceName.$referenceIndex.fr";
	    $i++;
	    $numFilesProcessed++;
	    $lastIndexSuccess = $referenceIndex;
	    close( referenceFile );
	}

	$referenceIndex++;
	
	$openfailed = 0;
    }
    $referenceName++;
}

print "----------\nno more files found, finished looking\n";
$sizeOfReferenceFileNames = ( $i - 1 );

$lastIndexSuccess = $testIndex;
$lastNameSuccess = $testName;
$i = 0;

print "\n\nlooking for test files...\n";
while( ( $testName - $lastNameSuccess ) <= 10 ) {
    $testIndex = $ARGV[3];
    while( ( $testIndex - $lastIndexSuccess) <= 25 ) {
	open( testFile, "$path/$testName.$testIndex.fr" ) or   $openfailed = 1;
	
	if( $openfailed == 0 ) {
	    print "found $testName.$testIndex.fr successfully\n";
	    $initListOfTestFileNames[$i] = "$testName.$testIndex.fr";
	    $i++;
	    $numFilesProcessed++;
	    $lastIndexSuccess = $testIndex;
	    $lastNameSuccess = $testName;
	    close( testFile );
	}

	$testIndex++;
	
	$openfailed = 0;
    }
    $testName++;
}

print "-----------\nno more files found, finished looking\n\n";


# Do some initializaton for the duplicate-checking loop.  The 
# duplicate-checking loop checks the test files to see if any are duplicated.
# It assumes all duplicates must be in sequence.  If it finds a duplicate, it 
# simply ignores it.
$sizeOfTestFileNames = $i;
$i = 0;
$j = 0;

while( ($i+1) < $sizeOfTestFileNames ) {
    if( system( "diff $path/$initListOfTestFileNames[$i] $path/$initListOfTestFileNames[$i+1] > indiff.log  ")) {
	$finalListOfTestFileNames[$j] = $initListOfTestFileNames[$i];
	$j++;

    }
    else {
	print "$initListOfTestFileNames[$i] & $initListOfTestFileNames[$i+1] identical,\n\tignoring former\t$j\n";
	
    }
    $i++;
}
$finalListOfTestFileNames[$j] = $initListOfTestFileNames[$i];
$sizeOfTestFileNames = $j;

# After we've checked for duplicates, and eliminated them, we want to be sure
# that we have the same number of test and reference files.  If we don't, bad
# things will happen, so we'll stop here and report the error.
if( $sizeOfTestFileNames != $sizeOfReferenceFileNames ) {
    die "error: mismatch in number of test & reference files\n";
}

print "matching:\n@finalListOfTestFileNames\n@listOfReferenceFileNames\n";

$h = 0;

# Now we're ready to do the diff'ing.  We'll use frdiff, since it has some 
# knowledge of the fr file format which is advantageous.  We'll just loop 
# through the two arrays of files, calling frdiff on them.
while( $h <= $sizeOfTestFileNames ) {
    print "------\n";
    print "$listOfReferenceFileNames[$h] & $finalListOfTestFileNames[$h]:\n";
	    
    system( "frdiff $path/$listOfReferenceFileNames[$h] $path/$finalListOfTestFileNames[$h]" );
    print "done.\n";
    
    $h++;
}

print "------\nall files finished\n\a\n";	
    










