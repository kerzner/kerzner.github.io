/*
	MUVESignore() -- dummy signal catcher function

	created:	92/07/14	D A Gwyn, K R Murray

	Simulates SIG_IGN, but actually catches the signal.
*/
#ifndef lint
static char RCSid[] = "$Id: ignore.c,v 1.2 1999/04/28 19:00:40 mjo Exp $";
#endif

#include	<signal.h>

void
MUVESignore( sig )
	int	sig;
	{
		(void)signal( sig, MUVESignore );
	}
