#!/bin/sh
#
#	host -- print out the host name
#
#	created:	91/04/02	G S Moss
#	RCSid:  	$Id: host.sh,v 1.2 1999/04/28 19:00:40 mjo Exp $
#
#	This script is intended to work on most platforms, but if none of
#	the listed executables are available, this script can be edited
#	to simply echo the name of the host.

for i in /bin/hostname /usr/bsd/hostname /bin/uname
do	if test -x $i
	then	$i; exit $?
	fi
done
echo '?unknown?'
echo "*** $0 not properly configured, notify your MUVES administrator!" >&2
exit 1
