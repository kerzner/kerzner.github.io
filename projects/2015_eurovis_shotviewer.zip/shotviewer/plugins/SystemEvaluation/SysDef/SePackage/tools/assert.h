/*
	<assert.h> -- definitions for verifying program assertions
			(replacement for deficient system implementations)

	created:	91/07/14	D A Gwyn

	RCSid:	 	$Id: assert.h,v 1.2 1999/04/28 19:00:36 mjo Exp $

	complies with the following standards:
		ANSI X3.159-1989 (except for use of a nonreserved identifier)
		IEEE Std 1003.1-1988
		SVID Issue 3 (except for the extra blank in the NDEBUG case)
		X/Open Portability Guide Issue 3 (ditto)
*/

#ifdef	assert
#undef	assert
#endif

#ifdef	NDEBUG

#define	assert(ignore)	((void)0)

#else	/* ! NDEBUG */

#ifdef	__STDC__

extern void	MUVES_assert( const char *, const char *, int );

#define	assert(ex)	((ex) ? (void)0 \
			: MUVES_assert( #ex, __FILE__, __LINE__ ))

#else	/* ! __STDC__ */

extern void	MUVES_assert();

#ifdef	lint

#define	assert(ex)	MUVES_assert( "ex", __FILE__, 0 )
/* ex is not evaluated as it can cause "constant in condition" warnings */

#else

/* Reiser CPP behavior assumed; int/void kludgery necessary for old PCC: */
#define	assert(ex)	((void)((ex) ? 0 \
			: (MUVES_assert( "ex", __FILE__, __LINE__ ), 0)))

#endif	/* lint */

#endif	/* __STDC__ */

#endif	/* NDEBUG */
