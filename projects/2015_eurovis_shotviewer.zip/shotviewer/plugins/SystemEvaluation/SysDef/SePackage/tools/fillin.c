/*
	fillin -- fills in a form using a combination of a template
		containing text with blanks to be filled in and special
		instructions, and user input from dialogue.

	Created by Nancy Thornton.
	Adapted for RSTS/E, with slight revisions, by D A Gwyn.

*/
#ifndef lint
static char RCSid[] = "$Id: fillin.c,v 1.8 2010/06/23 19:55:20 geoffs Exp $";
#endif

#include	<stdio.h>
#include	<ctype.h>
#include	<errno.h>
#include	<signal.h>
#include	<string.h>
#include	<unistd.h>
#include	<sys/wait.h>

#include	<std.h>

#define	BUFSIZE	512			/* size of input buffer */
#define	IF	-1L			/* placed on the stack when an if is
					   being processed and removed when it
					   is finished */
#define	LOOP	-2L			/* placed on the stack when a loop is
					   being processed and removed when it
					   is finished */

#ifdef unix
static char	*name = NULL;		/* "fillin" program name */
#endif
static FILE	*temp = NULL;		/* file descriptor for template file */
static char	buf[BUFSIZE+1] = { 0 };	/* line buffer from template */
static int	i = 0;			/* index for buf */
static long	lstack[100] = { 0L };
static int	top = 0;		/* top of stack */
static char	*str[128] = { NULL };	/* array of pointers to strings where
					   answers are stored */
static double	num[128] = { 0.0 };	/* array where double answers are stored
					 */
static char	strform[20] = "%s";	/* holds format specifier for answer
					   strings */
static char	numform[20] = "%g";	/* holds format specifier for numeric
					   answers */
static MuvesBool	ttyout = mTrue,
		ttyin = mTrue;		/* holds result of isatty */
static MuvesBool	dflag = mFalse,
		qflag = mFalse;
static char	*iname = NULL,		/* I/O file names */
		*oname = NULL;
static int	echo_level = 0;		/* used to determine whether to echo */
static MuvesBool	prompt = mFalse,
		in_lit = mFalse,
		in_ask = mFalse,
		holding = mFalse;

static void	catch(), do_ask(), do_clear(), do_count(), do_error(), do_get(),
		do_goto(), do_incl(), do_say(), do_set(), err(), Error(),
		if_skip(), loop_skip(), out(), putout(), test(), Warn();
#ifdef unix
static void	bufout();
#endif
static MuvesBool	eval(), getl(), prefix();
static char	*percent();

extern char	*optarg;
extern int	optind;

extern int	isatty();
extern void *	malloc();
extern void	exit(), free();
extern int	getopt();
extern double	atof();

static void
usage()
{
	(void)fputs(
    "Usage: fillin[ -d][ -e][ -q][ -i answer_file][ -o filled_form] template\n",
		stderr);
	exit(1);
	/*NOTREACHED*/
}

int
main(argc, argv)
	int	argc;
	char	*argv[];
{
	register int	c;

#ifdef unix
	name = argv[0];
#endif

	(void)signal(SIGINT, catch);
	(void)signal(SIGQUIT, catch);

	/* process args */

	while ((c = getopt(argc, argv, "dei:o:q")) != EOF)
		switch (c)
		{
		case 'i':
			if (iname != NULL)
				Error("too many -i args");
			if (freopen(iname = optarg, "r", stdin) == NULL)
				Error("can't open input file");
			break;
		case 'o':
			if (oname != NULL)
				Error("too many -o args");
			if (freopen(oname = optarg, "w", stdout) == NULL)
				Error("can't open output file");
			break;
		case 'q':
			qflag = mTrue;
			break;
		case 'e':
			echo_level = -1;
			break;
		case 'd':
			dflag = mTrue;
			break;
		default:
			usage();
			/*NOTREACHED*/
		}
	if (optind == argc)
		usage();
	if ((temp = fopen(argv[optind], "r")) == NULL)
		Error("can't open template file");

	if ((ttyout = isatty(fileno(stdout))))
	{
		if (! qflag)
			(void)fputs("fillin: no output file\n", stderr);
		echo_level = 0;
	}
	if ((ttyin = isatty(fileno(stdin))))
	{
		prompt = mTrue;
		setbuf(stdin, (char *)NULL);
	}

	lstack[top] = 0L;		/* put empty stack marker on stack */

	/* get line from template.
	   test to see if it is command or literal text. */

	while (getl())
	{
		i = 0;
		if (dflag)
		{
			if (in_ask)
			{
				(void)fputc('\n', stderr);
				in_ask = mFalse;
			}
			else if (in_lit)
			{
				if (echo_level != 0)
					(void)fputc('\n', stderr);
				else
					(void)putchar('\n');
				in_lit = mFalse;
			}
			(void)fputs("<<", stderr);
			(void)fputs(buf, stderr);
		}
		while (buf[i] == ' ' || buf[i] == '\t')
			++i;
		if (buf[i] != '?')
			putout(buf);
		else if (buf[++i] == '?')
			putout(&buf[i]);
		else
			test();
	}
	if (! qflag)
		(void)fputs("fillin: Done.\n", stderr);
	exit(0);
	/*NOTREACHED*/
}

/* putout - outputs literal text and fills in blanks as needed. */

static void
putout(s)
	char	*s;
{
	if (ttyout || echo_level != 0)
	{
		if (in_ask)
		{
			(void)fputc('\n', stderr);
			in_ask = mFalse;
		}
		if (! in_lit)
			if (echo_level != 0)
				(void)fputs(">>", stderr);
			else
				(void)fputs(">>", stdout);
	}
	out(s, stdout);
	if (echo_level != 0)
		out(s, stderr);
	if (holding)
	{
		if (ttyout || echo_level != 0)
			in_lit = mTrue;
		holding = mFalse;
	}
	else
	{
		(void)putchar('\n');
		if (echo_level != 0)
			(void)fputc('\n', stderr);
		in_lit = mFalse;
	}
}

/* test - calls appropriate subroutine to execute command. */

static void
test()
{
	if (prefix("say", &buf[i]))
		do_say(&buf[i+strlen("say")]);
	else if (prefix("ask", &buf[i]))
		do_ask(&buf[i+strlen("ask")]);
	else if (prefix("include", &buf[i]))
		do_incl();
	else if (prefix("get", &buf[i]))
		do_get();
	else if (prefix("!", &buf[i]))
		return;
	else if (prefix("clear", &buf[i]))
			do_clear();
	else if (prefix(":", &buf[i]))
		return;
	else if (prefix("set", &buf[i]))
		do_set();
	else if (prefix("echo", &buf[i]))
	{
		if (echo_level == 0 && ! ttyout)
			echo_level++;
	}
	else if (prefix("noecho", &buf[i]))
	{
		if (echo_level > 0)
			echo_level--;
	}
	else if (prefix("hold", &buf[i]))
		holding = mTrue;
	else if (prefix("-", &buf[i]) || prefix("+", &buf[i]))
		do_count();
	else if (prefix("goto", &buf[i]))
		do_goto();
	else if (prefix("if", &buf[i]))
	{
		lstack[++top] = IF;
		if (! eval())
			if_skip();
	}
	else if (prefix("else", &buf[i]))
	{
		if (lstack[top] != IF)
			err(buf);
		if_skip();
	}
	else if (prefix("endif", &buf[i]))
	{
		if (lstack[top] != IF)
			err(buf);
		top--;
	}
	else if (prefix("loop", &buf[i]))
	{
		lstack[++top] = ftell(temp);
		lstack[++top] = LOOP;
	}
	else if (prefix("until", &buf[i]))
	{
		if (lstack[top] != LOOP)
			err(buf);
		if (eval())
			loop_skip();
	}
	else if (prefix("repeat", &buf[i]))
	{
		if (lstack[top] != LOOP)
			err(buf);
		(void)fseek(temp, lstack[top-1], 0);
	}
	else if (prefix("error", &buf[i]))
		do_error(&buf[i]);
	else
		err(buf);
}

/* err - outputs the offending line and a warning message to both the
   output file and stderr, prints list of all defined string variables
   and all nonzero numeric variables on the output file, then exits. */

static void
err(s)
	char	*s;
{
	int	j;

	(void)fputs("fillin: template error:\n", stderr);
	(void)fputs(s, stderr);
	(void)fputc('\n', stderr);
	if (! ttyout)
	{
		Warn("template error:");
		(void)puts(s);
	}
	for (j = 0; j < 128; j++)
		if (str[j])
			(void)printf("$%c %s\n", tohostc(j), str[j]);
	for (j = 0; j < 128; j++)
		if (num[j] != 0.0)
			(void)printf("#%c %g\n", tohostc(j), num[j]);
	exit(1);
	/*NOTREACHED*/
}

/* do_say - outputs text to stderr with newline appended. */

static void
do_say(s)
	char	*s;			/* pointer to char in buffer after
					   "?say" */
{
	if (! prompt)
		return;			/* do not output if prompting is not
					   being done */
	while (*s == ' ' || *s == '\t')
		++s;			/* skip white space before text to be
					    output */
	out(s, stderr);
	(void)fputc('\n', stderr);
}

/* do_ask - outputs text to stderr with space appended. */

static void
do_ask(s)
	char	*s;			/* pointer to char in buffer after
					   "?ask" */
{
	if (! prompt)
		return;			/* do not output if prompting is not
					   being done */
	if (in_lit)
	{
		if (echo_level != 0)
			(void)fputc('\n', stderr);
		else
			(void)putchar('\n');
		in_lit = mFalse;
	}
	while (*s == ' ' || *s == '\t')
		++s;			/* skip white space before text to be
					   output */
	out(s, stderr);
	(void)fputc(' ', stderr);
	in_ask = mTrue;
}

/* do_get - gets answer from stdin or from output of UNIX command
   and stores it in appropriate place. */

static void
do_get()
{
#ifdef unix
	FILE	*fp;
#endif
	char	flag,
		redir,
		string[BUFSIZE+1],
		j,
		k,
		*s;
	int	len;
	if ((k = sscanf(buf, " %*s %c%c %c%s", &flag, &j, &redir, string)) < 2)
		err(buf);
	if (flag == '$' && j == '$' || flag == '#' && j == '#')
		err(buf);
	if (k > 2)
	{
#ifndef unix
		Error("?get <command not supported");
#else
		if (redir != '<' || k < 4 || string[0] == '\0')
			err(buf);
		s = buf;
		while (isspace(*s))
			++s;
		while (! isspace(*s))
			++s;
		while (isspace(*s))
			++s;
		++s;
		++s;
		while (isspace(*s))
			++s;
		++s;
		bufout(s, string);
		if ((fp = popen(string, "r")) == NULL
		 || fgets(string, BUFSIZE, fp) == NULL
		 || pclose(fp) != 0)
			Error("popen failed");
#endif
	}
	else
		while (fgets(string, BUFSIZE, stdin) == NULL)
		{
			if (! ttyin)
				Error("input file incomplete");
			(void)fputs("fillin: EOF unacceptable, please retype\n",
				stderr);
		}
	len = strlen(string);
	if (string[len-1] == '\n')
		string[len-1] = '\0';
	/* else
		if (k > 2)
			while (getchar() != '\n')
				;
	 * XXX - why read from stdin if response was greater than BUFSIZ? */
	k = toascii(j);
	if (flag == '$')
	{
		/* allocate storage space for answer string. */
		if (str[k])
			free(str[k]);
		if ((str[k] = malloc(BUFSIZE)) == NULL)
			Error("not enough storage");
		(void)strcpy(str[k], string);
	}
	else if (flag == '#')
	{
		num[k] = 0.0;
		if (sscanf(string, " %lf", &num[k]) == 0)
			num[k] = 0.0;
	}
	else
		err(buf);
}

/* prefix - compares p and string. if p matches the prefix
   of string it returns mTrue. if not, it returns mFalse. */

static MuvesBool
prefix(p, string)
	register char	*p,
			*string;
{
	while (*p != '\0')
		if (*p++ != *string++)
			return mFalse;
	return mTrue;
}

/* do_clear - reinitializes designated string variable to NULL. */

static void
do_clear()
{
	char	flag,
		j;

	if (sscanf(buf, "%*s %c%c", &flag, &j) != 2)
		err(buf);
	if (flag != '$')
		err(buf);
	if (j == '$')
		err(buf);
	j = toascii(j);
	if (str[j])
		free(str[j]);
	str[j] = NULL;
}

/* catch - intercepts interrupt and quit signals, prints warning
   message on stdout and stderr and exits. */

static void
catch( sig )
	int	sig;
{
	(void)signal(sig, SIG_IGN);
	(void)putchar('\n');
	Error("interrupted");
	/*NOTREACHED*/
}

/* do_goto - rewinds template file and seeks until it finds the
   label specified by the goto. */

static void
do_goto()
{
	char	com[BUFSIZE],
		lab1[BUFSIZE],
		lab2[BUFSIZE];
	char	save[BUFSIZE+1];

	/* save line for printing in case of template error */
	(void)strcpy(save, buf);
	if (sscanf(buf, " %*s %s", lab1) != 1)
		err(buf);
	rewind(temp);
	top = 0;
	while (getl())
	{
		if (sscanf(buf, " %s", com) > 0)
		if (strcmp(com, "?if") == 0)
			lstack[++top] = IF;
		else if (strcmp(com, "?loop") == 0)
			lstack[++top] = LOOP;
		else if (strcmp(com, "?endif") == 0)
		{
			if (lstack[top] != IF)
				err(buf);
			top--;
		}
		else if (strcmp(com, "?repeat") == 0)
		{
			if (lstack[top] != LOOP)
				err(buf);
			top--;
		}
		else if (strcmp(com, "?:") == 0)
		{
			if (sscanf(buf, " %*s %s", lab2) != 1)
				err(buf);
			if (strcmp(lab1, lab2) == 0)
				return;
		}
	}
	err(save);
}

/* eval - evaluate condition, return mTrue if mTrue, and mFalse if mFalse. */

static MuvesBool
eval()
{
	int	varst1 = 0;
	int	varst2 = 0;
	char	op[BUFSIZE],
		str1[BUFSIZE],
		str2[BUFSIZE];
	int	j, ret;
	double	num1, num2;

	if ((ret = sscanf(buf, " %*s %s %s %s", str1, op, str2)) < 2)
		err(buf);
	if (ret == 2)			/* if only 1 string is to be evaluated
					 */
		(void)strcpy(str2, "");
	if (strcmp(op, "diff") == 0 || strcmp(op, "same") == 0 ||
		strcmp(op, "yes") == 0 || strcmp(op, "no") == 0 ||
		strcmp(op, "def") == 0 || strcmp(op, "undef") == 0)
	{
		if (str1[0] == '$')
			if (str1[1] == '$')
				(void)strcpy(str1, &str1[1]);
			else if (str1[1] == '\0')
				err(buf);
			else
			{
				j = toascii(str1[1]);
				if (str[j] == NULL)
					varst1 = 1;
				else	{
					varst1 = 2;
					(void)strcpy(str1, str[j]);
					}
			}
		if (str2[0] == '$')
			if (str2[1] == '$')
				(void)strcpy(str2, &str2[1]);
			else if (str2[1] == '\0')
				err(buf);
			else
			{
				j = toascii(str2[1]);
				if (str[j] == NULL)
					varst2 = 1;
				else	{
					varst2 = 2;
					(void)strcpy(str2, str[j]);
					}
			}
	}
	else
	{
		if (str1[0] == '#')
			if (str1[1] == '\0' || str1[1] == '#')
				err(buf);
			else
				num1 = num[toascii(str1[1])];
		else
			num1 = atof(str1);
		if (str2[0] == '#')
			if (str2[1] == '\0' || str2[1] == '#')
				err(buf);
			else
				num2 = num[toascii(str2[1])];
		else
			num2 = atof(str2);
	}

	if (strcmp(op, "eq") == 0)
		return num1 < (num2+0.5) && num1 > (num2-0.5);
							/* virtually equal */
	else if (strcmp(op, "ne") == 0)
		return num1 > (num2+0.5) || num1 < (num2-0.5);
	else if (strcmp(op, "lt") == 0)
		return num1 < num2;
	else if (strcmp(op, "gt") == 0)
		return num1 > num2;
	else if (strcmp(op, "ge") == 0)
		return num1 >= num2;
	else if (strcmp(op, "le") == 0)
		return num1 <= num2;
	else if (strcmp(op, "diff") == 0)
		if (varst1 == 1 || varst2 == 1)
			err(buf);
		else
			return strcmp(str1, str2) != 0;
	else if (strcmp(op, "same") == 0)
		if (varst1 == 1 || varst2 == 1)
			err(buf);
		else
			return strcmp(str1, str2) == 0;
	else if (strcmp(op, "yes") == 0)
		if (varst1 == 1)
			err(buf);
		else
			return str1[0] == 'y' || str1[0] == 'Y';
	else if (strcmp(op, "no") == 0)
		if (varst1 == 1)
			err(buf);
		else
			return str1[0] != 'y' && str1[0] != 'Y';
	else if (strcmp(op, "def") == 0)
		return varst1 == 2;
	else if (strcmp(op, "undef") == 0)
		return varst1 == 1;
	else
		err(buf);
	/*NOTREACHED*/
}

/* loop_skip - skips until the corresponding "?repeat" is found. */

static void
loop_skip()
{
	char	com[BUFSIZE+1],
		save[BUFSIZE+1];
	int	lcount = 0;

	(void)strcpy(save, buf);
	while (getl())
	{
		if (sscanf(buf, " %s", com) > 0)	/* DAG */
		if (strcmp(com, "?loop") == 0)
			lcount++;
		else if (strcmp(com, "?repeat") == 0)
			if (--lcount < 0)
			{
				top -= 2;
				return;
			}
	}
	err(save);
}

/* if_skip - skips until it finds the "?endif" that corresponds to
   the "?if" that caused the skipping. */

static void
if_skip()
{
	char	com[BUFSIZE+1],
		save[BUFSIZE+1];
	int	ifcount = 0;

	(void)strcpy(save, buf);
	while (getl())
	{
		if (sscanf(buf, " %s", com) > 0)	/* DAG */
		if (strcmp(com, "?if") == 0)
			ifcount++;
		else if (strcmp(com, "?else") == 0)
		{
			if (ifcount == 0)
				return;
		}
		else if (strcmp(com, "?endif") == 0)
			if (--ifcount < 0)
			{
				top--;
				return;
			}
	}
	err(save);
}

/* do_count - either increments or decrements a counter. */

static void
do_count()
{
	char	op,
		flag,
		j;

	if (sscanf(buf, " ?%c %c%c", &op, &flag, &j) != 3)
		err(buf);
	if (flag != '#')
		err(buf);
	if (j == '#')
		err(buf);
	if (op == '-')
		num[toascii(j)] -= 1.0;
	else
		num[toascii(j)] += 1.0;
}

/* do_set - sets the appropriate string or number variable to
   the specified value. */

static void
do_set()
{
	char	flag,
		s[BUFSIZE],
		j;
	int	ret, k, l;

	if ((ret = sscanf(buf, " %*s %c%c %s", &flag, &j, s)) < 2)
		err(buf);
	if (ret == 2)
		(void)strcpy(s, "");
	if (flag == '$' && j == '$' || flag == '#' && j == '#')
		err(buf);
	k = toascii(j);
	if (flag == '$')
	{
		if (str[k])
			free(str[k]);
		if ((str[k] = malloc(BUFSIZE+1)) == NULL)
			Error("not enough storage");
		if (s[0] == '$')
		{
			if (s[1] == '$')
				(void)strcpy(str[k], &s[1]);
			else if (s[1] == '\0')
				err(buf);
			else
			{
				l = toascii(s[1]);
				if (str[l])
					(void)strcpy(str[k], str[l]);
				else
					err(buf);
			}
		}
		else if (s[0] == '#')
		{
			if (s[1] == '#')
				(void)strcpy(str[k], &s[1]);
			else if (s[1] == '\0')
				err(buf);
			else if (sprintf(str[k], "%g",
					num[toascii(s[1])]) != 1)
				err(buf);
		}
		else
			(void)strcpy(str[k], s);
	}
	else if (flag == '#')
	{
		if (s[0] == '$')
			err(buf);
		if (s[0] == '#')
		{
			if (s[1] == '#' || s[1] == '\0')
				err(buf);
			else
				num[k] = num[toascii(s[1])];
		}
		else
			num[k] = atof(s);;
	}
	else
		err(buf);
}

/* do_error - prints an error message generated by the template
   instead of by the program and then exits. */

static void
do_error(s)
	char	*s;
{
	out(s, stderr);
	(void)fputc('\n', stderr);
	exit(1);
	/*NOTREACHED*/
}

/* do_incl - switches to a new template file, processes it, and
   resumes processing the original. */

static void
do_incl()
{
#ifdef unix
	int	pid,
		w,
		status;
#endif
	char	inclfil[BUFSIZE];

	if (sscanf(buf, " %*s %s", inclfil) != 1)
		err(buf);
	(void)fflush(stdout);
#ifndef unix
	Error( "?include not supported" );
#else
	if ((pid = fork()) == -1)
		Error("no more new processes");
	if (pid == 0)
	{
		if (echo_level < 0)
		{
			(void)execlp(name, "subfillin", inclfil, "-q", "-e",
				0);
			Error("exec failed");
		}
		else
		{
			(void)execlp(name, "subfillin", inclfil, "-q", 0);
			Error("exec failed");
		}
	}
	while (((w = wait(&status)) != -1 || errno == EINTR) && w != pid)
		;
	if (w == -1 || status != 0)
		exit(1);
#endif
}

/* out - outputs text to the file indicated by f. fills in blanks
   according to format specifications. */

static void
out(s, f)
	char	*s;			/* first char of a string */
	FILE	*f;			/* file pointer */
{
	while (*s != '\n')
		if (*s == '$')
			if (*++s == '$')
				(void)fputc(*s++, f);
			else
			{
				if (str[toascii(*s)])	/* DAG */
					(void)fprintf(f, strform,
						str[toascii(*s)]);
				++s;
			}
		else if (*s == '#')
			if (*++s == '#')
				(void)fputc(*s++, f);
			else
			{
				(void)fprintf(f, numform, num[toascii(*s)]);
				++s;
			}
		else if (*s == '%')
			if (*++s == '%')
				(void)fputc(*s++, f);
			else
			{
				s = percent(s);
				++s;
			}
		else
			(void)fputc(*s++, f);
}

#ifdef unix
/* bufout - puts text in the buffer indicated by b. fills in blanks
   according to format specifications. XXX Should check for buffer overrun! */

static void
bufout(s, b)
	char	*s;			/* first char of a string */
	char	*b;			/* output buffer */
{
	while (*s != '\n')
		if (*s == '$')
			if (*++s == '$')
				*b++ = *s++;
			else
			{
				if (str[toascii(*s)])
					{
					(void)sprintf(b, strform,
						str[toascii(*s)]);
					while (*b != '\0')
						++b;
					}
				++s;
			}
		else if (*s == '#')
			if (*++s == '#')
				*b++ = *s++;
			else
			{
				(void)sprintf(b, numform, num[toascii(*s)]);
				while (*b != '\0')
					++b;
				++s;
			}
		else if (*s == '%')
		{
			if (*++s == '%')
				*b++ = *s++;
			else 
				s = percent(s);
			++s;
		}
		else
			*b++ = *s++;
	*b = '\0';
}
#endif

/* percent - picks up and stores format specifiers. */

static char *
percent(s)
	char	*s;
{
	char	string[20];
	int	j = 0;

	string[j++] = '%';
	while (! isalpha(*s) && *s != '\n')
		string[j++] = *s++;
	if (*s != 'g' && *s != 's' && *s != 'f' && *s != 'e')
		err(buf);
	string[j++] = *s;
	string[j] = '\0';
	if (*s == 's')
		(void)strcpy(strform, string);
	else
		(void)strcpy(numform, string);
	return s;
}

/* getl - gets 511-char line from template */

static MuvesBool
getl()
{
	int	len;

	if (fgets(buf, BUFSIZE, temp) != NULL)
	{
		register char	*cp;

		for (len = 0, cp = buf; *cp != '\0'; )
			if (*cp == '\r')
				(void)strcpy(cp, cp+1);
			else	{
				cp++;
				len++;
				}
		if (len == 0)
			return mFalse;

		if (buf[len-1] != '\n')
		{
			buf[len] = '\n';
			buf[len+1] = '\0';
			while (fgetc(temp) != '\n')
				;
		}
		return mTrue;
	}
	return mFalse;
}

/* Warn - output warning message to file on standard output */

static void
Warn( message )
	char	*message;		/* warning message text */
{
	(void)fputs( "* fillin * ", stdout );	/* avoid "printf" */
	(void)puts( message );
}

/* Error - output error message on stderr then die */

static void
Error( message )
	char	*message;		/* error message text */
{
	(void)fputs( "fillin: ", stderr );	/* avoid "fprintf" */
	(void)fputs( message, stderr );
	(void)putc( '\n', stderr );
	if ( !ttyout )
		Warn( message );
	exit( 1 );			/* fatal error */
	/*NOTREACHED*/
}
