/*
	created:	11/13/87	G S Moss
	RCSid:		$Id: Sc.h,v 1.6 2010/06/23 19:54:51 geoffs Exp $
*/
/**
	<Sc.h> -- MUVES "Sc" (Screen manager) package definitions
**/

/**
	The Sc package provides an interface to the terminal capa-
	bilities (termcap or terminfo) library (termlib(3)) for doing
	cursor movement, character attribute, and other low-level
	screen management operations.  It is intended for use in
	building terminal-independent full-screen user interfaces.
	Due to its use of the tgoto() termlib(3) routine, programs
	that use this package should turn off TAB3 in the terminal
	handler and restore TAB3 before exiting.
**/
#ifndef Sc_H_INCLUDE
#define Sc_H_INCLUDE

#include <std.h>

#if STD_C
extern MuvesBool ScInit( FILE *fp );
extern void ScClose( void );
#else
extern MuvesBool ScInit();
extern void ScClose();
#endif

extern char *ScAL;
extern char *ScBC;
extern char *ScCE;
extern char *ScCL;
extern char *ScCM;
extern char *ScCS;
extern char *ScDL;
extern char *ScHO;
extern char *ScPC;
extern char *ScSE;
extern char *ScSF;
extern char *ScSO;
extern char *ScSR;
extern char *ScTE;
extern char *ScTI;
extern char *ScUP;

extern int ScCO;
extern int ScLI;
extern int ScX;
extern int ScY;

#if STD_C
extern MuvesBool ScClrEOL( void );
extern MuvesBool ScClrRegScrl( void );
extern MuvesBool ScClrStandout( void );
extern MuvesBool ScClrText( void );
extern MuvesBool ScDeleteLn( void );
extern MuvesBool ScDnScroll( void );
extern MuvesBool ScHmCursor( void );
extern MuvesBool ScInsertLn( void );
extern MuvesBool ScMvCursor( int x, int y );
extern MuvesBool ScSetRegScrl( int top, int btm );
extern MuvesBool ScSetStandout( void );
extern MuvesBool ScUpScroll( void );
extern int ScPutStr( const char *str );
#else
extern MuvesBool ScClrEOL();
extern MuvesBool ScClrRegScrl();
extern MuvesBool ScClrStandout();
extern MuvesBool ScClrText();
extern MuvesBool ScDeleteLn();
extern MuvesBool ScDnScroll();
extern MuvesBool ScHmCursor();
extern MuvesBool ScInsertLn();
extern MuvesBool ScMvCursor();
extern MuvesBool ScSetRegScrl();
extern MuvesBool ScSetStandout();
extern MuvesBool ScUpScroll();
extern int ScPutStr();
#endif

#define ScTCAPSIZ 1024
#define ScTBUFSIZ 80

extern char ScTcap[ScTCAPSIZ];
extern char ScTerm[ScTBUFSIZ];

extern void ScPkgInit();

#endif		/* Sc_H_INCLUDE */


