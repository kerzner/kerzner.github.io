/**
	<Dq.h> -- MUVES "Dq" (doubly-linked queueing) package definitions
**/
/*
	created:	87/11/17	Karen Ross Murray
	RCSid:		$Id: Dq.h,v 1.13 2010/06/23 19:54:45 geoffs Exp $
*/

/**
	The Dq package provides support for doubly linked lists.  A
	doubly linked list, also known as a double-ended queue, is a
	data structure in which each node has two pointers, one forward
	("to the right") and one backward ("to the left").  These queues
	are implemented with an extra node, the master node, which
	contains no data but serves to make the operations more uniform.
	An empty queue consists of one node, the master node, whose left
	and right pointers both point to itself.

	Given a pointer to any node, it is possible to reach all the
	other nodes by traversing pointers.  The queue can be treated as
	a stack to the right of the master node; nodes can be pushed
	onto and popped off the top of the stack.  Nodes can also be
	appended to the end of the queue, or inserted to the right or
	left of any other node.  Nodes can be detached from any position
	in the queue, given a pointer to the node or its left or right
	neighbor.  Currently there is no support for inserting nodes in
	a "sorted" order.
**/

#ifndef	DqH_INCLUDE
#define	DqH_INCLUDE

#include <std.h>

#include <stdio.h>

/**
	typedef struct
		{
		DqNode *left;
		DqNode *right;
		} DqNode;

	All nodes in queues must be structures having as their first
	member a DqNode.  Typically, the master node will consist only
	of a DqNode rather than the usual larger structure that contains
	a DqNode.  Data nodes may include any additional data, as long
	as the first member is a DqNode.  Each user of the Dq package
	must maintain a head pointer which points to the DqNode that
	serves as the master node for the list; this head pointer is
	returned by DqOpen(), which allocates storage for it.

	If the left or right pointer of the master node contains the
	address of the master node itself, then both do, and the queue
	is empty.  Otherwise the right pointer of the master node points
	to a DqNode which is the first member of the first node in the
	queue.  For each node "a" in the queue, the node to the right of
	node "a" has a left pointer that points back to "a".  The right
	pointer of the last node in the queue points to the master node,
	and the master node's left pointer points to the last node in
	the queue.  Thus the master node acts like an extra entry in a
	circular list (note, however, that it has no associated data).

	An example of the typical usage is as follows:

	static DqNode *listhead = NULL;	// pointer to master node

	typedef struct			// queue node
		{
		DqNode link;
		int index;
		char *name;
		}
	ANode;


	Many of the functions in the Dq package are implemented as
	macros for reasons of run-time speed and programming
	convenience.  It is in general unsafe to pass arguments
	involving side effects to these functions; simple pointer
	variables are safe arguments.  Also watch out for expressions
	containing multiple Dq functions, since the queue may be
	modified by the Dq functions in the course of evaluating the
	expressions, leading to unpredictable results.  (A typical
	blunder is to change the structure of a queue within a DqEACH
	loop.)

	For all Dq package macros with type parameters "t", "t" must
	designate a type such that a pointer to the type can be produced
	by simply appending "*" to "t".  (Not all C type specifications
	have this property.)

**/

typedef struct Dq_node DqNode;
struct Dq_node {
    DqNode *left;
    DqNode *right;
};


/**
	DqNode *DqOpen( const char *str )

	DqOpen() opens a queue by allocating storage for the master node
	and returning a pointer to it.  Initially, both left and right
	pointers of the master node point to the master node.  DqOpen()
	terminates if it is unable to allocate storage. ErIndex will
	not be set.
**/

#if STD_C
extern	DqNode *DqOpenm( const char * );
#else
extern	DqNode *DqOpenm();
#endif


#define dq_cpp_str(s) # s
#define dq_cpp_xstr(s)  dq_cpp_str(s)
#define DQ_FLSTR __FILE__ ":" dq_cpp_xstr(__LINE__)

#define DqOpen() DqOpenm(DQ_FLSTR)

/**
	void DqClose( DqNode *dq )

	DqClose() closes a queue.  The queue is expected to be already
	empty before DqClose() is called, and all nodes removed from the
	queue should have been freed via the appropriate bu function.
	If the queue is empty, DqClose() simply frees the master node.
	If any nodes still remain linked into the queue, they are freed
	by calling free(); the appropriate bu freeing function cannot be
	used by DqClose() to free the data nodes because the actual node
	size is not known by DqClose().  Not only will such use of
	DqClose() cause bu usage logging to report mismatches, but also
	if any storage was accessed via a pointer within the node, it
	will be lost forever!  (Note that user data nodes can be freed
	only because of the constraint that their addresses coincide
	with those of their DqNode initial members.  They must have been
	dynamically allocated, however, or havoc will result!)
	DqClose() must be given a pointer to the master node for the
	queue; subsequently the pointer will no longer point to valid
	storage, so it must not be further used.
**/
#if STD_C
extern	void DqClose(DqNode *dq);
#else
extern	void DqClose();
#endif

/**
	The next two macros, DqPush() and DqPop(), treat the queue as a
	stack to the right of the master node.  DqPush() pushes a node
	on top of the stack, and DqPop() pops a node off the top of the
	stack.
**/

/**
	void	DqPush( DqNode *dq, DqNode *d )

	DqPush() inserts the node pointed to by d to the right of
	the master node pointed to by dq.

	Programming hint:  To push any node type without generating
	"lint" warnings about pointer type mixing, push the address
	of the DqNode member (typically named "link" or "thread") of
	the full node.  For example:  DqPush( &nhead, &np->link ).
**/
#if defined(lint) && !defined(DqLINT)
#if STD_C
extern	void DqPush(DqNode *dq, DqNode *d);
#else
extern	void DqPush();
#endif
#else	/* in-line for convenience */
#define DqPush(dq, d)		DqR_Insert(d, dq)
#endif


/**
	DqNode *DqPop( DqNode *dq )

	DqPop() removes the node to the right of the master node (top
	node of the stack) from the queue whose master node is pointed
	to by dq, and returns a pointer to the removed node.  It returns
	NULL if the queue is empty.
**/
#if defined(lint) && !defined(DqLINT)
#if STD_C
extern	DqNode *DqPop(DqNode *dq);
#else
extern	DqNode *DqPop();
#endif
#else	/* in-line for convenience */
#define DqPop(dq)		DqDetach(dq, (dq)->right)
#endif


/**
	t	*DqTPop( DqNode *dq, t )

	DqTPop() removes the node to the right of the master node (top
	node of the stack) from the queue whose master node is pointed
	to by dq, and returns a pointer to the removed node, assumed to
	be of type t, or NULL if the queue is empty.
**/
#if defined(lint) && !defined(DqLINT)	/* shut "lint" up */
#define	DqTPop(dq, t)	((void)DqPop(dq), (t *)0)
#else
#define	DqTPop(dq, t)	((t *)DqPop(dq))
#endif


/**
	void	DqAppend( DqNode *dq, DqNode *d )

	DqAppend() inserts the node pointed to by d to the right of the
	last data node in the queue whose master node is pointed to by
	dq.
**/
#if defined(lint) && !defined(DqLINT)
#if STD_C
extern	void DqAppend(DqNode *dq, DqNode *d);
#else
extern	void DqAppend();
#endif
#else	/* in-line for convenience */
#define DqAppend(dq, d)		DqR_Insert(d, (dq)->left)
#endif


/**
	void	DqL_Insert( DqNode *d, DqNode *p )

	DqL_insert() inserts the node pointed to by d to the left of the
	node pointed to by p.
**/
#if defined(lint) && !defined(DqLINT)
#if STD_C
extern	void DqL_Insert(DqNode *d, DqNode *p);
#else
extern	void DqL_Insert();
#endif
#else	/* in-line for convenience */
#define DqL_Insert(d, p)	DqR_Insert(d, (p)->left)
#endif


#if STD_C
extern	void DqR_Insert(DqNode *d, DqNode *p);
#else
extern	void DqR_Insert();
#endif


#if STD_C
extern	void	DqAppendQ( DqNode *dqa, DqNode *dqb);
#else
extern	void	DqAppendQ();
#endif

#if STD_C
extern	DqNode *DqDetach(DqNode *dq, DqNode *d);
#else
extern	DqNode *DqDetach();
#endif


/**
	t	*DqTDetach( DqNode *dq, DqNode *d, t )

	DqTDetach() detaches the node pointed to by d from the queue
	whose master node is pointed to by dq, and returns a pointer to
	the detached node, assumed to be of type t, or NULL if an
	attempt is made to detach the master node.
**/
#if defined(lint) && !defined(DqLINT)	/* shut "lint" up */
#define	DqTDetach(dq, d, t)	((void)DqDetach(dq, d), (t *)0)
#else
#define	DqTDetach(dq, d, t)	((t *)DqDetach(dq, d))
#endif


/**
	DqNode	*DqL_Detach( DqNode *dq, DqNode *d )

	DqL_Detach() detaches the node to the left of the node pointed
	to by d in the queue whose master node is pointed to by dq, and
	returns a pointer to the detached node.  A NULL pointer is
	returned if an attempt is made to detach the master node.
**/
#if defined(lint) && !defined(DqLINT)
#if STD_C
extern	DqNode *DqL_Detach(DqNode *dq, DqNode *d);
#else
extern	DqNode *DqL_Detach();
#endif
#else	/* in-line for convenience */
#define DqL_Detach(dq, d)	DqDetach(dq, (d)->left)
#endif


/**
	t	*DqTL_Detach( DqNode *dq, DqNode *d, t )

	DqTL_Detach() detaches the node to the left of the node pointed
	to by d in the queue whose master node is pointed to by dq, and
	returns a pointer to the detached node, assumed to be of type t,
	or NULL if an attempt is made to detach the master node.
**/
#if defined(lint) && !defined(DqLINT)	/* shut "lint" up */
#define	DqTL_Detach(dq, d, t)	((void)DqL_Detach(dq, d), (t *)0)
#else
#define	DqTL_Detach(dq, d, t)	((t *)DqL_Detach(dq, d))
#endif


/**
	DqNode	*DqR_Detach( DqNode *dq, DqNode *d )

	DqR_Detach() detaches the node to the right of the node pointed
	to by d in the queue whose master node is pointed to by dq, and
	returns a pointer to the detached node.  A NULL pointer is
	returned if an attempt is made to detach the master node.
**/
#if defined(lint) && !defined(DqLINT)
#if STD_C
extern	DqNode *DqR_Detach(DqNode *dq, DqNode *d);
#else
extern	DqNode *DqR_Detach();
#endif
#else	/* in-line for convenience */
#define DqR_Detach(dq, d)	DqDetach(dq, (d)->right)
#endif


/**
	t	*DqTR_Detach( DqNode *dq, DqNode *d, t )

	DqTR_Detach() detaches the node to the right of the node pointed
	to by d in the queue whose master node is pointed to by dq, and
	returns a pointer to the detached node, assumed to be of type t,
	or NULL if an attempt is made to detach the master node.
**/
#if defined(lint) && !defined(DqLINT)	/* shut "lint" up */
#define	DqTR_Detach(dq, d, t)	((void)DqR_Detach(dq, d), (t *)0)
#else
#define	DqTR_Detach(dq, d, t)	((t *)DqR_Detach(dq, d))
#endif


/**
	MuvesBool	DqIsEmpty( DqNode *dq )

	DqIsEmpty() tests whether the node to the right of the master
	node pointed to by dq is the master node itself (empty queue).
	DqIsEmpty() returns mTrue if the queue is empty, mFalse otherwise.
**/
#if defined(lint) && !defined(DqLINT)
#if STD_C
extern	MuvesBool DqIsEmpty(DqNode *dq);
#else
extern	MuvesBool DqIsEmpty();
#endif
#else	/* in-line for speed */
#define DqIsEmpty(dq)		((dq)->right == (dq))
#endif


/**
	t	*DqFirst( DqNode *dq, t )

	DqFirst() returns the address of the node to the right of the
	master node (*dq), cast to type pointer-to-t.
**/
#ifdef lint	/* make 'lint' shut up */
#define DqFirst(dq, t)		((t *)0)
#else
#define DqFirst(dq, t)		((t *)(dq)->right)
#endif


/**
	t	*DqLast( DqNode *dq, t )

	DqLast() returns the address of the node to the left of the
	master node (*dq), cast to type pointer-to-t.
**/
#ifdef lint	/* make 'lint' shut up */
#define DqLast(dq, t)		((t *)0)
#else
#define DqLast(dq, t)		((t *)(dq)->left)
#endif


/**
	DqNode	*DqPred( DqNode *dq, DqNode *d )

	DqPred() returns a pointer to the node to the left of the node
	pointed to by d in the queue whose master node is pointed to by
	dq.  The last node is considered to be to the left of the first
	node (for this function only); if there is only one node in the
	queue then it is to the left of itself.
**/
#if defined(lint) && !defined(DqLINT)
#if STD_C
extern	DqNode *DqPred(DqNode *dq, DqNode *d);
#else
extern	DqNode *DqPred();
#endif
#else	/* in-line for speed */
#define DqPred(dq, d)	((d)->left == (dq)?(dq)->left:(d)->left)
#endif


/**
	t	*DqTPred( DqNode *dq, DqNode *d, t )

	DqTPred() returns a pointer to the node (assumed to be of type
	t) to the left of the node pointed to by d in the queue whose
	master node is pointed to by dq.  The last node is considered to
	be to the left of the first node (for this function only); if
	there is only one node in the queue then it is to the left of
	itself.
**/
#if defined(lint) && !defined(DqLINT)	/* shut "lint" up */
#define	DqTPred(dq, d, t)	((void)DqPred(dq, d), (t *)0)
#else
#define	DqTPred(dq, d, t)	((t *)DqPred(dq, d))
#endif


/**
	DqNode	*DqNext( DqNode *dq, DqNode *d )

	DqNext() returns a pointer to the node to the right of the node
	pointed	to by d in the queue whose master node is pointed to by
	dq.  The first node is considered to be to the right of the last
	node (for this function only); if there is only one node in the
	queue then it is to the right of itself.
**/
#if defined(lint) && !defined(DqLINT)
#if STD_C
extern	DqNode *DqNext(DqNode *dq, DqNode *d);
#else
extern	DqNode *DqNext();
#endif
#else	/* in-line for speed */
#define DqNext(dq, d)	((d)->right == (dq)?(dq)->right:(d)->right)
#endif


#if STD_C
extern void DqSort( DqNode *q, int (*cmpfunc)());
#else
extern void DqSort();
#endif

/**
	t	*DqTNext( DqNode *dq, DqNode *d, t )

	DqTNext() returns a pointer to the node (assumed to be of type
	t) to the right of the node pointed to by d in the queue whose
	master node is pointed to by dq.  The first node is considered
	to be to the right of the last node (for this function only); if
	there is only one node in the queue then it is to the right of
	itself.
**/
#if defined(lint) && !defined(DqLINT)	/* shut "lint" up */
#define	DqTNext(dq, d, t)	((void)DqNext(dq, d), (t *)0)
#else
#define	DqTNext(dq, d, t)	((t *)DqNext(dq, d))
#endif


/**
	DqNode *dq;
	t *d;	// must be simple pointer variable
	// ...
	DqEACH( dq, d, t )
		// controlled statement

	DqEACH() is a macro used to start a loop that steps through each
	node in the queue pointed to by dq.  The variable d is
	initialized to point to the first node in the queue, cast to a
	pointer to the appropriate type t.  d is set to point to each
	succeeding node in turn, progressing forward (to the "right")
	until the end of the queue is reached.

	WARNING:  The queue linkage must not be altered within the body
	of the loop.
**/
#ifdef lint	/* make 'lint' shut up */
#define DqEACH(dq, d, t)	for (d = (t *)0; (dq) != (DqNode *)0; )
#else
#define DqEACH(dq, d, t)	for (d = DqFirst(dq, t); (d) != (t *)(dq); \
				     d = DqFirst((DqNode *)(d), t))
#endif


/**
	DqNode *dq;
	t *d;	// must be simple pointer variable
	// ...
	DqREVEACH( dq, d, t )
		// controlled statement

	DqREVEACH() is a macro used to start a loop that steps through
	each node in the queue pointed to by dq.  The variable d is
	initialized to point to the last node in the queue, cast to a
	pointer to the appropriate type t.  d is set to point to each
	preceding node in turn, progressing backward (to the "left")
	until the beginning of the queue is reached.

	WARNING:  The queue linkage must not be altered within the body
	of the loop.
**/
#ifdef lint	/* make 'lint' shut up */
#define DqREVEACH(dq, d, t)	for (d = (t *)0; (dq) != (DqNode *)0; )
#else
#define DqREVEACH(dq, d, t)	for (d = DqLast(dq, t); (d) != (t *)(dq); \
				     d = DqLast((DqNode *)(d), t))
#endif


/**
	DqNode *dq;
	DqNode *np;
	t *d;	// must be simple pointer variable
	// ...
	DqTAIL( dq, np, d, t )
		// controlled statement

	DqTAIL() is a macro used to start a loop that begins with a
	specified node (pointed to by np) in the queue pointed to by
	dq and steps through each remaining node in the queue.  The
	variable d is initialized to point to the node *np, cast to a
	pointer to the appropriate type t.  d is set to point to each
	succeeding node in turn, progressing forward (to the "right")
	until the end of the queue (the queue head) is reached.

	WARNING:  The queue linkage must not be altered within the body
	of the loop.
**/
#ifdef lint	/* make 'lint' shut up */
#define DqTAIL(dq, np, d, t)	for (d = (t *)0, np = (DqNode *)0; \
				     (dq) != (DqNode *)0; )
#else
#define DqTAIL(dq, np, d, t)	for (d = (t *)(np); (d) != (t *)(dq); \
				     d = DqFirst((DqNode *)(d), t))
#endif

extern void DqPkgInit();
extern void DqInit (DqNode *node);

#endif	/* DqH_INCLUDE */
