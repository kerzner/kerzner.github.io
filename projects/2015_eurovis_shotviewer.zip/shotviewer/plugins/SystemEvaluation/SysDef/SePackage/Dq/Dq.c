/*
	Dq.c -- MUVES "Dq" (Double-Linked Queueing) package queueing routines

	created:	87/11/17	Karen Ross Murray
*/

#ifndef lint
static char RCSid[] = "$Id: Dq.c,v 1.24 2010/11/03 17:06:36 cmurray Exp $";
#endif

#ifndef DEBUG
#define NDEBUG
#endif

#include <assert.h>
#include <stdio.h>

#ifdef __STDC__
#include <stdlib.h>	/* free */
#else
extern void free();
#endif	/* __STDC__ */

#include <std.h>
#include <bu.h>
#include <stdio.h>
#include <common.h>   /* BRL-CAD 7.2.4+ no longer use config.h (SCR670) */
#include <Dm.h>

#include <Dq.h>		/* definitions for Dq package */
#include <Er.h>

/* For genptr_t */
#include <Rt.h>

#undef DqOpen
#undef DqClose

extern int DqDebugging;
#define ErDebugging DqDebugging

/*
	DqOpen() opens a queue by allocating storage for the master node
	and returning a pointer to it.  Initially, both left and right
	pointers of the master node point to the master node.  DqOpen()
	will terminate if it is unable to allocate storage.
*/

#if STD_C
DqNode *
DqOpenm( const char *str )
#else
DqNode *
DqOpenm()
#endif
	{	register DqNode	*dq;

	dq = (DqNode  *)DmBallocm(sizeof(DqNode), DmBIN(sizeof(DqNode)), str);
	dq->left = dq->right = dq;
		return dq; /*will never be NULL since DmBallocm() never is. */
	}


/*
	DqClose() closes a queue.  The queue is expected to be already
	empty before DqClose() is called, and all nodes removed from the
	queue should have been freed via the appropriate bu function.
	If the queue is empty, DqClose() simply frees the master node.
	If any nodes still remain linked into the queue, they are freed
	by calling free(); the appropriate bu freeing function cannot be
	used by DqClose() to free the data nodes because the actual node
	size is not known by DqClose().  Not only will such use of
	DqClose() cause bu usage logging to report mismatches, but also
	if any storage was accessed via a pointer within the node, it
	will be lost forever!  (Note that user data nodes can be freed
	only because of the constraint that their addresses coincide
	with those of their DqNode initial members.  They must have been
	dynamically allocated, however, or havoc will result!)
	DqClose() must be given a pointer to the master node for the
	queue; subsequently the pointer will no longer point to valid
	storage, so it must not be further used.
*/

#if STD_C
void
DqClose( register DqNode *dq )
#else
void
DqClose( dq )
register DqNode *dq;
#endif
	{
	register DqNode *p;
	register DqNode *pnext=NULL;
	const char *ErMODULE_NAME = "DqClose";

	if (dq == NULL)
		return;

	if( ! DqIsEmpty( dq ) )
		{
		ErDEBUG( "BUG: Memory leak; nodes not freed." );

		assert(DqIsEmpty( dq ));
		for (p = dq->right; p != dq; p = pnext)
			{
			pnext = p->right;

			/* Can't use DmFree() because node types aren't
			   known.
			*/
#ifdef lint
			free((pointer)0);
#else
			free((pointer)p);
#endif
			}
		}

	DmFree((genptr_t)dq );
	}

void DqInit (DqNode *node)
{
  if (node == NULL) 
    {
      ErPLog ("DqInit: NULL pointer.\n");
    }
  else
    {
      node->left = node;
      node->right = node;
    }
  return;	
}


/**
        void DqAppendQ( DqNode *dqa, DqNode *dqb)

        DqAppendQ() appends the queue pointed to by dqa to the right
        of the last node in the queue whose master node is dqb. This
        seemed like a faster alternative to popping and pushing.
**/

void
#if STD_C
DqAppendQ( register DqNode *dqa, register DqNode *dqb)
#else
DqAppendQ( dqa, dqb)
register DqNode *dqa;
register DqNode *dqb;
#endif
	{
	assert( dqb != NULL ); /* must append to an open queue */

	if (( dqa != NULL) && (!DqIsEmpty(dqa)))
		{
		/* attach right side */
		dqb->left->right= dqa->right;
		dqa->left->right= dqb;
		/* attach left side */
		dqa->right->left= dqb->left;
		dqb->left= dqa->left;
		/* leave dqa empty */
		dqa->right= dqa->left= dqa;
		}
	}

/**
        DqNode  *DqDetach( DqNode *dq, DqNode *d )

        DqDetach() detaches the node pointed to by d from the queue
        whose master node is pointed to by dq, and returns a pointer to
        the detached node.  A NULL pointer is returned if an attempt is
        made to detach the master node (i.e. dq==d).

	A NULL is also return NULL is passed in as if dq or d
		(though this should never happen).

**/

#if STD_C
DqNode *
DqDetach( register DqNode *dq, register DqNode *d )
#else
DqNode *
DqDetach( dq, d )
register DqNode *dq;
register DqNode *d;
#endif
	{
	register DqNode *p;
	register DqNode *q;

	assert(d != NULL);
	assert(dq != NULL);

	if (d == dq || dq==NULL || d==NULL)
		return NULL;

	q = d->right;
	p = d->left;
	p->right = q;
	q->left = p;

	if (p==q) {/* then this was the last node in the list */
		/* "d", the last node is popped and still being returned.
		 * But dq->left,dq->right should point to 
		 * dq to show the master list is now empty.
		 */
	   dq->left = dq;
	   dq->right = dq;
	}

	return d;
	}


/**
        void    DqR_Insert( DqNode *d, DqNode *p )

        DqR_Insert() inserts the node pointed to by d to the right of
        the node pointed to by p.
**/

#if STD_C
void
DqR_Insert( register DqNode *d, register DqNode *p )
#else
void
DqR_Insert(d, p)
register DqNode *d;
register DqNode *p;
#endif
	{
	register DqNode *q;

	assert(d != NULL);
	assert(p != NULL);

	if (d == NULL || p == NULL)
		return;

	q = p->right;
	d->left = p;
	d->right = q;
	p->right = d;
	q->left = d;
	}
/**
	DqSort() sorts the elements of a Dq list using the
	comparison function 'cmpfunc'. DqSort allocates
	an array by the number of elements in the Dq list,
	fills the array with the list nodes and passes it
	to qsort. It then uses the sorted array to rebuild
	the Dq list in order. 

	The comparison function (see qsort manpage) should
	access the Dq nodes as follows:
	STATIC int exmple_cmp( const void *ap, const void *bp )
	{	NodeCategory **a = (NodeCategory **) ap;
		NodeCategory **b = (NodeCategory **) bp;
		if ( (*NodeCategory)->value < (*NodeCategory)->value )
			return (int)1;
		.	.	.	.	.
		.	.	.	.	.
		.	.	.	.	.
	}
**/
void
#if STD_C
DqSort( DqNode *q, int (*cmpfunc)())
#else
DqSort(q, cmpfunc)
DqNode *q;
int (*cmpfunc)();
#endif
	{
	DqNode		*tmp;
	DqNode		**sortarray;
	int		cnt=0,i;
	

	/* Get count of nodes in list */
	DqEACH( q, tmp, DqNode)
		cnt++;

	/* Allocate sort array */
	sortarray = (DqNode **)DmCalloc((int) cnt, sizeof(DqNode *));

	i=0;
	DqEACH( q, tmp, DqNode)
		sortarray[i++]=tmp;

	/* Sort list. */
	qsort( (char *) sortarray, cnt, sizeof(DqNode *), cmpfunc );

	/* Empty the queue. */
	while( DqPop( q ) != NULL )
		;

	/* Rebuild the queue in sorted order. */
	for( i = 0; i < cnt; i++)
		DqAppend( q, sortarray[i] );

	/* Free sort array */
	DmFree((genptr_t)sortarray );

	return;

sorterror:
	assert( ErIsSet());
	ErPLog("DqSort: Error allocating sort array.\n");
	}


void DqPkgInit ()
{
    static int done = 0;
    if (!done) {
	done = 1;
	ErPkgInit();
	
	
	#ifdef DEBUG
	ErPLog ("Dq package initialized.\n");
	#endif
    }        
}
