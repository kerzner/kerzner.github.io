/**
	<Cp.h> -- MUVES "Cp" (component properties) package definitions
**/
/*
	created:	96/1/15 Keith Bowman
	edited:         01/04/06	Cletus Hunt III
					moved CpPropNode from Cp.c
	edited:         01/05/11	Cletus Hunt III
					added '#include <Dq.h>', prototypes
					for CpGetPval(), CpAlProperties()
	edited:		02/06/10	C Hunt
					added CpORCA_PERSONNEL component
					property name for ORCA personnel
					(SCR446)
	edited:		03/06/02	Keith Bowman
					added prototypes for CpPrCrossRef(),
					CpPrDefaults(), CpPrProperties(),
					CpPrRegistry() because they are used by
					other files (corrected for SCR380)
	RCSid:	$Id: Cp.h,v 1.36 2010/06/23 19:54:45 geoffs Exp $
*/
/**
	Dependencies: Nm, Dq, Io, Er

	The Component Properties package is a spin off of the Material
	Properties "Mp" package for registering and storing component
	properties. This package replaces the handling of component
	properties by the "Dd" package. The "Cp" package also changes how
	properties are registered in the muves environment but does not
	change how component properties are defined by the user.

	Like "Mp", the component property package supports the notion of
	"property registry" through a file. Historically, component properties
	where registered through the file "DdProps" which was generated from
	a properties file using 'awk' programs at compiles time. The "Cp"
	package now registers component properties through a registry file
	similar to the material properties registry. "Cp" differs slightly
	in that it is designed to read two registry files. These files represent
	a 'Common' property registry and a 'Method Specific' property registry.
	This seperation of the registries allows developers to encapsulate
	component properties specific to a methodology. Both registries are
	read and merged into one component property name pool(CpProNam).


			Common Component Properies
			--------------------------
	The common component properties are registered from the centrally
	located file:

		 '$MUVES/lib/methods/CommonProperties.reg'

	which is available to all methods. The development location of this
	file is kept in the 'Cp' package. To add a common component property
	simply add the registry information to 'CommonProperties.reg' in the
	'Cp' package (see 'Mp' package for registry file format).

	Instead of directly indexing into property arrays using a defined
	index (ie. CpBHN) the 'Cp' functions use the property string name.
	For developer convenience and backward compatibilty the original
	property definitions have been redefined with their string names
	in the "Cp" header file.

			Method Specific Component Properies
			-----------------------------------
	The method specific component properties should be registered from
	a method specific location. For Instance, the 'stoch' method specific
	component properties are registered from file:

		 '$MUVES/lib/methods/stoch/MethProperties.reg'

	The development location of this file is kept in the 'methods/stoch'
	source directory. The property string definitions have been added to
	'stoch.h'. To add a method specific component property a developer
	need only add to these two files.

	Routines are provided for reading and printing both the component
	property registry and the component property definitions. Functions
	for querying component properties are also provided. For backward
	compatibily, two functions were created to replace the existing "Dd"
	functions, "DdGetStrProp()" and "DdGetProperty()". These new functions
	"CpGetStrProp()" and "CpGetProperty()" return the same type of data
	but now take a property string as an input parameter instead of a
	property index. In the "Dd" header file preprocessor definitions
	map the original functions to the new "Cp" functions as follows:

		#define DdGetStrProp	CpGetStrProp
		#define DdGetProperty	CpGetProperty

	Using the new component property string definitions along with
	the "Dd" to "Cp" mapping above allows continued use of "DdGetStrProp()"
	and "DdGetProperty()". This is intended as an interim measure
	until all the packages are updated. Newer development should use
	the "Cp" package calls.

	Like "Mp", the details of how the properties are stored in memory
	is private to this package.
**/
#ifndef Cp_H_INCLUDED
#define Cp_H_INCLUDED

#define CpORCA_PERSONNEL	"ORCA_PERSONNEL"

/* NOTE: For use in AppCode:Shotviewer, CpGetStrProp() is only used to get the
 *       value for ORCA_PERSONNEL component property and this is only used to
 *       check that all of the components list _orca built-in function have
 *       the same value; since the sysdef and .ir file loaded are the result
 *       of a successfully run analysis, this check has already been done and
 *       succeeded, so returning an string is sufficient.  */
#define CpGetStrProp(a, b)      "orcaman"
#endif /* Cp_H_INCLUDED */
