// vim:smarttab expandtab sw=4:
#ifndef SEEVALUATION_H
#define SEEVALUATION_H
#ifndef __device__
#define __device__
#endif

#ifndef __host__
#define __host__
#endif

/**
 *  This file contains common definitions used by classes that use the
 *  SeDevice class indirectly through the SeWrapper class for system
 *  definition evaluation, but don't need to include the SeDevice
 *  class.
 **/

#include <QtGlobal>
#include <QByteArray>
#include <QVector>
#include "SeStruct.h"
#include <QVector>
#include <QStringList>
#include <QRegExp>
#include <QHash>
#include <QPair>

#ifdef __cplusplus
using Vulnerability::Evaluation;
#endif

struct SeLockedSystem;

struct SeLockedSystem;


// evaluate expression code return status values (11-12-16 ch3)
// added frame error (12-03-16 ch3)
enum EvaluateStatusEnum {
    EvaluateGood,
    EvaluateDivByZero,
    EvaluateBadCode,
    EvaluateStackErr,
    EvaluateFrameErr,
    EvaluateSentinel
};


class SeQualItem
{
    int m_baseIndex;                            // base index of item
    int m_qualIndex;                            // index of qualifier

public:
    SeQualItem(void) :
        m_baseIndex(-1),
        m_qualIndex(-1) {
    }

    SeQualItem(int baseIndex, int qualIndex) :
        m_baseIndex(baseIndex),
        m_qualIndex(qualIndex) {
    }

    int baseIndex(void) const {
        return m_baseIndex;
    }
    int qualIndex(void) const {
        return m_qualIndex;
    }
    void get(int &baseIndex, int &qualIndex) const {
        baseIndex = m_baseIndex;
        qualIndex = m_qualIndex;
    }
};


typedef QHash<int, SeQualItem> SeQualHash;


// expression code information structure (11-12-07 ch3)
// added size of function call fragment to structure (12-03-16 ch3)
// added critical component variables to structure (12-09-12 ch3)
struct SeCodeInfo {  // SeDevice, SeWrapper
    QList<int> codeArray;       // array of encoded nodes
    QList<int> orderList;       // evaluation order of system indexes
    int stackSize;              // size of stack required for system
    int frameSize;              // size of frame required for system
    SeQualHash qualSystems;     // qualifier system information
};


struct SeIntervalData {  // TmpShotlines, SeDevice, SeWrapper
    int pixelsSize;             // allocated size of point/index arrays
    int pixelsCount;                 // number of shot line points
    SePoint *pixels;             // point data array [points]
    int *indicies;                 // indices into interval data array [points]
    int countSize;              // allocated size of interval data array
    int count;                  // number of intervals
    SeInterval *intervals;           // interval data array [count]

    SeIntervalData(void) :
        pixelsSize(0),
        pixels(NULL),
        indicies(NULL),
        countSize(0),
        intervals(NULL) {
    }
    ~SeIntervalData() {
        delete[] pixels;
        delete[] indicies;
        delete[] intervals;
    }
};


struct SeComponentData {        //FiremanPugh, FiremanPughPenEq.cu, SeDevice
    qint8 critical;             // component is critical flag
    qint8 spalls;               // component spalls flag
    qint16 materialIndex;       // material index for component

    SeComponentData() : spalls(0) {}
};



/*struct SeMaterialData {     //FiremanPugh, FiremanPughPenEq.cu, SeDevice
    float density;
    SeThorCoeff thorCoeff;
};*/


struct SeColor {  // VLTest, SeDevice, SeWrapper
    unsigned char red;
    unsigned char green;
    unsigned char blue;
};


enum {
    SeThreatParamCount = 4
};

struct SeThreatParams {
    float value[SeThreatParamCount];
};

// NOTE this structure may need to be a union by threat type to save memory
struct SeThreatData {  // VLTest, SeDevice, SeWrapper, IntervalBuilder,
    // FiremanPughPenEq.cu, FiremanPugh
    virtual int dataSize() {
        return sizeof(SeThreatData);
    }
    int             materialID;
    bool            isTargetMat;  //Is this a target material ID?
    SeThreatParams  params;

    SeThreatData() : isTargetMat(false) {}
};


enum SePenStatus {
    SePenNone,
    SePenContinue,
    SePenStopped,
    SePenOutSideStandoffDomain,
    SePenError,
    SePenShapeNotSupported,
    SePenSentinel
};


class SePenetrationFunction
{
public:
    __device__ __host__ SePenetrationFunction(void) {}
    __device__ __host__ ~SePenetrationFunction(void) {}

    virtual __device__ __host__ int penEqId(void) {
        return -1;
    }
    virtual __device__ __host__ int penetrate(SeInterval *intervals, int index,
            int subId, SeThreatData *threatData, SeComponentData *componentData,
            void *materialData, void *penData, void *extra) = 0;
};


struct SePenetrationModule {    //PenEqInterface, SeDevice
    QByteArray *penData;
    QByteArray *extra;
    SeThreatData *initialThreatData;
    QVector<int> materialIndex;
    QVector<int> spallFlags;
    QByteArray materialData;

    SePenetrationModule(void) : penData(NULL), extra(NULL),
        initialThreatData(NULL) {}
};


// predefined special table offset values
enum {
    SeTableOffsetInvalid       = 0,
    SeTableOffsetIsHit         = -1,
    SeTableOffsetIsThreatened  = -2,
    SeTableOffsetLineOfSite    = -3,
    SeTableOffsetTable2D       = -4,
    SeTableOffsetUnSet         = -5
};


struct SeCompEvalData {
    int tableOffset;            // offset into table buffer
    int stateIndex;             // index into state arrays
};


// evaluation data
// TODO this will probably need to be a union to save space
struct SeEvalData {  // VLTest, SeDevice, SeWrapper
    int qualifierId;
    int tableOffset;
    float los;
    float threshold;
};

enum SeDamageStatus {
    SeDamageNone,
    SeDamagePresent,
    SeDamageThreatened,
    SeDamageSentinel
};

struct SeDamageData {
    qint8 status;           // SeDamageStatus
    qint8 penStatus;
    qint8 spalls;
    qint8 penEqId;          // penetration equation that produced damage

    qint8 materialId;       // threat material
    qint8 future2;
    qint8 future3;
    qint8 future4;

    SeThreatParams in;
    SeThreatParams out;

    int compIndex;			// component index of the damaged component
    int next;				// next damage packet in this list of packets
};

struct SeArgsDoPenetration {
    SeArgsDoPenetration() {
        nevaluations = -1;
        shotlines = NULL;
        intervalData = NULL;
        threatData = NULL;
        compData = NULL;
        materialData = NULL;
        penData = NULL;
        damageData = NULL;
    }

    // inputs
    int nevaluations;               // number of evaluations (shot lines)
    SeShotline *shotlines;          // pointer to shotlines array
    //int *intervalIndex;             // pointer to interval index array
    SeInterval *intervalData;       // pointer to interval data array
    SeThreatData *threatData;       // initial threat data
    int threatSize;                 // data size for threatData
    bool multipleThreats;           // Are there multiple threats?
    SeComponentData *compData;      // pointer to component data
    // (Use compTotalCount to size buffer)
    void *materialData;   // pointer to material data
    void *penData;                  // pointer to penetration data
    void *extraData;                // pointer to extra data needed
    // outputs
    SeDamageData *damageData;       // pointer to damage data array
};

struct SeArgsEvaluateCompDamage {
    // inputs
    int nevaluations;               // number of evaluations (shot lines)
    int ncomps;                     // number of components
    qint8 *initCompTyps;            // initial component types aggregate array
    float *initCompVals;            // initial component values aggregate array
    int *compEvalStart;             // pointer to component table start index
    SeCompEvalData *compEvalData;   // pointer to component evaluation data
    char *evalTableData;            // pointer to evaluation table data
    SeShotline *shotlines;          // pointer to shotlines array
    Evaluation *evaluations;        // pointer to evluations array
    int *intervalIndex;             //XXX: DEPRICATED
    SeInterval *intervalData;       //XXX: DEPRICATED
    SeDamageData *damageData;       // pointer to damage data array
    SeEvalData evalData;            // evaluation data
    int *evalOffset;                // the eval offset into the shotlines array
    // outputs
    qint8 *compTyps;           // pointer to component types aggregate array
    float *compVals;           // pointer to component values aggregate array
};

struct SeArgsEvaluateSysDefs {
    // inputs
    int *code;                      // pointer to sysdef code array
    int nevaluations;               // number of evaluations (shot lines)
    int ncomps;                     // number of components
    int stackSize;                  // size of evaluation stack
    int frameSize;                  // size of evaluation frame stack
    int nsystems;                   // number of systems
    int nLockedSystems;             // number of locked systems
    SeLockedSystem *lockedSystems;  // pointer to locked system info
    qint8 *compTyps;                // pointer to component types array
    float *compVals;                // pointer to component values array
    // work
    float *stack;                   // pointer to evaluation stack
    qint16 *frame;                  // pointer to evaluation frame stack
    // outputs
    qint8 *status;                  // pointer to evaluation status array
    qint8 *sysTyps;                 // pointer to system types array
    float *sysVals;                 // pointer to system values array
};

#endif // SEEVALUATION_H
