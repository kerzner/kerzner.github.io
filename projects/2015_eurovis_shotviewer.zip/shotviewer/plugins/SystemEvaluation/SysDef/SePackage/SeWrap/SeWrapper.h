// vim:smarttab expandtab sw=4
#ifndef SEWRAPPER_H
#define SEWRAPPER_H

#include <QObject>
#include <QStringList>

extern "C" {
    typedef union sesysdef SeSysDef;
}
class SePrivate;

class SeWrapper : public QObject
{
    Q_OBJECT
public:
    explicit SeWrapper(QObject *parent = 0);
    ~SeWrapper(void);  /* 11-05-04 ch3: added for cleanup */

public slots:
    // Construct a new system definition.
    // Stash the ptr in the SeDataSystem
    // set the idx to the index into the
    // (SeSysNamePool/SysDataSystem/...) for the new system
    void buildSystemWithPtr(const QString &name, void *ptr, int *idx);

    // Construct a new SeComponent.
    // Stash the ptr in XXX?
    // set the idx to the index in SeComponents
    // for the new component
    void buildSystemWithPtr(const QString &name, void *ptr, int *idx);

    //  Set the current value for a component (killed 0.0/ alive 1.0)
    void setComponentValue(const int i, float val);

    //  Set the current value for a system
    // valid/invalid and value interpreted from single float number:
    // valid/killed 0.0
    // invalid     -1.0
    // valid/alive  1.0
    void setSystemValue(const int i, float val);

    float getSystemValue(const int i);

    void clearAllComponentValues();  // make everything "live"
    void invalidateAllSystemValues(); // make everything "invalid" so it is recomputed


    // Evaluate a system based upon some state vector for components
    float evaluateSystem(const QString &name);

    // functions for getting the full text for a system
    QString getSystem(const QString &name);
    //void sysGetExpr(QString &s, SeSysDef *sysdefp);

    // function for removing the definition for a system
    // returns list of names that were removed
    bool deleteSystem(const QString &name, QStringList &removed_names, QString &errmsg);

    // functions for replacing a system with a component
    bool sysReplaceWithComp(const QString &name, QString errmsg);
    void sysReplaceWithComp(SeSysDef *sysdefp, int sysindex, int compindex);

    //  register a new system (or replace an existing one
    void registerSystem(const int index);

    // functions for checking if a system is currently used
    bool sysIsUsed(int sysindex);
    bool sysIsUsed(SeSysDef *sysdefp, int sysindex);

    // functions for finding systems used in all system definitions
    int *sysFindUsed(void);
    void sysFindUsed(SeSysDef *sysdefp, int *used);

    QStringList sysUndefinedSystemList(void);

    //************************************
    //  USED INTERFACE RELATED FUNCTIONS
    //************************************

    // load a system definition file
    void sysDefOpenFile(const QString &fileName);

    // parse a string and add system
    void sysDefParseString(QString systemDefinition);

    // Define a set of components
    // If they were undefined systems the components should replace the systems
    // If they were defined systems ... that is an error of some type
    void addComponents(const QStringList &names);

    // delete currently selected system
    void deleteSystem(void);

    // make currently selected system
    void makeComponent(void);

signals:
    void newSystems(QStringList); // tell the world the name(s) of the new system(s)
    void systemText(const QString); // tell the world the full text of a system
    void errorMessages(QString);
    void removeSystem(QString);
public slots:
private:
    SePrivate *priv;
    int current_system;         // index of current system
    // private functions
    void sysEmitUserSystemList(void);  // emit list of all known user systems
    void walkSystem(SeSysDef *sysdefp);
};

#endif // SEWRAPPER_H
