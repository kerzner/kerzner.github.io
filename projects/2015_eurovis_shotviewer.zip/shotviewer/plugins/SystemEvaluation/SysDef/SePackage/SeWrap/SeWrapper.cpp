// vim:smarttab expandtab sw=4
#define SEPRIVATE
#include "SeWrapper.h"

extern "C" {
#include "std.h"
#include <Er.h>
//#include <Fa.h>
#include <Io.h>
#include <stdio.h>
#include <common.h>   /* BRL-CAD 7.2.4+ no longer use config.h (SCR670) */
#include <Dm.h>
#include <Rt.h>
#include <Sc.h>
#include <Se.h>

#include "SeDefs.h"     /* for SeTesting, SeSysDef, etc. */

    NmPool RtComponents;

// Register a system to the user interface (called from C)
    void SeWrapperRegisterSystem(int index, void *ptr)
    {
        SeWrapper * wrapper = (SeWrapper *)ptr;
        wrapper->registerSystem(index);

    }


};

extern "C" {
#include "Nm.h"
}

//  This is the data structure with the private data for the Se Package
//  It is here so that items which need SeWrapper are not exposed to the linkage
//  to the rest of the Se package and all its dependecies
class SePrivate
{
public:
    SePrivate() : vars(NULL) {}
    SeParseVars *vars;

};

class SeValueTable
{
    SeValue *values;
    void *values;
    void *parents;
    int tableSize;
    int lastUsed;
    bool isInitialized;

    void setValueAt(int i, float v);
    void setPtrsAt(int i, void *ptr, void *parent);
    void clearPtrsFrom(void *deadParent);
};


// Constructor
// Here we initialize any data that persists beyond a single method call
SeWrapper::SeWrapper(QObject *parent) :
    QObject(parent),
    priv(new SePrivate),
    current_system(-1),
    m_valueTable(new SeValueTable)
{

    DqPkgInit();

    NmInit (&RtComponents);


    if (NmIndex( "I_am_the_fake_component_to_make_Se_work", &RtComponents,
                 mTrue) == -1) {
        abort();
    }

    ErPkgInit();
    IoPkgInit();

    NmPkgInit();

    SePkgInit();

    // give path to library sysdef file (for now this is a hack)
    // (mTrue = interactive mode: allow duplicates, allocate error buffer)
    // 11-05-04 ch3: added "/" to library sysdef path
    priv->vars = SeSysInit("../Se/", mTrue, (void *)this);
    // 11-05-04 ch3: added error check from initialization failure
    if (priv->vars->error == SeFail2) {
        fprintf(stderr, "SeWrapper: SeSysInit() failed\n");
        SeSysTerm(priv->vars);
        priv->vars = NULL;
    }
}

// Destructor (11-05-03 ch3: added to cleanup memory leaks)
SeWrapper::~SeWrapper()
{
    if (priv->vars != NULL) {
        SeSysTerm(priv->vars);
        priv->vars = NULL;
    }
    NmClear(&RtComponents);
}


bool SeWrapper::evaluate(const QString &name, int currentStateOfComponents)
{
    return false;
}


// Return a string with the definition of the names system
// formatting is nice but not important now
//

QString SeWrapper::getSystem(const QString &name)
{
    int index = NmIndex(qPrintable(name), &SeSystems, mFalse);
    if (index == -1) {
        current_system = -1;
        return QString("system name '%1' unknown").arg(name);
    }
    current_system = index;
    QString expr;
    if (SeDataSystem[index] == NULL) {
        expr.append("<undefined>");
    } else {
        sysGetExpr(expr, SeDataSystem[index]->sysdef);
    }
    return QString("%1 = %2").arg(name, expr);
}


// Return expression for system definition node
void SeWrapper::sysGetExpr(QString &s, SeSysDef *sysdefp)
{
    const char *name;
    QString t;
    QString intnum;

    if (sysdefp == NULL) {
        s.append("<undefined>");
        return;
    }
    switch (sysdefp->type) {
    case SeNT_QUALSYS:
    case SeNT_SYSNAME:
        if ((name = NmName(sysdefp->c.index, &SeSystems)) == NULL) {
            s.append(QString("<BUG: bad system (%1) index (%2)>")
                     .arg(QString(sysdefp->core.text),
                          intnum.setNum(sysdefp->c.index)));
        } else {
            if (!StrEq(sysdefp->core.text, name)) {
                s.append(QString("<BUG: %1 %2 != %3>")
                         .arg(QString(SeCvtToStr(sysdefp->type)),
                              QString(sysdefp->core.text), QString(name)));
            } else {
                //DEBUG if (sysdefp->type == SeNT_QUALSYS) s.append("QS:");
                s.append(name);
            }
        }
        break;

    case SeNT_QUALIST:
    case SeNT_LISTNAME:
        if ((name = NmName(sysdefp->c.index, &SeLists)) == NULL) {
            s.append(QString("<BUG: bad list (%1) index (%2)>")
                     .arg(QString(sysdefp->core.text),
                          intnum.setNum(sysdefp->c.index)));
        } else {
            if (!StrEq(sysdefp->core.text, name)) {
                s.append(QString("<BUG: %1 %2 != %3>")
                         .arg(QString(SeCvtToStr(sysdefp->type)),
                              QString(sysdefp->core.text), QString(name)));
            } else {
                s.append(name);
            }
        }
        break;

    case SeNT_QUALCOMP:
        //DEBUG s.append("QC:");  // this node type should not be seen
    case SeNT_COMPNAME:
        if ((name = NmName(sysdefp->c.index, &SeComponents)) == NULL) {
            s.append(QString("<BUG: bad component index (%1)>")
                     .arg(intnum.setNum(sysdefp->c.index)));
        } else {
            if (!StrEq(sysdefp->core.text, name)) {
                s.append(QString("<BUG: %1 %2 != %3>")
                         .arg(QString(SeCvtToStr(sysdefp->type)),
                              QString(sysdefp->core.text), QString(name)));
            } else {
                //DEBUG if (sysdefp->type == SeNT_QUALCOMP) s.append("QC:");
                s.append(name);
            }
        }
        break;

    case SeNT_CONSTANT:
        // return original string of constant
        s.append(sysdefp->core.text);
        break;

    case SeNT_FNCALL:
        if ((name = NmName(sysdefp->f.index, &SeFunctions)) == NULL) {
            s.append(QString("<BUG: bad function definition index (%1)>")
                     .arg(intnum.setNum(sysdefp->f.index)));
        } else {
            //DEBUG s.append("FN:");
            s.append(name).append('(');
            SeArgExp *np;
            DqEACH(sysdefp->f.argexps, np, SeArgExp) {
                if (np != DqFirst(sysdefp->f.argexps, SeArgExp)) {
                    s.append(',');
                }
                t = QString();
                sysGetExpr(t, np->expp);
                s.append(t);
            }
            s.append(')');
        }
        break;

    case SeNT_PARAM:
        s.append(QString("$%1").arg(intnum.setNum(sysdefp->p.index)));
        break;

    case SeNT_MULTOCC:
        s.append("MultOcc ");  // should be none of these with VSL
        // FALL THRU
    case SeNT_EXPR:
        //DEBUG s.append("EXPR:");
        s.append(SeTtbl[SeNT_LF_PAREN].ts);
        t = QString();
        sysGetExpr(t, sysdefp->o.rhsp);
        s.append(t);
        s.append(SeTtbl[SeNT_RT_PAREN].ts);
        break;

    case SeNT_NOT:
    case SeNT_ANOT:
    case SeNT_ABS:
    case SeNT_BOOL:
        s.append(SeTtbl[sysdefp->type].ts);
        t = QString();
        sysGetExpr(t, sysdefp->o.rhsp);
        s.append(t);
        break;

    case SeNT_LIST:
    case SeNT_AND:
    case SeNT_XOR:
    case SeNT_OR:
    case SeNT_MIN:
    case SeNT_MAX:
    case SeNT_SUM:
    case SeNT_DIFF:
    case SeNT_PROD:
    case SeNT_QUOT:
    case SeNT_LT:
    case SeNT_GT:
    case SeNT_LTEQ:  // 11-05-05 ch3: missed operator
    case SeNT_GTEQ:  // 11-05-05 ch3: missed operator
        //DEBUG if (sysdefp->type == SeNT_MIN) s.append("MIN:");
        //DEBUG if (sysdefp->type == SeNT_MAX) s.append("MAX:");
        t = QString();
        sysGetExpr(t, sysdefp->o.lhsp);
        s.append(t);
        s.append(' ').append(SeTtbl[sysdefp->type].ts).append(' ');
        t = QString();
        sysGetExpr(t, sysdefp->o.rhsp);
        s.append(t);
        break;

    case SeNT_RUNIF:
    case SeNT_RNORM:
    case SeNT_MOFN:
    case SeNT_PKD:
    case SeNT_ORCA:
    case SeNT_EVAL:
        //DEBUG if (sysdefp->type == SeNT_EVAL) s.append("EVAL:");
        //DEBUG if (sysdefp->type == SeNT_RUNIF) s.append("RUNIF:");
        //DEBUG if (sysdefp->type == SeNT_RNORM) s.append("RNORM:");
        t = QString();
        sysGetExpr(t, sysdefp->o.lhsp);
        s.append(t);
        s.append(' ');
        t = QString();
        sysGetExpr(t, sysdefp->o.rhsp);
        s.append(t);
        break;

    case SeNT_QUALOP:
        //DEBUG s.append("QO:");
#if 0  // let's not surround component name with quotes
        if (sysdefp->o.lhsp->type == SeNT_COMPNAME) {
            s.append('"');
        }
#endif
        t = QString();
        sysGetExpr(t, sysdefp->o.lhsp);
        s.append(t);
#if 0  // let's not surround component name with quotes
        if (sysdefp->o.lhsp->type == SeNT_COMPNAME) {
            s.append('"');
        }
#endif
        //DEBUG s.append('@');
        t = QString();
        sysGetExpr(t, sysdefp->o.rhsp);
        s.append(t);
        break;

    case SeNT_CQUALIFIER:
        s.append('[').append(sysdefp->core.text).append(']');
        break;

    case SeNT_UNSET:
        s.append("<unset node type>");
        break;

    default:
        s.append(QString("<BUG: invalid node type (%1)>")
                 .arg(SeCvtToStr(sysdefp->type)));
        break;
    }
}


// Delete a system definition including its name and expression
// along with any undefined and unused systems in its expression
//
//   Arguments:
//     name          - name of system to delete
//     removed_names - list of system names removed (to update gui)
//     errmsg        - error message string if an error occurs
//
//   Returns:
//     true  - system was successfully deleted
//     false - error occurred, nothing deleted (error string in errmsg)

bool SeWrapper::deleteSystem(const QString &name, QStringList &removed_names,
                             QString &errmsg)
{
    const char *cname = qPrintable(name);
    int index = NmIndex(cname, &SeSystems, mFalse);
    if (index == -1) {
        errmsg.append("System name '%1' unknown").arg(name);
        return false;
    }
    if (SeDataSystem[index] == NULL) {
        errmsg.append("System '%1' not defined").arg(name);
        return false;
    }

    // get a list of components used in system definition before deleting it
    int *used = new int[NmSize(&SeSystems)];
    for (int i = SeSyDStart; i < NmSize(&SeSystems); i++) {
        used[i] = 0;
    }
    sysFindUsed(SeDataSystem[index]->sysdef, used);

    // first delete the system definition expression and array element
    SeExpFree(SeDataSystem[index]->sysdef);
    DmFree(SeDataSystem[index]);
    SeDataSystem[index] = NULL;

    // check if system is no longer used
    if (!sysIsUsed(index)) {
        // system not used, so it can be deleted from system name pool
        NmDeleteName(cname, &SeSystems);

        // add to list of removed names to return
        removed_names.append(name);
    }

    // check if undefined systems used by deleted system are no longer used
    for (int i = SeSyDStart; i < NmSize(&SeSystems); i++) {
        if (used[i] > 0 && SeDataSystem[i] == NULL && !sysIsUsed(i)) {
            // system no longer used, so it too can be deleted from name pool
            cname = NmName(i, &SeSystems);
            NmDeleteName(cname, &SeSystems);

            // add to list of removed names to return
            removed_names.append(name);
        }
    }
    delete used;
    return true;
}
void SeWrapper::registerSystem(int index)
{
    // Looking at SeSystemDef[index] which is defined in SeDefs.h

    SeSysDef *system = SeSystemDef[index];

    walkSystem(system);

    fprintf(stderr, "DEBUG: new system '%s' registered at index %d\n",
            NmName(index, &SeSystems), index);


}

void SeWrapper::walkSystem(SeSysDef *sysdefp)
{
    switch (sysdefp->type) {
    case SeNT_LIST:
    case SeNT_AND:
    case SeNT_XOR:
    case SeNT_OR:
    case SeNT_MIN:
    case SeNT_MAX:
    case SeNT_SUM:
    case SeNT_DIFF:
    case SeNT_PROD:
    case SeNT_QUOT:
    case SeNT_LT:
    case SeNT_GT:
    case SeNT_RUNIF:
    case SeNT_RNORM:
    case SeNT_MOFN:
    case SeNT_PKD:
    case SeNT_ORCA:
    case SeNT_EVAL:
    case SeNT_QUALOP:
        walkSystem(sysdefp->o.lhsp);
        walkSystem(sysdefp->o.rhsp);
        break;
    }
}

// Replace system with component in all system definitions
// (system must be undefined)
//
//   Arguments:
//     name   - name of system to change to a component
//     errmsg - error message string if an error occurs
//
//   Returns:
//     true  - system was successfully changes to a component
//     false - error occurred, nothing deleted (error string in errmsg)
//
//   Note:
//     Component names are added to the SeComponents, which in MUVES is
//     for qualified components, something not wanted for VSL use.  The
//     RtComponents name pool is set to one bogus component since Se
//     needs at least one component in this name pool.  With the
//     RtComponents essentially empty, the SeParse code will not see any
//     qualified components.  The SeCompile code will convert a QUALOP
//     (QUALSYS, CQUALIFIER) node to a QUALOP (COMPNAME, CQUALIFIER)
//     node if the QUALSYS name is in the SeComponent name pool.
//
//     If and when qualified components are needed for VSL, the Se
//     Evaluator can be changed to process this QUALOP/COMPNAME node
//     appropriately, but for now, the Se Evaluator will simply look at
//     the COMPNAME node and ignore the CQUALIFIER part.
//
//     For this replacing system with components here, the QUALSYS node
//     simply needs to be changed to a COMPNAME node and the CQUALIFIER
//     node will be left intact as is.

bool SeWrapper::sysReplaceWithComp(const QString &name, QString errmsg)
{
    // get index of system to replace
    const char *cname = qPrintable(name);
    int sysindex = NmIndex(cname, &SeSystems, mFalse);
    if (sysindex == -1) {
        errmsg.append("System name '%1' unknown").arg(name);
        return false;
    }
    if (SeDataSystem[sysindex] != NULL) {
        errmsg.append("System '%1' is already defined, "
                      "cannot be made a component").arg(name);
        return false;
    }

    // add name to component pool and get its index
    int compindex = NmIndex(cname, &SeComponents, mTrue);

    if (compindex == -1) {
        errmsg.append("Component name '%1' could not be added").arg(name);
        return false;
    }

    m_valueTable->atLeastThisBig(compindex);
    m_valueTable->setValueAt(compindex, 0.0);

    // go through each system and replace system with component
    for (int i = SeSyDStart; i < NmSize(&SeSystems); i++) {
        const char *name = NmName(i, &SeSystems);
        if (name != NULL && SeDataSystem[i] != NULL) {
            sysReplaceWithComp(SeDataSystem[i]->sysdef, sysindex, compindex);
        }
    }

    // now delete the system name from the system name pool
    // (something weird inside Nm changes cname, so reset pointer)
    cname = qPrintable(name);
    NmDeleteName(cname, &SeSystems);

    // report that system was replaced with component
    return true;
}


// Replace system with component in system definition
void SeWrapper::sysReplaceWithComp(SeSysDef *sysdefp, int sysindex,
                                   int compindex)
{
    SeArgExp *np;

    switch (sysdefp->type) {
    case SeNT_QUALSYS:
        // just change QUALSYS nodes to COMPNAME nodes
        // since VSL will not be needing qualified components for now,
        // the evaluator will simply ignore the qualifier
    case SeNT_SYSNAME:
        if (sysdefp->c.index == sysindex) {
            sysdefp->type = SeNT_COMPNAME;
            sysdefp->c.index = compindex;
        }
        break;

    case SeNT_FNCALL:
        DqEACH(sysdefp->f.argexps, np, SeArgExp) {
            sysReplaceWithComp(np->expp, sysindex, compindex);
        }
        break;

    case SeNT_MULTOCC:
        // FALL THRU
    case SeNT_EXPR:
    case SeNT_NOT:
    case SeNT_ANOT:
    case SeNT_ABS:
    case SeNT_BOOL:
        sysReplaceWithComp(sysdefp->o.rhsp, sysindex, compindex);
        break;

    case SeNT_LIST:
    case SeNT_AND:
    case SeNT_XOR:
    case SeNT_OR:
    case SeNT_MIN:
    case SeNT_MAX:
    case SeNT_SUM:
    case SeNT_DIFF:
    case SeNT_PROD:
    case SeNT_QUOT:
    case SeNT_LT:
    case SeNT_GT:
    case SeNT_LTEQ:  // 11-05-05 ch3: missed operator
    case SeNT_GTEQ:  // 11-05-05 ch3: missed operator
    case SeNT_RUNIF:
    case SeNT_RNORM:
    case SeNT_MOFN:
    case SeNT_PKD:
    case SeNT_ORCA:
    case SeNT_EVAL:
    case SeNT_QUALOP:
        sysReplaceWithComp(sysdefp->o.lhsp, sysindex, compindex);
        sysReplaceWithComp(sysdefp->o.rhsp, sysindex, compindex);
        break;

    case SeNT_QUALIST:
    case SeNT_LISTNAME:
    case SeNT_QUALCOMP:
    case SeNT_COMPNAME:
    case SeNT_CONSTANT:
    case SeNT_PARAM:
    case SeNT_CQUALIFIER:
    case SeNT_UNSET:
    default:
        break;  // leaf node, nothing to do
    }
}


// Reports if a system (by index) is current used in any system definition
bool SeWrapper::sysIsUsed(int sysindex)
{
    // go through each system and check if system is used
    for (int i = SeSyDStart; i < NmSize(&SeSystems); i++) {
        if (NmName(i, &SeSystems) != NULL && SeDataSystem[i] != NULL) {
            if (sysIsUsed(SeDataSystem[i]->sysdef, sysindex)) {
                return true;  // it's used, no need to check further
            }
        }
    }
    return false;  // not found
}

// Check if system used in the system definition node
// or any node below
bool SeWrapper::sysIsUsed(SeSysDef *sysdefp, int sysindex)
{
    SeArgExp *np;

    switch (sysdefp->type) {
    case SeNT_QUALSYS:
    case SeNT_SYSNAME:
        return sysdefp->c.index == sysindex;

    case SeNT_FNCALL:
        DqEACH(sysdefp->f.argexps, np, SeArgExp) {
            if (sysIsUsed(np->expp, sysindex)) {
                return true;  // it's used, no need to check further
            }
        }
        return false;  // not found in any of the arguments

    case SeNT_MULTOCC:
        // FALL THRU
    case SeNT_EXPR:
    case SeNT_NOT:
    case SeNT_ANOT:
    case SeNT_ABS:
    case SeNT_BOOL:
        return sysIsUsed(sysdefp->o.rhsp, sysindex);

    case SeNT_LIST:
    case SeNT_AND:
    case SeNT_XOR:
    case SeNT_OR:
    case SeNT_MIN:
    case SeNT_MAX:
    case SeNT_SUM:
    case SeNT_DIFF:
    case SeNT_PROD:
    case SeNT_QUOT:
    case SeNT_LT:
    case SeNT_GT:
    case SeNT_LTEQ:  // 11-05-05 ch3: missed operator
    case SeNT_GTEQ:  // 11-05-05 ch3: missed operator
    case SeNT_RUNIF:
    case SeNT_RNORM:
    case SeNT_MOFN:
    case SeNT_PKD:
    case SeNT_ORCA:
    case SeNT_EVAL:
    case SeNT_QUALOP:
        return sysIsUsed(sysdefp->o.lhsp, sysindex)
               || sysIsUsed(sysdefp->o.rhsp, sysindex);

    case SeNT_QUALIST:
    case SeNT_LISTNAME:
    case SeNT_QUALCOMP:
    case SeNT_COMPNAME:
    case SeNT_CONSTANT:
    case SeNT_PARAM:
    case SeNT_CQUALIFIER:
    case SeNT_UNSET:
    default:
        return false;  // leaf node, system not found
    }
}

// Make a list of all systems used in all system definitions
//
//   Arguments: none
//
//   Returns: array of integers, each representing a system definition
//            -2: type, library function or environment variable (ignore)
//            -1: system definition is not defined (ignore)
//             0: system not used (i.e. top level system)
//             N: system used N times by other systems
//
//   Note: integer array returned must be deleted by caller

int *SeWrapper::sysFindUsed(void)
{
    int *used = new int[NmSize(&SeSystems)];

    // initialized used count array
    for (int i = 0; i < NmSize(&SeSystems); i++) {
        if (i < SeSyDStart) {
            used[i] = -2;
        } else if (NmName(i, &SeSystems) == NULL) {
            used[i] = -1;
        } else {
            used[i] = 0;
        }
    }

    // go through each system and check if system is used
    for (int i = SeSyDStart; i < NmSize(&SeSystems); i++) {
        if (used >= 0 && SeDataSystem[i] != NULL) {
            sysFindUsed(SeDataSystem[i]->sysdef, used);
        }
    }
    return used;
}

// Count systems used in expression
void SeWrapper::sysFindUsed(SeSysDef *sysdefp, int *used)
{
    SeArgExp *np;

    switch (sysdefp->type) {
    case SeNT_QUALSYS:
    case SeNT_SYSNAME:
        used[sysdefp->c.index]++;
        break;

    case SeNT_FNCALL:
        DqEACH(sysdefp->f.argexps, np, SeArgExp) {
            sysFindUsed(np->expp, used);
        }
        break;

    case SeNT_MULTOCC:
        // FALL THRU
    case SeNT_EXPR:
    case SeNT_NOT:
    case SeNT_ANOT:
    case SeNT_ABS:
    case SeNT_BOOL:
        sysFindUsed(sysdefp->o.rhsp, used);

    case SeNT_LIST:
    case SeNT_AND:
    case SeNT_XOR:
    case SeNT_OR:
    case SeNT_MIN:
    case SeNT_MAX:
    case SeNT_SUM:
    case SeNT_DIFF:
    case SeNT_PROD:
    case SeNT_QUOT:
    case SeNT_LT:
    case SeNT_GT:
    case SeNT_LTEQ:  // 11-05-05 ch3: missed operator
    case SeNT_GTEQ:  // 11-05-05 ch3: missed operator
    case SeNT_RUNIF:
    case SeNT_RNORM:
    case SeNT_MOFN:
    case SeNT_PKD:
    case SeNT_ORCA:
    case SeNT_EVAL:
    case SeNT_QUALOP:
        sysFindUsed(sysdefp->o.lhsp, used);
        sysFindUsed(sysdefp->o.rhsp, used);

    case SeNT_QUALIST:
    case SeNT_LISTNAME:
    case SeNT_QUALCOMP:
    case SeNT_COMPNAME:
    case SeNT_CONSTANT:
    case SeNT_PARAM:
    case SeNT_CQUALIFIER:
    case SeNT_UNSET:
    default:
        break;  // leaf node
    }
}

// Return list of names of all known user systems that are undefined
QStringList SeWrapper::sysUndefinedSystemList(void)
{
    QStringList sl;
    for (int i = SeSyDStart; i < NmSize(&SeSystems); i++) {
        const char *name;
        if ((name = NmName(i, &SeSystems)) != NULL && SeDataSystem[i] == NULL) {
            sl.append(name);
        }
    }
    return QStringList(sl);
}


//************************************//
//  USER INTERFACE RELATED FUNCTIONS  //
//************************************//
// These function directly interface with user interface
// and may need to be modified dependent on the design of the used interface


// Open a file an parse it
// This should emit newSystems(QStringList) with a list of systems discovered
void SeWrapper::sysDefOpenFile(const QString &fileName)
{
    if (!SeSysReadFile(priv->vars, qPrintable(fileName))) {
        // need to report error here
        ErLog("ERROR: %s\n", priv->vars->errmsg);  // temporary FIXME
        return;  // FIXME for now just return
    }

    sysEmitUserSystemList();
}

// Parse a single string
// This needs to emit newSystems(QStringList) with a list of systems discovered
// (as in defined or merely referred to)
void SeWrapper::sysDefParseString(QString systemDefinition)
{
    char *sysdef = DmStrDup(qPrintable(systemDefinition));
    if (!SeSysAdd(priv->vars, sysdef)) {
        // temporary FIXME (error needs to be reported in GUI
        ErLog("ERROR: %s\n", priv->vars->errmsg);
    } else { // emit all currently known systems
        sysEmitUserSystemList();
    }
    DmFree(sysdef);
}

// Return list of names of all known user systems
void SeWrapper::sysEmitUserSystemList(void)
{
    QStringList sl;
    for (int i = SeSyDStart; i < NmSize(&SeSystems); i++) {
        const char *name;
        if ((name = NmName(i, &SeSystems)) != NULL) {
            sl.append(name);
        }
    }
    emit newSystems(sl);
}

// Add a list of components (replacing undefined systems)
void SeWrapper::addComponents(const QStringList &names)
{
    QString errmsg;
    for (int i = 0; i < names.size(); i++) {
        if (sysReplaceWithComp(names.at(i), errmsg)) {
            // now delete name from system list widget
            emit removeSystem(names.at(i));
        } else {
            // report error
            // FIXME temporary (report to gui)
            fprintf(stderr, "ERROR: %s\n", qPrintable(errmsg));
        }
    }
}

// Delete system currently selected
void SeWrapper::deleteSystem(void)
{
    QString errmsg;

    if (current_system == -1) {
        errmsg.append("No system selected for deleting");
    } else {
        QStringList removed_names;

        if (deleteSystem(QString(NmName(current_system, &SeSystems)),
                         removed_names, errmsg)) {
            // remove deleted names from system list widget
            for (int i = 0; i < removed_names.size(); i++) {
                emit removeSystem(removed_names.at(i));
            }
            current_system = -1;  /* reset selected system */
            return;
        }
    }

    // report error
    // FIXME temporary (report to gui)
    fprintf(stderr, "ERROR: %s\n", qPrintable(errmsg));
}

// Make currently selected system a component
// if system is not currently defined with an expression
void SeWrapper::makeComponent(void)
{
    QString errmsg;

    if (current_system == -1) {
        errmsg.append("No system selected for changing to component");
    } else {
        QString name(NmName(current_system, &SeSystems));
        if (sysReplaceWithComp(name, errmsg)) {
            // now delete name from system list widget
            emit removeSystem(name);
            return;
        }
    }

    // report error
    // FIXME temporary (report to gui)
    fprintf(stderr, "ERROR: %s\n", qPrintable(errmsg));
}

