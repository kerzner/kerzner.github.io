#ifndef SE_STRUCT_H
#define SE_STRUCT_H

/**
 * 	This file defines the data structures used by SeWrapper for the interval
 *  generation process.
 *
 *  -Jeff Amstutz (June 2012)
 *      --revised ( May 2013)
 *      --revised ( Nov 2013)
**/


struct SeInterval {
    int   compIndex;    // component index of segment
    float entryZ;       // z-value from view of entry point
    float exitZ;        // z value from fiew of exit point
    float exitN[3];     // exit normal
    float obliq;        // obliquity angle of segment into component
    int   next;         // index of next interval
};

struct SePoint {
    int x;				// x-coordinate
    int y;				// y-coordinate
};

typedef struct { //-->C style syntax for Rayforce trace code
    float org[3];            // origin of the shotline
    float dir[3];            // direction of the shotline
    int   intervalHeadIndex; // index of first interval
    //  for this shotline
    int   evalID;            // evaluation pixel value
    int   subID;             // sub-evaluation ID
    //  (spall, casing frags, etc...)
    int	  next;	             // index of next shotline
} SeShotline;

struct SeDebrisParam {
    int   nFrags;       // # frags generated at 1 km/s
    float pf;           // pen fraction
    float ha_min;       // hole area
    float ha_max;
    float ca_50;        // cone angle
    float ca_95;
    float ca_max;
    float sf_min;       // shape factor
    float sf_max;
    float da;           // deflection angle
};

struct SeSpallPacket {
    float exit[3];      // spall exit point (where event occurs)
    float normal[3];    // normal of the spall exit surface
    float dir[3];       // direction of the spalling threat
    float pen_density;  // material density of penetrator
    float pen_bhn;      // hardness of penetrator
    int   pen_mat_id;   // material id of penetrator
    float sp_density;   // material density of spalling component
    float sp_bhn;       // hardness of spalling component
    int   sp_mat_id;    // material id of spalling component
    float v_max;        // velocity max
    int   paramID;      // spall parameter ID
    int   evalID;       // evaluation ID
};

struct SeDetonationPoint {
    float org[3];   // munition origin
    float dir[3];   // munition orientation
    //TODO: add velocity
};

#ifdef __cplusplus
namespace Vulnerability
{
#endif

struct Evaluation {
    struct SePoint pixel;             // evaluation pixel x,y
    float          org[3];            // origin of the evaluation
    float          dir[3];            // direction of the evaluation
    float          pk;                // pk value of the evaluation
    int            shotlineHeadIndex; // head index of shotline list
    int 		   nShotlines;		  // number of shotlines
};

#ifdef __cplusplus
}
#endif

#endif // SE_STRUCT_H
