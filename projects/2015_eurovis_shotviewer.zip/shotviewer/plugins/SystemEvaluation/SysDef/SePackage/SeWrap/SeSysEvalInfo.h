#ifndef SESYSEVALINFO_H
#define SESYSEVALINFO_H

#include <QVector>
#include <QString>

extern "C" {
#include "Se.h"
}
#include "SeEvaluation.h"


struct SeLockedSystem {
    int index;
    SeValue value;
};

struct SeSysEvalInfo {  // SeDevice, SeWrapper
    int topIndex;                           // top system index (-1 if none)
    QString topName;                        // top system name

    int compCount;                          // number of evaluation components
    QVector<int> compEvalStart;             // start of evaluation entries array
    QVector<SeCompEvalData> compEvalData;   // component evaluation data array
    QByteArray evalTableBuffer;             // evaluation table data array

    int count;                              // number of evaluation systems
    QVector<int> index;                     // system index translation table

    QVector<int> code;                      // total evaluation code array
    int stackSize;                          // stack size needed for code
    int frameSize;                          // frame size needed for code

    QVector<SeLockedSystem> locked;         // locked systems array

    int compTotalCount(void) const {        // total number of components
        return compEvalStart.count() - 1;
    }

    int totalCount(void) const {            // total number of systems
        return index.count();
    }

    // function to set host locked system types and values
    //   - this function is only for host evaluation
    void setLockedSystemStates(QVector<qint8> &sysTypes,
                               QVector<float> &sysValues) {
        for (int i = 0; i < locked.size(); i++) {
            int index = locked.at(i).index;
            sysTypes[index] = locked.at(i).value.type;
            sysValues[index] = locked.at(i).value.value;
        }
    }
};

#endif // SESYSEVALINFO_H
