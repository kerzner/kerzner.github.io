/****************************************************************************
** Meta object code from reading C++ file 'SeWrapper.h'
**
** Created: Tue Mar 11 10:39:13 2014
**      by: The Qt Meta Object Compiler version 63 (Qt 4.8.1)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "SeWrapper.h"
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'SeWrapper.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 63
#error "This file was generated using the moc from 4.8.1. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
static const uint qt_meta_data_SeWrapper[] = {

// content:
    6,       // revision
    0,       // classname
    0,    0, // classinfo
    20,   14, // methods
    0,    0, // properties
    0,    0, // enums/sets
    0,    0, // constructors
    0,       // flags
    16,       // signalCount

// signals: signature, parameters, type, tag, flags
    11,   10,   10,   10, 0x05,
    32,   10,   10,   10, 0x05,
    60,   10,   10,   10, 0x05,
    87,   10,   10,   10, 0x05,
    115,  113,   10,   10, 0x05,
    149,   10,   10,   10, 0x05,
    181,  113,   10,   10, 0x05,
    207,   10,   10,   10, 0x05,
    225,   10,   10,   10, 0x05,
    268,  265,   10,   10, 0x05,
    303,  113,   10,   10, 0x05,
    335,  113,   10,   10, 0x05,
    371,  366,   10,   10, 0x05,
    422,  265,   10,   10, 0x05,
    469,  265,   10,   10, 0x05,
    516,   10,   10,   10, 0x05,

// slots: signature, parameters, type, tag, flags
    551,  542,  537,   10, 0x0a,
    586,  581,  537,   10, 0x2a,
    611,   10,   10,   10, 0x0a,
    644,  636,   10,   10, 0x0a,

    0        // eod
};

static const char qt_meta_stringdata_SeWrapper[] = {
    "SeWrapper\0\0wrapperInitialized()\0"
    "componentAllValuesCleared()\0"
    "componentValueChanged(int)\0"
    "deletedComponent(QString)\0,\0"
    "deletedDefinedSystem(int,QString)\0"
    "deletedUndefinedSystem(QString)\0"
    "newComponent(QString,int)\0clearComponents()\0"
    "newDefinedSystem(QList<SeTreeNodeInfo>)\0"
    ",,\0newDefinedSystem(int,QString,bool)\0"
    "newUndefinedSystem(QString,int)\0"
    "systemNameChanged(int,QString)\0,,,,\0"
    "systemValueChanged(QString,int,int,SeTypeID,float)\0"
    "undefinedSystemIsNowComponent(QString,int,int)\0"
    "componentIsNowUndefinedSystem(QString,int,int)\0"
    "sysEvalInfoChanged()\0bool\0name,ptr\0"
    "componentCreate(QString,int*)\0name\0"
    "componentCreate(QString)\0"
    "componentValueClearAll()\0mmScale\0"
    "setGeomMMScale(float)\0"
};

void SeWrapper::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        Q_ASSERT(staticMetaObject.cast(_o));
        SeWrapper *_t = static_cast<SeWrapper *>(_o);
        switch (_id) {
        case 0:
            _t->wrapperInitialized();
            break;
        case 1:
            _t->componentAllValuesCleared();
            break;
        case 2:
            _t->componentValueChanged((*reinterpret_cast< int(*)>(_a[1])));
            break;
        case 3:
            _t->deletedComponent((*reinterpret_cast< QString(*)>(_a[1])));
            break;
        case 4:
            _t->deletedDefinedSystem((*reinterpret_cast< int(*)>(_a[1])),(*reinterpret_cast< QString(*)>(_a[2])));
            break;
        case 5:
            _t->deletedUndefinedSystem((*reinterpret_cast< QString(*)>(_a[1])));
            break;
        case 6:
            _t->newComponent((*reinterpret_cast< QString(*)>(_a[1])),(*reinterpret_cast< int(*)>(_a[2])));
            break;
        case 7:
            _t->clearComponents();
            break;
        case 8:
            _t->newDefinedSystem((*reinterpret_cast< QList<SeTreeNodeInfo>(*)>(_a[1])));
            break;
        case 9:
            _t->newDefinedSystem((*reinterpret_cast< int(*)>(_a[1])),(*reinterpret_cast< QString(*)>(_a[2])),(*reinterpret_cast< bool(*)>(_a[3])));
            break;
        case 10:
            _t->newUndefinedSystem((*reinterpret_cast< QString(*)>(_a[1])),(*reinterpret_cast< int(*)>(_a[2])));
            break;
        case 11:
            _t->systemNameChanged((*reinterpret_cast< int(*)>(_a[1])),(*reinterpret_cast< QString(*)>(_a[2])));
            break;
        case 12:
            _t->systemValueChanged((*reinterpret_cast< QString(*)>(_a[1])),(*reinterpret_cast< int(*)>(_a[2])),(*reinterpret_cast< int(*)>(_a[3])),(*reinterpret_cast< SeTypeID(*)>(_a[4])),(*reinterpret_cast< float(*)>(_a[5])));
            break;
        case 13:
            _t->undefinedSystemIsNowComponent((*reinterpret_cast< QString(*)>(_a[1])),(*reinterpret_cast< int(*)>(_a[2])),(*reinterpret_cast< int(*)>(_a[3])));
            break;
        case 14:
            _t->componentIsNowUndefinedSystem((*reinterpret_cast< QString(*)>(_a[1])),(*reinterpret_cast< int(*)>(_a[2])),(*reinterpret_cast< int(*)>(_a[3])));
            break;
        case 15:
            _t->sysEvalInfoChanged();
            break;
        case 16: {
            bool _r = _t->componentCreate((*reinterpret_cast< const QString(*)>(_a[1])),(*reinterpret_cast< int*(*)>(_a[2])));
            if (_a[0]) *reinterpret_cast< bool*>(_a[0]) = _r;
        }
        break;
        case 17: {
            bool _r = _t->componentCreate((*reinterpret_cast< const QString(*)>(_a[1])));
            if (_a[0]) *reinterpret_cast< bool*>(_a[0]) = _r;
        }
        break;
        case 18:
            _t->componentValueClearAll();
            break;
        case 19:
            _t->setGeomMMScale((*reinterpret_cast< float(*)>(_a[1])));
            break;
        default:
            ;
        }
    }
}

const QMetaObjectExtraData SeWrapper::staticMetaObjectExtraData = {
    0,  qt_static_metacall
};

const QMetaObject SeWrapper::staticMetaObject = {
    {
        &QObject::staticMetaObject, qt_meta_stringdata_SeWrapper,
        qt_meta_data_SeWrapper, &staticMetaObjectExtraData
    }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &SeWrapper::getStaticMetaObject()
{
    return staticMetaObject;
}
#endif //Q_NO_DATA_RELOCATION

const QMetaObject *SeWrapper::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->metaObject : &staticMetaObject;
}

void *SeWrapper::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_SeWrapper))
        return static_cast<void*>(const_cast< SeWrapper*>(this));
    return QObject::qt_metacast(_clname);
}

int SeWrapper::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QObject::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 20)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 20;
    }
    return _id;
}

// SIGNAL 0
void SeWrapper::wrapperInitialized()
{
    QMetaObject::activate(this, &staticMetaObject, 0, 0);
}

// SIGNAL 1
void SeWrapper::componentAllValuesCleared()
{
    QMetaObject::activate(this, &staticMetaObject, 1, 0);
}

// SIGNAL 2
void SeWrapper::componentValueChanged(int _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 2, _a);
}

// SIGNAL 3
void SeWrapper::deletedComponent(QString _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 3, _a);
}

// SIGNAL 4
void SeWrapper::deletedDefinedSystem(int _t1, QString _t2)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)), const_cast<void*>(reinterpret_cast<const void*>(&_t2)) };
    QMetaObject::activate(this, &staticMetaObject, 4, _a);
}

// SIGNAL 5
void SeWrapper::deletedUndefinedSystem(QString _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 5, _a);
}

// SIGNAL 6
void SeWrapper::newComponent(QString _t1, int _t2)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)), const_cast<void*>(reinterpret_cast<const void*>(&_t2)) };
    QMetaObject::activate(this, &staticMetaObject, 6, _a);
}

// SIGNAL 7
void SeWrapper::clearComponents()
{
    QMetaObject::activate(this, &staticMetaObject, 7, 0);
}

// SIGNAL 8
void SeWrapper::newDefinedSystem(QList<SeTreeNodeInfo> _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 8, _a);
}

// SIGNAL 9
void SeWrapper::newDefinedSystem(int _t1, QString _t2, bool _t3)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)), const_cast<void*>(reinterpret_cast<const void*>(&_t2)), const_cast<void*>(reinterpret_cast<const void*>(&_t3)) };
    QMetaObject::activate(this, &staticMetaObject, 9, _a);
}

// SIGNAL 10
void SeWrapper::newUndefinedSystem(QString _t1, int _t2)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)), const_cast<void*>(reinterpret_cast<const void*>(&_t2)) };
    QMetaObject::activate(this, &staticMetaObject, 10, _a);
}

// SIGNAL 11
void SeWrapper::systemNameChanged(int _t1, QString _t2)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)), const_cast<void*>(reinterpret_cast<const void*>(&_t2)) };
    QMetaObject::activate(this, &staticMetaObject, 11, _a);
}

// SIGNAL 12
void SeWrapper::systemValueChanged(QString _t1, int _t2, int _t3, SeTypeID _t4, float _t5)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)), const_cast<void*>(reinterpret_cast<const void*>(&_t2)), const_cast<void*>(reinterpret_cast<const void*>(&_t3)), const_cast<void*>(reinterpret_cast<const void*>(&_t4)), const_cast<void*>(reinterpret_cast<const void*>(&_t5)) };
    QMetaObject::activate(this, &staticMetaObject, 12, _a);
}

// SIGNAL 13
void SeWrapper::undefinedSystemIsNowComponent(QString _t1, int _t2, int _t3)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)), const_cast<void*>(reinterpret_cast<const void*>(&_t2)), const_cast<void*>(reinterpret_cast<const void*>(&_t3)) };
    QMetaObject::activate(this, &staticMetaObject, 13, _a);
}

// SIGNAL 14
void SeWrapper::componentIsNowUndefinedSystem(QString _t1, int _t2, int _t3)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)), const_cast<void*>(reinterpret_cast<const void*>(&_t2)), const_cast<void*>(reinterpret_cast<const void*>(&_t3)) };
    QMetaObject::activate(this, &staticMetaObject, 14, _a);
}

// SIGNAL 15
void SeWrapper::sysEvalInfoChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 15, 0);
}
QT_END_MOC_NAMESPACE
