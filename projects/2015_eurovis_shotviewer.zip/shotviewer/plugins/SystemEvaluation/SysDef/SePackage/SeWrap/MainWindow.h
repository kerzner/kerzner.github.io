// vim:smarttab expandtab sw=4
#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>

namespace Ui
{
class MainWindow;
}
class SeWrapper;
class QListWidgetItem;

class MainWindow : public QMainWindow
{
    Q_OBJECT
public:
    MainWindow(QWidget *parent = 0);
    ~MainWindow();

protected:
    void changeEvent(QEvent *e);

private slots:
    void on_actionOpen_triggered();
    void compileDefinition();
    void addSystems(QStringList);
    void itemClicked(QListWidgetItem *);
    void deleteDefinition();
    void componentDefinition();
    void removeSystem(QString);

private:
    void settingsRead();
    void settingsWrite();


    Ui::MainWindow *ui;
    SeWrapper *seWrapper;
    QString m_lastDir;


};

#endif // MAINWINDOW_H
