// vim:smarttab expandtab sw=4
#include "MainWindow.h"
#include "ui_MainWindow.h"
#include <QSettings>
#include <QFile>
#include <QFileDialog>
#include <QFileInfo>
#include <QListWidgetItem>
#include "SeWrapper.h"

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow),
    seWrapper(new SeWrapper(this))
{
    ui->setupUi(this);
    // When new system(s) are parsed, add it to the listWidget
    connect(seWrapper, SIGNAL(newSystems(QStringList)),
            this,      SLOT(addSystems(QStringList)));

    connect(seWrapper, SIGNAL(removeSystem(QString)),
            this,      SLOT(removeSystem(QString)));

    // When user clicks compile, try to parse the buffer
    connect(ui->compileButton, SIGNAL(clicked()),
            this,              SLOT(compileDefinition()));

    // When user clicks delete, try to delete the system
    connect(ui->deleteButton, SIGNAL(clicked()),
            this,             SLOT(deleteDefinition()));

    // When user clicks component, try to change system to component
    connect(ui->componentButton, SIGNAL(clicked()),
            this,                SLOT(componentDefinition()));

    // When an Item is clicked in the list, display the definition
    connect(ui->systemListWidget, SIGNAL(itemClicked(QListWidgetItem*)),
            this,                 SLOT(itemClicked(QListWidgetItem*)));
}

MainWindow::~MainWindow()
{
    delete ui;
    delete seWrapper;
}

void MainWindow::changeEvent(QEvent *e)
{
    QMainWindow::changeEvent(e);
    switch (e->type()) {
    case QEvent::LanguageChange:
        ui->retranslateUi(this);
        break;
    default:
        break;
    }
}

// When new system(s) are parsed, add it to the listWidget
void MainWindow::addSystems(QStringList names)
{
    foreach (QString name, names) {
        QList<QListWidgetItem *> item = ui->systemListWidget->findItems(name,
                                        Qt::MatchFixedString|Qt::MatchCaseSensitive);

        if (item.length() == 0) {
            ui->systemListWidget->addItem(name);
        }
    }
}


// When user clicks compile, try to parse the buffer
void MainWindow::compileDefinition()
{
    seWrapper->sysDefParseString(ui->sysDefEditor->toPlainText());
}

// When user clicks delete, try to delete the system
void MainWindow::deleteDefinition()
{
    // get the name of the system to be deleted

    seWrapper->deleteSystem();


}

// When user clicks component, try to change system to component
void MainWindow::componentDefinition()
{
    seWrapper->makeComponent();
}

// When an Item is clicked in the list, display the definition
void MainWindow::itemClicked(QListWidgetItem *i)
{
    ui->sysDefEditor->document()->setPlainText(
        seWrapper->getSystem(i->text()));
}

// Load persistent settings
void MainWindow::settingsRead()
{
    QSettings settings("Army Research Laboratory", qApp->applicationName());
    m_lastDir = settings.value("lastDirectory").toString();
}

// Save persistent settings
void MainWindow::settingsWrite()
{
    QSettings settings("Army Research Laboratory", qApp->applicationName());
    settings.setValue("lastDirectory", m_lastDir);
}

// User wants to open a file
void MainWindow::on_actionOpen_triggered()
{
    // As for the file name
    QString fileName = QFileDialog::getOpenFileName(this, "open file",
                       m_lastDir, QString("*.vsl *.wrl *.osg *.mat *.ive *.obj *.sysdef "
                                          "*.txt"));
    if (fileName.isEmpty()) {
        ui->statusBar->showMessage("File Open cancelled");
        qApp->beep();
        return;
    }

    // Make sure file exists
    QFileInfo fileInfo(fileName);
    if(! fileInfo.exists()) {
        ui->statusBar->showMessage(QString("File Does Not Exist"));
        return;
    }

    ui->statusBar->showMessage(QString("Loading File " + fileInfo.fileName()
                                       + "..."));
    QString canonicalFilePath = fileInfo.canonicalFilePath();
    m_lastDir = fileInfo.absoluteDir().absolutePath();

    // Open the file
    seWrapper->sysDefOpenFile(fileName);
}
void MainWindow::removeSystem(QString name)
{
    QList<QListWidgetItem *>items = ui->systemListWidget->findItems(name,
                                    Qt::MatchExactly);

    fprintf(stderr, "deleting %s %d\n", qPrintable(name),
            items.length());
    foreach (QListWidgetItem *i, items) {
        int row = ui->systemListWidget->row(i);
        QListWidgetItem *takenItem = ui->systemListWidget->takeItem(row);

        if (i == takenItem) {
            fprintf(stderr, "yes it is\n");
        } else {
            fprintf(stderr, "no it is not\n");
        }

        delete takenItem;

    }

}
