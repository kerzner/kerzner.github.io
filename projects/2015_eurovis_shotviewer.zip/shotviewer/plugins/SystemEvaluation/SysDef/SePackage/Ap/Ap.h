/**
	<Ap.h> -- MUVES "Ap" (analysis parameters) package definitions
**/
/*
	created:	87/10/08	Jeff Hanes
	edited:		03/05/09	Cletus Hunt
			added 'mod' and 'confidence' keywords
			(changes made by SURVICE for AJEM)
	edited:		05/10/07	Cletus Hunt
			added prototype for new function ApIndirectFire()
			(AJEM SCR493)
	edited:		06/09/25	Cletus Hunt
			added salvo related key string definitions (SCR539)
	edited:		07/05/03	Cletus Hunt
			added additional salvo related "elevation" and
			"no_intermediate" key string definitions (SCR854)
	edited:		07/06/05	Cletus Hunt
			added additional salvo related "averages_only" key
			string definition (SCR854)
	edited:		07/07/10	Geoff Sauerborn
			added Information Security related protypes (SCR951)
			ApStIsClassificationFileName() - set (store) filename
			ApGetIsClassificationFileName() - get filename
	edited:		09/04/24	Cletus Hunt
			added function prototype for new function
			ApSetEnvVarValue() (SCR1215)

	RCSid:		$Id: Ap.h,v 1.43 2010/06/23 19:54:44 geoffs Exp $
 */
/**
	The "Ap" package acts as a "clearing house" for the details
	of an analysis.  The parent function calls ApRead(), which
	reads the analysis parameters file and stores the
	information it finds into local memory.  It reads until it
	encounters the ApK_ANALYZE keyword or end-of-file, then it
	returns to the parent function. It returns a "true" if there
	is more information to be read and "false" if it came to the
	end of the file or detected a fatal error.  ApRead() does
	not return any analysis parameters to the parent function;
	that function is reserved for other "Ap" package routines.

	The analysis parameters file is a text file which contains
	the user's commands.  The commands are in the form of
	keywords, indicating which value is defined, followed by one
	or more strings.  These strings may consist of numeric or
	alphabetic values depending on the type of information
	needed to define a particular command.

	In order for controlling functions in the process to obtain
	information from the "Ap" package, they must call the
	delivery functions. These comprise the majority of the "Ap"
	package.  Each one is designed to return the value, string
	or structure required for a particular command.  For
	instance, ApShots() returns a pointer to a queue of one or
	more shot structures, each of which may have a shot pattern
	attached, while ApTarget() returns the name of the target
	to be used in the current analysis.  All of these functions
	are defined below.

	Some of the functions may contain more than one set of
	values; this is indicated in the description of the
	function. These functions maintain the parameters in
	internal lists using the "Dq" package software.  These lists
	are produced when the same keyword is invoked more than
	once before an ApK_ANALYZE command.  They are automatically
	removed when a new set of parameters is read for the next
	analysis.

	In order to access the different sets of parameters within a
	particular queue, there are three defined constants one may
	use as arguments to the "Ap" functions.  They are ApCURRENT,
	ApNEXT, and ApRESET.  These will cause the delivery function
	to return the parameters at the current location in the
	list, move to the next location in the list, or move to the
	first location in the list.  If no value is provided to a
	delivery function, it will return a NULL value.  If a delivery
	function is called with ApNEXT, and the current location is
	already the end of the list, NULL will be returned and the
	current pointer will remain unchanged, that is, left on the
	last entry.

	When ApRead() sees the ApK_ANALYZE keyword, it returns to the
	calling function, indicating that it should compute results
	with the current parameters.  Before it reads the next set
	of parameters, ApRead() will completely clear the previous
	set.  Thus, all of the desired parameters must be included
	before each separate ApK_ANALYZE command in the session file.

	The package can also read from standard input rather than
	from a file.  This permits the User Interface to send
	instructions directly to the analysis process rather than
	routing them through the UNIX file system.


	The following is a list of the keywords recognized by the
	"Ap" package and the associated parameters:

	keyword		    | parameter(s)
	--------------------------------------------------

	ApK_TITLE	    |  (string) title for session
	ApK_ANALYZE	    |  (file path name) final results file
			    |  (file path name) session file

	ApK_TARGET	    |  (file path name) target name
	ApK_CMPROP	    |  (file path name) component property file
	ApK_MTPROP	    |  (file path name) material property file
	ApK_PARAMS	    |  (file path name) parameters file
	ApK_PACK	    |  (file name) armor packages file
	ApK_CATMAP	    |  (file path name) component category map
	ApK_SYSEXP	    |  (file path name) system definition expressions
	ApK_STATES	    |  (file path name) state vector lists
	ApK_DAMSEL	    |  (file path name) damage evaluation selection
	ApK_IFMSEL	    |  (file path name) indirect-fire module selection
	ApK_THREAT	    |  (file path name) threat initial parameters
	    <ApK_RANGE>	    |  (real) range value

	ApK_VECTOR	    |  (string) state vector name

	ApK_APPROX	    |  (string) name of approximation method

	ApK_GROUP	    |  (string) label
	ApK_ENDGROUP

	ApK_SHOT
	    ApK_AZEL	    |  (real) azimuth
			    |  (real) elevation
	 OR ApK_DIRECTION   |  (real) X component
			    |  (real) Y component
			    |  (real) Z component
	   < ApK_XYZ	    |  (real) X coordinate
			    |  (real) Y coordinate
			    |  (real) Z coordinate
	  OR ApK_HV >	    |  (real) horizontal offset
			    |  (real) vertical offset
	ApK_BURST
	    ApK_ORIGIN	    |  (real) X coordinate
			    |  (real) Y coordinate
			    |  (real) Z coordinate
	    ApK_DIRECTION   |  (real) X component
			    |  (real) Y component
			    |  (real) Z component
	ApK_SALVO             |  (int) number of iterations
	    < ApK_AIMPOINT    |  (real) X coordinate
			      |  (real) Y coordinate
			      |  (real) Z coordinate
	  OR ApK_AUTOAIMPT    |
	  OR ApK_RANDAIMPT >  |
	    ApK_ALTITUDE      |  (real) minimum altitude
	                      | < (real) maximum altitude
			      |  (real) step altitude >
	    ApK_SLANTRANGE    |  (real) minimum slant_range
	                      | < (real) maximum slant_range
			      |  (real) step slant_range >
	    ApK_AZIMUTH       |  (real) minimum azimuth
	                      | < (real) maximum azimuth
			      |  (real) step azimuth >
	  < ApK_BURSTS 	      |  (int) required number of bursts >
	  < ApK_INTBURST >    |
	    ApK_ROUNDS 	      |  (int) required number of rounds
	  < ApK_INTROUND >    |
	  < ApK_DBGMODE >     |
	  < ApK_SEED 	      |  (int) random seed value >

	The GRID, GAUSS, UNIFORM, UNCIRCLE and UNSPHERE keywords can
	follow either SHOT or BURST commands to specify a pattern of
	shots or burst points.  All but UNSPHERE and DELTA_ELEV
	describe distributions of points within a plane perpendicular
	to the specified direction and containing the specified point
	as the origin of the grid or distribution.  The UNSPHERE
	pattern is a uniform distribution of points lying on the
	surface of a sphere of a given radius. The DELTA_ELEV pattern
	is a distribution of points on a plane with directions
	originating from a single point or line parallel to the plane.

	ApK_GRID
	    ApK_ENVELOPE    |  (string) type of envelope
	      ApK_BOX       |  (vector) minima of bounding box
			    |  (vector) maxima of bounding box
	      ApK_SINGLE    |
	      ApK_MULTIPLE  |
	    ApK_CELLSIZE    |  (real) horizontal cell size
			    |  (real) vertical cell size
	    <ApK_EXTENT>    |  (int) number of horizontal points
			    |  (int) number of vertical points
	    <ApK_RANDOM>
	    <ApK_SEED>	    |  (long) random seed

	ApK_GAUSS	    |  (int) number of desired points
	    ApK_SIGMA	    |  (real) horizontal standard deviation
			    |  (real) vertical standard deviation
	    <ApK_SEED>	    |  (long) random seed

	ApK_UNIFORM	    |  (int) number of desired points
	    ApK_UNI_RANGE   |  (real) horizontal range
			    |  (real) vertical range
	    <ApK_SEED>	    |  (long) random seed

	ApK_UNCIRCLE	    |  (int) number of desired points
	    ApK_UNI_RADIUS  |  (real) radius of circle
	    <ApK_SEED>	    |  (long) random seed

	ApK_UNSPHERE
	    <ApK_FINENESS>  |  (real) fineness of coverage
			    |  (real) diameter of coverage

	    <ApK_NUMPTS>    |  (int) number of points desired

	    <ApK_DISTANCE>  |  (real) distance between rays

	    <ApK_RANDOM>
	    <ApK_SEED>	    |  (long) random seed

	ApK_DELTA_ELEV
	  < ApK_ORIGIN	    |  (real) X coordinate
			    |  (real) Y coordinate
			    |  (real) Z coordinate
	 OR ApK_XYZ >       |  (real) X coordinate
			    |  (real) Y coordinate
			    |  (real) Z coordinate
	    <ApK_DELTA_AZIM>|  (real) angle offset
	    <ApK_CELLSIZE>  |  (real) horizontal cell size
			    |  (real) vertical cell size
	    <ApK_EXTENT>    |  (int) number of horizontal points
			    |  (int) number of vertical points
	    <ApK_RANDOM>
	    <ApK_SEED>	    |  (long) random seed(s)

	ApK_VIEWFILE	    |  (file path name) shot pattern (view) file

	ApK_UNITS	    |  (string) unit of length for shot specification
	ApK_ERRORS	    |  (file path name) error log file name
	ApK_IRESULT	    |  (file path name) intermediate results destination
	ApK_AUDIT	    |  (file path name) audit sheet file name
	ApK_REUSRA	    |  (file path name) re-useable ray file name
	ApK_SEED	    |  (optional int) seed value for random generator
			       (no argument indicates random seed)

	ApK_ENVFILE         |  (string) environment variable file
	ApK_ENV		    |  (string) environment variable name
			    |  (string) associated value
			    |  (string) associated units of measure

	ApK_MODKEY	    |  (string) interaction module keyword
			    |  (string) associated value

	ApK_ICURVE	    |  (file path name) interaction module data
	ApK_ECURVE	    |  (file path name) evaluation module data
	ApK_FCURVE	    |  (file path name) indirect-fire module data

        ApK_MOD             |  (thrtname { keyword = value })
			       modification to threat inputs
        ApK_CONFIDENCE      |  (stvect member value) set a state vector
			       confidence limit

	The following are used exclusively by stochastic methods:

	ApK_CLUSTER	    |  <any valid pattern specification>
	ApK_LIMITS	    |  (string) parameter to limit
			    |  (int) maximum value

**/

/* Legal names for Ap package key words. */
#define ApK_ANALYZE  "analyze"
#define ApK_APPROX   "approx"
#define ApK_AUDIT    "audit"
#define ApK_BCURVE   "bcurve"
#define ApK_CATMAP   "category"     /* component category map file */
#define ApK_CLUSTER  "cluster"	    /* iterate on shot pattern (stoch only) */
#define ApK_CMPROP   "property"     /* component properties file */
#define ApK_MTPROP   "matprop"	    /* material properties file */
#define ApK_PARAMS   "params"	    /* parameters file */
#define ApK_DAMSEL   "eval"
#define ApK_ECURVE   "evaldata"     /* correlation (evaluation) curves file */
#define ApK_ENDGROUP "endgroup"     /* end of group of shots */
#define ApK_ENVFILE  "envfile"	    /* environment variable file */
#define ApK_ENV	     "env"	    /* environment variable setting */
#define ApK_ERRORS   "errors"
#define ApK_FCURVE   "ifmdata"	    /* data needed by indirect-fire modules */
#define ApK_IFMSEL   "ifmselect"    /* indirect-fire module selection file */
#define ApK_BURST    "burst"	    /* burst specification */
#define		ApK_ORIGIN   "origin"	/* target-space coordinates of burst */
#define ApK_EXPLICIT "explicit"	/* forces burst at origin  */
#define ApK_GAUSS    "gauss"	    /* gaussian distribution of shots */
#define		ApK_SIGMA    "sigma"	 /* hor. and vert. std. deviations */
#define ApK_GRID     "grid"	    /* rectangular grid specification */
#define		ApK_ENVELOPE "envelope"  /* restrict grid to an envelope */
#define		ApK_BOX      "box"       /* use box as guide */
#define		ApK_SINGLE   "single"    /* use grid that just covers components */
#define		ApK_MULTIPLE "multiple"  /* give each component a separate grid */
#define		ApK_CELLSIZE "csize"     /* cell size */
#define		ApK_EXTENT   "extent"    /* dimensions of grid */
#define		ApK_RANDOM   "random"    /* dithered cells */
#define			ApK_SEED	"seed"	/* user-specified seed */
#define ApK_GROUP    "group"	    /* begin group of shots */
#define ApK_ICURVE   "interdata"    /* interaction curves file */
#define ApK_IRESULT  "intermediate" /* intermediate results file */
#define ApK_LIMITS   "limits"       /* limits to stoch value from Mc package */
/* Acceptable string args naming stochastic value in McKeys[],
 	and description in McDescrip[]. */
#define ApK_MODKEY   "modkey"
#define ApK_REUSRA   "rayfile"      /* reusable ray file */
#define ApK_PACK     "packages"		/* armor packages file */
#define ApK_SHOT     "shot"	    /* shot specification */
#define		ApK_AZEL      "azel"      /* azimuth and elevation angles */
#define		ApK_DIRECTION "direction" /* direction cosines */
#define		ApK_HV        "hv"        /* horizontal and vertical offsets */
#define		ApK_XYZ       "xyz"       /* target-space offsets */
#define ApK_STATES   "states"	    /* state vector file */
#define ApK_SYSEXP   "system"       /* system expressions file */
#define ApK_TARGET   "target"       /* target characterization */
#define ApK_THREAT   "threat"       /* threat characterization */
#define		ApK_RANGE      "range"     /* range to target */
#define ApK_TITLE    "title"	    /* title of session */
#define ApK_UNIFORM  "uniform"	/* uniform random rectangular dist. of shots */
#define		ApK_UNI_RANGE	"range"    /* width and height of rectangle */
#define ApK_UNCIRCLE "uncircle"	/* uniform random circular dist. of shots */
#define		ApK_UNI_RADIUS	"radius"   /* radius of circle */
#define ApK_UNITS    "units"
#define ApK_UNSPHERE "unsphere"	/* uniform spherical distribution */
#define		ApK_FINENESS	"fineness"   /* fineness of coverage */
#define		ApK_NUMPTS	"numpts"    /* number of points desired */
#define		ApK_DISTANCE	"distance"   /* distance between rays */
#define ApK_VECTOR   "vector"       /* state vector name from states file */
#define ApK_VIEWFILE "viewfile"	    /* view file */
#define ApK_WORKERHOST "workerhost"	/* remote worker host machine */
#define ApK_LOCALWORKERS "localworkers" /* number of local workers */
/* 06-09-25 ch3: added salvo related types (SCR539) */
#define ApK_SALVO    "salvo"              /* salvo specification */
#define ApK_ITERATIONS  "iterations"      /* salvo iterations specification */
#define 	ApK_AUTOAIMPT  "auto_aimpoint"  /* automatic aimpoint */
#define 	ApK_RANDAIMPT  "random_aimpoint"  /* random aimpoint */
#define 	ApK_AIMPOINT  "aimpoint"  /* target aimpoint */
#define 	ApK_ALTITUDE  "altitude"  /* target altitude */
#define		ApK_SLANTRANGE "slant_range" /* slant range */
#define 	ApK_AZIMUTH    "azimuth"    /* target azimuth */
#define 	ApK_BURSTS    "bursts"    /* required number of bursts */
#define		ApK_INTBURST "intermediate_burst" /* results flag */
#define 	ApK_ROUNDS    "rounds_per_burst" /* required number of rounds */
#define		ApK_INTROUND "intermediate_round" /* results flag */
#define		ApK_DBGMODE  "debug_mode"  /* debug mode flag */
/* 07-05-03 ch3: added additional salvo related type (SCR854) */
#define 	ApK_ELEVATION  "elevation"    /* target elevation */
#define		ApK_NOINT    "no_intermediate" /* results flag */
/* 07-06-05 ch3: added additional salvo related type (SCR854) */
#define		ApK_AVGSONLY   "averages_only" /* averages_only flag */
/* 07-07-10 (SRC 951) added Information Security (Is) type */
#define ApK_INFORMATION_SECURITY "classification" /* denotes security markings file */

/* SCR 1023: Shotlines with varying AZ & EL  */
#define ApK_DELTA_ELEV "delta_elev"
#define ApK_DELTA_AZIM "delta_azim"


/* DRH: mod keywords */
#define ApK_MOD "mod"
#define ApK_CONFIDENCE "confidence"

#define ApK_MASS "mass"
#define ApK_VEL "vel"
#define ApK_SHAPEFACTOR "sfactor"

/* Pseudo keyword. */
#define ApK_COMMENT "#"

/*
XXX	?inpattern? 	"grid|gauss|uniform" ...

	to identify the viewfile input definition...

	(e.g. for generated view files, etc.)

 */
/**
	All input files specified in the analysis parameters files
	are marked for use used the MUVES "Lk" package.  Upon successful
	completion of an analysis, they are protected for archival,
	otherwise they are left in a writable state.  The application
	indicates successful completion in its argument to ApUnlock()
	and ApFree() at the end of a run.  Aside from this flag, the
	locking and file protection are invisible to the application.
**/
/*
TO BE ADDED:
	?patchfile?	|  (file path name) ray editing file
*/

#ifndef	Ap_H_INCLUDE		/* once-only latch */
#define	Ap_H_INCLUDE

#include	<Dq.h>
#include	<Nm.h>
/* #include	<Rt.h> */
#include	<Sa.h>
#include	<Vm.h>

/**
	The structures defined below are used by various functions
	in this package to return collections of related values to
	the modules that need them.


	typedef struct
		{
		char	*name;		// name of state vector
		int	index;		// number of state vector in list
		}	ApStSpec;

	The state vector specification structure contains a pointer to
	the string containing the state vector name.
**/
typedef struct {
    char	*name;
    int	index;
}	ApStSpec;

/**
	typedef struct
		{
		char	*key;		// keyword for parameter
		int	limit;		// limit value for parameter
		}	ApLimSpec;

	The limit value structure contains a pointer to the keyword
	and a value to be used for limiting the stochastic behavior.
**/
typedef struct {
    char	*key;
    int	limit;
}	ApLimSpec;

/**
	The following data structure is used to store environment variables.
	Use ApGetEnvVar() to retrieve a variables's corresponding data ptr.

	typedef struct
		{
		char *name;  // name of environment variable
		char *units; // official name for user units (ie meters/second)
		double conv; // conversion factor to user units from internal
		double val;  // user-specified value
		}
	ApT_EnvVar;
**/

typedef struct {
    char *name;  /* name of environment variable */
    char *units; /* official name for user units (ie meters/second) */
    double conv; /* conversion factor to user units from internal units */
    double val;  /* user-specified value */
}
ApT_EnvVar;

/**
	The following values should be used as arguments to the
	functions below which list "action" as their input
	arguments.  These tell the functions what to do with the
	values they have stored in their internal queues.

		ApCURRENT	-- return current value in queue
		ApNEXT		-- return next value in queue
		ApRESET		-- return first value in queue
**/
#define	ApCURRENT	0
#define	ApNEXT		1
#define	ApRESET		2


#if STD_C
extern MuvesBool	ApSetModkey( const char *name, const char *str );
extern void	ApRmModkey( void );
extern MuvesBool	ApRead( const char *PmtrFile );
extern MuvesBool	ApReadFp( FILE *fp );
#else
extern MuvesBool	ApSetModkey();
extern MuvesBool	ApRnModkey();
extern MuvesBool	ApRead();
extern MuvesBool	ApReadFp();
#endif

/* 00-04-24 ch3: added new function prototype (SCR1215) */
extern ApT_EnvVar *ApSetEnvVarValue PARAMS((const char *name, double value,
        const char *units));

extern MuvesBool 	ApReadExtra(const char *filename);

#if STD_C
extern DqNode	*ApShots( int  action );
#else
extern DqNode	*ApShots();
#endif

/* 05-10-07 ch3: added new function prototype (SCR493) */
#if STD_C
extern int	ApIndirectFire( int action );
#else
extern int	ApIndirectFire();
#endif

#if STD_C
extern int	ApNShots( void );
#else
extern int	ApNShots();
#endif


#if STD_C
extern char	*ApLabel( void );
#else
extern char	*ApLabel();
#endif

#if STD_C
extern SaPattern	*ApCluster( void );
#else
extern SaPattern	*ApCluster();
#endif

/**
	int	ApAnalysisID
	int	ApRunNumber

	"ApAnalysisID" contains an identifier for the current analysis
	session.  "ApRunNumber" contains an identifier for a particular
	analysis within the current session.  These identifiers should
	be used to differentiate between various MUVES output files in
	the same directory and to associate these results with the input
	files they depend on.  These identifiers are provided by the user
	interface and are chosen to prevent file name collisions with
	previous runs under the same project data space.
**/
extern int	ApAnalysisID;
extern int	ApRunNumber;

#if STD_C
extern char	*ApApprox( int  action );
#else
extern char	*ApApprox();
#endif

#if STD_C
extern int	ApNApprox( void );
#else
extern int	ApNApprox();
#endif

#if STD_C
extern const char	*ApTitle( void );
#else
extern char	*ApTitle();
#endif

#if STD_C
extern int	ApNVector( void );
#else
extern int	ApNVector();
#endif

// ApStSpec contains an index and a string
// Action has been defined
#if STD_C
extern ApStSpec	*ApVector( int  action );
#else
extern ApStSpec	*ApVector();
#endif

#if STD_C
extern const char	*ApInter( void );
#else
extern char		*ApInter();
#endif

#if STD_C
extern const char	*ApAudit( void );
#else
extern char		*ApAudit();
#endif

/**
	NmPool	*ApModKeys
	char	**ApModValues

	ApModKeys points to a name pool containing keywords for use
	by the interaction modules, while ApModValues is an array of
	strings containing the values attached to those keywords.
	To get a particular value, use `NmIndex()' to find the index
	of the keyword, then use ApModValues[index] to find the
	associated value.

	ApModKeys contains keywords specific to certain interaction
	modules.  By changing the values for their associated strings,
	the analyst may modify the behavior of those interaction modules
	during the course of a run.  The values are interpreted in
	various fashions in the "Im" initializing functions, depending
	on the keyword.

	The keywords and their possible values are documented with the
	interaction modules that use them.
**/

extern NmPool	*ApModKeys;
extern char	**ApModValues;

#if STD_C
extern const char	*ApRayfile( void );
#else
extern char		*ApRayfile();
#endif

#if STD_C
extern const char	*ApResults( void );
#else
extern char	*ApResults();
#endif


#if STD_C
extern char	*ApTarget( int  action );
#else
extern char	*ApTarget();
#endif

#if STD_C
extern int	ApNTarget( void );
#else
extern int	ApNTarget();
#endif

#if STD_C
extern char	*ApProperty( int  action );
#else
extern char	*ApProperty();
#endif

#if STD_C
extern int	ApNProperty( void );
#else
extern int	ApNProperty();
#endif

#if STD_C
extern char *ApMatProp( int action );
#else
extern char *ApMatProp();
#endif

#if STD_C
extern int ApNMatProp( void );
#else
extern int ApNMatProp();
#endif

#if STD_C
extern char *ApParams( int action );
#else
extern char *ApParams();
#endif

#if STD_C
extern int ApNParams( void );
#else
extern int ApNParams();
#endif

#if STD_C
extern char *ApPack( int action );
#else
extern char *ApPack();
#endif

#if STD_C
extern int ApNPacks( void );
#else
extern int ApNPacks();
#endif

#if STD_C
extern char	*ApCategory( int  action );
#else
extern char	*ApCategory();
#endif

#if STD_C
extern int	ApNCategory( void );
#else
extern int	ApNCategory();
#endif

#if STD_C
extern char	*ApSystem( int  action );
#else
extern char	*ApSystem();
#endif

#if STD_C
extern int	ApNSystem( void );
#else
extern int	ApNSystem();
#endif

#if STD_C
extern char	*ApAssess( int  action );
#else
extern char	*ApAssess();
#endif

#if STD_C
extern int	ApNAssess( void );
#else
extern int	ApNAssess();
#endif

#if STD_C
extern char	*ApEval( int  action );
#else
extern char	*ApEval();
#endif

#if STD_C
extern int	ApNEval( void );
#else
extern int	ApNEval();
#endif


#if STD_C
extern char	*ApIFMSelect( int  action );
#else
extern char	*ApIFMSelect();
#endif

#if STD_C
extern const char	*ApInCurve( void );
#else
extern const char	*ApInCurve();
#endif

#if STD_C
extern const char	*ApEvCurve( void );
#else
extern const char	*ApEvCurve();
#endif

#if STD_C
extern const char	*ApBlastCurve( void );
#else
extern const char	*ApBlastCurve();
#endif

#if STD_C
extern const char	*ApIfmCurve( void );
#else
extern const char	*ApIfmCurve();
#endif

#if STD_C
extern char	*ApThreat( int  action );
#else
extern char	*ApThreat();
#endif

#if STD_C
extern double	ApRange( void );
#else
extern double	ApRange();
#endif

#if STD_C
extern int	ApNThreat( void );
#else
extern int	ApNThreat();
#endif

MuvesBool ApSetThreat PARAMS((char *threat_name, double range));

#if STD_C
extern const ApLimSpec	*ApLimits( int action );
#else
extern const ApLimSpec	*ApLimits();
#endif

#if STD_C
extern const char	*ApUnits( void );
#else
extern const char	*ApUnits();
#endif

/*
 *  Public interface the remote host queue.
 */
int 	ApNWorkerHosts PARAMS(( void ));
char *  ApWorkerHost PARAMS(( int action ));

/*
 *  Public interface to the local worker specifications. Note that
 *  ApNLocalWorkers is NOT the number of workers requested, rather
 *  it is the number of LocalWorkers lines in the input deck.
 */
int 	ApNLocalWorkers PARAMS(( void ));
char *  ApLocalWorkers PARAMS(( int action ));

int 	ApDmuvesSession PARAMS ((char **sfn));

extern const char *ApGetModkeyValue PARAMS((const char *key));

/**
	double	ApFactor

	ApFactor contains the numerical factor required to convert
	numbers in the user's chosen system of measurement into the
	MUVES system of measurement (millimeters) and vice versa.
	This factor is applied exclusively to parameters relating to
	the shot pattern specification.

	This factor is intended for use with the Uc functions
	UcStdUnits() and UcUserUnits().
**/
#if !defined(lint) || defined(ApLINT)
extern	double	ApFactor;
#endif

#if STD_C
extern void	ApFree( MuvesBool complete );
#else
extern void	ApFree();
#endif

#if STD_C
extern void	ApUnlock( MuvesBool protect );
#else
extern void	ApUnlock();
#endif

#if STD_C
#if 0
extern ApT_EnvVar *ApEnvVars( int action )
{
    return NULL;
}
extern ApT_EnvVar *ApGetEnvVar( const char *name )
{
    return NULL;
}
#else
#define ApEnvVars(action) ((ApT_EnvVar *)NULL)
#define ApGetEnvVar(name) ((ApT_EnvVar *)NULL)
#define ApPkgInit() /* */
#endif

#else
extern ApT_EnvVar *ApEnvVars();
extern ApT_EnvVar *ApGetEnvVar();
extern void ApRmEnvVar();
extern int ApSetEnvVar();
extern void ApEnvWriteVars();
#endif
// extern void ApPkgInit ();

/** (SCR915) - added prototypes:
  *  ApStIsClassificationFileName() - store the session's markings file name
  *  ApGetIsClassificationFileName() - get (retrieve) session's markings file name
  */
/**
  ApGetIsClassificationFileName()
     This file contains the session's default classification markings.
     If there was no "classification" key word in the session file,
     then NULL is returned.

     @returns the classification filename or NULL if none.

**/
const char *ApGetIsClassificationFileName();

#endif
