/*
 * NmCompat.c -- Legacy Nm package compatability functions
 * 
 * created:     2000/09/21      R A Bowers 
 * edited:	2011/06/22	C Hunt
 *		updated to call nm_xxx function directory (not as member
 *		function pointers of the NmPool structure)
 *		removed all redundant assert statments
 */

/**
    NmCompat.c contains the wrapper functions that enable the new Nm 
    package to be used by old MUVES code.

**/
#ifndef lint
static char RCSid[] = "";

#endif

#ifndef DEBUG
#define	NDEBUG			/*
				 * disable assertions 
				 */
#endif

#include	<assert.h>
#include	<std.h>
#include	<Er.h>	
#include <common.h>   /* BRL-CAD 7.2.4+ no longer use config.h (SCR670) */
#include <Dm.h>
#include	<Nm.h>	

extern int NmDebugging;

/**
    void NmInit( NmPool *pool )

    	NmInit() initializes a name pool.  Nothing is assumed about the
    	validity of its previous contents.

	Unlike the previous Nm implementation, NmPools can not be
        statically initialized.

	Once the name pool has been properly initialized, NmClear()
	should be used whenever it is desired to re-initialize it, in
	order to ensure that storage dynamically allocated by the "Nm"
	package for the name pool is properly freed.
**/
void 
NmInit (NmPool * pool)
{
    assert (pool != NULL);
    
    nm_init (pool);

    return;
}

/**
    void NmClear( NmPool *pool )

	NmClear() empties an already-valid name pool.  Associated
	dynamically-allocated internal storage is freed.  Upon return,
	the name pool has been freshly initialized.

    	If the name pool has not been previously initialized, NmInit()
    	should be used instead.
**/
void 
NmClear (NmPool * pool)
{
    assert (pool != NULL);
    assert (pool->magic == NM_POOL_MAGIC);
    nm_clear (pool);
    return;
}

/**
    MuvesBool NmDup( const NmPool *old, NmPool *new )

	NmDup() duplicates an existing name pool.  The new name pool,
	which must also already exist, should be empty before the call
	to NmDup(); otherwise, memory previously allocated for it will
	become forever inaccessible.  NmDup() returns mTrue if the
	contents of the old name pool are successfully copied into the
	new one; if insufficient memory is available for the new name
	pool or if the old name pool is found to be corrupted, NmDup()
	returns mFalse.
**/
MuvesBool 
NmDupXX (const NmPool * old, NmPool * new, const char *s)
{
    assert (NmCount (new) == 0);	/*
					 * else dynamic memory will be lost 
					 */

    if (nm_duplicateXX((NmPool *)old, (NmPool *)new, s) < 0) {
	ErPLog ("NmDup: could not duplicate name pool.\n");
	return mFalse;
    }
    return mTrue;
}

/**
    int NmIndex( const char *name, NmPool *pool, MuvesBool enter )

	NmIndex() finds a name in the specified name pool and returns
	its index number.  If the "enter" argument is mTrue, NmIndex()
	will register the name if it is not already in the pool;
	otherwise, an unregistered name is considered an error and -1 is
	returned.  -1 is also returned if memory cannot be allocated.	
**/
int 
NmIndexXX (const char *name, NmPool * pool, MuvesBool enter, const char *s)
{
    int	    index;

    assert (enter == mTrue || enter == mFalse);

    if (enter) {
	if ((index = nm_addXX(pool, name, s)) < 0) {
	    return -1;
	}
    } else {
	if ((index = nm_getindex(pool, name)) < 0) {
	    /* ErPLog("NmIndex: %s not found in 0x%x.\n", name, pool); */
	    ErSet (NmERROR_NOT_FOUND);	/*
					 * name not registered 
					 */
	    return -1;
	}
    }
    return index;
}

/**
    MuvesBool NmChangeName( const char *old, const char *new, NmPool *pool )

	NmChangeName() finds an existing name "old" in a name pool and
	replaces it with the specified name "new".  The index (as 
	returned by NmIndex()) will be the same.

    	If successful, NmChangeName() returns mTrue.  If the old name 
	can not be found, or if memory cannot be allocated, the error 
	index is set and mFalse is returned.
**/
MuvesBool 
NmChangeName (const char *old, const char *new, NmPool * pool)
{
    return nm_changename(pool, old, new) >= 0;
}

/**
    MuvesBool NmDeleteName( const char *name, NmPool *pool )

	NmDeleteName() finds an existing name "name" in a name pool and
	deletes it.  WARNING: this routine does not shrink the size of the
	pool in memory, so if it is to be used repeatedly, NmDup can
	be used to make a shrink-wrapped copy.

	If successful, NmDeleteName() returns mTrue.  If the old name can 
	not be found, the error index is set and mFalse is returned.	
**/
MuvesBool 
NmDeleteName (const char *name, NmPool * pool)
{
    return nm_delete(pool, name) >= 0;
}

/**
    const char	*NmName( int index, const NmPool *pool )

	NmName() finds in the specified name pool the name string that
    	corresponds to the given index (which must have been obtained
    	from a previous call to NmIndex()) and returns a pointer to it.
**/
const char *
NmName (int index, const NmPool * pool)
{
    return nm_getname(pool, index);
}

/**
    int	NmSize( const NmPool *pool )

    	NmSize() returns the size of the name pool, which includes deleted
	entries.  An empty (e.g. newly initialized) pool has 0 entries.
**/
/* 11-04-21 ch3: implemented new function to get true size (VSL) */
int 
NmSize (const NmPool * pool)
{
#ifndef COMPILE_FOR_VSL
    return nm_count(pool);
#else  // VSL
    return nm_size(pool);
#endif
}

/**
    int	NmCount( const NmPool *pool )

    	NmCount() returns the number of entries in the specified name
    	pool. An empty (e.g. newly initialized) pool has 0 entries.
**/
int 
NmCount (const NmPool * pool)
{
    return nm_count(pool);
}

void NmPkgInit()
{
    static int done = 0;
    if (!done) {
	done = 1;
	ErPkgInit();
		

	#ifdef VDEBUG
	ErPLog("Nm package initialized.\n");
	#endif
    }
}
