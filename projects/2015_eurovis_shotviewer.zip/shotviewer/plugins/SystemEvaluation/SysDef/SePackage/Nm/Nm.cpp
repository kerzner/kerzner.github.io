// vim:ts=8:sw=4
/*
    <Nm.cpp> -- MUVES "Nm" (name management) package methods

    created:	11/06/21	C Hunt
 */

#include <string>
#include <vector>
#include <map>

extern "C" {

#include <assert.h>
#include <std.h>
#include <common.h>   /* BRL-CAD 7.2.4+ no longer use config.h (SCR670) */
#include <stdio.h>
#include <string.h>  /* 03-06-02 kb: added */
#include <Dm.h>
#include <Er.h>
#include <Nm.h>

}

#define DEBUG	999
#undef	NDEBUG

#include <NamePool.h>

// copy constructor to copy names from one pool to another
NamePool::NamePool(const NamePool &pool)
{
    nameMap::const_iterator it;

    for (it = pool.namemap.begin(); it != pool.namemap.end(); it++) {
        addName((*it).first.c_str());
    }
}


// clears all names and entries from the pool
void NamePool::clear(void)
{
    namemap.clear();
    entries.clear();
    deleted.clear();
}


// adds a name to the pool
int NamePool::addName(const char *name)
{
    std::pair<nameItr,bool> ret;
    int index;
    bool used;

    if (deleted.size() > 0) {
        index = deleted.back();  // use last deleted index
        used = true;
    } else {
        index = namemap.size();  // new index at end
        used = false;
    }
    ret = namemap.insert(std::pair<std::string,int>(name, index));
    if (ret.second == false) {
        if (NmDebugging) {
            ErPLog("nm_add: %s already in pool.\n", name);
        }
        // item already exists, return index
        return (*ret.first).second;
    }

    if (used) {
        deleted.pop_back();  // remove from deleted list
    } else {
        entries.resize(index + 1);  // increase size
    }
    entries[index] = ret.first;
    return index;
}


// deletes a name from the pool
int NamePool::deleteName(const char *name)
{
    nameItr it = namemap.find(name);
    if (it == namemap.end()) {
        if (NmDebugging) {
            ErPLog("nm_delete: %s not found in name pool.\n", name);
        }
        ErSet(NmERROR_NOT_FOUND);
        return NmNOT_FOUND;
    }
    int index = (*it).second;
    namemap.erase(it);
    entries[index] = namemap.end();
    deleted.push_back(index);
    return index;
}


// changes a name in the pool
int NamePool::changeName(const char *oldname, const char *newname)
{
    nameItr it = namemap.find(newname);
    if (it != namemap.end()) {
        ErPLog("nm_changename: new name '%s' already exists in pool.\n",
               newname);
        ErSet(NmERROR_NAME_EXISTS);
        return NmNAME_EXISTS;
    } else if (NmDebugging) {
        ErPLog("nm_changename: new name '%s' ok,  change can proceed.\n",
               newname);
    }

    it = namemap.find(oldname);
    if (it == namemap.end()) {
        ErPLog("nm_changename: %s not found in pool.\n", oldname);
        ErSet(NmERROR_NOT_FOUND);
        return NmNOT_FOUND;
    }
    int index = (*it).second;  // get index of entry
    namemap.erase(it);         // erase old map entry

    std::pair<nameItr,bool> ret;
    ret = namemap.insert(std::pair<std::string,int>(newname, index));
    if (ret.second == false) {
        /*
         * This shouldn't happen. The first check should detect
         * name collisions. If this fails, then the pool is bad.
         */
        ErPLog("nm_changename: BUG! name collision -> bad pool.\n");
        ErSet(NmERROR_NAME_EXISTS);
        return NmNAME_EXISTS;
    }

    entries[index] = ret.first;  // set new map entry
    return index;
}


// returns the name for an index
const char *NamePool::getName(int index)
{
    if (index < 0 || index >= (int)entries.size()) {
        ErSet(NmERROR_OUT_OF_RANGE);
        ErPrint();
        return NULL;
    }

    nameItr entry = entries[index];
    if (entry == namemap.end()) {
        if (NmDebugging) {
            ErPLog("nm_getname: id %d has NULL entry.\n", index);
        }
        return NULL;
    }
    return (*entries[index]).first.c_str();
}


// returns the index of a name
int NamePool::getIndex(const char *name)
{
    nameItr it = namemap.find(name);
    if (it == namemap.end()) {
        if (NmDebugging) {
            ErPLog("nm_getindex: %s not found in pool.\n", name);
        }
        ErSet (NmERROR_NOT_FOUND);
        return NmNOT_FOUND;
    }
    return (*it).second;
}


/**
    Nm.c contains the methods for interacting with the "new" name pool.
**/

extern "C" {

    /**
        nm_create ()

        Dynamically creates and initializes a name pool.
    **/
    NmPool *
    nm_createXX (const char *s)
    {
        NmPool *pool;

        pool = (NmPool *)DmBallocm(sizeof(NmPool), DmBIN(sizeof(NmPool)), s);

        nm_init (pool);
        return pool;
    }

    /**
        nm_init (NmPool *pool)

        Initializes an existing NmPool.  Note that it does not allocate
        space for the entries yet. This is done by nm_add.
    **/
    void
    nm_init (NmPool *pool)
    {
        assert (pool != NULL);

        pool->magic = NM_POOL_MAGIC;
        pool->ptr = (void *)new NamePool;
        // not necessary to call NamePool::init() function here
        // (NamePool member will all be in an initialized state)
    }

    /**
        nm_destroy (NmPool *pool)

        Destroys (clears and deallocates) a dynamically allocated name pool.
    **/
    void
    nm_destroy (NmPool * pool)
    {
        assert (pool != NULL);
        assert (pool->magic == NM_POOL_MAGIC);

        // NamePool destructor will clear all the members
        delete ((NamePool *)pool->ptr);
        bzero (pool, sizeof (NmPool));
        DmFree(pool);
    }

    /**
        nm_clear (NmPool *pool)

        Clears all information from a pool.
    **/
    void
    nm_clear (NmPool * pool)
    {
        assert (pool != NULL);
        assert (pool->magic == NM_POOL_MAGIC);

        ((NamePool *)pool->ptr)->clear();
    }

    /**
        int nm_add (NmPool *pool, const char *name)

        Adds a name to the pool, the value of the name is index in the
        entries array. If the name already exists, nm_add returns the id
        number of the entry. If a failure occurrs, an Er error value is set
        and nm_add retuns  NmERROR. Otherwise, the index number of the new
        member is returned.
    **/
    int
    nm_addXX (NmPool * pool, const char *name, const char *s)
    {
        assert (pool != NULL);
        assert (name != NULL);
        assert (pool->magic == NM_POOL_MAGIC);
        assert (name[0] != 0);

        return ((NamePool *)pool->ptr)->addName(name);
    }

    /**
        int nm_delete (NmPool *pool, const char *name)

        Deletes a name from a name pool. If the name is not found, nm_delete
        returns NmNOT_FOUND. Otherwise, nm_delete returns the id. On error
        it returns NmERROR. If a name is deleted, its slot in the entries
        array is marked with a NULL, but it won't be reused. Thus, the id
        number previously associated with the entry is invalid.
    **/
    int
    nm_delete (NmPool * pool, const char *name)
    {
        assert (pool != NULL);
        assert (name != NULL);
        assert (pool->magic == NM_POOL_MAGIC);
        assert (name[0] != 0);

        return ((NamePool *)pool->ptr)->deleteName(name);
    }

    /**
        const char *nm_getname (const NmPool *pool, int id)

        Given a valid id number, nm_getname returns the name associated with
        that id number.  Note that the caller MUST NOT modify the returned
        string.
    **/
    const char *
    nm_getname (const NmPool * pool, int id)
    {
        assert (pool != NULL);
        assert (pool->magic == NM_POOL_MAGIC);

        return ((NamePool *)pool->ptr)->getName(id);
    }

    /**
        int	nm_getindex (NmPool *pool, const char *name)

        Given a name, returns the index number associated with it. If the
        name is not in the pool, NmNOT_FOUND is returned.
    **/
    int
    nm_getindex (const NmPool * pool, const char *name)
    {
        assert (pool != NULL);
        assert (name != NULL);
        assert (pool->magic == NM_POOL_MAGIC);
        assert (name[0] != 0);

        return ((NamePool *)pool->ptr)->getIndex(name);
    }

    /**
        nm_changename(NmPool *pool, const char *oldname,
    	const char *newname)

        Replaces the name associated with an index number with a new name.
    **/
    int
    nm_changename (NmPool * pool, const char *oldname, const char *newname)
    {
        assert (pool != NULL);
        assert (pool->magic == NM_POOL_MAGIC);
        assert (oldname != NULL);
        assert (oldname[0] != 0);
        assert (newname != NULL);
        assert (newname[0] != 0);

        return ((NamePool *)pool->ptr)->changeName(oldname, newname);
    }

    /**
        int	nm_count (NmPool *pool)

        Returns the 'count' of the pool, which is the number of active
        entries.
    **/
    int
    nm_count (const NmPool * pool)
    {
        assert (pool != NULL);
        assert (pool->magic == NM_POOL_MAGIC);

        return ((NamePool *)pool->ptr)->count();
    }

    /**
        int	nm_size (NmPool *pool)

        Returns the 'size' of the pool, which is the total number of entries
        (some of which may be deleted entries).
    **/
    int
    nm_size (const NmPool * pool)
    {
        assert (pool != NULL);
        assert (pool->magic == NM_POOL_MAGIC);

        return ((NamePool *)pool->ptr)->size();
    }

    /**
        int	nm_duplicate (NmPool *old, NmPool *new)

        Name pool duplicator.
    **/
    int nm_duplicateXX(NmPool *src, NmPool *dst, const char * /*s*/)
    {
        nm_init(dst);
        // no need to call nm_clear()

        NamePool *src_pool = (NamePool *)src->ptr;
        NamePool *dst_pool = (NamePool *)dst->ptr;
        // use copy constructor to do the work
        *dst_pool = *src_pool;
        return dst_pool->count();
    }

    /**
        int	nm_namepool (NmPool *pool)

        return C++ class name pool pointer of name pool.
    **/
    NamePool *nm_namepool (const NmPool *pool)
    {
        return (NamePool *)pool->ptr;
    }


}  // end extern "C"
