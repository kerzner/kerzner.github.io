/*
    <Nm.c> -- MUVES "Nm" (name management) package methods

    created:	2000/09/15
    edited:	03/06/02	K Bowman
		added includes for string.h so that correct definitions are
		included (corrected for SCR380)
    RCSid:		$Id: Nm.c,v 1.21 2008/10/07 11:56:35 jhunt Exp $
 */

/**
    Nm.c contains the methods for interacting with the "new" name pool.
**/
#include <assert.h>
#include <std.h>
#include <tcl.h>
#include <common.h>   /* BRL-CAD 7.2.4+ no longer use config.h (SCR670) */
#include <stdio.h>
#include <Dm.h>
#include <bu.h>
#include <stdio.h>
#include <string.h>  /* 03-06-02 kb: added */
#include <Er.h>
#include <Nm.h>

/* bizarrely, this include wasn't here before, even though genptr_t needs
   it... */
#include <Rt.h>

#define DEBUG	999
#undef	NDEBUG

/**
    nm_create ()
    
	Dynamically creates and initializes a name pool.     	
**/
NmPool *
nm_createXX (const char *s)
{
    NmPool *pool;
    
    pool = (NmPool *)DmBallocm(sizeof(NmPool), DmBIN(sizeof(NmPool)), s);
    
    nm_init (pool);
    /*
     *  Note that nm_init sets pool->destructor to nm_clear, this is proper
     *  for statically allocated pools, but dynamically allocated pools should
     *  be freed with nm_destroy
     */
    pool->destructor = nm_destroy;
    return pool;
}

/**
    nm_init (NmPool *pool)
    
    	Initializes an existing NmPool.  Note that it does not allocate 
	space for the entries yet. This is done by nm_add.
**/
void 
nm_init (NmPool * pool)
{
    assert (pool != NULL);

    /*
    if (pool->magic == NM_POOL_MAGIC && pool->entries != NULL &&
	pool->add == nm_add) {
	ErSet (NmERROR_INIT_NONEMPTY);
	ErPrint ();
	return;
    }
    */
    bzero (pool, sizeof (NmPool));

    pool->magic = NM_POOL_MAGIC;
    pool->destructor = nm_clear;
    pool->add = nm_addXX;
    pool->remove = nm_delete;
    pool->change_name = nm_changename;
    pool->append = nm_appendXX;
    pool->stats = nm_stats;

    pool->get_index = nm_getindex;
    pool->get_name = nm_getname;

    Tcl_InitHashTable (&pool->ht, TCL_STRING_KEYS);
    
    return;
}

/**
    nm_destroy (NmPool *pool)
    
	Destroys (clears and deallocates) a dynamically allocated name 
	pool.
**/
void 
nm_destroy (NmPool * pool)
{
    assert (pool != NULL);
    assert (pool->magic == NM_POOL_MAGIC);

    Tcl_DeleteHashTable (&pool->ht);
    if (pool->entries != NULL) {
    	DmFree((genptr_t)pool->entries);
    }
    DmFree((genptr_t)pool->entries);
    bzero (pool, sizeof (NmPool));
    DmFree((genptr_t)pool);
    
    return;
}

/**
    nm_clear (NmPool *pool)
    
    	Clears all information from a pool.
**/
void 
nm_clear (NmPool * pool)
{
    assert (pool != NULL);
    assert (pool->magic == NM_POOL_MAGIC);
    
    Tcl_DeleteHashTable (&pool->ht);

    if (pool->entries != NULL) {
    	DmFree((genptr_t)pool->entries);
    }
    pool->entries = NULL;
    pool->sizeEntries = 0;
    pool->index = 0;   
    pool->count = 0;

    Tcl_InitHashTable (&pool->ht, TCL_STRING_KEYS);

    return;
}

/**
    int nm_add (NmPool *pool, const char *name)
    
	Adds a name to the pool, the value of the name is index in the 
	entries array. If the name already exists, nm_add returns the id
	number of the entry. If a failure occurrs, an Er error value is 
	set and nm_add retuns  NmERROR. Otherwise, the index number of 
	the new member is returned.
**/
int 
nm_addXX (NmPool * pool, const char *name, const char *s)
{
    int exists = 1;
    int id = NmERROR;
    Tcl_HashEntry *entry;

    assert (pool != NULL);
    assert (name != NULL);
    assert (pool->magic == NM_POOL_MAGIC);
    assert (name[0] != 0);

    /*
     * Allocate space for the entry
     */
    if (pool->sizeEntries == 0) {
	pool->entries = (Tcl_HashEntry **)DmCallocm(128, sizeof(Tcl_HashEntry *), s);

	if (pool->entries == NULL) {
	    ErPrint ();
	    ErSet (NmERROR_CANT_ADD);
	    return NmERROR;
	}
	pool->sizeEntries = 128;

    /* 11-04-21 ch3: don't expend array if there are deleted entries (VSL) */
    } else if (pool->count == pool->index
	    && pool->count == pool->sizeEntries - 1) {
	pool->entries = (Tcl_HashEntry * *)DmReallocm(pool->entries, (2 * pool->sizeEntries)*sizeof(Tcl_HashEntry *), s);

	if (pool->entries == NULL) {
	    ErPrint ();
	    ErSet (NmERROR_CANT_ADD);
	    return NmERROR;
	}
	pool->sizeEntries *= 2;
    }
    entry = Tcl_CreateHashEntry (&pool->ht, name, &exists);

    if (exists == 0) {
	/*
	 * Name found in pool.
	 */
	if (NmDebugging) {
	    ErPLog ("nm_add: %s already in pool.\n", name);
	}
	return ((int)Tcl_GetHashValue (entry));
    }
    /*
     *  As the name pool index to be the value associated with the name 
     *	in the hash table. Also assign the Hash Entry to the entries array.
     */
    /* 11-04-21 ch3: added check to look for deleted entries (VSL) */
    if (pool->count < pool->index) {  /* deleted entries? */
	for (id = 0; id < pool->index; id++) {
	    if (pool->entries[id] == NULL) {  /* found one */
		break;
	    }
	}
    } else {
	id = pool->index;
    }
    Tcl_SetHashValue (entry, id);
    pool->entries[id] = entry;
    ++pool->count;
    ++pool->index;
    return id;
}

/**
    int nm_delete (NmPool *pool, const char *name)
    
	Deletes a name from a name pool. If the name is not found, 
	nm_delete returns NmNOT_FOUND. Otherwise, nm_delete returns 
	the id. On error it returns NmERROR. If a name is deleted, 
	its slot in the entries array is marked with a NULL, but it 
	won't be reused. Thus, the id number previously associated 
	with the entry is invalid.
**/
int 
nm_delete (NmPool * pool, const char *name)
{
    Tcl_HashEntry *entry;
    int id;

    assert (pool != NULL);
    assert (name != NULL);
    assert (pool->magic == NM_POOL_MAGIC);
    assert (name[0] != 0);

    if ((entry = Tcl_FindHashEntry (&pool->ht, name)) == NULL) {
	if (NmDebugging) {
	    ErPLog ("nm_delete: %s not found in name pool.\n", name);
	}
	ErSet (NmERROR_NOT_FOUND);
	return NmNOT_FOUND;
    }
    id = (int) Tcl_GetHashValue (entry);
    Tcl_DeleteHashEntry (entry);
    pool->entries[id] = NULL;
    --pool->count;
    return id;
}

/**
    const char *nm_getname (const NmPool *pool, int id)
    
    	Given a valid id number, nm_getname returns the name associated
    	with that id number.  Note that the caller MUST NOT modify the 
    	returned string.
**/
const char *
nm_getname (const NmPool * pool, int id)
{
    Tcl_HashEntry *entry;

    assert (pool != NULL);
    assert (pool->magic == NM_POOL_MAGIC);

    if (id < 0 || id >= pool->index) {
	ErSet (NmERROR_OUT_OF_RANGE);
	ErPrint ();
	return NULL;
    }
    entry = pool->entries[id];

    if (entry == NULL) {
	if (NmDebugging) {
	    ErPLog ("nm_getname: id %d has NULL entry.\n", id);
	}
	return NULL;
    }
    return Tcl_GetHashKey (&pool->ht, entry);
}

/**
    int	nm_getindex (NmPool *pool, const char *name)
    
    	Given a name, returns the index number associated with it. If
    	the name is not in the pool, NmNOT_FOUND is returned.
**/
int 
nm_getindex (const NmPool * pool, const char *name)
{
    Tcl_HashEntry *entry;
    int id;

    assert (pool != NULL);
    assert (name != NULL);
    assert (pool->magic == NM_POOL_MAGIC);
    assert (name[0] != 0);

    if ((entry = Tcl_FindHashEntry (&((NmPool *)pool)->ht, name)) == NULL) {
	if (NmDebugging) {
	    ErPLog ("nm_getindex: %s not found in pool.\n", name);
	}
	ErSet (NmERROR_NOT_FOUND);
	return NmNOT_FOUND;
    }
    id = (int) Tcl_GetHashValue (entry);
    return id;
}

/**
    nm_changename (NmPool *pool, const char *oldname, const char *newname)
    
    	Replaces the name associated with an index number with a new name.
**/
int 
nm_changename (NmPool * pool, const char *oldname, const char *newname)
{
    Tcl_HashEntry *entry;
    int id;
    int exists;

    assert (pool != NULL);
    assert (pool->magic == NM_POOL_MAGIC);
    assert (oldname != NULL);
    assert (newname != NULL);

    /*
     *  Is the new name already in the pool?
     */
    if ((id = pool->get_index (pool, newname)) >= 0) {
	ErPLog ("nm_changename: new name '%s' already exists in pool.\n",
	    newname);
	ErSet (NmERROR_NAME_EXISTS);
	return NmNAME_EXISTS;
    } else if (NmDebugging) {
	ErPLog ("nm_changename: new name '%s' ok,  change can proceed.\n", 
	    newname);	
    }
    if ((id = pool->get_index (pool, oldname)) == NmNOT_FOUND) {
	ErPLog ("nm_changename: %s not found in pool.\n", oldname);
	ErSet (NmERROR_NOT_FOUND);
	return NmNOT_FOUND;
    }
    entry = pool->entries[id];

    Tcl_DeleteHashEntry (entry);

    entry = Tcl_CreateHashEntry (&pool->ht, newname, &exists);

    if (exists == 0) {
	/*
	 * This shouldn't happen. The first check should detect
	 * name collisions. If this fails, then the pool is bad.
	 */
	ErPLog ("nm_changename: BUG! name collision -> bad pool.\n");
	ErSet (NmERROR_NAME_EXISTS);
	return NmNAME_EXISTS;
    }
    /*
     *    Make the linkages.
     */
    Tcl_SetHashValue (entry, (ClientData) id);
    pool->entries[id] = entry;
    return id;
}

/**
    int	nm_count (NmPool *pool)
    
    	Returns the 'count' of the pool, which is the number of active 
    	entries.
**/
int 
nm_count (const NmPool * pool)
{
    assert (pool != NULL);
    assert (pool->magic == NM_POOL_MAGIC);
    return pool->count;
}

/**
    int nm_append (NmPool *old, NmPool *new)
    
    	Appends a name pool onto another existing name pool. If the new 
	pool is empty, the old pool is copied exactly, NULLs and all. If 
	the new pool is not empty, then the entries from the old pool are 
	cleaned up as they are copied.  nm_append returns the number of 
	elements successfully copied from the old  pool to the new pool.
**/
int 
nm_appendXX (NmPool * old, NmPool * new, const char *s)
{
    Tcl_HashSearch search;
    Tcl_HashEntry *entry;
    NmPool *newPool;
    char *name;
    int i;
    int ignore_nulls;
    int rv;
    int t = 0;

    assert (old != NULL);
    assert (old->magic == NM_POOL_MAGIC);
    assert (new != NULL);
    
    if (new->magic != NM_POOL_MAGIC) {
	if (NmDebugging) {
	    ErPLog("nm_append: initializing target namepool.\n");
	}
	nm_init(new);	
    }

    assert (new->magic == NM_POOL_MAGIC);

    if (nm_count (new) > 0) {
	ignore_nulls = 1;
    } else {
	ignore_nulls = 0;
    }

    for (i = 0; i < old->index; ++i) {
	entry = old->entries[i];
	if (entry != NULL) {
	    name = Tcl_GetHashKey (&old->ht, entry);
	    rv = new->add (new, name, s);
	    if (rv == NmERROR) {
		ErPLog ("nm_append: nm_add failed.\n");
		return NmERROR;
	    } else if (rv == NmNAME_EXISTS) {
		ErPLog ("nm_append: nm_add failed - %s exists in new pool.\n");
		return NmNAME_EXISTS;
	    } else {
		++t;
	    }
	} else if (ignore_nulls == 0) {
	    new->entries[i] = NULL;
	    ++new->index;
	}
    }
    return t;
}

/**
    char *nm_stats (NmPool *pool)
    
	Returns a string describing the state of the hash table.
**/

char *
nm_stats (const NmPool * pool)
{
    assert (pool != NULL);
    assert (pool->magic == NM_POOL_MAGIC);
    return (char *)Tcl_HashStats (&((NmPool *)pool)->ht);
}

/**
    int	nm_duplicate (NmPool *old, NmPool *new)
    
    	Name pool duplicator. 
**/
int nm_duplicateXX(NmPool *old, NmPool *new, const char *s)
{
	nm_init( new );
	nm_clear( new );
	return( nm_appendXX(old, new, s) );
}
