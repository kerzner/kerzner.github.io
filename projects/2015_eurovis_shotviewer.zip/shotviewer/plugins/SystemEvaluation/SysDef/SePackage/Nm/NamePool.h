// vim:ts=8:sw=4
/*
    <NamePool.h> -- MUVES "Nm" (name management) name pool class header file

    created:	13/11/17	C Hunt
    		from the Nm.cpp file
 */

#ifndef NAMEPOOL_H
#define NAMEPOOL_H

#include <string>
#include <vector>
#include <map>


typedef std::map<std::string,int> nameMap;
typedef nameMap::iterator nameItr;

//! Class to contain a name pool

//! The functions of this class have the same behavior as the various previous
//! nm_xxx functions.  None of the functions contain assert() statements, these
//! remain in the nm_xxx C interface functions.
//!
//! External requirements:
//! NmDebugging - external int
//! ErSet() - external function for setting the error flag
//! ErPLog() - external function for prefixed error messages


class NamePool
{
    //! map of names and indexes with access by name
    nameMap namemap;
    //! vector of map entries for access by index
    std::vector<nameItr> entries;
    //! vector of indexes that have been deleted
    std::vector<int> deleted;

public:
    //! default constructor
    NamePool(void) {}

    //! copy constructor to copy names from one pool to another
    NamePool(const NamePool &pool);

    //! clears all names and entries from the pool
    void clear(void);

    //! adds a name to the pool
    int addName(const char *name);

    //! deletes a name from the pool
    int deleteName(const char *name);

    //! changes a name in the pool
    int changeName(const char *oldname, const char *newname);

    //! returns the name for an index
    const char *getName(int index);

    //! returns the index of a name
    int getIndex(const char *name);

    //! returns the number of actual names in the pool
    int count(void) {
        return namemap.size();
    }

    //! returns the number of entries in the pool (some entries may be empty)
    int size(void) {
        return entries.size();
    }
};


extern "C" {
    struct nm_pool;
    extern NamePool *nm_namepool (const struct nm_pool *pool);
}

#endif // NAMEPOOL_H

