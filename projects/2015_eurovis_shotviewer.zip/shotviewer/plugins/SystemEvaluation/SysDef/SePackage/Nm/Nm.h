/*
	<Nm.h> -- MUVES "Nm" (name management) package definitions

	created:	87/11/15	D A Gwyn
	edited:		03/06/02	K Bowman
			added prototype for nm_count() because it is used by
			other files (corrected for SCR380)
	edited:		11/06/22	C Hunt
			removed all members from NmPool (including member
			function pointers) except magic and added a single
			void pointer, which is meant to be used for a pointer
			to the new NamePool C++ class (a void so that the C
			code does not need to be aware of the C++ class)
	RCSid:		$Id: Nm.h,v 1.15 2010/06/23 19:54:48 geoffs Exp $
 */
/**
	The Nm package supports multiple simultaneous "name pools",
	where a name pool consists of a set of character strings and
	associated small non-negative integral index numbers.  A name
	may be referred to by either the index number or the string,
	whichever best fits the application.  Each separate name pool
	is accessed via a "handle" of type NmPool provided by the
	application.  A valid empty name pool can be established
	simply by default C initialization of a static NmPool variable;
	otherwise, invoke NmInit() to initially establish the pool as
	empty.  NmClear() should be invoked to deallocate internal pool
	storage when it is no longer needed.

	Nm functions that return an error indication first register an
	appropriate error index via ErSet().  Note that validity
	checks are performed if the environment variable NmDebugging
	has been set.

	Note that as of 2000/09/15 the Nm package has been reimplemented
	to use the Tcl hash table package for its string-lookup rather than
	the binary search technique used originally.  This should reduce lookup
	times for all of those long names analysts like to use.

	As of 2011/06/21 the Nm package has been reimplemented again for
	the VSL project to not use the Tcl hash table package, but to use the
	C++ STL (specifically map with vector).
**/

#ifndef Nm_H_INCLUDED
#define	Nm_H_INCLUDED			/* once-only latch */

#include <std.h>
#ifndef COMPILE_FOR_VSL
#include <tcl.h>
#endif

/**

	The NmPool

	The New NmPool structure uses a Tcl Hash table for its name lookups.
	See Tcl_CreateHashTable(3) for the details. The hash table provides
	a fast name to index mapping.  The index to name mapping is provided
	by simply indexing into the entries array.

	The 'real' NmPool methods are here, the old calls are wrappers.

	Note that the client should never access the internal variables
	directly. They are 'private.'

	typedef struct nm_pool NmPool;
	struct {
		int		magic;
		*** following for non VSL compiling ***
		void 		(*destructor)(NmPool *);
				    -- Destroys the name pool
		int		(*add)(NmPool *, char *);
				    -- Adds a name
		int		(*remove)(NmPool *, char *);
				    -- Deletes a name
		int		(*append)(NmPool *old, NmPool *new);
				    -- Appends this pool.
		char *		(*stats)(NmPool *);
				    -- Returns statistics
		int		(*get_index)(NmPool *, char *);
				    -- given name rtns index
		int		(*get_name)(NmPool *, int, char **);
				    -- index rtns name
		int		(*change_name) (NmPool *, const char *,
				    const char *);
		int		count;
				    -- number of names in pool
		Tcl_HashTable	ht;
				    -- the hash table
		Tcl_HashEntry	**entries;
				    -- the array of entries
		int		sizeEntries;
				    -- the size of the array
		int		index;								-- insertion point.
		*** following for VSL compiling ***
		void		*ptr;
	} nm_pool;

**/

#define NM_POOL_MAGIC	0x1815DB
typedef struct nm_pool NmPool;
struct nm_pool {
    int		magic;
#ifndef COMPILE_FOR_VSL
    void 		(*destructor)(NmPool *);
    int		(*add)(NmPool *, const char *, const char *);
    int		(*remove)(NmPool *, const char *);
    int		(*append)(NmPool *, NmPool *, const char *);
    char *		(*stats)(const NmPool *);
    int		(*get_index)(const NmPool *, const char *);
    const char *	(*get_name)(const NmPool *, int);
    int 		(*get_count)(const NmPool *);
    int		(*change_name) (NmPool *, const char *, const char *);
    int		count;
    Tcl_HashTable	ht;
    Tcl_HashEntry	**entries;
    int		sizeEntries;
    int		index;
#else  // VSL
    void		*ptr;
#endif
};


#define NmNOT_FOUND	-1
#define NmNAME_EXISTS	-2
#define NmERROR		-3

extern int NmDebugging;

/*
 	Declarations for Nm.c
 */
extern void 	nm_destroy (NmPool *pool);
extern int 	nm_addXX (NmPool *pool, const char *name, const char *s);
extern int	nm_delete (NmPool *pool, const char *name);
extern int 	nm_appendXX (NmPool *old, NmPool *newPool, const char *s);
extern int	nm_duplicateXX (NmPool *old, NmPool *newPool, const char *s);
extern char *	nm_stats (const NmPool *pool);
extern int	nm_getindex (const NmPool *pool, const char *name);
extern const char *nm_getname (const NmPool *pool, int index);
extern int	nm_getcount (const NmPool *pool);
extern int	nm_changename (NmPool *pool, const char *old, const char *newName);
extern NmPool * nm_createXX (const char *);

extern void	nm_init (NmPool *); 	/* initialize a pool declared on the stack */
extern void 	nm_clear (NmPool *);    /* clear a pool */

#define nm_cpp_str(s) # s
#define nm_cpp_xstr(s)  nm_cpp_str(s)
#define NM_FLSTR __FILE__ ":" nm_cpp_xstr(__LINE__)

#define nm_add(p,n) nm_addXX(p,n,NM_FLSTR)
#define nm_append(o,n) nm_appendXX(o,n,NM_FLSTR)
#define nm_duplicate(o,n) nm_duplicateXX(i,n,NM_FLSTR)
#define nm_create() nm_createXX(NM_FLSTR)

/*
 	Declarations for NmCompat.c
 */
extern void 	NmInit (NmPool *pool);
extern void 	NmClear (NmPool *pool);
extern MuvesBool 	NmDupXX (const NmPool *old, NmPool *newPool, const char *s);
extern int 	NmIndexXX (const char *name, NmPool *pool, MuvesBool enter, const char *s);
extern const char *	NmName (int index, const NmPool *pool);
extern int 	NmCount (const NmPool *pool);
extern MuvesBool 	NmChangeName (const char *old, const char *newPool, NmPool *pool);
/* 11-04-21 ch3: added new function type (VSL) */
extern int 	NmSize (const NmPool *pool);
extern MuvesBool 	NmDeleteName (const char *name, NmPool *pool);
extern void     NmGlobalInit ( );
extern void	NmPkgInit();
/* 03-06-02 kb: added the following prototype */
extern int	nm_count (const NmPool * pool);
/* 11-06-21 ch3: added the following prototype */
#ifdef COMPILE_FOR_VSL
extern int	nm_size (const NmPool * pool);
#endif

#define NmDup(o,n) NmDupXX(o,n,NM_FLSTR)
#define NmIndex(n,p,e) NmIndexXX(n,p,e,NM_FLSTR)

#endif /* Nm_H_INCLUDED */



