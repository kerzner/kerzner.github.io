/*
	ErDebug.c -- MUVES "Er" (error handling) package debugging routines

	created:	97/10/31	J Hunt
	edited:		03/02/13	A Ross
			removed 'not implemented' comment from RtDebugging
	edited:		06/11/02	C Hunt
			added separate VuSalvoDebug environment variable for
			salvo methodology (which is also enabled with VuDebug)
			(SCR539)
	edited:		09/08/12	C Hunt
			added separate WaterlineDebug environment variable for
			below waterline checking code (SCR1194)
 */


#ifndef lint
static char RCSid[] = "$Id: ErDebug.c,v 1.16 2010/06/23 19:54:46 geoffs Exp $";
#endif

#ifndef DEBUG
#define	NDEBUG
#endif

#include	<assert.h>
#include	<stdio.h>
#include 	<string.h>
#include	<std.h>

#if STD_C
#include	<stdarg.h>
#else
#include	<varargs.h>
#endif

#include	<Ap.h>			/* definitions for "Ap" package */
#include	<Er.h>			/* definitions for "Er" package */
#include 	<Nm.h>			/* needed for NmName and NmCount */

/**
	MuvesBool ErDebug( int level, const char *comp_name, int line, 
		      const char *file, const char *module, const char *string )

	ErDebug() provides low-level routines with run time settable
	debug message logging.  It is not intended to be called
	directly, but by using the ErDEBUG() and ErCDEBUG() macros:

		MuvesBool ErDEBUG( const char *string )
		MuvesBool ErCDEBUG( const char *comp_name, const char *string )

	These macros assume that ErDebugging has been either locally
	#defined or set to the packages error debugging variable
	(ThDebugging, PiDebugging, etc.) and that ErMODULE_NAME has
	been locally #defined or set to the name of the module being
	executed.  Note that ErDebugging and ErMODULE_NAME are not and
	should not be globally defined or declared and should not
	appear in any header file.

	Depending on the value of level, various amounts of
	information are sent to the log file using ErLog():
	
	level &3	output
	--------	------------
	    0		nothing
	    1		module: string\n
	    2		module(comp_name): string\n
	    3		module(comp_name) [file;line]: string\n

	The return status is that of the ErLog() call: mTrue upon
	successful write to the log file, mFalse otherwise.
**/
MuvesBool
#if STD_C
ErDebug( int level, const char *comp_name, int line, const char *file,
	 const char *module, const char *string )
#else
ErDebug( level, comp_name, line, file, module, string )
     int 		level;
     const char *	comp_name;
     int 		line;
     const char *	file;
     const char *	module;
     const char *	string;
#endif
{
	MuvesBool status;

	switch( level & 3 ) {
	case 0:	/* No debugging? */
		if( ! level )
			return mTrue;
		/* else fall through */
	default:
	case 1:	/* Minimal debugging, just module name */
		status = ErLog( "%s: %s\n", module, string );
		break;
	case 2:	/* Component debugging */
		status = ErLog( "%s(%s): %s\n", module,
				comp_name != NULL ? comp_name : "", string );
		break;
	case 3:	/* Full debugging */
		status = ErLog( "%s(%s) [\"%s\";%d]: %s\n", module,
				comp_name != NULL ? comp_name : "", file,
				line, string );
		break;
	}
	return status;
}

/**
	const char *ErF( const char *format, ... )

	ErF() is a convenience routine that returns a statically
	allocated string that is constructed using a format string,
	variable argument list and vsprintf().  It is intended to be
	used with the ErDEBUG() and ErCDEBUG() macros, for example:

	ErDEBUG( ErF( "mass = %g grams", mass ) );
**/
/*VARARGS*/
const char *
#if STD_C
ErF( const char *format, ... )
#else
ErF( va_alist )
     va_dcl
#endif
{
	static char buffer[BUFSIZ];
#if !STD_C
	const char *format;
#endif
	va_list ap;

#if STD_C
	va_start( ap, format );
#else
	va_start( ap );
	format = va_arg( ap, const char * );
#endif

	vsprintf( buffer, format, ap );
	va_end( ap );

	return buffer;
}

/**
	int ErInitDebugging( const char *module, int level )

	ErInitDebugging() is a convenience routine used to examine the
	environment variable file for a variable with the same name as
	the module name, with a "Debug" string appended.  If found,
	its value is or'd with the default level argument.  The
	resulting level is returned and if not zero, a message is sent
	to the log file indicating the debugging level.  If an error
	occurs writing the message, a -1 is returned, otherwise the
	resulting debugging level is returned.
**/
int
#ifdef STD_C
ErInitDebugging( const char *module, int level )
#else
ErInitDebugging( module, level )
     const char *module;
     int level;
#endif
{
	ApT_EnvVar *envp;
	char buffer[256];

	sprintf( buffer, "%sDebug", module );
	if((envp = ApGetEnvVar( buffer )) != NULL)
		level |= (int) envp->val;

	if( level &&
	    ! ErLog( "%s: Debugging level set to %d\n", module, level ) )
		return -1;

	return level;
}

/**
	MuvesBool ErDebugInit( void )

	ErDebugInit() is used to initialize all lower level MUVES
	packages that use debugging.  For each package, a global
	variable containing the debugging level is declared and set
	using a call to ErInitDebugging().  The variables use the two
	letter package name with "Debugging" appended:

		extern int ApDebugging;
		extern int AtDebugging;
		extern int CdDebugging; // Not implemented
		extern int CpDebugging;
		extern int DdDebugging;
		extern int DmDebugging;
		extern int DqDebugging;
		extern int DxDebugging; // Not implemented
		extern int EmDebugging;
		extern int EvDebugging;
		extern int FaDebugging;
		extern int FpDebugging;
		extern int FrDebugging;
		extern int HmDebugging; // Not implemented
		extern int IfDebugging; // Not used
		extern int ImDebugging;
		extern int InDebugging;
		extern int IoDebugging;
		extern int IrDebugging;
		extern int LkDebugging;
		extern int McDebugging; // Not used
		extern int MpDebugging;
		extern int NmDebugging;
		extern int PiDebugging; // Not implemented
		extern int RnDebugging; // Not implemented
		extern int RtDebugging;
		extern int SaDebugging; // Not implemented
		extern int ScDebugging; // Not implemented
		extern int SeDebugging; // Not implemented
		extern int TcDebugging; // Not implemented
		extern int ThDebugging; // Not implemented
		extern int TiDebugging; // Not implemented
		extern int UcDebugging; // Not implemented
		extern int UiDebugging; // Not implemented
		extern int VmDebugging; // Not implemented
		extern int VuDebugging; // Not implemented

	If an environment variable has been defined with a two letter
	package name with a "Debug" string appended, that environment
	variable is used to set the package debugging level.  Also, is
	the environment variable "DefaultDebug" has been set, it is
	used as the default debugging level for all packages and its
	value is bitwise or'd with any other debugging variable.  If
	no level is set in the environment variable file, no debugging
	is used.

	ErDebugInit() returns mTrue upon success, mFalse upon falure.
	ErDebugInit() could potentially fail if attempts to write to
	the log file fail.
**/

int ApDebugging = 0;
int AsDebugging = 0;
int AtDebugging = 0;
int CdDebugging = 0;
int CpDebugging = 0;
int DdDebugging = 0;
int DmDebugging = 0;
int DqDebugging = 0;
int DxDebugging = 0;
int EmDebugging = 0;
int EvDebugging = 0;
int FaDebugging = 0;
int FpDebugging = 0;
int FrDebugging = 0;
int HmDebugging = 0;
int IfDebugging = 0;
int ImDebugging = 0;
int InDebugging = 0;
int IoDebugging = 0;
int IrDebugging = 0;
int LkDebugging = 0;
int McDebugging = 0;
int MpDebugging = 0;
int NmDebugging = 0;
int PiDebugging = 0;
int RnDebugging = 0;
int RtDebugging = 0;
int SaDebugging = 0;
int ScDebugging = 0;
int SeDebugging = 0;
int TcDebugging = 0;
int ThDebugging = 0;
int TiDebugging = 0;
int UcDebugging = 0;
int UiDebugging = 0;
int VmDebugging = 0;
int VuDebugging = 0;
int VuQDebugging = 0;
/* 06-11-02 ch3: added support for VuSalvoDebug (SCR539) */
int VuSalvoDebugging = 0;
/* 09-08-12 ch3: added support for WaterlineDebug (SCR1194) */
int WaterlineDebugging = 0;

MuvesBool
#ifdef STD_C
ErDebugInit( void )
#else
ErDebugInit()
#endif
{
	int level;
	if( ( level = ErInitDebugging( "Ap", 0 ) < 0 ) )
		return mFalse;
	if( ( ApDebugging = ErInitDebugging( "Ap", level ) ) < 0 ||
	    ( AsDebugging = ErInitDebugging( "At", level ) ) < 0 ||
	    ( AtDebugging = ErInitDebugging( "At", level ) ) < 0 ||
	    ( CdDebugging = ErInitDebugging( "Cd", level ) ) < 0 ||
	    ( CpDebugging = ErInitDebugging( "Cp", level ) ) < 0 ||
	    ( DdDebugging = ErInitDebugging( "Dd", level ) ) < 0 ||
	    ( DmDebugging = ErInitDebugging( "Dm", level ) ) < 0 ||
	    ( DqDebugging = ErInitDebugging( "Dq", level ) ) < 0 ||
	    ( DxDebugging = ErInitDebugging( "Dx", level ) ) < 0 ||
	    ( EmDebugging = ErInitDebugging( "Em", level ) ) < 0 ||
	    ( EvDebugging = ErInitDebugging( "Ev", level ) ) < 0 ||
	    ( FaDebugging = ErInitDebugging( "Fa", level ) ) < 0 ||
	    ( FpDebugging = ErInitDebugging( "Fp", level ) ) < 0 ||
	    ( FrDebugging = ErInitDebugging( "Fr", level ) ) < 0 ||
	    ( HmDebugging = ErInitDebugging( "Hm", level ) ) < 0 ||
	    ( IfDebugging = ErInitDebugging( "If", level ) ) < 0 ||
	    ( ImDebugging = ErInitDebugging( "Im", level ) ) < 0 ||
	    ( InDebugging = ErInitDebugging( "In", level ) ) < 0 ||
	    ( IoDebugging = ErInitDebugging( "Io", level ) ) < 0 ||
	    ( IrDebugging = ErInitDebugging( "Ir", level ) ) < 0 ||
	    ( LkDebugging = ErInitDebugging( "Lk", level ) ) < 0 ||
	    ( McDebugging = ErInitDebugging( "Mc", level ) ) < 0 ||
	    ( MpDebugging = ErInitDebugging( "Mp", level ) ) < 0 ||
	    ( NmDebugging = ErInitDebugging( "Nm", level ) ) < 0 ||
	    ( PiDebugging = ErInitDebugging( "Pi", level ) ) < 0 ||
	    ( RnDebugging = ErInitDebugging( "Rn", level ) ) < 0 ||
	    ( RtDebugging = ErInitDebugging( "Rt", level ) ) < 0 ||
	    ( SaDebugging = ErInitDebugging( "Sa", level ) ) < 0 ||
	    ( ScDebugging = ErInitDebugging( "Sc", level ) ) < 0 ||
	    ( SeDebugging = ErInitDebugging( "Se", level ) ) < 0 ||
	    ( TcDebugging = ErInitDebugging( "Tc", level ) ) < 0 ||
	    ( ThDebugging = ErInitDebugging( "Th", level ) ) < 0 ||
	    ( TiDebugging = ErInitDebugging( "Ti", level ) ) < 0 ||
	    ( UcDebugging = ErInitDebugging( "Uc", level ) ) < 0 ||
	    ( UiDebugging = ErInitDebugging( "Ui", level ) ) < 0 ||
	    ( VmDebugging = ErInitDebugging( "Vm", level ) ) < 0 ||
	    ( VuDebugging = ErInitDebugging( "Vu", level ) ) < 0 ||
	    ( VuQDebugging = ErInitDebugging( "VuQ", level ) ) < 0 ||
	    /* 06-11-02 ch3: added support for VuSalvoDebug (SCR539) */
	    ( VuSalvoDebugging = ErInitDebugging( "VuSalvo", VuDebugging ) ) < 0 ||
	    /* 09-08-12 ch3: added support for WaterlineDebug (SCR1194) */
	    ( WaterlineDebugging = ErInitDebugging( "Waterline", WaterlineDebugging ) ) < 0 )
		return mFalse;
	return mTrue;
}
