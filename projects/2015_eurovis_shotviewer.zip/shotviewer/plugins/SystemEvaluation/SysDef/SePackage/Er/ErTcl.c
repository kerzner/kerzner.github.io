/*******************************************************************************
* ErTcl.c  MUVES "Er" (error) package TCL interface routines
*
* Contents:
*   er_tcl_init()        initialize the Er package TCL interface
*   er_tcl_help()        display Er package TCL command help information
*   er_tcl_debuginit()   calls the Er routine to initialize debug flags
*   er_tcl_logfile()     sets or gets the muves error log file
*   er_tcl_errstring()   gets string for current error if error index is set
*
* Created:  01/04/04  C Hunt III
* Edited:   03/06/02  K Bowman
*           changed include <strings.h> to <string.h> so that correct
*           definitions are included (corrected for SCR380)
*******************************************************************************/

#include <stdio.h>
#include <string.h>  /* 03-06-02 kb: changed from strings.h */
#include <stdlib.h>
#include <tcl.h>
#include <tk.h>

#include <common.h>   /* BRL-CAD 7.2.4+ no longer use config.h (SCR670) */
#include <Dm.h>

#include <Er.h>


/* tcl command function prototypes */

int er_tcl_help(ClientData clientData, Tcl_Interp *interp, int objc,
	Tcl_Obj *const objv[]);

int er_tcl_debuginit(ClientData clientData, Tcl_Interp *interp, int objc,
	Tcl_Obj *const objv[]);

int er_tcl_logfile(ClientData clientData, Tcl_Interp *interp, int objc,
	Tcl_Obj *const objv[]);

int er_tcl_logerror(ClientData clientData, Tcl_Interp *interp, int objc,
	Tcl_Obj *const objv[]);

int er_tcl_errstring(ClientData clientData, Tcl_Interp *interp, int objc,
	Tcl_Obj *const objv[]);


static struct tclcmd {
	char *cmdName;
	int (*cmdFunc)();
	char *cmdDesc;
}  tcl_cmds[] = {
	"er_help", er_tcl_help,	
		"Prints this help message.",
	"er_debuginit", er_tcl_debuginit,
		"Initializes the Er debug flags",
	"er_logfile", er_tcl_logfile,
		"Sets/gets the error log file name",
	"er_logerror", er_tcl_logerror,
		"Log an error message to the error log file",
	"er_errstring", er_tcl_errstring,
		"Gets string for the current error if error index is set",
	(char *)0, (int (*)())0, (char *)NULL
};


static char *ErTclLogFile = NULL;  /* pointer to error log file name */


/*******************************************************************************
* er_tcl_init()  initialize the Er package TCL interface
*
* Arguments:
*   interp   pointer to the TCL interpreter information structure
*   approx   approximation name string
*
* Returns: TCL_OK if successful, TCL_ERROR if not
*******************************************************************************/

int
er_tcl_init(Tcl_Interp *interp, const char *approx)
{
	struct tclcmd *tclcp;    /* tcl command information pointer */

	if (Tcl_PkgProvide(interp, "ErSupport", TCL_VERSION) == TCL_ERROR) {
		return TCL_ERROR;
	}

	for (tclcp = tcl_cmds; tclcp->cmdName != (char *)0; ++tclcp) {
		Tcl_CreateObjCommand(interp, tclcp->cmdName, tclcp->cmdFunc,
			(ClientData)NULL, (Tcl_CmdDeleteProc *)NULL);
	}

	return TCL_OK;

}  /* er_tcl_init() */


/*******************************************************************************
* er_tcl_help()  display Er package TCL command help information
*	
* Arguments:
*   clientData   client data
*   interp       pointer to the TCL interpreter information structure
*   objc         command argument object count
*   objv         pointer to an array of argument object pointers
*
* Returns: TCL_OK
*******************************************************************************/

int
er_tcl_help(ClientData clientData, Tcl_Interp *interp, int objc,
	Tcl_Obj *const objv[])
{
	register struct tclcmd *tclcp;

	Tcl_AppendResult(interp, "\nAvailable commands in the ErTcl package:\n"
		"(for individual command usage, use -help with command)\n\n",
		(char *)NULL);

	for (tclcp = tcl_cmds; tclcp->cmdName != (char *)0; ++tclcp) {
		Tcl_AppendResult(interp, "    ", tclcp->cmdName, " -- \n\t",
			tclcp->cmdDesc, "\n", (char *)NULL);
	}

	return TCL_OK;

}  /* er_tcl_help() */


/*******************************************************************************
* er_tcl_debuginit()  calls the Er routine to initialize debug flags
*	
* Arguments:
*   clientData   client data
*   interp       pointer to the TCL interpreter information structure
*   objc         command argument object count
*   objv         pointer to an array of argument object pointers
*
* Returns: TCL_OK if successful, TCL_ERROR if error
*******************************************************************************/

int
er_tcl_debuginit(ClientData clientData, Tcl_Interp *interp, int objc,
	Tcl_Obj *const objv[])
{
	if (objc > 1) {
		Tcl_SetResult(interp, "usage: er_debuginit", TCL_STATIC);
		return TCL_ERROR;
	}

	Tcl_SetBooleanObj(Tcl_GetObjResult(interp), ErDebugInit());

	return TCL_OK;

}  /* er_tcl_debuginit() */


/*******************************************************************************
* er_tcl_logfile()  sets or gets the muves error log file
*	
* Arguments:
*   clientData   client data
*   interp       pointer to the TCL interpreter information structure
*   objc         command argument object count
*   objv         pointer to an array of argument object pointers
*
* Returns: TCL_OK if successful, TCL_ERROR if error
*******************************************************************************/

int
er_tcl_logfile(ClientData clientData, Tcl_Interp *interp, int objc,
	Tcl_Obj *const objv[])
{
	Tcl_Obj *resultPtr;      /* pointer to result object */

	if (objc > 2 || objc > 1 && StrEq(Tcl_GetString(objv[1]), "-help")) {
		Tcl_SetResult(interp, "usage: er_logfile ?log_filename?",
			TCL_STATIC);
		return TCL_ERROR;
	}

	resultPtr = Tcl_GetObjResult(interp);

	if (objc == 1) {
		if (ErTclLogFile != NULL) {
			Tcl_SetStringObj(resultPtr, ErTclLogFile, -1);
		}
		return TCL_OK;
	}

	if (ErTclLogFile != NULL) {
		DmFree(ErTclLogFile);
	}
	ErTclLogFile = DmStrDup(Tcl_GetString(objv[1]));
	if (ErFile(ErTclLogFile)) {
		Tcl_SetBooleanObj(resultPtr, mTrue);
	} else {
		DmFree(ErTclLogFile);
		ErTclLogFile = NULL;
		Tcl_SetBooleanObj(resultPtr, mFalse);
	}

	return TCL_OK;

}  /* er_tcl_logfile() */


/*******************************************************************************
* er_tcl_logerror()  logs an error message to the error log file
*	
* Arguments:
*   clientData   client data
*   interp       pointer to the TCL interpreter information structure
*   objc         command argument object count
*   objv         pointer to an array of argument object pointers
*
* Returns: TCL_OK if successful, TCL_ERROR if error
*******************************************************************************/

int
er_tcl_logerror(ClientData clientData, Tcl_Interp *interp, int objc,
	Tcl_Obj *const objv[])
{
	if (objc != 2 || objc > 1 && StrEq(Tcl_GetString(objv[1]), "-help")) {
		Tcl_SetResult(interp, "usage: er_logerror error_string",
			TCL_STATIC);
		return TCL_ERROR;
	}

	ErLog("%s\n", Tcl_GetString(objv[1]));

	return TCL_OK;

}  /* er_tcl_logfile() */


/*******************************************************************************
* er_tcl_errstring()  gets string for current error if error index is set
*	
* Arguments:
*   clientData   client data
*   interp       pointer to the TCL interpreter information structure
*   objc         command argument object count
*   objv         pointer to an array of argument object pointers
*
* Returns: TCL_OK if successful, TCL_ERROR if error
*******************************************************************************/

int
er_tcl_errstring(ClientData clientData, Tcl_Interp *interp, int objc,
	Tcl_Obj *const objv[])
{
	if (objc > 1) {
		Tcl_SetResult(interp, "usage: er_errstring", TCL_STATIC);
		return TCL_ERROR;
	}

	Tcl_SetStringObj(Tcl_GetObjResult(interp), (char *)ErString(), -1);
	return TCL_OK;

}  /* er_tcl_errstring() */


/* ErTcl.c */
