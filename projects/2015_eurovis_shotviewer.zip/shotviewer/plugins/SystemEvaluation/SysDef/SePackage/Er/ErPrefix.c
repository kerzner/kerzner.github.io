/*
	ErPrefix.c -- MUVES "Er" (error handling) package prefixed-log routines

	created:	88/06/19	D A Gwyn
 */

#ifndef lint
static char RCSid[] = "$Id: ErPrefix.c,v 1.6 2006/11/20 16:13:45 jhunt Exp $";
#endif

#ifndef DEBUG
#define	NDEBUG
#endif

#include	<assert.h>
#include	<string.h>

#ifdef CTRACE
#include	<stdio.h>		/* for _iob */
#endif

#include	<std.h>

#if STD_C
#include	<stdarg.h>
#else
#include	<varargs.h>
#endif

#include	<Er.h>			/* definitions for "Er" package */

#ifndef DEF_PFX
#define	DEF_PFX	"MUVES"			/* "generic" default prefix */
#endif

#ifndef STATIC
#define	STATIC	static
#endif

STATIC const char	ErDfl[] = DEF_PFX;	/* default prefix */
STATIC const char	*ErPfx = ErDfl;	/* prefix to be printed */

/**
	void    ErPLog( const char *format, ... )

	ErPLog() operates just like ErLog(), with two exceptions:
	it does not return a value to indicate whether it succeeded,
	and it precedes the specified output with a "program prefix"
	followed by the string ": ".
        This design was motivated by the most common method of using
        the more general ErLog() function.
**/

#if STD_C
void
ErPLog( const char *format, ... )
#else
/*VARARGS*/
void
ErPLog( va_alist )
	va_dcl
#endif
	{
#if !STD_C
	register const char	*format;	/* picked up by va_arg() */
#endif
	va_list			ap;

#if STD_C
	va_start( ap, format );
#else
	va_start( ap );
	format = va_arg( ap, const char * );
#endif
	ErPVLog( format, ap );		/* see below */
	va_end( ap );
	}

/**
	void    ErPVLog( const char *format, va_list argument_pointer )

	ErPVLog() operates just like ErVLog(), with two exceptions:
	it does not return a value to indicate whether it succeeded,
	and it precedes the specified output with a "program prefix"
	followed by the string ": ".
        This design was motivated by the most common method of using
        the more general ErVLog() function.
**/

#if STD_C
void
ErPVLog( const char *format, va_list ap )
#else
void
ErPVLog( format, ap )
	const char	*format;
	va_list		ap;
#endif
	{
	assert(ErPfx != NULL);
	assert(ErPfx[0] != 0);

	(void)ErLog( "%s: ", ErPfx );	/* first the prefix */
	(void)ErVLog( format, ap );	/* then the specific information */
	}

/**
	void    ErPrefix( const char *prefix )

	ErPrefix() stores the specified prefix string pointer for later
	use in printing a "program prefix" by ErPLog() and ErPVLog().
	If a prefix has not been set, also after ErPrefix has been
	invoked with a null pointer argument, a default prefix will be
	supplied, typically "MUVES".

        Warning:  The pointed-to string must remain valid throughout
        use of the "Er" package.  For the typical use where the string
        is obtained from argv[0] of the main() function, this does not
        pose a problem, unless an atexit()-registered function happens
        to invoke ErPLog() or ErPVLog().  In other cases, it may be
        necessary to make a "safe" copy of the string with DmStrDup().
**/

#if STD_C
void
ErPrefix( const char *prefix )
#else
void
ErPrefix( prefix )
	const char	*prefix;
#endif
	{
	ErPfx = prefix == NULL || prefix[0] == '\0' ? ErDfl : prefix;
	}

/**
	const char      *ErSimple( const char *pathname )

	ErSimple() returns a pointer to the "simple part" of the given
	pathname, defined as the maximal rightmost part of the pathname
	not containing a `/' character.  If the specified pathname is a
	null pointer, ErSimple() will return a null pointer.

        This function is typically applied to argv[0] of the main()
        function to obtain the argument for ErPrefix().
**/

#if STD_C
const char *
ErSimple( const char *pathname )
#else
const char *
ErSimple( pathname )
	const char		*pathname;
#endif
	{
	register const char	*s;	/* -> slash character, etc. */

	if ( pathname == NULL || pathname[0] == '\0' )
		return (const char *)NULL;

	if ( (s = (const char *)strrchr( pathname, '/' )) == NULL )
		return pathname;

	/* Skip over the slash character; see if anything remains. */

	return *++s != '\0' ? s : (const char *)NULL;
	}
