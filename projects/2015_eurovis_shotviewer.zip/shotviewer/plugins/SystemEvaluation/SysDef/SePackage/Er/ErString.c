/*
	ErString.c -- MUVES "Er" (error handling) package message finder

	created:	87/08/09	D A Gwyn
 */


#ifndef lint
static char RCSid[] = "$Id: ErString.c,v 1.3 1999/04/27 13:03:34 mjo Exp $";
#endif

#ifndef DEBUG
#define	NDEBUG
#endif

#include	<assert.h>
#include	<ctype.h>
#include	<stdio.h>
#include	<string.h>

#ifdef __STDC__
#include	<stddef.h>
#include	<stdlib.h>
#else
extern char	*getenv();
extern long	atol();
#endif

#include	<std.h>			/* VLD/VMB standard header */

#ifndef __STDC__
extern void	free();
extern pointer	malloc();
#endif

#include	<Er.h>			/* definitions for "Er" package */

#ifndef DEF_ROOT
#define	DEF_ROOT	"/vld/muves"	/* default for $MUVES */
#endif

/*
	ErIndex is the recorded error index.
 */

long	ErIndex = ErNONE;		/* set by low-level routines */

/**
	void    ErAuxText( const char *message_file )
	
	ErAuxText() establishes the specified message file name to be
	used to map error indices other than those defined in <Er.h>
	(actually, <sys/ErSym.h>) to error message text strings.  See
	ErString() for details.

	If the argument is a null pointer, the auxiliary file will be
	disabled.

	The message file consists of a series of text lines, each of
	which should be of the form
		<optional white space> <index> <white space> <symbol>
			<white space> <message text>
	Lines not of this form are considered comments and are skipped.
	The symbol is normally the same as a macro used to represent
	the index while programming, but it is not actually used.
	Message texts in excess of 50 characters will be truncated to
	that length by other "Er" package functions.

	Example:

		# my own error message file

		 50000	XxBUG	Terminal programmer stupidity occurred.
		100001	XxRTFM	Operator confusion is evident.

	Warning:  Be sure your auxiliary error index numbers lie well
	beyond the range reserved for use by MUVES; otherwise, you risk
	having those errors incorrectly reported as MUVES-specific
	errors, since the MUVES message file is searched first.
**/

static char	*aux_file = NULL;	/* -> name of auxiliary message file */

void
#if STD_C
ErAuxText( register const char *message_file )
#else
ErAuxText( message_file )
	register const char	*message_file;
#endif
	{
	/* First get rid of the old recorded auxiliary message file name. */

	if ( aux_file != NULL )
		free( (pointer)aux_file );

	if ( message_file == NULL )
		aux_file = NULL;
	else	{
		/* Try to save a copy of the file name (protects against
		   storage pointed to by message_file being overwritten). */

		aux_file = (char *)malloc( strlen( message_file ) + 1 );

		if ( aux_file != NULL )
			(void)strcpy( aux_file, message_file );
		/* else errors will print in generic form; not a catastrophe */
		}
	}

/**
	const char      *ErString( void )

	ErString() returns a pointer to an internal text string that
	describes the error condition corresponding to the current
	recorded error index.  It never returns a null pointer; if the
	correct description cannot be determined for any reason, the
	returned string will still be the best possible message text
	under those circumstances.  If no error is recorded, a pointer
	to an empty string is returned.  ErString() does not modify the
	recorded error index.

	The message text is first sought in $MUVES/lib/errors, which is
	automatically created in parallel with <sys/ErSym.h> when the
	"Er" package is installed, and if no matching index is found
	there, then the file specified by the most recent invocation of
	ErAuxText() (if any) is searched for the index.  If that also
	fails to locate the text, then a generic error message is used.

	If the returned string will not be used immediately (before any
	other MUVES function that might invoke ErString()), then a copy
	must be made in a safe place, since strings returned by
	ErString() share a single internal buffer.
**/

/*
	This implementation is inefficient, but should suffice if
	there are relatively few invocations of ErString().
 */

const char *
#if STD_C
ErString( void )
#else
ErString()
#endif
	{
	static char	message[ErMAX_MSG + 1];	/* holds returned string */
	register FILE	*fp;		/* -> message file stream */
	int		fnum;		/* message file # (0: MUVES; 1: aux.) */

	if ( ErIndex == ErNONE )	/* *must* be 0L */
		return (const char *)"";	/* no error */

#ifdef DEBUG
	assert(ErIndex > 0L);
#else
	if ( ErIndex < 0L )
		goto punt;		/* illegal, won't be in message file */
#endif

	{
	static const char	suffix[] = ErTEXT_FILE;
					/* file name after $MUVES */
	char			fn[ErMAX_LINE + 1];
					/* full MUVES message file path name */
	register const char	*root;	/* MUVES root directory name */
	register int		len;	/* number of characters in root name */

	/* Construct primary (MUVES) message file name. */

	/* IoMUVES() is not available during initial installation,
	   so we can't use it here. */
	if ( (root = (const char *)getenv( "MUVES" )) == NULL )
		root = (const char *)DEF_ROOT;	/* use default */

	len = strlen( root );

	if ( len + (int)sizeof suffix > ErMAX_LINE + 1 )
		fp = NULL;		/* path name too long, skip file */
	else	{
		(void)strcpy( strcpy( fn, root ) + len, suffix );

		/* Open primary message file. */

		fp = fopen( fn, "r" );	/* NULL is okay (see below) */
		}
	}	/* `root', `len', `fn' now undefined */

	/* Scan message files, looking for a matching index. */

	for ( fnum = 0; fnum < 2; ++fnum )
		{
		char	line[ErMAX_LINE + 1];	/* line from error-text file */

		if ( fp != NULL )	/* (the message file might not exist) */
			{
			while ( fgets( line, ErMAX_LINE, fp ) != NULL )
				{
				static const char	ws[] = " \t\r\v\f";
					/* non-NL white space */
				register int		c;
					/* input character from file */
				register char		*cp;	/* -> line[.] */
	
				line[ErMAX_LINE] = '\0';
					/* ensure terminator */
	
				if ( (cp = strchr( line, '\n' )) != NULL )
					*cp = '\0';	/* remove trailing NL */
				else	{
					while ( (c = getc( fp )) != EOF
					     && c != '\n'
					      )
						;	/* skip through NL */
	
					if ( c == EOF )
						break;	/* incomplete line */
					}
	
				/* Parse line; unparsable lines are comments. */
	
				if ( (cp = strtok( line, ws )) == NULL
				  || !isdigit( *cp )
				   )
					continue;	/* no index */
	
				if ( atol( cp ) != ErIndex )
					continue;	/* non-matching index */
	
				if ( (cp = strtok( (char *)NULL, ws )) == NULL )
					continue;	/* no symbol */
	
				cp = strchr( cp, '\0' );
					/* relies on terminator */
	
				while ( *++cp != '\0' && isspace( *cp ) )
					;	/* skip leading white-space */
	
				if ( *cp == '\0' )
					continue;	/* no message */
	
				/* Found the message; return pointer to copy. */
	
				(void)strncpy( message, cp, ErMAX_MSG );
				message[ErMAX_MSG] = '\0';
					/* ensure termination */
	
				(void)fclose( fp );
	
				return (const char *)message;
				}	/* `c', `cp' now undefined */

			(void)fclose( fp );
			}

		/* No match so far, try the auxiliary message file. */

		if ( fnum == 0 )
			fp = fopen( aux_file, "r" );	/* NULL is okay */

		}	/* `line' now undefined */

	/* No match in any message file; fall through into default handler. */

    punt:
	/* Cannot come up with anything better, so just report the index #. */

	(void)sprintf( message, "error # %ld", ErIndex );

	return (const char *)message;
	}
