/*
	ErLog.c -- MUVES "Er" (error handling) package error log routines

	created:	88/01/26	D A Gwyn
	edited:		03/06/02	K Bowman
			added includes for stdlib.h so that correct definitions
			are included (corrected for SCR380)
 */

#ifndef lint
static char RCSid[] = "$Id: ErLog.c,v 1.12 2010/11/30 14:45:06 jhunt Exp $";
#endif

#ifndef DEBUG
#define	NDEBUG
#endif

#include	<assert.h>
#include	<stdio.h>

#include	<std.h>
#include	<stdlib.h>  /* 03-06-02 kb: added for abort() */

#if STD_C
#include	<stdarg.h>
#else
#include	<varargs.h>
#endif

#include	<Er.h>			/* definitions for "Er" package */

#ifndef STATIC
#define	STATIC	static
#endif

/* The following cannot be portably initialized to stderr, alas. */
static FILE	*fp = NULL;		/* error log stream (may be stderr) */

/* SCR 1447: log file limit variables: */
static long ErLogFileLimit = 0;
static int ErLogFileLimitExceeded = 0;
/* default limit is a gigbyte */
#define DEFAULT_FILE_SIZE_LIMIT "1000000000"

/* Client-provided logging function (set by ErFunc()) or NULL. */
STATIC MuvesBool	(*ErFnPtr) PARAMS(( const char *, va_list )) = NULL;

/**
	MuvesBool    ErFile( const char *error_log )

	If an error log other than the standard error output is already
	open, ErFile() first closes that error log; then it attempts to
	open or create the specified error log file in append mode.  If
	the argument is a null pointer, then the standard error output
	will be subsequently used for printing errors; this is also the
	initial package state.  If ErFile() cannot open or create the
	error log, or if an error occurs while closing the previous
	error log file, ErFile() sets an appropriate error index and
	returns mFalse; otherwise it returns mTrue.  In case of failure,
	the error log is reset to the standard error output.
        Since an invocation of ErFile() with a null pointer can be used
        to close an error log file, no separate close function exists.
**/

#if STD_C
MuvesBool
ErFile( const char *error_log )
#else
MuvesBool
ErFile( error_log )
	const char	*error_log;
#endif
	{
	register MuvesBool	status = mTrue;	/* no problems so far! */

	/* Close previous log file. */

	if ( fp != stderr && fp != NULL && fclose( fp ) != 0 )
		{
		ErSet( ErLOG_BROKE );
		status = mFalse;
		}

	if ( error_log == NULL )
		fp = NULL;		/* reset to default */
	else if ( (fp = fopen( error_log, "a" )) == NULL )
		{
		ErSet( ErBAD_LOG_FILE );
		status = mFalse;
		/* Leave fp set to NULL, for default. */
		}
#ifdef _IOLBF	/* normally should be */
	else
		(void)setvbuf( fp, (char *)NULL, _IOLBF, BUFSIZ*sizeof(char) );
#endif

	/* NULL fp (default) is equivalent to stderr; see ErVLog() below. */

	/* SCR 1447: reset log file limits */
	ErLogFileLimit = 0;
	ErLogFileLimitExceeded = 0;

	return status;
	}

/**
	void ErFunc( MuvesBool (*fnp)( const char *format, va_list ap ) )

	ErFunc() sets up an ancillary logging function that is invoked
	from Er*Log() with an error message before it is output through
	the normal means described above.  Arguments to the ancillary
	function will be suitable for use with the v*printf() family
	of standard library functions.  The ancillary function must
	return mTrue if normal error logging is also to be performed,
	or mFalse if the error message is not to be logged normally.

	The ancillary function can be disabled by invoking ErFunc()
	with a null-pointer argument.
**/

#if STD_C
void
ErFunc( MuvesBool (*fnp)( const char *, va_list ) )
#else
void
ErFunc( fnp )
	MuvesBool (*fnp)();
#endif
	{
	ErFnPtr = fnp;			/* (may be null) */
	}

/** 
	MuvesBool    ErLog( const char *format, ... )

	ErLog() appends a message to the currently-open error log,
	converting its arguments according to the printf()-style
	format specification.  If an error is detected during
	printing, ErLog() resets the error log to stderr, tries
	again to print the message, sets an appropriate error index,
	and returns mFalse (leaving the error log reset to stderr);
	otherwise it returns mTrue.
**/

#if STD_C
MuvesBool
ErLog( const char *format, ... )
#else
/*VARARGS*/
MuvesBool
ErLog( va_alist )
	va_dcl
#endif
	{
#if !STD_C
	register const char	*format;	/* picked up by va_arg() */
#endif
	va_list			ap;
	register MuvesBool		status;	/* saves ErVLog() return value */

#if STD_C
	va_start( ap, format );
#else
	va_start( ap );
	format = va_arg( ap, const char * );
#endif
	status = ErVLog( format, ap );	/* see below */
	va_end( ap );
	return status;
	}

/**
	MuvesBool    ErVLog( const char *format, va_list argument_pointer )

	ErVLog() operates just like ErLog(), except that it takes an
	argument pointer parameter (previously set up by va_start(),
	perhaps with some intervening va_arg() invocations) rather
	than a variable argument list.

        The "va_list" type is defined by <stdarg.h> or <varargs.h>.
        The C Standard guarantees that it can be used in this way;
        however, after return from ErVLog() the va_list object must
        not be further used except as an argument to va_end().

	NOTE:  All Er*Log() functions eventually funnel through here.
**/

#if STD_C
MuvesBool
ErVLog( const char *format, va_list ap )
#else
MuvesBool
ErVLog( format, ap )
	const char		*format;
	va_list			ap;
#endif
	{
#ifndef DEBUG
	static const char	help[] = "BUG: bad format in error log call\n";
#endif
	register MuvesBool		status;	/* records whether problems occur */

	if (ErLogFileLimitExceeded)
	  return 1;

#ifdef DEBUG
	assert(format != NULL);		/* let's get it fixed! */
#else
	if ( format == NULL )
		format = help;		/* let's be gentle! */
#endif

	if ( ErFnPtr != NULL && !(*ErFnPtr)( format, ap ) )
		return mTrue;		/* no default logging wanted */

	if ( fp == NULL )		/* default is stderr */
		{
		fp = stderr;
#ifdef _IOLBF	/* normally should be */
		(void)setvbuf( fp, (char *)NULL, _IOLBF, BUFSIZ*sizeof(char) );
#endif
		}

	if (ErLogFileLimit >= 0) {
	  long size = ftell(fp);
	  if (ErLogFileLimit == 0) {
	    /* not set yet */
	    char *env = getenv("MUVES_LOG_FILE_SIZE_LIMIT");
	    if (env == NULL)
	      env = getenv("MUVES_FILE_SIZE_LIMIT");
	    if (env == NULL)
	      env = DEFAULT_FILE_SIZE_LIMIT;
	    ErLogFileLimit = atol(env);
	  }
	  if (size < 0) {
	    ErLogFileLimit = -1;
	  } else if (ErLogFileLimit >= 0 && size > ErLogFileLimit) {
	    fprintf(fp, "\n *** Log file size limit (%ld) exceeded.\n",
		    ErLogFileLimit);
	    fprintf(fp, " *** Set MUVES_LOG_FILE_SIZE_LIMIT higher or to -1"
		    " for unlimited size.\n");
	    ErLogFileLimitExceeded = 1;
	    return 1;
	  }
	}

	status = vfprintf( fp, format, ap ) >= 0;

	if ( fflush( fp ) != 0 )	/* try to flush, in any case */
		status = mFalse;

	if ( !status )
		{
		if ( fp != stderr )
			{
			/* Reset error log to stderr; ignore close error. */

			(void)ErFile( (char *)NULL );

			/* Try again to print, this time to stderr. */

			(void)vfprintf( stderr, format, ap );
			(void)fflush( stderr );
			}

		ErSet( ErLOG_BROKE );
		}

	return status;
	}


void 
ErFatal ()
{
  ErPLog ("Application exitting due to a fatal error.\n");
  ErPLog ("Please contact the MUVES team (mdt@arl.army.mil)\n" );
  abort();
}

void ErPkgInit()
{
    static int done = 0;
    if (!done) {
	
	#ifdef VDEBUG
	ErPLog ("Er package initialized.\n");
	#endif
    }
}

/* ErFp() accesses local (FILE*)fp for Is calls in mervat:main(). */
/* This function is not advertised in Er.h. (...SCR 806) */
FILE *ErFp(void) { return fp; }
