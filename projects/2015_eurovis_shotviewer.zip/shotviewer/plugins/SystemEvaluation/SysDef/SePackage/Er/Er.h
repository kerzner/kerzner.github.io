/**
	<Er.h> -- MUVES "Er" (error handling) package definitions

	The "Er" package provides simple support for reporting errors
	encountered in lower-level modules while permitting error-
	handling strategy to be determined at higher levels.  It also
	provides functions for printing messages to an error log file.
**/
/*
	created:	87/08/10	D A Gwyn
	edited:		04/11/03	C Hunt
			moved ErLDEBUG() level debug macro from s2ReusableRays.c
			so that it can be used throughout the source code
			(SCR446)
	edited:		07/04/09	C Hunt
			added ErMDEBUG() mask debug marco (SCR539)
	edited:		07/04/09	C Hunt
			added ErCLDEBUG() level and ErCMDEBUG() mask debugs
			marcos for equivalent component macros (SCR1006)
	RCSid:		$Id: Er.h,v 1.17 2010/06/23 19:54:46 geoffs Exp $
 */


#ifndef Er_H_INCLUDED
#define	Er_H_INCLUDED			/* once-only latch */

#include	<std.h>			/* for MuvesBool, const, STD_C */

#if STD_C
#include	<stdarg.h>		/* for va_list */
#else
#include <varargs.h>
#endif

/**
	long	ErIndex

	ErIndex is a recorded error index (see below).  It is globally
	visible only so that its value may be temporarily saved in
	order to later restore it, in situations where an intervening
	operation may cause it to be undesirably altered.  All other
	access to this datum should be made only via the functions
	described below.
**/

extern long	ErIndex;		/* set by low-level routines */

/**
	ErNONE is the value of ErIndex when there is no error
	registered; it may be useful with functions such as
	IoOpenFile().
**/

#define	ErNONE	0L			/* indicates "no error" */

/**
	void	ErSet( long index )

	ErSet() records the given index value, which must be one of the
	mnemonic symbolic constants defined by <Er.h> (actually by
	<sys/ErSym.h>, which <Er.h> includes), for possible later use
	in determining an appropriate error description text string.
	If an auxiliary message file has been established, the index
	value may also be one found in the auxiliary file (see below).

	Thus, logging information about an error is efficiently
	accomplished at a low level without presupposing what the
	high-level error-handling strategy might be.  In addition to
	recording the error with ErSet(), a low-level function should
	also return an error indication to its invoker.
**/

#if defined(lint) && !defined(ErLINT)
#if STD_C
extern void	ErSet( long index );
#else
extern void	ErSet();
#endif
#else	/* in-line for speed */
#define	ErSet( index )	((void)(ErIndex = (index)))
#endif

/**
	void	ErClear( void )

	ErClear() resets the recorded error index to indicate "no
	error".

	This must be done by the high-level routine that enforces the
	error-handling strategy, once the error description string has
	been obtained via ErString() or otherwise disposed of.
**/

#if defined(lint) && !defined(ErLINT)
#if STD_C
extern void	ErClear( void );
#else
extern void	ErClear();
#endif
#else	/* in-line for speed */
#define	ErClear()	ErSet( ErNONE )
#endif

/**
	MuvesBool	ErIsSet( void )

	ErIsSet() returns mTrue if an error index is currently recorded,
	mFalse otherwise.

	This is faster and often more convenient than testing for an
	empty string return from ErString().
**/

#if defined(lint) && !defined(ErLINT)
#if STD_C
extern MuvesBool	ErIsSet( void );
#else
extern MuvesBool	ErIsSet();
#endif
#else	/* in-line for speed */
#define	ErIsSet()	(ErIndex != ErNONE)
#endif

#if STD_C
extern void	ErAuxText( const char *message_file );
#else
extern void	ErAuxText();
#endif

#if STD_C
extern const char	*ErString( void );
#else
extern const char	*ErString();
#endif

#if STD_C
extern MuvesBool	ErFile( const char *error_log );
#else
extern MuvesBool	ErFile();
#endif


#if STD_C
extern MuvesBool	ErLog( const char *format, ... );
#else
extern MuvesBool	ErLog();
#endif

#if STD_C
extern MuvesBool	ErVLog( const char *format, va_list argument_pointer );
#else
extern MuvesBool	ErVLog();
#endif


#if STD_C
extern void	ErPLog( const char *format, ... );
#else
extern void	ErPLog();
#endif

#if STD_C
extern void	ErPVLog( const char *format, va_list argument_pointer );
#else
extern void	ErPVLog();
#endif


#if STD_C
extern void	ErFunc( MuvesBool (*fnp)( const char *format, va_list ap ) );
#else
extern void	ErFunc();
#endif


#if STD_C
extern void	ErPrefix( const char *prefix );
#else
extern void	ErPrefix();
#endif


#if STD_C
extern const char	*ErSimple( const char *pathname );
#else
extern const char	*ErSimple();
#endif


#if STD_C
extern void	ErPrint( void );
#else
extern void	ErPrint();
#endif

/**
	The master MUVES error message text file, $MUVES/lib/errors, has
	the following format:

	file:		  { line NL }*
	NL:		  <new-line character>
	line:		  error-line
			| <anything else is considered just a comment>
	error-line:	  WS* index WS+ symbol WS+ message
	WS:		  <non-NL white-space character>
	index:		  <positive integer>
	symbol:		  pkg-prefix mnemonic
	pkg-prefix:	  <2-character package name, u.c. then l.c.>
	mnemonic:	  <u.c. (including _) symbol not containing WS>
	message:	  <arbitrary amount of non-NL descriptive text>

	Indices must be unique within the entire file.

	Mnemonics must be unique in their first 6 characters within each
	package.

	Messages should not exceed 50 characters; any additional
	characters will not be returned by ErString().

	Example of lines:
		# 1100-1199 reserved for "Se" (system evaluation) package
		1100    SeBADSEEK  Failed to reposition "states" or "sysdef" file.
**/

/*
	<sys/ErSym.h> is automatically generated from $MUVES/lib/errors
	when the "Er" package is built.
 */

#include	<sys/ErSym.h>		/* indices & their symbols */

/*
	The following definitions are solely for the convenience of the
	"Er" package and must not be referred to elsewhere.
 */

#ifdef ErDEBUG		/* shorter line limit, to test that ErString() code */
#define	ErMAX_LINE	60		/* # significant chars in line */
#else
#define	ErMAX_LINE	511		/* # significant chars in line */
#endif
#define	ErMAX_MSG	50		/* # significant chars in message */
#define	ErMAX_SYM	6		/* # significant chars in mnemonic */
#define	ErTEXT_FILE	"/lib/errors"	/* append to $MUVES for file name */

extern MuvesBool ErDebug PARAMS(( int level, const char *comp_name, int line,
                                  const char *file, const char *module,
                                  const char *string ));
#if STD_C
extern const char *ErF PARAMS(( const char *format, ... ));
#else
extern const char *ErF PARAMS();
#endif
extern int ErInitDebugging PARAMS(( const char *module, int level ));
extern MuvesBool ErDebugInit PARAMS(( void ));


#define ErDEBUG(str)	if( ErDebugging ) \
(void)ErDebug( ErDebugging, NULL, __LINE__, __FILE__, ErMODULE_NAME, str )

/* 04-11-03 ch3: added macro that checks a level, moved from s2ReusableRays.c */
#define ErLDEBUG(level,str)	if( ErDebugging > (level) ) \
(void)ErDebug( ErDebugging, NULL, __LINE__, __FILE__, ErMODULE_NAME, str )

/* 07-04-09 ch3: added macro that checks a mask (SCR539) */
#define ErMDEBUG(mask,str)	if( ErDebugging & (mask) ) \
(void)ErDebug( ErDebugging, NULL, __LINE__, __FILE__, ErMODULE_NAME, str )

#define ErCDEBUG(comp,str)	if( ErDebugging ) \
(void)ErDebug( ErDebugging, comp, __LINE__, __FILE__, ErMODULE_NAME, str )

/* 09-11-02 ch3: added component level/mask check macros (SCR1006) */
#define ErCLDEBUG(comp,level,str)	if( ErDebugging > (level) ) \
(void)ErDebug( ErDebugging, comp, __LINE__, __FILE__, ErMODULE_NAME, str )

#define ErCMDEBUG(comp,mask,str)	if( ErDebugging & (mask) ) \
(void)ErDebug( ErDebugging, comp, __LINE__, __FILE__, ErMODULE_NAME, str )


extern void ErFatal ();
extern void ErPkgInit();


#endif	/* Er_H_INCLUDED */
