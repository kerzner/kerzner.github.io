/*
	ErPrint.c -- MUVES "Er" (error handling) package simple printout

	created:	87/08/09	D A Gwyn
 */

#ifndef lint
static char RCSid[] = "$Id: ErPrint.c,v 1.3 1999/04/27 13:03:34 mjo Exp $";
#endif

#ifdef CTRACE
#include	<stdio.h>	/* for _iob; see CTFLAGS in ../Make.conf */
#endif

#include	<std.h>

#include	<Er.h>			/* definitions for "Er" package */

/**
	void    ErPrint( void )

	ErPrint() prints an error message obtained via ErString() on
	the error log, then resets the recorded error index.  If no
	error index is currently registered, nothing is printed.

        This function provides a simple method of default high-level
        error handling.  However, alternative error handling strategies
        should always be considered.
**/

#if STD_C
void
ErPrint( void )
#else
void
ErPrint()
#endif
	{
	if ( ErIsSet() )
		{

		/* Print the error message. */

		ErPLog( "%s\n", ErString() );

		/* Reset the error index. */

		ErClear();
		}
	/* else do nothing */
	}
