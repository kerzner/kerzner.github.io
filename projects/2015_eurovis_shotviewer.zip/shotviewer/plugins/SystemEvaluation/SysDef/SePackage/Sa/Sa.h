/**
	<Sa.h> -- MUVES "Sa" (shot array generator) package definitions

	created:	87/09/10	Jeff Hanes
	edited:		03/04/18        C Hunt
			added new error pointer argument to SaRdShot()
			function prototype
	edited:		03/05/17        C Hunt
			added the threat mod structure SaThMod which contains
			information to change threat input data on an SaShot
			basis
			added the enviroment variable mod structure SaEnvMod
			which contains information to change enviroment
			variables on an SaShot basis
			(changes made by SURVICE for AJEM)
	edited:		06/09/25        C Hunt
			added SaSalvo and Sa_salvo pattern structures (SCR539)
	edited:		06/10/20        C Hunt
			added direction type definitions for SALVO and pt
			variable to SaDirec (SCR539)
	edited:		06/10/30        C Hunt
			added function prototype for SaRdSalvo() (SCR539)
	edited:		07/05/03        C Hunt
			added elevation variables to SaSalvo and Sa_salvo
			pattern structures; added SaIntermediateOff to
			SaIntermediate enumeration (SCR854)
	edited:		07/06/05        C Hunt
			added average_only flag to SaSalvo and Sa_salvo
			pattern structures (SCR854)
	edited:		09/08/12        C Hunt
			added new variables to Sa_grid to support below
			waterline checking (SCR1194)

	RCSid:		$Id: Sa.h,v 1.35 2010/06/23 19:54:50 geoffs Exp $
 */
/**
	The "Sa" package provides shot rays to the calling process.  Shot
	rays consist of a point and a direction; the point is defined
	as a VmPoint, while the direction is specified using the SaDirec
	structure defined below.  These rays are arranged in a pattern
	requested by the user on input.  They may use one of the patterns
	defined below, or they may consist of a set of individual
	selected shots.  These shot vectors are intended for use with
	the Rt package, though there may be some other uses for them.

	SaSetup() uses the input shot pattern to create a shot array
	specification, SaArray.  This is an internal structure used to
	maintain information about the state of the array of shot rays
	while they are being processed.  SaSetup() returns a pointer to
	this specification, which the calling function should keep.  The
	caller should do nothing with this pointer except use it as an
	argument to SaNext().

	SaNext() determines the next ray in the shot array, updates the
	shot array specification and returns the shot ray to the calling
	process.  In this manner, the caller receives a shot ray only
	when it asks for one.

	This procedure allows MUVES to process different shot arrays
	"simultaneously" without their clobbering each other (which
	would be the inevitable result if we tried to do this with static
	variables).  An Interaction Module called while evaluating a
	particular component trace can create a shot pattern and ray
	trace secondary threats without interfering with the
	array of initial threats, since they are maintained separately.
	The target interactions package will, therefore, be able to
	evaluate the entire path of each generated threat before moving
	to the next one.  This procedure also avoids the problem of
	wasting available memory maintaining large vector arrays, since
	these shots can only be evaluated one at a time, anyway.
**/
#ifndef	Sa_H_INCLUDED
#define	Sa_H_INCLUDED		/*  once only latch  */

#include	"std.h"
#include	<Dq.h>
#include	<Vm.h>
#include	<Rn.h>

#define SaFP_TOLERANCE	1.0e-6

/**
	The following structures are used to specify shot patterns.
	The calling function must fill in the fields of this structure,
	the use this as an argument to SaSetup(), which will convert
	the pattern to a form more useable within the package.  This
	will be returned as a pointer to an SaArray.  After setting
	up, the original shot pattern specification is no longer
	needed and may be discarded or used for setting up further
	shots; the Sa package no longer needs it.
**/

/* selection of RNG streams for gridding and clustering */
#define Sa_SHOT_PATTERN_STREAM		RnShotPatternStream
#define Sa_CLUSTER_STREAM		RnClusterStream

/**
	typedef struct
		{
		double	xsize;		// horiz. size of grid
		double	ysize;		// vert. size of grid
		int	xpts;		// # horiz. points
		int	ypts;		// # vert. points
		int	rand;		// desired random behavior
		unsigned long	rn_seed;	// seed for RNG
		RnStreamSelect rn_stream; // random number generator stream
		int	envelope;	// desired envelope type
		VmPoint	env_min;	// minima point of bbox
		VmPoint env_max;	// maxima point of bbox
		} SaGrid;

	The grid shot pattern is likely to be the most commonly
	used, at least initially.  The structure used to define
	this pattern contains the spacing and number of points in
	the horizontal and vertical directions.  It also has a
	the "rand" value to indicate what type of random behavior
	to use.  The possible values are shown below.  If there
	is to be a user-definded seed, it is stored in "rn_seed".
**/
typedef struct {
    double	xsize;		/* horiz. size of grid */
    double	ysize;		/* vert. size of grid */
    int	xpts;		/* # horiz. points */
    int	ypts;		/* # vert. points */
    int	rand;		/* desired random behavior */
    unsigned long	rn_seed;  /* seed for RNG */
    RnStreamSelect rn_stream; /* random number generator stream */
    int	envelope;	/* desired envelope type */
    VmPoint	env_min;	/* minima point of bbox */
    VmPoint env_max;	/* maxima point of bbox */
} SaGrid;

/**
	These defined constants are used to determine the behavior
	of the random number generator when processing a shot
	pattern.


		SaNORAND	(turn off random behavior)
		SaDEFSEED	(use the default random seed)
		SaUSERSEED	(use an analyst-defined seed)
**/
#define	SaNORAND	0
#define	SaDEFSEED	1
#define	SaUSERSEED	2

/**
	These defined constants are used to determine the behavior
	of the envelope when processing a shot pattern.


		SaNOENV		(turn off envelope)
		SaBOX		(use predefined bounding box)
		SaSINGLE	(use one grid that just covers the components)
		SaMULTIPLE	(use several grids, one for each component)
**/
#define SaNOENV		0
#define SaBOX		1
#define SaSINGLE	2
#define SaMULTIPLE	3

/**
	typedef struct
		{
		int	npts;		// # points to fire
		double	xsig;		// horiz. standard deviation
		double	ysig;		// vert. standard deviation
		int	rand;		// desired random behavior
		unsigned long	rn_seed;	// seed for RNG
		RnStreamSelect rn_stream; // random number generator stream
		} SaGauss;

	The gaussian shot pattern uses a random number generator
	to define shot origins distributed in a bi-variate Gaussian
	pattern on the plane around the aim point.  The structure
	gives the number of points to be fired and the sizes of
	the standard deviations for the gaussian pattern.  The type
	of seed behavior is indicated by "rand"; this variable may
	not be set to SaNORAND.  If there is to be a user-definded
	seed, it is stored in "rn_seed".
**/
typedef struct {
    int	npts;		/* # points to fire */
    double	xsig;		/* horiz. standard deviation */
    double	ysig;		/* vert. standard deviation */
    int	rand;		/* desired random behavior */
    unsigned long	rn_seed; /* seed for RNG */
    RnStreamSelect rn_stream; /* random number generator stream */
} SaGauss;

/**
	typedef struct
		{
		int npts;		  // # points to fire
		double xrange;		  // horiz. range of values
		double yrange;		  // vert. range of values
		int rand;		  // desired random behavior
		unsigned long rn_seed;	  // seed for RNG
		RnStreamSelect rn_stream; // random number generator stream
		} SaUniform;

	The uniform rectangle pattern uses a RNG to define shot origins
	that are uniformly distributed around the aim point within the
	confines of a rectangle.  The structure gives the number of points
	to be fired and the width (horizontal range) and height (vertical
	range) of the rectangle. The type of seed behavior is indicated by
	"rand"; this variable may not be set to SaNORAND.  If there is to
	be a user-definded seed, it is stored in "rn_seed".
**/
typedef struct {
    int	npts;		/* # points to fire */
    double	xrange;		/* horiz. range of values */
    double	yrange;		/* vert. range of values */
    int	rand;		/* desired random behavior */
    unsigned long	rn_seed;	/* seed for RNG */
    RnStreamSelect rn_stream; /* random number generator stream */
} SaUniform;

/**
	typedef struct
		{
		int npts;		  // # points to fire
		double radius;		  // radius of circle
		int rand;		  // desired random behavior
		unsigned long rn_seed;	  // seed for RNG
		RnStreamSelect rn_stream; // random number generator stream
		} SaUnCircle;

	The uniform circular pattern uses a RNG to define shot origins
	that are uniformly distributed around the aim point within the
	confines of a circle.  The structure gives the number of points
	to be fired and the radius of the circle. The type of seed behavior
	is indicated by "rand"; this variable may not be set to SaNORAND.
	If there is to be a user-definded seed, it is stored in "rn_seed".
**/
typedef struct {
    int	npts;		/* # points to fire */
    double	radius;		/* radius of circle */
    int	rand;		/* desired random behavior */
    unsigned long	rn_seed;	/* seed for RNG */
    RnStreamSelect rn_stream; /* random number generator stream */
} SaUnCircle;

/**
        The uniform sphere pattern is currently used for HEI blast
        shotline determination.  The structure used to define
        this pattern contains the three options to choose for
        determining the uniform sphere shot pattern.  The first option
        is to choose the number of shotlines (nrays).  The second
        option is how fine you want your shot pattern given a
        radius from the burst point (fineness and radius).  The third
        option is the distance between shotline from the burst point
        (distance).  Rand and rn_seed are included for consistancy.
        It also has a the "rand" value to indicate what type of random
        behavior to use.  The possible values are shown below.  If there
        is to be a user-definded seed, it is stored in "rn_seed".

        typedef struct
                {
                int     nrays;           // rays to fire
                double  fineness        // minimum component size of interest
                double  radius          // distance from bp to component
                double  distance        // distance between points
		double	min_phi;	// 0.0, or angle (radian) to start
					   a partial uniform sphere
		double	max_phi;	// PI,  or angle (radian) to end
					   a partial uniform sphere
                int     rand;           // desired random behavior
                unsigned long   rn_seed;        // seed for RNG
		RnStreamSelect rn_stream; // random number generator stream
                } SaUnSphere;
**/

typedef struct {
    int     nrays;           /* # rays to fire */
    double  fineness;        /* minimum component size of interest */
    double  radius;          /* distance from bp to component */
    double  distance;        /* distance between points */
    double	min_phi;	 /* 0.0, or angle (radian) to start
				    a partial uniform sphere */
    double	max_phi;	 /* PI,  or angle (radian) to end
				    a partial uniform sphere */
    int     rand;           /* desired random behavior */
    unsigned long   rn_seed;        /* seed for RNG */
    RnStreamSelect rn_stream; /* random number generator stream */
} SaUnSphere;


/**
	The salvo pattern is not technically a shot pattern like the
	other patterns but is a structure for containing

	The salvo pattern is used by the salvo view.  The structure
	used to define this pattern contains the information used
	to generate the rounds that are shot at the target.  The origin
	point will be automatically be generated from this information
	and using the aim point, which is obtained from the target
	geometry.

	typedef struct
		{
		long iterations;	// number of iterations to perform
		VmVect aimpoint;	// user entered aim point
		double range_min;	// range minimum value
		double range_max;	// range maximum value
		double range_step;	// range step value
		double alt_min;		// altitude minimum value
		double alt_max;		// altitude maximum value
		double alt_step;	// altitude step value
		double az_min;		// azimuth minimum value
		double az_max;		// azimuth maximum value
		double az_step;		// azimuth step value
		double el_min;		// elevation minimum value
		double el_max;		// elevation maximum value
		double el_step;		// elevation step value
		int nbursts;		// number of bursts
		int nrounds;		// number of rounds per burst
		SaIntermediate intermediate;	// intermiate values flag
		MuvesBool debug_mode;	// debug mode flag
		MuvesBool averages_only;	// averages only flag
		} SaSalvo;
**/

/* 06-09-25 ch3: added salvo pattern structure (SCR539) */
typedef enum {
    SaIntermediateNone,
    SaIntermediateBurst,
    SaIntermediateRound,
    SaIntermediateOff  /* 07-05-03: added (SCR854) */
}
SaIntermediate;

typedef struct {
    int iterations;		/* number of iterations to perform */
    double range_min;	/* range minimum value */
    double range_max;	/* range maximum value */
    double range_step;	/* range step value */
    double alt_min;		/* altitude minimum value */
    double alt_max;		/* altitude maximum value */
    double alt_step;	/* altitude step value */
    double az_min;		/* azimuth minimum value */
    double az_max;		/* azimuth maximum value */
    double az_step;		/* azimuth step value */
    /* 07-05-03 ch3: added elevation variables (SCR854) */
    double el_min;		/* elevation minimum value */
    double el_max;		/* elevation maximum value */
    double el_step;		/* elevation step value */
    int nbursts;		/* number of bursts */
    int nrounds;		/* number of rounds per burst */
    SaIntermediate intermediate;	/* intermiate values flag */
    MuvesBool debug_mode;	/* debug mode flag */
    /* 07-06-05 ch3: added average_only flag (SCR854) */
    MuvesBool averages_only;	/* averages only flag */
} SaSalvo;


/**
	typedef struct
		{
		VmPoint loc;		// location of burst or line
		MuvesBool    burst;		// use burst point (else use a line)
		double  delta_az;	// azimuthal offset angle
		double	xsize;		// horiz. size of grid
		double	ysize;		// vert. size of grid
		int	xpts;		// # horiz. points
		int	ypts;		// # vert. points
		int	rand;		// desired random behavior
		unsigned long	rn_seed;	// seed for RNG
		RnStreamSelect rn_stream; // random number generator stream

		} SaDeltaElev;

	The grid shot pattern is likely to be the most commonly
	used, at least initially.  The structure used to define
	this pattern contains the spacing and number of points in
	the horizontal and vertical directions.  It also has a
	the "rand" value to indicate what type of random behavior
	to use.  The possible values are shown below.  If there
	is to be a user-definded seed, it is stored in "rn_seed".
**/
typedef struct {
    VmPoint loc;		/* location of burst or line */
    MuvesBool    burst;		/* use burst point (else use a line) */
    double  delta_az;	/* azimuthal offset angle */
    double	xsize;		/* horiz. size of grid */
    double	ysize;		/* vert. size of grid */
    int	xpts;		/* # horiz. points */
    int	ypts;		/* # vert. points */
    int	rand;		/* desired random behavior */
    unsigned long	rn_seed;  /* seed for RNG */
    RnStreamSelect rn_stream; /* random number generator stream */
} SaDeltaElev;

/**
	typedef struct
		{
		SaPatternType type;		// selection of union types
		union	{
			SaGrid		gr;	// grid shot pattern
			SaGauss		gs;	// Gaussian pattern
			SaUniform	un;	// uniform rectangle pattern
			SaUnCircle	uc;	// uniform circle pattern
                        SaUnSphere      us;     // uniform sphere
			SaSalvo		salvo;	// salvo pattern information
			SaDeltaElev	de;	// delta_elev pattern
			} pat;
		} SaPattern;

	The shot pattern structure contains a union of the various
	shot patterns available.  The "type" field is used to determine
	the type of pattern actually stored in the union.  It may
	take one of the following defined values:

		SaPatTypeRectGrid		-- rectangular grid pattern
		SaPatTypeBivGaussRand		-- bivariate Gaussian random
		SaPatTypeUnifRandRectangle	-- rectangular uniform random
		SaPatTypeUnifRandCircle		-- uniform circular randum
		SaPatTypeUnifRandSphere		-- uniform spherical random
		SaPatTypeSalvo			-- salvo pattern
		SaPatTypeDeltaElev		-- delta_elev pattern
**/
/* Enumerated types for specifying different shot patterns: */
typedef enum {
    SaPatTypeUnset = -1,
    SaPatTypeSingle,
    SaPatTypeRectGrid,
    SaPatTypeBivGaussRand,
    SaPatTypeUnifRandRectangle,
    SaPatTypeUnifRandCircle,
    SaPatTypeUnifRandSphere,
    SaPatTypeSalvo,		/* 06-09-25 ch3: added (SCR539) */
    SaPatTypeDeltaElev,
    SaPatTypeSentinel
}
SaPatternType;

typedef struct {
    SaPatternType type;		/* selection of union types */
    union	{
        SaGrid		gr;	/* rectangular grid pattern */
        SaGauss		gs;	/* bivariate Gaussian pattern */
        SaUniform	un;	/* rectangular uniform pattern */
        SaUnCircle	uc;	/* uniform circular pattern */
        SaUnSphere      us;     /* uniform spherical pattern */
        SaSalvo		salvo;	/* salvo pattern */
        SaDeltaElev	de;	/* delta_elev pattern */
    } pat;
} SaPattern;

#define SaUNSET		0
#define	SaDIRVEC	1
#define	SaPOLAR		2
/* 06-10-20 ch3: added types for salvo (SCR539) */
#define	SaUSERAIMPT	3	/* user set aim point */
#define	SaAUTOAIMPT	4	/* automatic aim point */
#define	SaRANDAIMPT	5	/* random aim point */

/* Enumerated types for specifying coordinates: */
typedef enum {
    SaPosTypeUnset,
    SaPosTypeCartesianXYZ,
    SaPosTypeCartesianOrigin,
    SaPosTypePlanarOffsets
}
SaPositionType;

typedef union {
    SaPositionType type;
    struct {
        SaPositionType type;
        double x;	/* cart. coords that shot passes thru */
        double y;
        double z;
    }
    coords;
    struct {
        SaPositionType type;
        double h;	/* horizontal offset in grid plane */
        double v;	/*   vertical offset in grid plane */
    }
    offset;
}
SaPosition;

/**
	typedef struct
		{
		int	type;			// type of coordinates used
		union	{
			VmVect	vec;		// direction vector
			struct	{
				double	az;	// azimuth
				double	el;	// elevation
				} polar;
			} d;
		} SaDirec;

	The direction structure contains the viewing direction for
	a given shot.  This information may be stored in on of two
	ways, depending on how it was specified.  The union provides
	for a direction vector or an azimuth and elevation (which
	is misnamed "polar coordinates" for convenience).  There
	is also a type variable to indicate which is contained in
	a particular direction structure or that a direction has not
	been specified (a viable option with indirect-fire munitions).
	The valid values are:

		SaUNSET --	direction not specified
		SaDIRVEC --	direction vector
		SaPOLAR --	azimuth and elevation
		SaUSERAIMPT --	salvo user entered aim point
		SaAUTOAIMPT --	salvo automatic aim point
		SaRANDAIMPT --	salvo random aim point
**/
typedef struct {
    int	type;			/* type of coordinates used */
    union	{
        VmVect	vec;		/* direction vector */
        struct	{
            double	az;	/* azimuth */
            double	el;	/* elevation */
        } polar;
        VmPoint	pt;		/* salvo aim point (06-10-20 ch3) */
    } d;
} SaDirec;

typedef struct {
    int count;			/* set if at least one seed set */
    unsigned long seedlist[RnSTREAMS_INUSE];  /*Random stream seeds (optional)*/
} SaSeedInfo;

#ifdef AJEM
/** DRH
	typedef struct
		{
		DqNode chain;	// link to other nodes
		char *thtname;	// group name (for reference)
		char **tuples;	// keyword value pairs
				// (eg. "velocity = 5000"), NULL terminated
		int ntuples;	// number of tuples
		}
	SaThMod;

	The threat mod structure contains information to change the
	threat input data on a SaShot basis.
**/
typedef struct {
    DqNode chain;	/* link to other nodes */
    char *thtname;	/* group name (for reference) */
    char **tuples;	/* keyword value pairs */
    /* (eg. "velocity = 5000"), NULL terminated */
    int ntuples;	/* number of tuples */
}
SaThMod;

/** DRH
	typedef struct
		{
		DqNode chain;	// link to other nodes
		char *envname;	// variable name
		double value;	// variable value
		} SaEnvMod;

	The environment variable mod structure contains information to
	change the environment data on a SaShot basis.
**/
typedef struct {
    DqNode chain;	/* link to other nodes */
    char *envname;	/* variable name */
    double value;	/* variable value */
} SaEnvMod;
#endif  /* AJEM */

/**
	typedef struct
		{
		DqNode chain;		// link to other shots
		MuvesBool directfire;	// direct-fire munition?
		MuvesBool proj;		// project outside target space
		SaPosition pos;		// user-specified shot coords
		VmPoint loc;		// shot origin for ray tracing
		SaDirec dir;		// shot direction
		SaPattern *ptrn;	// shot pattern (optional)
		SaSeedInfo seed;	// stream seed information
		DqNode *thmods;		// pointer to SaThMod list
		DqNode *envmods;	// pointer to SaEnvMod list
		}
	SaShot;

	The shot structure contains one member of a list of shots which
	define a shot group.  Each shot structure contains VmPoint and
	SaDirec structures which defines a location and direction for
	ray-tracing.  The user's specification of the shot coordinates
	(or offsets) are stored as well.  It also contains a pointer to
	a pattern structure.  If this pointer is NULL, the point and
	direction is treated as a single, discrete shot, otherwise it is
	used as the orientation for the associated pattern, but not
	individually ray-traced.
**/
/*
	So, to refer to the azimuth of "shot", use:

		shot.dir.d.polar.az

	to refer to the X coordinate of a direction vector:

		shot.dir.d.vec.x
 */
typedef struct {
    DqNode chain;		/* link to other shots */
    MuvesBool directfire;	/* direct-fire munition? */
    MuvesBool proj;		/* project outside target space */
    MuvesBool explicit;		/* if indirect fire and force to origin */
    SaPosition pos;		/* user-specified shot coordinates */
    VmPoint loc;		/* shot origin for ray tracing */
    SaDirec dir;		/* shot direction */
    SaPattern *ptrn;	/* shot pattern (optional) */
    SaSeedInfo seed;
    MuvesBool hasVP;
    double mass;
    double vel;
    double sfactor;
    double csize;
#ifdef AJEM
    /* DRH: added SaThMod list to change threat input params on the fly */
    DqNode *thmods;		/* pointer to SaThMod list */
    /* DRH: added SaEnvMod list to change environment params on the fly */
    DqNode *envmods;	/* pointer to SaEnvMod list */
#endif
}
SaShot;

/**
	typedef struct
		{
		DqNode		chain;		// link to other views
		char		*label;		// group name (for reference)
		DqNode		*shots;		// head node for shots
		SaPattern	*cluster_ptrn;	// cluster pattern (optional),
						   for stochastic shots
		} SaView;

	The SaView structure contains one complete view specification,
	including a queue of shots (this queue will only contain one shot
	unless the view is a "group" of shots), a groupname (if a "group"),
	and a cluster pattern specification (only used for stochastic shots).
	The Ap package maintains a queue of these SaView structures for
	an analysis.
**/

/*	"View" structure used to store lists of shot structures. */
typedef struct {
    DqNode		chain;		/* link to other views */
    char		*label;		/* group name (for reference) */
    DqNode		*shots;		/* head node for shots */
    SaPattern	*cluster_ptrn;	/* cluster pattern (optional),
					   for stochastic shots */
} SaView;

#if STD_C
/* 03-04-18 ch3: added error pointer argument */
extern SaShot	*SaRdShot( char *inbuf, double unit_fac, char *error );
#else
extern SaShot	*SaRdShot();
#endif

/* 06-10-30 ch3: added function prototype (SCR539) */
SaShot *SaRdSalvo PARAMS((char *inbuf, double unit_fac, char *error));

#if STD_C
extern SaPattern	*SaRdGrid( char *inbuf, double unit_fac );
#else
extern SaPattern	*SaRdGrid();
#endif

#if STD_C
extern SaPattern	*SaRdGauss( char *inbuf, double unit_fac );
#else
extern SaPattern	*SaRdGauss();
#endif

#if STD_C
extern SaPattern	*SaRdUniform( char *inbuf, double unit_fac );
#else
extern SaPattern	*SaRdUniform();
#endif

#if STD_C
extern SaPattern        *SaRdUnCircle( char *inbuf, double unit_fac );
#else
extern SaPattern        *SaRdUnCircle();
#endif

#if STD_C
extern SaPattern        *SaRdSphere( char *inbuf, double unit_fac );
#else
extern SaPattern        *SaRdSphere();
#endif

extern SaPattern *SaRdDeltaElev PARAMS((char *inbuf, double unit_fac));

#ifdef AJEM
/* DRH: MOD read function */
#if STD_C
extern MuvesBool SaRdMod( char *inbuf, SaShot *cur_shot );
#else
extern MuvesBool SaRdMod();
#endif
#endif

/*	The following data structures require "Sa" names in order for
	the code to compile, since SaArray must be defined.  However,
	they will be kept "package static" in the MUVES code.
 */

/*  GRID SPECIFICATION */
/*	Maintains all information about the state of a grid pattern
	(how to make the next shot and where to end). */
typedef struct {
    VmPoint	center;		/* grid center point */
    /* (in target origin plane) */
    VmVect	h_spc;		/* horizontal spacing vector */
    VmVect	v_spc;		/* vertical spacing vector */
    double	hstart;		/* H start value for grid */
    double	vstart;		/* V start value for grid */
    double	hend;		/* H end value for grid */
    double	vend;		/* V end value for grid */
    double	hcur;		/* current H value in grid */
    double	vcur;		/* current V value in grid */
    int	dither;		/* dither shot origins? */
    unsigned long	seed;	/* RNG seed used for dithering */
    RnStreamSelect stream; /* random number generator stream */
    int	envelope;	/* desired envelope type */
    VmPoint	env_min;	/* minima point of bbox */
    VmPoint env_max;	/* maxima point of bbox	*/
    /* 09-08-12 ch3: new variables for waterline support (SCR1194) */
    MuvesBool bycolumn;		/* do grid by columns flag */
    MuvesBool skipcolumn;	/* skip to next column flag */
} Sa_grid;

/*  GAUSS SPECIFICATION */
/*	Maintains all information about the state of a Gaussian
	pattern (how to orient the shot and how many are required). */
typedef struct {
    VmPoint	center;		/* center point */
    /* (in target origin plane) */
    VmVect	h_vec;		/* horizontal unit vector */
    VmVect	v_vec;		/* vertical unit vector */
    int	total;		/* number of shots to fire */
    int	shots;		/* number of shots fired */
    double	hsig;		/* horizontal standard deviation */
    double	vsig;		/* vertical standard deviation */
    int	rand;		/* random number behavior */
    unsigned long	seed;	/* random number generator seed */
    RnStreamSelect stream; /* random number generator stream */
} Sa_gauss;

/*  UNIFORM SPECIFICATION */
/*	Maintains all information about the state of a uniform
	pattern (how to orient the shot and how many are required). */
typedef struct {
    VmPoint	center;		/* center point */
    /* (in target origin plane) */
    VmVect	h_vec;		/* horizontal unit vector */
    VmVect	v_vec;		/* vertical unit vector */
    int	total;		/* number of shots to fire */
    int	shots;		/* number of shots fired */
    double	hrange;		/* horizontal range of values */
    double	vrange;		/* vertical range of values */
    int	rand;		/* random number behavior */
    unsigned long	seed;	/* random number generator seed */
    RnStreamSelect stream; /* random number generator stream */
} Sa_uniform;

/*  UnCIRCLE SPECIFICATION */
/*	Maintains all information about the state of a uniform circle
	pattern (how to orient the shot and how many are required). */
typedef struct {
    VmPoint	center;		/* center point */
    /* (in target origin plane) */
    VmVect	h_vec;		/* horizontal unit vector */
    VmVect	v_vec;		/* vertical unit vector */
    int	total;		/* number of shots to fire */
    int	shots;		/* number of shots fired */
    double	radius;		/* radius of circle */
    int	rand;		/* random number behavior */
    unsigned long	seed;	/* random number generator seed */
    RnStreamSelect stream; /* random number generator stream */
} Sa_uncircle;


/*  UnSPHERE SPECIFICATION */
/*      Maintains all information about the state of a uniform sphere
        pattern (how to orient the shot and how many are required). */
typedef struct {
    VmPoint center;         /* center point */
    /* (in target origin plane) */
    VmVect  h_vec;          /* horizontal unit vector */
    VmVect  v_vec;          /* vertical unit vector */

    int     nrays;          /* calculated number of rays */
    double  sigma;          /* solid angle per ray */
    double  delta;          /* max angular separation of rays */
    double  phi_top;        /* declination of top of current band */
    double  phi_bottom;     /* declination of bottom of band */
    double  phi_min;        /* minimum declination */
    double  phi_max;        /* maximum declination */
    double  gamma;          /* location around current band */
    double  gamma_inc;      /* location increment for looping */
    double  gamma_limit;    /* final location */
    double  gamma_offset;	/* random offset (0 -> 2PI) */
    int rand;		/* random number behavior */
    unsigned long   seed;   /* random number generator seed */
    RnStreamSelect stream; /* random number generator stream */
} Sa_unsphere;


/*  SALVO SPECIFICATION */
/* 06-09-25 ch3: added salvo pattern structure (SCR539) */
/*      Maintains all information about the state of a salvo
        pattern (how to orient the shot and how many are required). */
typedef struct {
    int aimpoint;		/* aim point option (SaUSER/AUTO/RANDAIMPT) */
    long iterations;	/* number of iterations to perform */
    double range_min;	/* range minimum value */
    double range_max;	/* range maximum value */
    double range_step;	/* range step value */
    double alt_min;		/* altitude minimum value */
    double alt_max;		/* altitude maximum value */
    double alt_step;	/* altitude step value */
    double az_min;		/* azimuth minimum value */
    double az_max;		/* azimuth maximum value */
    double az_step;		/* azimuth step value */
    /* 07-05-03 ch3: added elevation variables (SCR854) */
    double el_min;		/* elevation minimum value */
    double el_max;		/* elevation maximum value */
    double el_step;		/* elevation step value */
    int nbursts;		/* number of bursts */
    int nrounds;		/* number of rounds per burst */
    SaIntermediate intermediate;	/* intermiate values flag */
    MuvesBool debug_mode;	/* debug mode flag */
    /* 07-06-05 ch3: added average_only flag (SCR854) */
    MuvesBool averages_only;	/* averages only flag */
    SaSeedInfo seed;	/* random seed information */
#if 0
    int rand;		/* random number behavior */
    unsigned long   seed;   /* random number generator seed */
    RnStreamSelect stream;	/* random number generator stream */
#endif
} Sa_salvo;

/*  DELTA_ELEV SPECIFICATION */
/*	Maintains all information about the state of a delta_elev pattern
	(how to make the next shot and where to end). */
typedef struct {
    VmPoint loc;		/* burst point or line reference */
    MuvesBool    burst;		/* burst point (else line) */
    double  d_az;		/* delta azimuth angle */
    VmVect	dir;		/* direction vector (normal to grid plane) */
    VmPoint	center;		/* grid center point */
    /* (in target origin plane) */
    VmVect	h_spc;		/* horizontal spacing vector */
    VmVect	v_spc;		/* vertical spacing vector */
    double	hstart;		/* H start value for grid */
    double	vstart;		/* V start value for grid */
    double	hend;		/* H end value for grid */
    double	vend;		/* V end value for grid */
    double	hcur;		/* current H value in grid */
    double	vcur;		/* current V value in grid */
    int	dither;		/* dither shot origins? */
    unsigned long	seed;	/* RNG seed used for dithering */
    RnStreamSelect stream; /* random number generator stream */

} Sa_delta_elev;


/*	Union of shot pattern information to be included with a
	shot. */
typedef struct {
    int	type;
    union	{
        Sa_grid		gr;
        Sa_gauss	gs;
        Sa_uniform	un;
        Sa_uncircle	uc;
        Sa_unsphere     us;
        Sa_salvo	salvo;  /* 06-09-25 ch3: added (SCR539) */
        Sa_delta_elev   de;
    } pat;
    /*	Sa_shot	*layer;*/		/* next layer of shots */
} Sa_pattern;

/* Sa Ray structure */
typedef VmRay	SaRay;

/*	Shot information including orienting shot and (potential)
	pattern. */
typedef struct {
    SaSeedInfo	seed;
    SaRay		shot;
    Sa_pattern	*ptrn;		/* shot pattern */
} Sa_shot;

/*  SHOT ARRAY SPECIFICATION  */
typedef struct {
    MuvesBool directfire;	/* direct-fire munition? */
    MuvesBool proj;		/* project outside target space */
    MuvesBool explicit;		/* if indirect fire and force to origin */
    int dirtype;		/* how is direction specified as in SaDirec */
    int nshots;		/* number of shot patterns */
    int done;		/* number of processed patterns */
    Sa_shot	*shots;		/* -> array of shots */
    Sa_shot	*cur_shot;	/* -> active shot */
} SaArray;

#if STD_C
extern SaArray	*SaSetup( DqNode *shots );
#else
extern SaArray	*SaSetup();
#endif

#if STD_C
extern DqNode	*SaNewShGroup( SaRay *shot, SaPattern *ptrn, MuvesBool proj, MuvesBool directfire );
#else
extern DqNode	*SaNewShGroup();
#endif


#if STD_C
extern MuvesBool SaGetReal( double *val );
#else
extern MuvesBool SaGetReal();
#endif

#if STD_C
extern MuvesBool SaNext( SaArray *sas, SaRay *rayp );
#else
extern MuvesBool SaNext();
#endif

#if STD_C
extern int SaNshots( SaArray *array );
#else
extern int SaNshots();
#endif

#if STD_C
extern void SaDiscard( SaArray *array );
#else
extern void SaDiscard();
#endif


extern void SaSeedFromArray (SaArray *sas);


#if STD_C
extern void	SaShFree( DqNode *shot );
#else
extern void	SaShFree();
#endif

/*	Private macro; for use within the Sa package only.*/
#define SaEPSILON	.001

/*      Macro for computing the solid angle of a cone
        subtended by the angle A.                           */

#define SolidAngle( A ) ( 2.0 * PI * ( 1.0 - cos( A ) ))


/*      Macro for computing the angle which subtends a
        cone resulting in solid angle B.                    */

#define InverseSolidAngle( B ) acos( 1.0 - ( B / ( 2.0 * PI )) )

/*	XXX - Could be moved to lower-level package or std.h. */
#ifndef Sqr
#define Sqr(a) ((a)*(a))
#endif

extern void SaPkgInit();

#endif	/*  for Sa_H_INCLUDED  */

