
/**
	<Vm.h> -- MUVES "Vm" (vector math) package definitions
**/
/*
	created:	87/10/21	Jeff Hanes
	edited:		05/05/30	Cletus Hunt
			added new macros VmDComb() and VmComb() and function
			prototype for new function VmFindPerpendicular() to
			support vector calculations needed in new
			MultipleEfpWarhead IFM (AJEM SCR616)
	edited:		08/05/30	Cletus Hunt
			implemented VmEqual(), an efficient version of
			VmNearEqual() to be used when a vector was copied by
			VmCopy() (SCR1091)

	RCSid:		$Id: Vm.h,v 1.22 2010/06/23 19:54:52 geoffs Exp $
 */
/**
	This package is designed to allow for easier manipulation of
	vectors and matrices in the MUVES system.  To accomplish this,
	it defines "VmVect", "VmPoint", and "VmMatrix" types, then
	defines numerous macros for performing vector and matrix math
	with those data types.  There are also a few functions used to
	perform certain operations which cannot be conveniently written
	as macros.

	WARNING:   Most of the functions (not the macros) in the "Vm"
	package require the use of certain subroutines in the `C' math
	library.  Any program using the "Vm" package must be compiled
	with the -lm option in order for these functions to work
	properly.  Also, any routine that uses the VmPrint() macro
	should include <stdio.h>.

	The "VmVect" type is a structure containing three double
	precision floating point variables labeled "x", "y" and "z".
	A "VmPoint" is identical to a "VmVect", but the name is used
	to maintain the conceptual difference between the two.  The `C'
	definition for a "VmVect" is:

		typedef struct
			{
			double	x, y, z;
			}
		VmVect;

	Most of the operations described below are macros, but they
	are described as function calls for aesthetic reasons.  They
	are macros unless otherwise noted.  Because they are, in fact,
	macros, care should be taken in their use.  Pointers should
	not be incremented, nor should scalar values be altered inside
	function calls.  This is guaranteed to cause errors in the
	resulting vectors (if the operation works at all!).

	Many of the macros described below have two flavors of operation:
	one with an explicit destination, and one without.  The former
	begin with "VmD" and stuff the results in the first vector
	in the argument list.  The latter have no such distinction;
	the documentation will indicate which of the arguments is the
	destination.  Users should be careful not to confuse the two
	flavors when using this package.

	NOTE:   All macros and functions require pointers to vectors
	as arguments, NOT structure names.
**/
#ifndef	Vm_H_INCLUDED
#define	Vm_H_INCLUDED		/*  once only latch  */

#include <std.h>

#include <Er.h>			/* needed for VmErPrint() */



/* enumerated type is used as the return value of intersection routines,
	currently being used by VmIntLineWithPlane() function. Expand as
	needed.
*/
typedef enum {
    VmNoIntersect = -1,
    VmIntersectAtPoint,
    VmIntersectAtLine
}	VmIntersectType;

/*	There are (as far as I can tell) two reasonable ways to define
	the types `VmVect' and `VmPoint'.  The better one (in my opinion)
	is shown below.
 */
typedef struct {
    double	x, y, z;	/* MUST be double (for Rt package, etc.) */
}
VmVect;

typedef VmVect	VmPoint;

/*    Adding Ray definition here to remove dependency of Sa on Rt    */
/**
	typedef struct
		{
		VmPoint	loc;		// location
		VmVect	dir;		// direction
		}	VmRay;

	An VmRay data structure is used to specify the starting
	location and direction of a shot ray.

	The "VmPoint" and "VmVect" data types are declared in <Vm.h>.
**/

typedef struct {
    VmPoint loc;                    /* location */
    VmVect  dir;                    /* direction */
}
VmRay;

/**
	The following pointers refer to unit vectors in the primary
	Cartesian coordinate directions.  They are provided as a
	convenience, since they are often required in view computations.

		const VmVect	*Vm_Xaxis
		const VmVect	*Vm_Yaxis
		const VmVect	*Vm_Zaxis
**/
extern const VmVect	*Vm_Xaxis;
extern const VmVect	*Vm_Yaxis;
extern const VmVect	*Vm_Zaxis;

/*	Most of the macros defined in this package are defined as void
	expressions in order to prevent misuse of any random "return"
	values left by the operations performed.
 */

/**
	void VmAdd( VmVect *A, const VmVect *B )

	VmAdd() adds the second vector to the first, leaving the result
	in the first vector.
**/
#if defined(lint) && !defined(VmLINT)
#if STD_C
extern void	VmAdd( VmVect *A, const VmVect *B );
#else
extern void	VmAdd();
#endif
#else	/* in-line for speed */
#define	VmAdd( A, B )		((void)( (A)->x += (B)->x, \
				         (A)->y += (B)->y, \
				         (A)->z += (B)->z ))
#endif

/**
	void VmDAdd( VmVect *A, const VmVect *B, const VmVect *C )

	VmDAdd() adds the second and third vectors, putting the result
	in the first vector.
**/
#if defined(lint) && !defined(VmLINT)
#if STD_C
extern void	VmDAdd( VmVect *A, const VmVect *B, const VmVect *C );
#else
extern void	VmDAdd();
#endif
#else	/* in-line for speed */
#define	VmDAdd( A, B, C )	((void)( (A)->x = (B)->x + (C)->x, \
				         (A)->y = (B)->y + (C)->y, \
				         (A)->z = (B)->z + (C)->z ))
#endif

#if STD_C
extern double	VmAngle( const VmVect *A, const VmVect *B );
#else
extern double	VmAngle();
#endif

/**
	void	VmCopy( VmVect *A, const VmVect *B )

	VmCopy() copies the contents of the second vector into the
	first.
**/
#if defined(lint) && !defined(VmLINT)
#if STD_C
extern void	VmCopy( VmVect *A, const VmVect *B );
#else
extern void	VmCopy();
#endif
#else	/* in-line for speed */
#ifdef STRUCT_COPY_BUG
#define VmCopy( A, B )		((void)( (A)->x = (B)->x, \
				         (A)->y = (B)->y, \
				         (A)->z = (B)->z ))
#else
#define VmCopy( A, B )		((void)(*(A) = *(B)))
#endif
#endif

/**
	void	VmCross( VmVect *A, const VmVect *B, const VmVect *C )

	VmCross() calculates the cross product of the second and
	third vectors (in that order) and puts the result in the
	first vector.
**/
#if defined(lint) && !defined(VmLINT)
#if STD_C
extern void	VmCross( VmVect *A, const VmVect *B, const VmVect *C );
#else
extern void	VmCross();
#endif
#else	/* in-line for speed */
#define	VmCross( A, B, C )	((void)( (A)->x=(B)->y*(C)->z-(B)->z*(C)->y, \
				         (A)->y=(B)->z*(C)->x-(B)->x*(C)->z, \
				         (A)->z=(B)->x*(C)->y-(B)->y*(C)->x ))
#endif

/**
	void	VmDiff( VmVect *A, const VmVect *B )

	VmDiff() takes pointers to two vectors.  It subtracts the
	second vector from the first, leaving the results in the
	first vector.
**/
#if defined(lint) && !defined(VmLINT)
#if STD_C
extern void	VmDiff( VmVect *A, const VmVect *B );
#else
extern void	VmDiff();
#endif
#else	/* in-line for speed */
#define VmDiff( A, B )		((void)( (A)->x -= (B)->x, \
				         (A)->y -= (B)->y, \
				         (A)->z -= (B)->z ))
#endif

/**
	void VmDDiff( VmVect *A, const VmVect *B, const VmVect *C )

	VmDiff() subtracts the third vector from the second, leaving
	the results in the first vector.
**/
#if defined(lint) && !defined(VmLINT)
#if STD_C
extern void	VmDDiff( VmVect *A, const VmVect *B, const VmVect *C );
#else
extern void	VmDDiff();
#endif
#else	/* in-line for speed */
#define VmDDiff( A, B, C )	((void)( (A)->x = (B)->x - (C)->x, \
				         (A)->y = (B)->y - (C)->y, \
				         (A)->z = (B)->z - (C)->z ))
#endif

#if STD_C
extern double	VmDist( const VmPoint *A, const VmPoint *B );
#else
extern double	VmDist();
#endif

#if STD_C
extern void	VmDiv( VmVect *A, double s );
#else
extern void	VmDiv();
#endif

#if STD_C
extern void	VmDDiv( VmVect *A, const VmVect *B, double s );
#else
extern void	VmDDiv();
#endif

/**
	double	VmDot( const VmVect *A, const VmVect *B )

	VmDot() returns the dot product of the two vectors given.
**/
#if defined(lint) && !defined(VmLINT)
#if STD_C
extern double	VmDot( const VmVect *A, const VmVect *B );
#else
extern double	VmDot();
#endif
#else	/* in-line for speed */
#define	VmDot( A, B )		( (A)->x*(B)->x + \
				  (A)->y*(B)->y + \
				  (A)->z*(B)->z )
#endif

#if STD_C
extern double	VmMag( const VmVect *A );
#else
extern double	VmMag();
#endif

/**
	MuvesBool	VmNearEqual( const VmVect *A, const VmVect *B, double tol )

	VmNearEqual() tests whether two vectors are approximately
	equal by checking whether their individual components are
	within a user-defined tolerance of each other.
**/
#if defined(lint) && !defined(VmLINT)
#if STD_C
extern MuvesBool	VmNearEqual( const VmVect *A, const VmVect *B, double tol );
#else
extern MuvesBool	VmNearEqual();
#endif
#else	/* in-line for speed */
#define VmNearEqual( A, B, t )	( Abs((A)->x - (B)->x) < (t) && \
				  Abs((A)->y - (B)->y) < (t) && \
				  Abs((A)->z - (B)->z) < (t)   )
#endif

/**
	MuvesBool	VmEqual( const VmVect *A, const VmVect *B )

	VmEqual() tests whether two vectors are identical by checking
	whether their individual components are equal.  This function is
	a more efficient alternative to VmNearEqual() when, for example,
	a vector was copied using VmCopy(), and this should be the only
	use, otherwise VmNearEqual() should be used that allows a
	tolerance.
**/
/* 08-05-30 ch3: implemented an efficient version of VmNearEqual() (SCR1091) */
#if defined(lint) && !defined(VmLINT)
#if STD_C
extern MuvesBool	VmEqual( const VmVect *A, const VmVect *B );
#else
extern MuvesBool	VmEqual();
#endif
#else	/* in-line for speed */
#define VmEqual( A, B )	( (A)->x == (B)->x && \
			  (A)->y == (B)->y && \
			  (A)->z == (B)->z   )
#endif

/**
	MuvesBool	VmZeroLenVec( const VmVect *A, double tol )

	VmZeroLenVec() tests whether a vector is approximately zero
	by checking whether its individual components are within
	a user-defined tolerance of zero.
**/
#if defined(lint) && !defined(VmLINT)
#if STD_C
extern MuvesBool	VmZeroLenVec( const VmVect *A, double tol );
#else
extern MuvesBool	VmZeroLenVec();
#endif
#else	/* in-line for speed */
#define VmZeroLenVec( A, t )	( Abs((A)->x) < (t) && \
				  Abs((A)->y) < (t) && \
				  Abs((A)->z) < (t)   )
#endif

#if STD_C
extern void	VmNorm( VmVect *A );
#else
extern void	VmNorm();
#endif

/**

	void	VmPrint( const VmVect *A, const char *l )

	VmPrint() prints the vector to standard out with the string
	as a label.  When VmPrint() is used, be sure to include
	<stdio.h> before <Vm.h>.
**/
#if defined(lint) && !defined(VmLINT)
#if STD_C
extern void	VmPrint( const VmVect *A, const char *l );
#else
extern void	VmPrint();
#endif
#else	/* in-line for speed */
#define	VmPrint( A, l )	( (void) printf( "%s\t[%g, %g, %g]\n", \
					 l, (A)->x, (A)->y, (A)->z ) )
#endif

/**
	void	VmErPrint( const VmVect *A, const char *l )

	VmErPrint() prints the vector to the error package output with
	the string as a label (preceded by the current ErPrefix).
**/
#if defined(lint) && !defined(VmLINT)
#if STD_C
extern void	VmErPrint( const VmVect *A, const char *l );
#else
extern void	VmErPrint();
#endif
#else	/* in-line for speed */
#define	VmErPrint( A, l )	ErPLog(	"%s\t[%g, %g, %g]\n", \
					l, (A)->x, (A)->y, (A)->z )
#endif

/**
	void	VmScale( VmVect *A, double s )

	VmScale() multiplies each component of the vector by the
	scalar value.

	void	VmReverse( VmVect *A )

	VmReverse() reverses the direction of the vector.
**/
#if defined(lint) && !defined(VmLINT)
#if STD_C
extern void	VmScale( VmVect *A, double s );
extern void	VmReverse( VmVect *A );
#else
extern void	VmScale();
extern void	VmReverse();
#endif
#else	/* in-line for speed */
#define VmScale( A, s )		((void)( (A)->x *= (s), \
				         (A)->y *= (s), \
				         (A)->z *= (s) ))
#define VmReverse( A )		VmScale( A, -1.0 )
#endif

/**
	void	VmDScale( VmVect *A, const VmVect *B, double s )

	VmDScale() multiplies each component of the second vector by
	the scalar value and puts the result in the first vector.

	void	VmDReverse( VmVect *A, const VmVect *B )

	VmDReverse() reverses the direction of the second vector and
	puts the result in the first vector.
**/
#if defined(lint) && !defined(VmLINT)
#if STD_C
extern void	VmDScale( VmVect *A, const VmVect *B, double s );
extern void	VmDReverse( VmVect *A, const VmVect *B );
#else
extern void	VmDScale();
extern void	VmDReverse();
#endif
#else	/* in-line for speed */
#define VmDScale( A, B, s )	((void)( (A)->x = (B)->x * (s), \
				         (A)->y = (B)->y * (s), \
				         (A)->z = (B)->z * (s) ))
#define VmDReverse( A, B )	VmDScale( A, B, -1.0 )
#endif

/**
	void	VmSet( VmVect *A, double a, double b, double c )

	VmSet() sets the components of the given vector equal to the
	scalar values given.  (component x = a, etc.)
**/
#if defined(lint) && !defined(VmLINT)
#if STD_C
extern void	VmSet( VmVect *A, double a, double b, double c );
#else
extern void	VmSet();
#endif
#else	/* in-line for speed */
#define	VmSet( A, a, b, c )	((void)( (A)->x=(a), (A)->y=(b), (A)->z=(c) ))
#endif

/**
	void VmDComb( VmVect *A, const VmVect *B, const VmVect *C,
		double theta )

	VmDComb() combines the second and third orthogonal vectors using
	an angle to create the components of a new vector and puts the
	result in the first vector.

	A = B * cos(theta) + C * sin(theta)

	If the second and third vectors are unit vectors, then the
	result vector will be a unit vector.  The second or third vector
	may be specified as the first vector, in which case, the
	original vector will be overwritten, or the following alternate
	form of the macro below can be used.

	This macro can be thought of as rotating the second vector
	towards the third vector by an angle in the same plane as both
	vectors.

	void VmComb( VmVect *A, const VmVect *B, double theta )

	A = A * cos(theta) + B * sin(theta)

	This macro can be thought of as rotating the first vector
	towards the second vector by an angle in the same plane as both
	vectors.
**/
/* 05-05-30 ch3: added new macros (SCR616) */
#if defined(lint) && !defined(VmLINT)
#if STD_C
extern void	VmDComb( VmVect *A, VmVect *B, VmVect *C, double theta );
extern void	VmComb( VmVect *A, VmVect *B, double theta );
#else
extern void	VmDComb();
extern void	VmComb();
#endif
#else	/* in-line for speed */
#define	VmDComb( A, B, C, theta )	((void)( \
	(A)->x = (B)->x * cos(theta) + (C)->x * sin(theta), \
	(A)->y = (B)->y * cos(theta) + (C)->y * sin(theta), \
	(A)->z = (B)->z * cos(theta) + (C)->z * sin(theta) ))
#define	VmComb( A, B, theta )		VmDComb( A, A, B, theta )
#endif

#if STD_C
extern void	VmAzElConvert( double az, double el, VmVect *dir );
#else
extern void	VmAzElConvert();
#endif

#if STD_C
extern void	VmDirConvert( const VmVect *dir, double *az, double *el );
#else
extern void	VmDirConvert();
#endif

#if STD_C
extern void	VmFindOrthog( const VmVect *view,
                          VmVect *horiz, VmVect *vert );
#else
extern void	VmFindOrthog();
#endif

void
#if STD_C
VmRotateAroundVec( const VmVect *deltarayp, VmVect *newrayp,
                   double phi, double gamma );
#else
VmRotateAroundVec( );
#endif


#if STD_C
extern void	VmGridVecs( double azim, double elev,
                        VmVect *horiz, VmVect *vert );
#else
extern void	VmGridVecs();
#endif

/* Matrix data type. */
typedef struct {
    VmVect toprow;
    VmVect mdlrow;
    VmVect btmrow;
}
VmMatrix;

/**
	The "VmMatrix" type is a structure containing 3 "VmVect"s
	labeled toprow, mdlrow, and btmrow:

		typedef struct
			{
			VmVect toprow;
			VmVect mdlrow;
			VmVect btmrow;
			}
		VmMatrix;
**/

#if STD_C
extern const VmMatrix *VmMatIdentity( void );
extern const VmMatrix *VmMatXMat( const VmMatrix *lft, const VmMatrix *rgt );
extern const VmMatrix *VmRotXAxis( double theta );
extern const VmMatrix *VmRotYAxis( double theta );
extern const VmMatrix *VmRotZAxis( double theta );
extern const VmMatrix *VmMatTranspose( const VmMatrix *matp );
extern const VmVect *VmLeastContribAxis( VmVect *v );
extern const VmVect *VmMatXVec( const VmMatrix *matp, const VmVect *vecp );
extern double VmRotAngle( const VmVect *A, const VmVect *B, const VmVect *C );
extern VmMatrix *VmMatCopy( VmMatrix *dstp, const VmMatrix *srcp );
extern VmIntersectType VmIntLineWithPlane( VmRay *, VmPoint *,
        VmVect *, VmPoint *, VmVect * );
extern double VmDistPtToLine( VmPoint *pt, VmPoint *P0, VmPoint *P1 );
extern void VmLRotYAxis( double theta, VmVect *xp, VmVect *yp, VmVect *zp );
extern void VmRotVec( double theta, const VmVect *uvecp, VmVect *vvecp );
/* 05-05-30 ch3: added the following function prototype (SCR616) */
extern void VmFindPerpendicular( const VmVect *uvecp, VmVect *vvecp );
#else
extern const VmMatrix *VmMatIdentity();
extern const VmMatrix *VmMatXMat();
extern const VmMatrix *VmRotXAxis();
extern const VmMatrix *VmRotYAxis();
extern const VmMatrix *VmRotZAxis();
extern const VmMatrix *VmMatTranspose();
extern const VmVect *VmLeastContribAxis();
extern const VmVect *VmMatXVec();
extern double VmRotAngle();
extern VmMatrix *VmMatCopy();
extern VmIntersectType VmIntLineWithPlane();
extern double VmDistPtToLine();
extern void VmLRotYAxis();
extern void VmRotVec();
/* 05-05-30 ch3: added the following function prototype (SCR616) */
extern void VmFindPerpendicular();
#endif

extern void VmPkgInit();

#endif	/*  for Vm_H_INCLUDED  */
