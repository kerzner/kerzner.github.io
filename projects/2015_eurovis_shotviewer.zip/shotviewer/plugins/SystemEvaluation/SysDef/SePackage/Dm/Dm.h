/**
	<Dm.h> -- MUVES "Dm" (Dynamic Memory) package definitions
**/
/*
	RCSid:		$Id: Dm.h,v 1.3 2008/10/07 11:56:33 jhunt Exp $
*/

#ifndef	DmH_INCLUDE
#define	DmH_INCLUDE

extern void *DmMallocm(unsigned int size, const char *source);
extern void *DmBallocm(unsigned int size, unsigned int bin, const char *source);
extern void *DmCallocm(unsigned int nelem, unsigned int elsize,
                       const char *source);
extern void *DmReallocm(void *ptr, unsigned int size, const char *source);
extern void DmFreem(void *ptr, const char *source);
extern char *DmStrDupm(const char *s1, const char *source);
extern void DmExemptm(void *ptr, const char *source);

extern void DmCheck(void);

/* DmFLSTR copied from brlcad/bu.h to keep header file independent. */
#define DmCPPstr(s) # s
#define DmCPPxstr(s)  DmCPPstr(s)
#define DmFLSTR __FILE__ ":" DmCPPxstr(__LINE__)

#define DmMalloc(size) DmMallocm(size, DmFLSTR)
#define DmBalloc(size, bin) DmBallocm(size, bin, DmFLSTR)
#define DmCalloc(nelem, elsize) DmCallocm(nelem, elsize, DmFLSTR)
#define DmRealloc(ptr, size) DmReallocm(ptr, size, DmFLSTR)
#define DmFree(ptr) DmFreem(ptr, DmFLSTR)
#define DmStrDup(str) DmStrDupm(str, DmFLSTR)
#define DmExempt(ptr) DmExemptm(ptr, DmFLSTR)

#define SHIFT 8
#define ROUNDUP 0xff

/* When used with a constant value, the DmBIN macro should optimize
   into a constant value at compile time, for example:

        DmBIN(sizeof(x));

 */
#define DmBIN(size) ((size_t)(size + ROUNDUP) >> SHIFT)
#define DmXalloc(x) DmBallocm(sizeof(x), DmBIN(sizeof(x)), DmFLSTR)

#endif	/* DmH_INCLUDE */
