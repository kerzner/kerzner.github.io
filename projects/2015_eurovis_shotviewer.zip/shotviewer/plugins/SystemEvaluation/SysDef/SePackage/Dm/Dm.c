/*
	Dm.c -- MUVES "Dm" (Dynamic Memory) package routines

*/

#ifndef lint
static char RCSid[] = "$Id: Dm.c,v 1.7 2010/10/06 20:20:45 geoffs Exp $";
#endif

#include <errno.h>		/* errno */
#include <stdlib.h>		/* size_t, NULL, malloc, calloc, free,
				   abort, atexit, getenv, atoi */
#include <stdio.h>
#include <string.h>		/* memcpy, memset, strlen, strerror */
#include <unistd.h>		/* sleep, sysconf */

/* SCR 1314: need to use ErLog instead of stderr */
#include <Er.h>

#include "Dm.h"

typedef struct block {
	long magic;
	struct block *prev;
	struct block *next;
	const char *source;
	size_t bytes;
	size_t size;
	size_t block;
}  DmBlock;

#define DmMAGIC 0xA110CA73
#define BINS 32

static int initialized = 0;
static DmBlock cache[BINS+1], used[BINS+1], exempt[BINS+1];
static unsigned int max = 0, current = 0;
static size_t pagesize = 0;
static size_t pagebin = 0;

/* DmTerm should only be called after exit() */

static void
DmTerm(void) {
	register DmBlock *bp, *hp, *lp, *up = NULL, *ep = NULL;
	register int i;
	register long b = 0;
	extern int DmDebugging;

	/* Check the DmDebug UNIX environment variable which is
	   necessary for the non-muverat utility and GUI programs. */
	if (!DmDebugging && getenv("DmDebug"))
		DmDebugging = atoi(getenv("DmDebug"));

	ErLog("Peak MUVES memory usage: %u bytes.\n", max);

	/* Make a list of (unique) leaked blocks. */
	for (i = BINS; i >= 0; --i) {
		for (hp = &used[i], bp = hp->next; bp != hp; bp = bp->next) {
			for (lp = up; lp != NULL; lp = lp->prev) {
				if (lp->source == bp->source) {
					lp->block++;
					b += lp->bytes;
					break;
				}
			}
			if (lp == NULL) {
				bp->prev = up;
				up = bp;
				bp->block = 1;
				b += bp->bytes;
			}
		}
		/* Only count exempt blocks if DmDebug >= 2 */
		if (DmDebugging < 2)
			continue;
		for (hp = &exempt[i], bp = hp->next; bp != hp; bp = bp->next) {
			for (lp = ep; lp != NULL; lp = lp->prev) {
				if (lp->source == bp->source) {
					lp->block++;
					break;
				}
			}
			if (lp == NULL) {
				bp->prev = ep;
				ep = bp;
				bp->block = 1;
			}
		}
	}

	/* Report list of exemptions. */
	if (DmDebugging >= 2) {
		for (i = 0, lp = ep; lp != NULL; lp = lp->prev) ++i;
		ErLog("Exempted memory leaks:\n");
		for (lp = ep; lp != NULL; lp = lp->prev) {
			ErLog("%ld bytes from %s",
			      (long)lp->bytes, lp->source);
			if (lp->block > 1)
				ErLog(" (%d times)", (int)lp->block);
			ErLog("\n");
		}
	}

	/* Report list of leaks. */
	for (i = 0, lp = up; lp != NULL; lp = lp->prev) ++i;
	if (i && DmDebugging )
		ErLog("Memory leaks detected: [pid:%d]\n",getpid());
	else if (i) {
		ErLog("%d memory leaks (%ld bytes) detected."
		      "(Set DmDebug for specifics.)\n", (int)i, b);
		up = NULL;
	}
	for (lp = up; lp != NULL; lp = lp->prev) {
		ErLog("%ld bytes from %s",
		      (long)lp->bytes, lp->source);
		if (lp->block > 1)
			ErLog(" (%d times)", (int)lp->block);
		ErLog("\n");
	}

	/* Don't bother explicitly calling free() since the program is
	   about to exit.. */
	return;
}

/* DmInit() should only be called once. */
static void
DmInit(void) {
	register int i;

	if (initialized)
		return;

	/* get system page size for malloc'ing more blocks at a time */
	pagesize = sysconf(_SC_PAGE_SIZE) - 1;

	/* Initialize the free and used blocks arrays. */
	for (i = 0; i < BINS+1; ++i) {
		cache[i].magic = used[i].magic = exempt[i].magic = DmMAGIC;
		cache[i].prev = cache[i].next = &cache[i];
		used[i].prev = used[i].next = &used[i];
		exempt[i].prev = exempt[i].next = &exempt[i];

		/* check if this bin fits into a page of memory */
		if (((size_t)i << SHIFT) + sizeof(DmBlock) <= pagesize)
			pagebin = i;
	}

	initialized = 1;

	atexit(DmTerm);

	return;
}

/* SCR 1157 -- copy the DmAlloc() code into each function to avoid
 * extra function calls. 
 *
 * Future code changes must be reflected in each of the following
 * functions:
 *
 *	DmMallocm
 *	DmBallocm
 *	DmCallocm
 *	DmReallocm
 *	DmStrDupm
 */

void *
DmMallocm(unsigned int size, const char *source) {
	register DmBlock *bp, *hp;
	register size_t b, bytes;

	if (!initialized)
		DmInit();

	/* Compute the free blocks array index. */
	b = (size_t)(size + ROUNDUP) >> SHIFT;

	/* Compute actual number of bytes needed. */
	bytes = (b << SHIFT) + sizeof(DmBlock);

	/* Very large blocks do not get cached. */
	if (b > BINS) {
		bytes = (size_t)size + sizeof(DmBlock);
		b = BINS;
	}

	/* Check if there is an available block to reuse. */
	hp = &cache[b];
	if (b < BINS && hp->next != hp) {
		/* Pop next free block off the list. */
		bp = hp->next;
		bp->next->prev = hp;
		hp->next = bp->next;
		if (bp->magic != DmMAGIC) {
			ErPLog("BUG: Corrupt memory at %p.\n", (void*)bp);
			abort();
		}
	} else {
		static unsigned int counter = 0;
		/* Get more blocks for future use to cut down on
		   number of malloc() calls */
		register size_t more_bytes;
		if (b < BINS && pagesize > bytes)
			more_bytes = (size_t)(pagesize/bytes) * bytes;
		else
			more_bytes = bytes;
		/* Loop until memory becomes available. */
		for (bp = NULL; bp == NULL; ) {
			bp = malloc(more_bytes);
			if (bp == NULL) {
				/* Out of memory..
				   Sleep for a second and try again. */
				if (!counter)
					ErPLog(
"\nThe system is out of memory.\n"
"This program will pause until memory becomes available.\n\n"
						);
				if (!(counter++ % 60))
					/* output the error each minute */
					/* perror(source); */
					ErPLog("%s: %s\n", source,
					      strerror(errno));
				sleep(1);
				errno = 0;
			}
		}
		if ((current += more_bytes) > max)
			max = current;

		/* Cache the extra blocks for later */
		while (more_bytes != bytes) {
			more_bytes -= bytes;
			bp->magic = DmMAGIC;
			hp->prev->next = bp;
			bp->prev = hp->prev;
			hp->prev = bp;
			bp->next = hp;
			bp = (DmBlock*)((char *)bp + bytes);
		}
	}

	/* Setup the block header. */
	bp->magic = DmMAGIC;
	bp->source = source;
	bp->bytes = bytes;
	bp->size = (size_t)size;
	bp->block = b;

	/* Add to the used block array. */
	hp = &used[b];
	hp->next->prev = bp;
	bp->next = hp->next;
	hp->next = bp;
	bp->prev = hp;

	/* Return the memory address just after the block. */
	return (void*)++bp;
}

void *
DmBallocm(unsigned int size, unsigned int bin, const char *source) {
	register DmBlock *bp, *hp;
	register size_t b, bytes;

	if (!initialized)
		DmInit();

	/* Compute actual number of bytes needed. */
	if (bin < BINS) {
		b = (size_t)bin;
		bytes = (b << SHIFT) + sizeof(DmBlock);
	} else {
		b = BINS;
		bytes = (size_t)size + sizeof(DmBlock);
	}

	/* Check if there is an available block to reuse. */
	hp = &cache[bin];
	if (bin < BINS && hp->next != hp) {
		/* Pop next free block off the list. */
		bp = hp->next;
		bp->next->prev = hp;
		hp->next = bp->next;
		if (bp->magic != DmMAGIC) {
			ErPLog("BUG: Corrupt memory at %p.\n", (void*)bp);
			abort();
		}
	} else {
		static unsigned int counter = 0;
		/* Get more blocks for future use to cut down on
		   number of malloc() calls */
		register size_t more_bytes;
		if (bin < BINS && pagesize > bytes)
			more_bytes = (size_t)(pagesize/bytes) * bytes;
		else
			more_bytes = bytes;
		/* Loop until memory becomes available. */
		for (bp = NULL; bp == NULL; ) {
			bp = malloc(more_bytes);
			if (bp == NULL) {
				/* Out of memory..
				   Sleep for a second and try again. */
				if (!counter)
					ErPLog(
"\nThe system is out of memory.\n"
"This program will pause until memory becomes available.\n\n"
						);
				if (!(counter++ % 60))
					/* output the error each minute */
					/* perror(source); */
					ErPLog("%s: %s\n", source,
					      strerror(errno));
				sleep(1);
				errno = 0;
			}
		}
		if ((current += more_bytes) > max)
			max = current;

		/* Cache the extra blocks for later */
		while (more_bytes != bytes) {
			more_bytes -= bytes;
			bp->magic = DmMAGIC;
			hp->prev->next = bp;
			bp->prev = hp->prev;
			hp->prev = bp;
			bp->next = hp;
			bp = (DmBlock*)((char *)bp + bytes);
		}
	}

	/* Setup the block header. */
	bp->magic = DmMAGIC;
	bp->source = source;
	bp->bytes = bytes;
	bp->size = (size_t)size;
	bp->block = bin;

	/* Add to the used block array. */
	hp = &used[bin];
	hp->next->prev = bp;
	bp->next = hp->next;
	hp->next = bp;
	bp->prev = hp;

	/* Return the memory address just after the block. */
	return (void*)++bp;
}

void *
DmCallocm(unsigned int nelem, unsigned int elsize, const char *source) {
	register DmBlock *bp, *hp;
	register size_t bytes, b, size = nelem * elsize;

	if (!initialized)
		DmInit();

	/* Compute the free blocks array index. */
	b = (size + ROUNDUP) >> SHIFT;

	/* Compute actual number of bytes needed. */
	bytes = (b << SHIFT) + sizeof(DmBlock);

	/* Very large blocks do not get cached. */
	if (b > BINS) {
		b = BINS;
		bytes = (size_t)size + sizeof(DmBlock);
	}

	/* Check if there is an available block to reuse. */
	hp = &cache[b];
	if (b < BINS && hp->next != hp) {
		/* Pop next free block off the list. */
		bp = hp->next;
		bp->next->prev = hp;
		hp->next = bp->next;
		if (bp->magic != DmMAGIC) {
			ErPLog("BUG: Corrupt memory at %p.\n", (void*)bp);
			abort();
		}
	} else {
		static unsigned int counter = 0;
		/* Get more blocks for future use to cut down on
		   number of malloc() calls */
		register size_t more_bytes;
		if (b < BINS && pagesize > bytes)
			more_bytes = (size_t)(pagesize/bytes) * bytes;
		else
			more_bytes = bytes;
		/* Loop until memory becomes available. */
		for (bp = NULL; bp == NULL; ) {
			bp = malloc(more_bytes);
			if (bp == NULL) {
				/* Out of memory..
				   Sleep for a second and try again. */
				if (!counter)
					ErPLog(
"\nThe system is out of memory.\n"
"This program will pause until memory becomes available.\n\n"
						);
				if (!(counter++ % 60))
					/* output the error each minute */
					/* perror(source); */
					ErPLog("%s: %s\n", source,
					      strerror(errno));
				sleep(1);
				errno = 0;
			}
		}
		if ((current += more_bytes) > max)
			max = current;

		/* Cache the extra blocks for later */
		while (more_bytes != bytes) {
			more_bytes -= bytes;
			bp->magic = DmMAGIC;
			hp->prev->next = bp;
			bp->prev = hp->prev;
			hp->prev = bp;
			bp->next = hp;
			bp = (DmBlock*)((char *)bp + bytes);
		}
	}

	/* zero out the memory */
	memset((void*)bp, 0, bytes);

	/* Setup the block header. */
	bp->magic = DmMAGIC;
	bp->source = source;
	bp->bytes = bytes;
	bp->size = (size_t)size;
	bp->block = b;

	/* Add to the used block array. */
	hp = &used[b];
	hp->next->prev = bp;
	bp->next = hp->next;
	hp->next = bp;
	bp->prev = hp;

	/* Return the memory address just after the block. */
	return (void*)++bp;
}

void
DmFreem(void *ptr, const char *source) {
	register DmBlock *bp, *hp;

	if (!initialized) {
		ErPLog("BUG: %s called free before alloc.\n", source);
		abort();
	}

	if (ptr == NULL) {
		ErPLog("BUG: %s called free with NULL pointer.\n", source);
		/* same behavior as bu_free() is to just return */
		return;
	}

	/* Get the block header info. */
	bp = (DmBlock *)ptr - 1;
	if (bp->magic != DmMAGIC) {
		ErPLog("BUG: Corrupt memory at %p.\n", ptr);
		abort();
	}

	/* Unlink from used list. */
	bp->next->prev = bp->prev;
	bp->prev->next = bp->next;

	/* Return really large chunks to the system. */
	if (bp->block >= BINS) {
		current -= bp->bytes;
		free((void*)bp);
	} else {
		/* Place the block on a cache list. */
		hp = &cache[bp->block];
		hp->prev->next = bp;
		bp->prev = hp->prev;
		hp->prev = bp;
		bp->next = hp;
	}

	return;
}

void *DmReallocm(void *ptr, unsigned int size, const char *source) {
	register DmBlock *bp, *hp, *op = NULL;
	register size_t b, bytes;
	register void *nptr;

	if (!initialized)
		DmInit();

	/* Compute the free blocks array index. */
	b = (size + ROUNDUP) >> SHIFT;

	/* Compute actual number of bytes needed. */
	bytes = (b << SHIFT) + sizeof(DmBlock);

	if (ptr != NULL) {
		/* Get the block header info. */
		op = (DmBlock *)ptr - 1;
		if (op->magic != DmMAGIC) {
			ErPLog("BUG: Corrupt memory at %p.\n", ptr);
			abort();
		}

		/* If the block is already big enough, just return it. */
		else if (op->bytes >= bytes) {
			op->size = (size_t)size;
			return ptr;
		}
	}

	/* Automatically increase the bin up to the pagebin. */
	if (b < pagebin)
		b = pagebin;

	/* If its over the pagebin, increment it. */
	else
		++b;

	/* Compute the number of bytes (will be more than needed). */
	bytes = (b << SHIFT) + sizeof(DmBlock);

	/* Very large blocks do not get cached. */
	if (b > BINS)
		b = BINS;

	/* Check if there is an available block to reuse. */
	hp = &cache[b];
	if (b < BINS && hp->next != hp) {
		/* Pop next free block off the list. */
		bp = hp->next;
		bp->next->prev = hp;
		hp->next = bp->next;
		if (bp->magic != DmMAGIC) {
			ErPLog("BUG: Corrupt memory at %p.\n", (void*)bp);
			abort();
		}
	} else {
		static unsigned int counter = 0;
		/* Loop until memory becomes available. */
		for (bp = NULL; bp == NULL; ) {
			bp = malloc(bytes);
			if (bp == NULL) {
				/* Out of memory..
				   Sleep for a second and try again. */
				if (!counter)
					ErPLog(
"\nThe system is out of memory.\n"
"This program will pause until memory becomes available.\n\n"
						);
				if (!(counter++ % 60))
					/* output the error each minute */
					/* perror(source); */
					ErPLog("%s: %s\n", source,
					      strerror(errno));
				sleep(1);
				errno = 0;
			}
		}
		if ((current += bytes) > max)
			max = current;
	}

	/* Setup the block header. */
	bp->magic = DmMAGIC;
	bp->source = source;
	bp->bytes = bytes;
	bp->size = (size_t)size;
	bp->block = b;

	/* Add to the used block array. */
	hp = &used[b];
	hp->next->prev = bp;
	bp->next = hp->next;
	hp->next = bp;
	bp->prev = hp;

	/* Get the memory address just after the block. */
	nptr = (void*)++bp;

	if (ptr != NULL) {
		/* Copy the old data. */
		(void)memcpy(nptr, ptr, op->size);

		/* Release the old memory. */
		DmFreem(ptr, source);
	}

	return nptr;
}

char *
DmStrDupm(const char *s1, const char *source) {
	register DmBlock *bp, *hp;
	register size_t b, bytes, len;
	char *s2;

	if (!initialized)
		DmInit();

	len = strlen(s1) + 1;

	/* Compute the free blocks array index. */
	b = (len + ROUNDUP) >> SHIFT;

	/* Compute actual number of bytes needed. */
	bytes = (b << SHIFT) + sizeof(DmBlock);

	/* Very large blocks do not get cached. */
	if (b > BINS) {
		bytes = (size_t)len + sizeof(DmBlock);
		b = BINS;
	}

	/* Check if there is an available block to reuse. */
	hp = &cache[b];
	if (b < BINS && hp->next != hp) {
		/* Pop next free block off the list. */
		bp = hp->next;
		bp->next->prev = hp;
		hp->next = bp->next;
		if (bp->magic != DmMAGIC) {
			ErPLog("BUG: Corrupt memory at %p.\n", (void*)bp);
			abort();
		}
	} else {
		static unsigned int counter = 0;
		/* Get more blocks for future use to cut down on
		   number of malloc() calls */
		register size_t more_bytes;
		if (b < BINS && pagesize > bytes)
			more_bytes = (size_t)(pagesize/bytes) * bytes;
		else
			more_bytes = bytes;
		/* Loop until memory becomes available. */
		for (bp = NULL; bp == NULL; ) {
			bp = malloc(more_bytes);
			if (bp == NULL) {
				/* Out of memory..
				   Sleep for a second and try again. */
				if (!counter)
					ErPLog(
"\nThe system is out of memory.\n"
"This program will pause until memory becomes available.\n\n"
						);
				if (!(counter++ % 60))
					/* output the error each minute */
					/* perror(source); */
					ErPLog("%s: %s\n", source,
					      strerror(errno));
				sleep(1);
				errno = 0;
			}
		}
		if ((current += more_bytes) > max)
			max = current;

		/* Cache the extra blocks for later */
		while (more_bytes != bytes) {
			more_bytes -= bytes;
			bp->magic = DmMAGIC;
			hp->prev->next = bp;
			bp->prev = hp->prev;
			hp->prev = bp;
			bp->next = hp;
			bp = (DmBlock*)((char *)bp + bytes);
		}
	}

	/* Setup the block header. */
	bp->magic = DmMAGIC;
	bp->source = source;
	bp->bytes = bytes;
	bp->size = (size_t)len;
	bp->block = b;

	/* Add to the used block array. */
	hp = &used[b];
	hp->next->prev = bp;
	bp->next = hp->next;
	hp->next = bp;
	bp->prev = hp;

	/* Get the memory address just after the block. */
	s2 = (char *)((void*)++bp);

	/* Copy the old and return a pointer to the string. */
	return memcpy(s2, s1, len);
}

void
DmCheck(void) {
	register DmBlock *bp, *hp;
	register int i, c = 0;

	if (!initialized)
		return;

	/* Check used blocks. */
	for (i = 0; i <= BINS; ++i) {
		for (hp = &used[i], bp = hp->next; bp != hp; bp = bp->next) {
			if (bp->magic != DmMAGIC) {
				ErPLog("BUG: Corrupt (used) memory "
				      "at %p.\n", (void*)bp);
				ErLog("\tsource = \"%s\"\n",
				      bp->source);
				ErLog("\tsize = %u\n",
				      (unsigned int)bp->bytes);
				ErLog("\tblock = %d\n",
				      (int)bp->block);
				c = 1;
			}
		}
	}

	/* Check used blocks. */
	for (i = 0; i < BINS; ++i) {
		for (hp = &cache[i], bp = hp->next; bp != hp; bp = bp->next) {
			if (bp->magic != DmMAGIC) {
				ErPLog("BUG: Corrupt (cached) memory "
				      "at %p.\n", (void*)bp);
				ErLog("\tsource = \"%s\"\n",
				      bp->source);
				ErLog("\tsize = %u\n",
				      (unsigned int)bp->bytes);
				ErLog("\tblock = %d\n",
				      (int)bp->block);
				c = 1;
			}
		}
	}

	if (c) abort();
}

void
DmExemptm(void *ptr, const char *source) {
	register DmBlock *bp, *hp;

	if (!initialized) {
		ErPLog("BUG: %s called exempt before alloc.\n", source);
		abort();
	}

	if (ptr == NULL) {
		ErPLog("BUG: %s called exempt with NULL pointer.\n", source);
		/* same behavior as bu_free() is to just return */
		return;
	}

	/* Get the block header info. */
	bp = (DmBlock *)ptr - 1;
	if (bp->magic != DmMAGIC) {
		ErPLog("BUG: Corrupt memory at %p.\n", ptr);
		abort();
	}

	/* Unlink from used list. */
	bp->next->prev = bp->prev;
	bp->prev->next = bp->next;

	/* Place the block on an exempt list. */
	hp = &exempt[bp->block];
	hp->prev->next = bp;
	bp->prev = hp->prev;
	hp->prev = bp;
	bp->next = hp;

	return;
}
