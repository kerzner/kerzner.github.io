/*
	 Io.c -- MUVES "Io" (input/output utilities) package functions

	created:	88/08/12	D A Gwyn
	modified:       2004/18/02      M J Gillich -- Added IoRdKeyVector
	edited:		08/09/24	C Hunt
			added IoPrParamIntString() to print a string in addition
			to the integer value (SCR1099)

	Many of these routines originated in other packages and were
	migrated here because they were of general utility.
*/
#ifndef lint
static char RCSid[] = "$Id: Io.c,v 1.71 2010/11/03 17:06:36 cmurray Exp $";
#endif

#ifndef DEBUG
#define	NDEBUG				/* disable assertions */
#endif

#ifndef STATIC
#define	STATIC	static
#endif

#include <assert.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <time.h>
#include <ctype.h>
#include <stdio.h>
#include <string.h>
#include <bu.h>

extern FILE	*popen();		/* not necessarily in <stdio.h> */

#ifdef __STDC__
#include	<stdlib.h>		/* getenv */
#else
extern char	*getenv();
#endif

#include <std.h>			/* VLD/VMB standard definitions */

#if STD_C
#include <stdarg.h>
#else
#include <varargs.h>
#endif

#include <Er.h>			/* "Er" package definitions */
#include <Io.h>			/* "Io" package definitions */
#include <stdio.h>
#include <common.h>   /* BRL-CAD 7.2.4+ no longer use config.h (SCR670) */
#include <Dm.h>
#include <Nm.h>			/* "Nm" for Name Pool definition */

/* bizarrely, this include wasn't here before, even though genptr_t needs
   it... */
#include <Rt.h>

extern int IoDebugging;
#define ErDebugging IoDebugging

#define IoPARSE_ERROR "*** Error parsing input file"

static char *IdentBuf = NULL;
static int   IdentLen = 0;        /* total length of Identifier buffer */
static char *LabelBuf = NULL;
static int   LabelLen = 0;        /* total length of Identifier buffer */

/**
        double difftime( time_t time1, time_t time2)

                - already defined in STD_C implementations. Used in the
        'Fa' and 'Io' packages. Simply returns the difference between
        the input variables.
**/
#if ! STD_C
double difftime( time1, time0 )
time_t time1;
time_t time0;
	{
	return	(double)(time1 - time0);
	}
#endif


/**
	void    IoDeblank( char *b )

	IoDeblank() removes leading and trailing white space (including
	new-line characters) from a character string, leaving the result
	left-justified in the original buffer.  An empty string may
	result.
	        
	WARNING:  This should not be applied to strings created by
        DmStrDup(), because DmFree() will lose track of the
        truncated characters.
**/

void
#if STD_C
IoDeblank( char *b )
#else
IoDeblank( b )
	char	*b;			/* buffer being deblanked */
#endif
	{
	register char	*r;		/* -> potential location to set s */
	register char	*s;		/* -> last non-white character + 1 */
	register char	*t;		/* -> first non-white character */

	assert(b != NULL);

 	/* Find first non white-space character, or end of string. */

	for ( t = b; *t != '\0' && isspace( *t ); ++t )
		;

	/* Find last non white-space character, or end of string. */

	s = r = t;

	while ( *r != '\0' )
		if ( !isspace( *r ) )
			s = ++r;
		else
			++r;

	assert(b <= t);			/* (see diagram in Developer Notes) */
	assert(t <= s);
	assert(s <= r);

	/* Left justify by moving isolated segment leftwards, if necessary. */

	if ( t == b )			/* already left-justified; save time */
		*s = '\0';		/* just truncate at proper place */
	else	{
		assert(t > b);

		r = b;			/* r moves through target segment */

		while ( t < s )		/* t moves through source segment */
			*r++ = *t++;	/* left justify */

		assert(r < s);		/* r == s would have been t == b */

		*r = '\0';		/* truncate target at proper place */
		}
	}

/*
	IoRmblanks() removes leading and trailing white space (including
	new-line characters) from a character string, leaving the result
	left-justified in the original buffer.  An empty string may
	result.
*/

void
#if STD_C
IoRmblanks( char *b )
#else
IoRmblanks( b )
	char	*b;			/* buffer being deblanked */
#endif
	{
	register char	*r;		/* -> potential location to set s */
	register char	*s;		/* -> last non-white character + 1 */
	register char	*t;		/* -> first non-white character */

	assert(b != NULL);

 	/* Find first non white-space character, or end of string. */

	for ( t = b; *t != '\0' && isspace( *t ); ++t )
		;

	/* Find last non white-space character, or end of string. */

	s = r = t;

	while ( *r != '\0' )
		if ( !isspace( *r ) )
			s = ++r;
		else
			++r;

	assert(b <= t);			/* (see diagram in Developer Notes) */
	assert(t <= s);
	assert(s <= r);

	/* Left justify by moving isolated segment leftwards, if necessary. */

	assert(t >= b);

	r = b;			/* r moves through target segment */

	while ( t < s )		/* t moves through source segment */
		if( !isspace (*t) )
			*r++ = *t++;	/* left justify */
		else
			t++;
	assert(r <= s);		/* r == s would have been t == b */

	*r = '\0';		/* truncate target at proper place */
	}

/**
	bs_type	IoStrToInt(const char *str, int *i)

	IoStrToInt() is a convenience function that converts the string 
	passed to it into an integer.  IoStrToInt() returns the bs_type
	values of GOOD, BAD, and UGLY depending on the result of the
	conversion.

	GOOD: The string was converted to an integer with no problems.

	BAD: Part of the string was converted to an integer, but some
	trailing garbage was detected.  Nonetheless, some conversion
	still occurred and it may be useful to the caller.

	UGLY: No conversion occured on any part of the string.
**/

bs_type
#if STD_C
IoStrToInt(const char *str, int *i)
#else
IoStrToInt()
	const char	*str;
	int		*i;
#endif
{
    char *tail = NULL;

    if ((*i = strtod(str, &tail)) == 0.0 || tail == str || *tail != '\0')
    {
	if (tail == str)      /* no conversion */
	    return(bs_ugly);

	if (*tail != '\0')    /* trailing garbage */
	    return(bs_bad);
    }

    return(bs_good);
}

/**
	bs_type	IoStrToDouble(const char *str, double *d)

	IoStrToDouble() is a convenience function that converts the string 
	passed to it into a double.  IoStrToDouble() returns the bs_type
	values of GOOD, BAD, and UGLY depending on the result of the
	conversion.

	GOOD: The string was converted to a double with no problems.

	BAD: Part of the string was converted to an double, but some
	trailing garbage was detected.  Nonetheless, some conversion
	still occurred and it may be useful to the caller.

	UGLY: No conversion occured on any part of the string.
**/

bs_type
#if STD_C
IoStrToDouble(const char *str, double *d)
#else
IoStrToInt()
	const char	*str;
	double		*d;
#endif
{
    char *tail = NULL;

    if ((*d = strtod(str, &tail)) == 0.0 || tail == str || *tail != '\0')
    {
        if (tail == str)      /* no conversion */
            return(bs_ugly);

        if (*tail != '\0')    /* trailing garbage */
            return(bs_bad);
    }

    return(bs_good);
}


/**
	void    IoDecomment( char *b )

	IoDecomment() removes trailing white space (including new-line
	characters) followed by an optional comment (defined as all
	characters after and including any `#' character that is either
	at the start of the string or immediately preceded by a space or
	tab character) from a character string, leaving the result left-
	justified in the original buffer.  An empty string may result.
       
	The specified condition for a '#' character to be treated as a
        comment character allows a string such as "fuel oil #2" to be
        parsed without part of the string being treated as a comment.

        WARNING:  This should not be applied to strings created by
        DmStrDup(), because DmFree() will lose track of the
        truncated characters.

        The macro IoCOMMENT_CHAR is defined to be '#' for the
        convenience of other packages that may wish to parse comments
        themselves consistent with this more global convention.
**/

void
#if STD_C
IoDecomment( char *b )
#else
IoDecomment( b )
	char		*b;		/* buffer being decommented */
#endif
	{
	register char	*s;		/* -> last non-white character + 1 */
	register char	*t;		/* -> last non-comment character + 1 */

	assert(b != NULL);

	/* Find first comment character, or end of string. */

	t = s = b;

	while ( *t != '\0' && 
		(*t != IoCOMMENT_CHAR || 
			t > b && t[-1] != '\t' && t[-1] != ' ') 
	      )
		if ( !isspace( *t ) )
			s = ++t;
		else
			++t;

	assert(b <= s);			/* (see diagram in Developer Notes) */
	assert(s <= t);

	/* Remove trailing white space preceding comment character (or EOS). */

	*s = '\0';			/* just truncate at proper place */
	}


/**
	const char *IoDirCat( const char *s1, const char *s2 )

	Construct a UNIX path name from 's1' and 's2' by concatenating
	them with a slash in-between and returning a pointer to the
	new string in a static area.  This static area will be overwritten
	on the next call to this routine.
**/
const char *
#if STD_C
IoDirCat( const char *s1, const char *s2 )
#else
IoDirCat( s1, s2 )
const char *s1, *s2;
#endif
	{	static char buffer[BUFSIZ];
	assert( s1 != NULL && s2 != NULL );
	assert( strlen( s1 ) + strlen( s2 ) + 2 <= BUFSIZ );
	if( s2[0] == '.' && s2[1] == '/' )
		s2 += 2; /* drop redundant "./" */
	(void) sprintf( buffer, "%s/%s", s1, s2 );
	return buffer;
	}

/**
	const char      *IoCharStr( int c )

	IoCharStr() returns a printable representation of the character
	given as its argument, which is assumed to be a value that might
	be returned by getc() (including EOF).  The returned value is a
	pointer to an internal array with static storage duration, so a
	copy must be made if it is to be retained past another call to
	IoCharStr() or IoStrStr().  The maximum possible length of the
	returned string (not including null terminator) is given by the
	macro IoMAX_CharStr.

	Example input characters and corresponding returned strings
	(USASCII code set assumed):

		EOF		"EOF"
		'\0'		"NUL"
		'\t'		"\\t"
		' '		" "
		'\030'		"^X"
		'@'		"@"
		'X'		"X"
		'x'		"x"
		'\177'		"^?"
		'\230'		"~^X"
		'\330'		"~X"

	Note that this implementation depends heavily on macros in <std.h>.
	Character identification is much easier using the ASCII domain.
**/

const char *
#if STD_C
IoCharStr( register int c )
#else
IoCharStr( c )
	register int	c;		/* character to be converted */
#endif
	{
	static char	conv[4];	/* holds result to be returned */
	register char	*cp;		/* -> conv[.] */

	if ( c == '\0' )
		{
		static const char	nulstr[] = "NUL";
		assert(strlen( nulstr ) <= IoMAX_CharStr);
		return nulstr;
		}
	else if ( c == EOF )
		{
		static const char	eofstr[] = "EOF";
		assert(strlen( eofstr ) <= IoMAX_CharStr);
		return eofstr;
		}

	cp = conv;			/* left-justify result string */

	c &= 0xFF;			/* 8-bit code set assumed */
	c = fromhostc( c );		/* map host char code to ASCII */

	if ( (c & ~0x7F) != 0 )		/* catches any high bit, for safety */
		{
		*cp++ = '~';		/* we'll call it a "meta" character */
		c &= 0x7F;		/* map remainder to 7-bit range */
		}

	if ( c == 0x7F )
		{
		*cp++ = '^';		/* special-case "control" character */
		c = 0x3F;		/* ASCII '?' */
		}
	else if ( c < 0x20 )
		{
		if ( c >= 0x07 && c <= 0x0D )
			{		/* special "C" escape sequence */
			*cp++ = '\\';
			c = fromhostc( "abtnvfr"[c - 0x07] );
			}
		else	{		/* normal "control" character */
			*cp++ = '^';
			c += 0x40;	/* map to ASCII '@' through '_' */
			}
		}

	*cp++ = tohostc( c );		/* map ASCII to host char code */
	*cp = '\0';			/* append null-byte terminator */
	assert(strlen( conv ) <= IoMAX_CharStr);
	return (const char *)conv;
	}


/**
	const char      *IoStrStr( const char *string )

	IoStrStr() returns a printable representation of the null-
	terminated string given as its argument; each character is
	individually mapped as described for IoCharStr().  The return
	value is a pointer to an internal array with static storage
	duration, so a copy must be made if it is to be retained past
	another call to IoStrStr().  If the converted string exceeds
	the size of the internal array, the final characters will be
	converted to "..." at the end of the buffer.
**/

const char *
#if STD_C
IoStrStr( register const char *string )
#else
IoStrStr( string )
	register const char *string;	/* -> string to be converted */
#endif
	{
	static char		conv[IoMAX_InsStr + 1];
					/* holds result of conversion */
	register char		*cp;	/* -> conv[.] */

	assert(IoMAX_InsStr >= 3);	/* minimum is "..." */
	assert(IoMAX_CharStr >= 3);	/* so "..." is safe to copy */
	assert(IoMAX_InsStr >= IoMAX_CharStr - 1);	/* must have "slop" */

	if ( string == NULL )		/* just in case */
		{
		static const char	nulstr[] = "[NULL]";
		return nulstr;
		}

	for ( cp = conv; *string != '\0'; ++string )
		{
		register const char	*s;	/* -> mapped-character text */

		/* the following is not perfect, but it should be good enough */
		if ( cp >= &conv[IoMAX_InsStr - IoMAX_CharStr - 1] )
			{		/* internal buffer overflow */
			cp = strcpy( cp, "..." ) + 3;
			break;
			}

		s = IoCharStr( (int)(unsigned char)*string );

		assert(s != NULL);
		assert(strlen( s ) <= IoMAX_CharStr);

		cp = strcpy( cp, s ) + strlen( s );
		}

	assert(cp <= &conv[IoMAX_InsStr]);
	*cp = '\0';			/* append null-byte terminator */
	return (const char *)conv;
	}


/*
	const IoLineTokens *IoTokenize(const char *str, const char *delstr)

	IoTokenize() takes the string passed to it and breaks it into
	its comprising tokens, delimited by the characters specified
	and passed to it in delstr.  IoTokenize() is a wrapper for strtok(),
	provided for programming convenience.  The returned value,
	IoLineTokens *, contains the number of tokens parsed in str
	and an array of pointers to each token (in string format).

	Example:

	IoLineTokens	*input;
	input = IoTokenize(line, " \t");

	- input->nfields contains the number of fields parsed from the
	input string.

	- input->fields[0] is a copy of the string provided as input to the
	function.

	- input->fields[1] to input->fields[input->nfields] references the
	respective field parsed from the input string.
	
	NOTE: The calling function is expected to handle the outcome
	where IoTokenize() returns NULL and an error condition is set.
*/

IoLineTokens *
#if STD_C
IoTokenize(const char *str, const char *delstr)
#else
IoTokenize()
    const char *str;		/* string to be tokenized. */
    const char *delstr;		/* delimiters */
#endif
{
    int		len;            	/* length of input string */
    int		count;			/* number of fields in input string */
    char	strcopy[IoMAXLINELEN];	/* copy of input string */
    char	*curtok;         	/* current token parsed by strtok() */
    char	**tokens;		/* array of the fields in string */
    IoLineTokens *result;		/* return value */
    const char	*ErMODULE_NAME = "IoTokenize";	/* For "Er" package */
    int		i;			/* misc/loop control */

    len = strlen(str);

    if (len + 1 > IoMAXLINELEN)
    {
	ErPLog("IoTokenize(): Input line '%s' is too long for buffer\n", str);
	ErSet(IoTOO_LONG);

	return NULL;
    }

    if (strcpy(strcopy, str) == NULL)
    {
	ErPLog("IoTokenize(%s) failed\n", str);
	ErSet(IoBAD_STRING);

	return NULL;
    }

    /*
	First pass.  Count the fields.
    */
    count = 0;
    if ((curtok = strtok(strcopy, delstr)) == NULL)
    {
	/* Right now, this is not considered a fatal error. */
	ErPLog("IoTokenize(): no tokens were parsed from string '%s'\n",
	    strcopy);

	return NULL;
    }

    do
    {
	count++;
    } while ((curtok = strtok(NULL, delstr)) != NULL);

    /*
	Allocate space for the IoLineTokens structure that will be filled in.
    */
    result = (IoLineTokens *)DmXalloc(IoLineTokens);

    /*
    SCR 1133 - This code stores the original string in the [0] position
     and then all the others. Therefore, it needs count+1 array positions.
    */
    tokens = (char **)DmCalloc(count+1, sizeof(char *));

    /*
	Re-copy the input string, since strtok clobbered it during the
	first pass.
    */
    if (strcpy(strcopy, str) == NULL)
	goto failure;

    /*
	Set the very first field to be the entire, unparsed input line,
	like awk's $0.
    */
    tokens[0] = DmStrDup(str);

    /*
	Second pass.  Tokenize the input string.
    */
    curtok = strtok(strcopy, delstr);
    for (i = 1; i <= count; i++)
    {
	tokens[i] = DmStrDup(curtok);

	curtok = strtok(NULL, delstr);
    }

    result->nfields = count;
    result->linelen = strlen(str) + 1;	/* Include '\0' for safety */
    result->fields  = tokens;

    if (IoDebugging)
    {
	ErDEBUG(ErF("line: %s", str));
	ErDEBUG(ErF("nfields: %d", result->nfields));

	for (i = 0; i <= result->nfields; i++)
	    ErDEBUG(ErF("    fields[%d]: %s", i, result->fields[i]));
    }

    return result;

failure:
    ErPLog("IoTokenize(): out of memory\n");
    ErSet(IoMEMORY);

    return NULL;
}


void
#if STD_C
IoLineTokensFree(IoLineTokens *old)
#else
IoLineTokensFree(old)
    IoTokStr	*old;
#endif
{
    int		i;

    for (i = 0; i <= old->nfields; i++)
	DmFree((genptr_t)old->fields[i]);
    DmFree((genptr_t)old->fields);
    DmFree((genptr_t)old);
}


/**
	const char *IoInsert( register const char *templateStr, 
		const char *substitute )

	IoInsert() copies the template string into an internal buffer of
	static storage duration, replacing every isolated occurrence of
	the '^' character within the template with the specified
	substitute string.  Two adjacent '^' characters in the template
	are replaced by a single '^' character in the buffer.
	IoInsert() returns a pointer to the internal filled-in buffer,
	unless the resulting substituted string would be too large for
	the buffer, in which case a null pointer is returned.  The macro
	IoMAX_InsStr gives the maximum supported result string length
	(typically 255).
**/

#define	IoCARET	'^'			/* insertion marker */

const char *
#if STD_C
IoInsert( register const char *templateStr, const char *substituteStr )
#else
IoInsert( templateStr, substituteStr )
	register const char	*templateStr;	/* template containing '^'s */
	const char		*substituteStr;	/* string to be substituted */
#endif
	{
	static char		ins[IoMAX_InsStr + 1];	/* holds result */
	register char		*ip;	/* -> ins[.] */

	assert(templateStr != NULL);
	assert(substituteStr != NULL);

	/* Copy and fill in template, checking for overflow. */

	for ( ip = ins; ; )
		switch ( (int)*templateStr )
			{
		case '\0':		/* end of template */
			*ip++ = '\0';
			return (const char *)ins;

		case IoCARET:		/* possible insertion point */
			if ( *++templateStr == IoCARET )
				*ip++ = *templateStr++;	/* literal caret char */
			else	{
				register const char	*sp;
					/* -> substitute[.] */

				for ( sp = substituteStr; *sp != '\0'; )
					{
					if ( ip == &ins[IoMAX_InsStr] )
						goto overflow;

					*ip++ = *sp++;
					}
				}

			break;

		default:
			if ( ip == &ins[IoMAX_InsStr] )
				goto overflow;

			*ip++ = *templateStr++;
			break;
			}

    overflow:

	ErSet( IoOVERFLOW );
	return (const char *)NULL;
	}


/**
	MuvesBool    IoSafeName( const char *pathname )

	IoSafeName() checks the specified pathname to determine whether
	it is safe for use as a relative pathname, assuming that it is
	not safe to allow the pathname to access files outside the scope
	of the current working directory's hierarchy.  For example,
	"foo/../../bar" and "/etc/passwd" are considered unsafe names.
	If the pathname is deemed safe, IoSafeName() returns mTrue,
	otherwise it returns mFalse.

	Note that this form of safety checking works only if it is known
	that the current working directory hierarchy contains no links.
**/

MuvesBool
#if STD_C
IoSafeName( const char *pathname )
#else
IoSafeName( pathname )
	const char		*pathname;
#endif
	{
	register const char	*p = pathname;	/* -> pathname[.] */

	assert(pathname != NULL);

	if ( *p == '/'			/* absolute path */
	  || *p == '.' && p[1] == '.'	/* moves up (probably) */
	   )
		return mFalse;

	while ( *p != '\0' )
		if ( *p++ == '/' )
			if ( *p == '.' && p[1] == '.' )	/* moves up */
				return mFalse;

	return mTrue;			/* no problems found */
	}


/**
	bs_type IoGetLine( char *line_buffer, int size, FILE *fp )

	IoGetLine() reads the next text line from the open stream into a
	caller-supplied buffer.  If EOF is reached before reading a
	valid line, bs_bad is returned; if the specified buffer size is
	exceeded or an I/O error occurs, an appropriate global error
	index value is set and bs_ugly is returned; otherwise bs_good is
	returned.  The trailing new-line character is removed.
**/

bs_type
#if STD_C
IoGetLine( char *line_buffer, int size, FILE *fp )
#else
IoGetLine( line_buffer, size, fp )
	char		*line_buffer;
	int		size;
	FILE		*fp;
#endif
	{
	register char	*p;		/* -> new-line character in buffer */

	assert(line_buffer != NULL);
	assert(size > 0);
	assert(fp != NULL);

	if ( fgets( line_buffer, size, fp ) == NULL )
		{
		if ( feof( fp ) )
			return bs_bad;	/* EOF at beginning of line */

		assert(ferror( fp ));
		ErPLog( "Couldn't read line from file because: %s.\n",
			IoStrPerror() );
		ErSet( IoREAD_ERROR );
		return bs_ugly;		/* malfunction */
		}
	
	if ( (p = strchr( line_buffer, '\n' )) == NULL )
		{
		if ( feof( fp ) )
			return bs_bad;	/* EOF in middle of line */

		ErSet( IoTOO_LONG );
		ErPLog( "Input line longer than %d characters.\n", size );
		return bs_ugly;		/* buffer not large enough */
		}

	*p = '\0';			/* trim off new-line character */
	return bs_good;			/* OK, got a good input line */
	}


/**
	bs_type IoGetTrim( char *line_buffer, int size, FILE *fp )

	IoGetTrim() reads the next text line from the open stream into a
	caller-supplied buffer, removing comments and leading and
	trailing whitespace (including the new-line character).  An
	empty string may result.  If EOF is reached before reading a
	valid line, bs_bad is returned; if the specified buffer size is
	exceeded or an I/O error occurs, an appropriate global error
	index value is set and bs_ugly is returned; otherwise bs_good is
	returned.
**/

bs_type
#if STD_C
IoGetTrim( char *line_buffer, int size, FILE *fp )
#else
IoGetTrim( line_buffer, size, fp )
	char			*line_buffer;
	int			size;
	FILE			*fp;
#endif
	{
	register bs_type	status;

	assert(line_buffer != NULL);
	assert(size > 0);
	assert(fp != NULL);

	if ( (status = IoGetLine( line_buffer, size, fp )) == bs_good )
		{
		IoDecomment( line_buffer );
		IoDeblank( line_buffer );
		}

	assert(status == bs_good || status == bs_bad || status == bs_ugly);
	return status;
	}


/**
	bs_type IoGetNonempty( char *line_buffer, int size, FILE *fp )

	IoGetNonempty() reads the next non-comment, non-blank text
	line from the open stream into a caller-supplied buffer,
	removing comments and leading and trailing whitespace (including
	the new-line character).  An empty string will never result.  If
	EOF is reached before reading a valid nonempty line, bs_bad is
	returned; if the specified buffer size is exceeded or an I/O
	error occurs, an appropriate global error index value is set and
	bs_ugly is returned; otherwise bs_good is returned.
**/

bs_type
#if STD_C
IoGetNonempty( char *line_buffer, int size, FILE *fp )
#else
IoGetNonempty( line_buffer, size, fp )
	char			*line_buffer;
	int			size;
	FILE			*fp;
#endif
	{
	register bs_type	status;

	assert(line_buffer != NULL);
	assert(size > 0);
	assert(fp != NULL);

	while ( (status = IoGetTrim( line_buffer, size, fp )) == bs_good
	     && line_buffer[0] == '\0'	/* empty line after trimming */
	      )
		;

	assert(status == bs_good || status == bs_bad || status == bs_ugly);
	return status;
	}


/**
	const char      *IoMUVES( void )

	IoMUVES() returns the value of the MUVES environment variable
	(MUVES system root directory absolute path) or a default
	value (typically "/usr/muves") if MUVES is not set.  The
	value is that of an object with static storage duration.

	NOTE:  In a UNIX environment, a subsequent getenv() will not
	clobber this string.  In non-UNIX environments, it might, so
	DmStrDup() should be used to make a safe copy.  Since MUVES
	is explicitly UNIX-based, I did not take that approach here.
	(The main problem with DmStrDup() is recovering if it fails.)
**/

const char *
#if STD_C
IoMUVES( void )
#else
IoMUVES()
#endif
	{
#ifndef DEF_ROOT
#define	DEF_ROOT	"/usr/muves"
#endif
	static const char	def[] = DEF_ROOT;
	static const char	*muves = NULL;

	if ( muves == NULL ) {
		muves = getenv( "MUVES" );
		if ( muves == NULL ) {
			ErPLog("MUVES undefined.\n");
			exit(-1);
		}
		muves = DmStrDup(muves);
		DmExempt((void*)muves);
	}
	assert(muves != NULL);
	return muves;
	}

/**
	MuvesBool IoNewer( const char *path1, const char *path2 )

	If the file named by path1 is newer than the file named by
	path2 (i.e., if modification time of path1 is later than path2),
	IoNewer() returns mTrue.  Otherwise, mFalse is returned.
**/

MuvesBool
#if STD_C
IoNewer( const char *path1, const char *path2 )
#else
IoNewer( path1, path2 )
const char *path1;
const char *path2;
#endif
	{
	struct stat statbuf1;
	struct stat statbuf2;
	const char *ErMODULE_NAME = "IoNewer";

	ErDEBUG( ErF( "(%s,%s)\n", path1, path2 ) );

	if( stat( path1, &statbuf1 ) == -1 )
		{
		ErPLog( "Can't access \"%s\" because: %s.",
			path1, IoStrPerror() );
		return mFalse;
		}
	if( stat( path2, &statbuf2 ) == -1 )
		{
		ErPLog( "Can't access \"%s\" because: %s.",
			path2, IoStrPerror() );
		return mFalse;
		}

	if( difftime( statbuf1.st_mtime, statbuf2.st_mtime ) > 0 )
		return mTrue;

	return mFalse;
	}

/**
	FILE    *IoOpenFile( const char *mode, long errnum, ... )

	IoOpenFile() opens the file named by the concatenation of its
	variable character-string arguments for read/write/append
	according to the specified mode (which is passed to fopen());
	it returns NULL if memory could not be allocated to build the
	pathname or if the file could not be opened (in which case
	ErIndex is set to `errnum').  The final argument must be
	(char *)NULL.
**/

/*VARARGS*/
FILE *
#if STD_C
IoOpenFile( const char *mode, long errnum, ... )
	{
#else
IoOpenFile( va_alist )
	va_dcl
	{
	const char	*mode;
	long		errnum;
#endif
	va_list		ap;
	register FILE	*fp;		/* opened file stream pointer */
	register char	*p;		/* -> filename segment */
	register char	*cp;		/* -> end of partial filename */
	register int	name_len;	/* string allocation length */
	char		*fname;		/* full path name of file */
	const char *ErMODULE_NAME = "IoOpenFile";

	/* Allocate space for filename. */

#if STD_C
	va_start( ap, errnum );
#else
	va_start( ap );
	mode = va_arg( ap, char * );
	errnum = va_arg( ap, long );
#endif
	assert(mode != NULL);
	assert(*mode == 'r' || *mode == 'w' || *mode == 'a');
	assert(errnum >= 0L);

	for ( name_len = 1; (p = va_arg( ap, char * )) != NULL; )
		name_len += strlen( p );

	va_end( ap );

	fname = cp = (char *)DmCalloc(name_len, sizeof(char ));

	/* Construct concatenated filename. */

#if STD_C
	va_start( ap, errnum );
#else
	va_start( ap );
#ifndef CTRACE
	(void)	/* sorry! */
#endif
	va_arg( ap, char * );		/* skip mode */
#ifndef CTRACE
	(void)	/* sorry! */
#endif
	va_arg( ap, long );		/* skip errnum */
#endif

	while ( (p = va_arg( ap, char * )) != NULL )
		while ( (*cp = *p++) != '\0' )
			++cp;

	va_end( ap );
	assert(cp != fname);
	assert(*cp == 0);

	/* Try to open the file. */

	ErDEBUG( ErF( "(%s): %s", mode, fname ) );

	if ( (fp = fopen( fname, mode )) == NULL )
		{
		ErDEBUG( ErF( "Couldn't open file \"%s\" because: %s.\n",
			      fname, IoStrPerror() ) );
		ErSet( errnum );
		}

	/* Deallocate filename space. */

	DmFree((genptr_t)fname );
	return fp;			/* (may be NULL) */
	}


/**
	const char      *IoVersion( void )

	IoVersion() returns a pointer to an internal static string
	containing the version of the current MUVES release; this is
	typically a date/time stamp indicating when the source
	distribution was made.  If the version cannot be determined,
	a null pointer is returned.
**/

/* NOTE: VuQueueDistribute() relies on the machine type to be the last
   field in the version string. */ 
const char *
#if STD_C
IoVersion( void )
#else
IoVersion()
#endif
	{	static char		version[IoMAX_InsStr] = "";
		static char		cmdbuf[IoMAX_InsStr] = "";
		register const char	*muves;
		register FILE		*fp;

	if ( version[0] != '\0' )
		return (const char *)version;

	if ( (muves = IoMUVES()) == NULL )
		return NULL;		/* ErIndex already set */

	(void) sprintf( cmdbuf, "SHELL=/bin/sh %s/bin/version", muves );
	if( strlen( cmdbuf ) > sizeof(cmdbuf) - 1 )
		{
		ErSet( IoTOO_LONG );
		ErPLog( "BUG: IoVersion: internal buffer too small.\n" );
		return NULL;
		}
	if( (fp = popen( cmdbuf, "r" )) == NULL )
		{
		ErSet( IoREAD_ERROR );
		ErPLog( "BUG: IoVersion: can't execute \"%s\"\n", cmdbuf );
		version[0] = '\0';
		return NULL;
		}

	switch( IoGetLine( version, IoMAX_InsStr, fp ) )
		{
	case bs_bad:
		assert( ! ErIsSet() );
		if( ! ErIsSet() )
			ErSet( IoREAD_ERROR );
		/* FALLTHRU*/
	case bs_ugly : /* error index already set */
		ErPLog( "BUG: IoVersion: can't get string from \"%s\".\n",
			cmdbuf );
		version[0] = '\0';
		break;
		}

	if ( pclose( fp ) != 0 )
		{
		if( ! ErIsSet() )
			ErSet( IoREAD_ERROR );
		ErPLog( "BUG: IoVersion: can't shutdown \"%s\".\n", cmdbuf );
		}

	assert(version[0] != 0 || ErIsSet());

	return version[0] == '\0' ? (const char *)NULL
				  : (const char *)version;
	}

#include <errno.h>

/**
        const char *IoStrPerror( void )

**/
const char *
#if STD_C
IoStrPerror( void )
#else
IoStrPerror()
#endif
        {	extern int errno;

	return	strerror( errno );

        }

/**
	MuvesBool IoCopyBool( IoParamBool *tobp, IoParamBool *frombp )

	This function sets the value of the boolean parameter pointed
	to by it's first argument, to that of the second arg.  If all goes
	well, it returns the copied value, but if the second parameter was
	not set a programming error diagnostic is issued, the first
	parameter will be reset (invalidated), and -1 is returned.
**/
MuvesBool
#if STD_C
IoCopyBool( IoParamBool *tobp, IoParamBool *frombp )
#else
IoCopyBool( tobp, frombp )
IoParamBool *tobp, *frombp;
#endif
	{
	if( ! IoIsSetBool( frombp ) )
		{
		ErPLog( "BUG: parameter \"%s\" not set.\n",
			frombp->key );
		assert( IoIsSetBool( frombp ) );
		IoResetBool( tobp );
		return -1;
		}
	return IoSetBool( tobp, IoGetBool( frombp ) );
	}


/**
	double IoCopyDbl( IoParamDbl *todbblp, IoParamDbl *fromdblp )

	This function sets the value of the double-precision parameter
	pointed to by it's first argument, to that of the second arg.  If all
	goes well, it returns the copied value, but if the second parameter
	was not set a programming error diagnostic is issued, the first
	parameter will be reset (invalidated), and -1.0 is returned.
**/
double
#if STD_C
IoCopyDbl( IoParamDbl *todblp, IoParamDbl *fromdblp )
#else
IoCopyDbl( todblp, fromdblp )
IoParamDbl *todblp, *fromdblp;
#endif
	{
	if( ! IoIsSetDbl( fromdblp ) )
		{
		ErPLog( "BUG: parameter \"%s\" not set.\n",
			fromdblp->key );
		assert( IoIsSetDbl( fromdblp ) );
		IoResetDbl( todblp );
		return -1.0;
		}
	return IoSetDbl( todblp, IoGetDbl( fromdblp ) );
	}

/**
	const char *IoCopyString( IoParamStr *tostrp,
				  const IoParamStr *fromstrp )

	This function copies the value of the text string
	parameter from the second arg to the first arg.  The first
	parameter must be unset and the second must be set, otherwise
	a programming error diagnostic is issued, and NULL is
	returned.  If all goes well, this routine returns a pointer to
	the copied value.
**/
const char *
#if STD_C
IoCopyString( IoParamStr *tostrp, const IoParamStr *fromstrp )
#else
IoCopyString( tostrp, fromstrp )
IoParamStr *tostrp;
const IoParamStr *fromstrp;
#endif
	{
	if( IoIsSetString( tostrp ) )
		{
		ErPLog( "BUG: parameter \"%s\" already set.\n",
			tostrp->key );
		assert( ! IoIsSetString( tostrp ) );
		return NULL;
		}
	if( ! IoIsSetString( fromstrp ) )
		{
		ErPLog( "BUG: parameter \"%s\" not set.\n",
			fromstrp->key );
		assert( IoIsSetString( fromstrp ) );
		return NULL;
		}
	tostrp->val = fromstrp->val;
	return tostrp->val;
	}

/**
	VmVect *IoCopyVec( IoParamVec *tovecp, IoParamVec *fromvecp )

	This function sets the double-precision 3-d vector parameter
	pointed to by it's first argument, to that of the second arg.  If
	all goes well, it returns the address of the copied VmVect struct,
	but if the second parameter was not set a programming error diag-
	nostic is issued, the first parameter will be reset (invalidated),
	and NULL is returned.
**/
VmVect *
#if STD_C
IoCopyVec( IoParamVec *tovecp, IoParamVec *fromvecp )
#else
IoCopyVec( tovecp, fromvecp )
IoParamVec *tovecp, *fromvecp;
#endif
	{
	if( ! IoIsSetVec( fromvecp ) )
		{
		ErPLog( "BUG: parameter \"%s\" not set.\n",
			fromvecp->key );
		assert( IoIsSetVec( fromvecp ) );
		IoResetVec( tovecp );
		return (VmVect *) NULL;
		}
	return IoSetVec( tovecp, IoGetVec( fromvecp ) );
	}

/**
 	double IoGetBool( IoParamBool *bp )

	Get double-precision parameter from the address given by bp.
	This routine will succeed and return the requested parameter
	value if this parameter has been set.  If the parameter is not set
	it is considered a programming error.  An appropriate diagnostic
	will be printed, an assertion will trip (if enabled) and -1 will
	be returned.
**/
MuvesBool
#if STD_C
IoGetBool( IoParamBool *bp )
#else
IoGetBool( bp )
IoParamBool *bp;
#endif
	{
	if( ! IoIsSetBool( bp ) )
		{
		ErPLog( "BUG: parameter \"%s\" not set.\n", bp->key );
		assert( IoIsSetBool( bp ) );
		return -1;
		}
	else
		return bp->val;
	}

/**
	double IoGetDbl( IoParamDbl *dblp )

	Get double-precision parameter from the address given by
	dblp.  This routine will succeed and return the requested parameter
	value if this parameter has been set.  If the parameter is not set
	it is considered a programming error.  An appropriate diagnostic
	will be printed, an assertion will trip (if enabled) and -1.0 will
	be returned.
**/
double
#if STD_C
IoGetDbl( IoParamDbl *dblp )
#else
IoGetDbl( dblp )
IoParamDbl *dblp;
#endif
	{
	if( ! IoIsSetDbl( dblp ) )
		{
		ErPLog( "BUG: parameter \"%s\" not set.\n", dblp->key );
		assert( IoIsSetDbl( dblp ) );
		return -1.0;
		}
	else
		return dblp->val;
	}

/**
	const char *IoGetString( const IoParamStr *strp )

	Get the text parameter from the address given by
	strp.  This routine will succeed and return the requested parameter
	value if this parameter has been set.  If the parameter is not set
	it is considered a programming error.  An appropriate diagnostic
	will be printed, an assertion will trip (if enabled) and NULL will
	be returned.
**/
const char *
#if STD_C
IoGetString( const IoParamStr *strp )
#else
IoGetString( strp )
const IoParamStr *strp;
#endif
	{
	if( ! IoIsSetString( strp ) )
		{
		ErPLog( "BUG: parameter \"%s\" not set.\n", strp->key );
		assert( IoIsSetString( strp ) );
		return (const char *) NULL;
		}
	else
		return strp->val;
	}

/**
	VmVect *IoGetVec( IoParamVec *vecp )

	Get 3-d double-precision vector parameter from the address
	given by vecp.  This routine will succeed and return the requested
	parameter value if this parameter has been set.  If the parameter
	is not set it is considered a programming error.  An appropriate
	diagnostic will be printed, an assertion will trip (if enabled) and
	NULL will be returned.
**/
VmVect *
#if STD_C
IoGetVec( IoParamVec *vecp )
#else
IoGetVec( vecp )
IoParamVec *vecp;
#endif
	{
	if( ! IoIsSetVec( vecp ) )
		{
		ErPLog( "BUG: parameter \"%s\" not set.\n", vecp->key );
		assert( IoIsSetVec( vecp ) );
		return NULL;
		}
	else
		return &vecp->val;
	}

/**
	void IoResetBool( IoParamBool *bp )

	Clear boolean parameter at the specified address.
	This function clears memory for this parameter and marks it as un
**/
void
#if STD_C
IoResetBool( IoParamBool *bp )
#else
IoResetBool( bp  )
IoParamBool *bp;
#endif
	{
	bp->val = 0;
	bp->status = IoUnset;
	}

/**
	MuvesBool IoSetBool( IoParamBool *bp, MuvesBool value )

	Set the boolean parameter at the specified address to the
	specified value.  This function takes care of storing the value
	and marks this parameter as set.  It returns the new value.
**/
MuvesBool
#if STD_C
IoSetBool( IoParamBool *bp, MuvesBool value )
#else
IoSetBool( bp, value )
IoParamBool *bp;
MuvesBool value;
#endif
	{
	bp->status = IoSet;
	return bp->val = value;
	}

/**
	double IoSetDbl( IoParamDbl *dblp, double value )

	Set double-precision parameter at the specified address to
	the specified value.  This function takes care of storing the value
	and marks this parameter as being set.  It returns the new value.
**/
double
#if STD_C
IoSetDbl( IoParamDbl *dblp, double value )
#else
IoSetDbl( dblp, value )
IoParamDbl *dblp;
double value;
#endif
	{
	dblp->status = IoSet;
	return dblp->val = value;
	}

/**
	VmVect *IoSetVec( IoParamVec *vecp, VmVect *valp )

	Set 3-d double-precision vector parameter at the specified
	address to the values contained in the provided VmVect structure.
	This function takes care of storing the vector and marks this
	parameter as set.  It returns the address of the new vector.
**/
VmVect *
#if STD_C
IoSetVec( IoParamVec *vecp, VmVect *valp )
#else
IoSetVec( vecp, valp )
IoParamVec *vecp;
VmVect *valp;
#endif
	{
	VmCopy( &vecp->val, valp );
	vecp->status = IoSet;
	return &vecp->val;
	}

/**
	void IoResetDbl( IoParamDbl *dblp )

	Clear double-precision parameter at the specified address.
	This function clears memory for this parameter and marks it as unset.
**/
void
#if STD_C
IoResetDbl( IoParamDbl *dblp )
#else
IoResetDbl( dblp  )
IoParamDbl *dblp;
#endif
	{
	dblp->val = -1.0;
	dblp->status = IoUnset;
	}

/**
        void IoResetVec( IoParamVec *vecp )

        Clear 3-d double-precision vector parameter at the specified
        address. This function clears memory for this parameter and marks it
        as unset.
**/
void
#if STD_C
IoResetVec( IoParamVec *vecp )
#else
IoResetVec( vecp  )
IoParamVec *vecp;
#endif
        {
        vecp->val.x = vecp->val.y = vecp->val.z = -1.0;
        vecp->status = IoUnset;
        }

void
#if STD_C
IoInitAngle( IoParamDbl *dblp, const char *key, const char *skey )
#else
IoInitAngle( dblp, key, skey )
IoParamDbl *dblp;
const char *key;
const char *skey;
#endif
	{
	IoInitDbl( dblp, key, skey, "angle", "degrees", DEGRAD );
	}

void
#if STD_C
IoInitBHN( IoParamDbl *dblp, const char *key, const char *skey )
#else
IoInitBHN( dblp, key, skey )
IoParamDbl *dblp;
const char *key;
const char *skey;
#endif
	{
	IoInitDbl( dblp, key, skey, "bhn", "dimensionless", 1.0 );
	}

void
#if STD_C
IoInitBool( IoParamBool *bp, const char *key, const char *skey )
#else
IoInitBool( bp, key, skey )
IoParamBool *bp;
const char *key, *skey;
#endif
	{
	bp->key = key;
	bp->skey = skey;
	bp->param_type = IoTypeBoolean;
	IoResetBool( bp );
	}

void
#if STD_C
IoInitConst( IoParamDbl *dblp, const char *key, const char *skey )
#else
IoInitConst( dblp, key, skey )
IoParamDbl *dblp;
const char *key;
const char *skey;
#endif
	{
	IoInitDbl( dblp, key, skey, "constant", "none", 1.0 );
	}

void
#if STD_C
IoInitDbl( IoParamDbl *dblp, const char *key, const char *skey, 
		const char *type, const char *units, double conv )
#else
IoInitDbl( dblp, key, skey, type, units, conv )
IoParamDbl *dblp;
const char *key, *skey, *type, *units;
double conv;
#endif
	{
	dblp->key = key;
	dblp->skey = skey;
	dblp->param_type = IoTypeDouble;
	dblp->type = type;
	dblp->units = units;
	dblp->conv = conv;
	IoResetDbl( dblp );
	}

void
#if STD_C
IoInitDensity( IoParamDbl *dblp, const char *key, const char *skey )
#else
IoInitDensity( dblp, key, skey )
IoParamDbl *dblp;
const char *key;
const char *skey;
#endif
	{
	IoInitDbl( dblp, key, skey, "density", "g/cc", 1.0 );
	}

void
#if STD_C
IoInitLinear( IoParamDbl *dblp, const char *key, const char *skey )
#else
IoInitLinear( dblp, key, skey )
IoParamDbl *dblp;
const char *key;
const char *skey;
#endif
	{
	IoInitDbl( dblp, key, skey, "length", "millimeters", 1.0 );
	}

void
#if STD_C
IoInitMass( IoParamDbl *dblp, const char *key, const char *skey )
#else
IoInitMass( dblp, key, skey )
IoParamDbl *dblp;
const char *key;
const char *skey;
#endif
	{
	IoInitDbl( dblp, key, skey, "mass", "kilograms", 1.0 );
	}
void
#if STD_C
IoInitStdMass( IoParamDbl *dblp, const char *key, const char *skey )
#else
IoInitStdMass( dblp, key, skey )
IoParamDbl *dblp;
const char *key;
const char *skey;
#endif
	{
	IoInitDbl( dblp, key, skey, "mass", "grams", 1.0 );
	}

/**
	void IoInitStress( IoParamDbl *dblp, const char *key, const char *skey )

	Initialize IoParamDbl to proper units and conversion factor for
	such things as Flow Stress and Young's Modulus.  Convert from pascals
	to CGS units (dynes/cm^2).
**/
void
#if STD_C
IoInitStress( IoParamDbl *dblp, const char *key, const char *skey )
#else
IoInitStress( dblp, key, skey )
IoParamDbl *dblp;
const char *key;
const char *skey;
#endif
	{
	IoInitDbl( dblp, key, skey, "stress", "pascals", 10.0 );
	}

void
#if STD_C
IoInitTime( IoParamDbl *dblp, const char *key, const char *skey )
#else
IoInitTime( dblp, key, skey )
IoParamDbl *dblp;
const char *key;
const char *skey;
#endif
	{
	IoInitDbl( dblp, key, skey, "time", "microseconds", 1.0 );
	}

void
#if STD_C
IoInitString( IoParamStr *strp, const char *key, const char *skey )
#else
IoInitString( strp, key, skey )
IoParamStr *strp;
const char *key;
const char *skey;
#endif
	{
	strp->key = key;
	strp->skey = skey;
	strp->param_type = IoTypeString;
	strp->val = NULL;
	}

void
#if STD_C
IoInitVec( IoParamVec *vecp, const char *key, const char *skey,
	   const char *type, const char *units, double conv )
#else
IoInitVec( vecp, key, skey, type, units, conv )
IoParamVec *vecp;
const char *key, *skey, *type, *units;
double conv;
#endif
	{
	vecp->key = key;
	vecp->skey = skey;
	vecp->param_type = IoTypeVector;
	vecp->type = type;
	vecp->units = units;
	vecp->conv = conv;
	IoResetVec( vecp );
	}

void
#if STD_C
IoInitVelocity( IoParamDbl *dblp, const char *key, const char *skey )
#else
IoInitVelocity( dblp, key, skey )
IoParamDbl *dblp;
const char *key;
const char *skey;
#endif
	{
	IoInitDbl( dblp, key, skey, "velocity", "meters/sec", 1.0 );
	}

/**
	Parsing functions:

	All of the IoRd_______ functions will set an error index upon
	failure if a definitive parsing or system error has occurred.
	Sometimes, like when an EOF is encountered, it can not be
	determined whether an error has occurred or if it is a normal
	termination of input, so the calling routine must decide whether
	to report an error.
**/

/*
	MuvesBool IoRdAngle( FILE *fp, IoParamDbl *dblp )

	Read a number from the file which represents an anglular
	measurement.  User units are degrees, but convert to radians for
	internal use.
 */
MuvesBool
#if STD_C
IoRdAngle( FILE *fp, IoParamDbl *dblp )
#else
IoRdAngle( fp, dblp )
FILE *fp;
IoParamDbl *dblp;
#endif
	{
	IoInitAngle( dblp, dblp->key, dblp->skey );
	if( ! IoRdDbl( fp, dblp ) )
		return mFalse;
	dblp->val /= dblp->conv;
	return mTrue;
	}

MuvesBool
#if STD_C
IoRdBool( FILE *fp, IoParamBool *bp )
#else
IoRdBool( fp, bp )
FILE *fp;
IoParamBool *bp;
#endif
{	const char *sp;
	IoInitBool( bp, bp->key, bp->skey );
	if( ( sp = IoRdIdentifier( fp )) == NULL )
		return mFalse;
	if( StrEq( sp, "false" ))
	    bp->val = mFalse;
	else
	if( StrEq( sp, "true" ))
	    bp->val = mTrue;
	else
	    return mFalse;

	bp->status = IoSet;
	    
	return mTrue;
}
	
MuvesBool
#if STD_C
IoRdConst( FILE *fp, IoParamDbl *dblp )
#else
IoRdConst( fp, dblp )
FILE *fp;
IoParamDbl *dblp;
#endif
	{
	assert( dblp != NULL );
	assert( dblp->key != NULL );
	IoInitConst( dblp, dblp->key, dblp->skey );
	if( ! IoRdDbl( fp, dblp ) )
		return mFalse;
	return mTrue;
	}


/**
        int IoLineNo( FILE *fp )

        Output line number of current position in specified file.
        If an error is detected in reading the file, an error index
        is set and -1 is returned.
**/
int
#if STD_C
IoLineNo( FILE *fp )
#else
IoLineNo( fp )
FILE *fp;
#endif
	{	register int c;
		int lineno;
		long initpos;
		long curpos;

	/* Record current position in file. */
	if( (initpos = ftell( fp )) == EOF )
		goto read_error;

	/* Start at beginning of file and count newlines. */
	rewind( fp );

	lineno = 1;
	while( (c = getc( fp )) != EOF )
		{
		curpos = ftell( fp );
		if( curpos >= initpos )
			break;
		if( c == '\n' )
			lineno++;
		}
	if( c == EOF)
		goto read_error;

	/* Reset file to initial position before returning. */
	if( fseek( fp, initpos, 0) != 0)
		goto read_error;

	return lineno;

read_error:
	ErSet( IoREAD_ERROR );
	return -1;

	}


STATIC void
#if STD_C
IoErChrParse( int c )
#else
IoErChrParse( c )
int c;
#endif
	{
	ErPLog( "%s, '%c' expected.\n", IoPARSE_ERROR, c );
	ErSet( IoBAD_SYNTAX );
	}

/**
	void IoErParse( const char *msg )

	Output specified error message when encountering a syntax error.
	Sets the error index.
**/
void
#if STD_C
IoErParse( const char *msg )
#else
IoErParse( msg )
const char *msg;
#endif
	{
	ErPLog( "\n\t%s, %s.\n", IoPARSE_ERROR, msg );
	ErSet( IoBAD_SYNTAX );
	}

MuvesBool
#if STD_C
IoRdDbl( FILE *fp, IoParamDbl *dblp )
#else
IoRdDbl( fp, dblp )
FILE *fp;
IoParamDbl *dblp;
#endif
	{
	char buffer[IoMAXLINELEN];
	char *p = buffer;
	int c;
	const char *ErMODULE_NAME = "IoRdDbl";

	ErDEBUG( "entered" );

	do	{
		switch( c = getc( fp ) )
			{
		case '}' : /* Normal termination of keyword input. */
			goto check_buffer;
		case EOF :
			IoErParse( "double expected" );
			ErPLog( "Encountered end-of-file.\n" );
			goto check_buffer;
		case IoCOMMENT_CHAR :
			/* We have a comment character, so burn rest of line. */
			while( (c = getc( fp )) != '\n' )
				if( c == EOF )
					goto check_buffer;
			break;
		default :
			if( isspace( c ) )
				{
				if( p > buffer )
					goto null_terminate;
				else
					break; /* skip leading white space */
				}
			if( ! isprint( c ) )
				{
				IoErParse( "double expected" );
				ErPLog( "Encountered %s: 0x%x\n",
					"non-printing character", c );
				goto check_buffer;
				}
			/* Stuff character in buffer. */
			*p++ = c;
			}
		}
	while( p - buffer < IoMAXLINELEN );
check_buffer:
	if( p > buffer )
		{	double value;
null_terminate:
		if( p - buffer > IoMAXLINELEN )
			{
			p--;
			assert( p - buffer == IoMAXLINELEN );
			*p = '\0';
			ErPLog( "*** buffer too small for %s.\n",
				"parameter double" );
			ErPLog( "Value truncated to \"%s\".\n", buffer );
			}
		else
			*p = '\0';
		if( sscanf( buffer, "%lg", &value ) != 1 )
			{
			IoErParse( "double expected" );
			ErPLog( "Encountered \"%s\".\n", buffer );
			goto failure;
			}
		(void) IoSetDbl( dblp, value );

		if( IoDebugging )
			{
			double junk = IoGetDbl( dblp );
			ErDEBUG( ErF( "value is %f", junk ) );
			}

		return mTrue;
		}
failure:
	IoResetDbl( dblp ); /* saftey net */
	return mFalse;
	}

/**
	MuvesBool IoParseDbl( IoKeyValue *keyvp, IoParamDbl *dblp )

	Set the value of the IoParamDbl structure from the string
	representation in the IoKeyValue structure.

	Return mTrue for success.  Otherwise, return mFalse and print
	an error.
**/
MuvesBool
#if STD_C
IoParseDbl( IoKeyValue *keyvp, IoParamDbl *dblp )
#else
IoParseDbl( keyvp, dblp )
IoKeyValue *keyvp;
IoParamDbl *dblp;
#endif
	{
	double value;
	const char *ErMODULE_NAME = "IoParseDbl";

	if( sscanf( keyvp->value, "%lg", &value ) != 1 )
		{
		IoErParse( "double expected" );
		ErPLog( "Encountered \"%s\".\n", keyvp->value );
		goto failure;
		}
	(void) IoSetDbl( dblp, value );

	ErDEBUG( ErF( "value is %g", IoGetDbl( dblp ) ) );

	return mTrue;
failure:
	IoResetDbl( dblp ); /* saftey net */
	return mFalse;
	}

MuvesBool
#if STD_C
IoRdDensity( FILE *fp, IoParamDbl *dblp )
#else
IoRdDensity( fp, dblp )
FILE *fp;
IoParamDbl *dblp;
#endif
	{
	assert( dblp != NULL );
	assert( dblp->key != NULL );
	IoInitDensity( dblp, dblp->key, dblp->skey );
	if( ! IoRdDbl( fp, dblp ) )
		return mFalse;
	return mTrue;
	}

MuvesBool
#if STD_C
IoRdBHN( FILE *fp, IoParamDbl *dblp )
#else
IoRdBHN( fp, dblp )
FILE *fp;
IoParamDbl *dblp;
#endif
	{
	assert( dblp != NULL );
	assert( dblp->key != NULL );
	IoInitBHN( dblp, dblp->key, dblp->skey );
	if( ! IoRdDbl( fp, dblp ) )
		return mFalse;
	return mTrue;
	}



/**
	int IoNonSpaceGetChar( FILE *fp )

	This routine returns the next non-white-space character from 
	stream fp.  Comments are skipped over.

	RETURN: the next valid non-white-space character on the input stream

		EOF if end-of-file is encountered (this is not handled as an
		error, because it may be a normal situation).
**/
int
#if STD_C
IoNonSpaceGetChar( register FILE *fp )
#else
IoNonSpaceGetChar( fp )
register FILE *fp;
#endif
	{
	register int c;
	const char *ErMODULE_NAME = "IoNonSpaceGetChar";

	assert(fp != NULL);
#if STD_C
	ErDEBUG( ErF( "(%p)", (pointer) fp ) );
#else
	ErDEBUG( ErF( "(0x%lx)\n", (long) fp ) );
#endif
	do	{
		if( (c = getc( fp )) == IoCOMMENT_CHAR )
			/* skip rest of line */
			while( ( c = getc( fp ) ) != EOF )
				if( c == '\n' )
					break;
		}
	while( isspace( c ) );
	return	c;			/* may be EOF */
	}


/**
	bs_type IoGetIdentifier( int c, char *tokbufp, FILE *fp, char *symbolist )

	This routine decides whether c is the start of an identifier token
	and if so, attempts to read the remainder of the token from input
	stream fp, copy it into the buffer pointed to by tokbufp.

	c is a character which has just been read, but not pigeonholed yet.
	To qualify as starting an identifier, it could be a double-quote mark,
	an escape symbol, or a valid identifier character.  tokbufp must
	point to enough storage to hold the identifier (IoBUFSIZE bytes).

	This function was copied from the Se pkg (SeIdentifierGet), so it
	uses the same rules for identifiers as the Se pkg (quoting and 
	escaping are allowed) but, it also allows a string of symbols to
	be passed in as a parameter. These symbols will be allowed as part
	of the identifier for all except the first character.

	RETURN: bs_good for success

		bs_bad if the input token is not a legal identifier

		bs_ugly, print a message on the error log, and set an error
		index if an error is detected parsing the identifier or if
		the identifier token contains improper characters 
		(e.g. escaped controls)
**/
bs_type
#if STD_C
IoGetIdentifier( register int c, char *tokbufp,
			register FILE *fp, char *symbolist )
#else
IoGetIdentifier( c, tokbufp, fp, symbolist )
register int c;
char *tokbufp;
register FILE *fp;
char *symbolist;	/* list of allowable symbols */
#endif
	{
	register char *outbuf;	/* -> tokbufp[.] for "output" */
	register MuvesBool quoted;	/* identifier is in "..." */
	const char *ErMODULE_NAME = "IoGetIdentifier";

	assert(tokbufp != NULL);
	assert(fp != NULL);
#if STD_C
	ErDEBUG( ErF( "('%s',%p,%p)",
		      IoCharStr( c ), (pointer) tokbufp, (pointer) fp ) );
#else
	ErDEBUG( ErF( "('%s',0x%lx,0x%lx)",
		      IoCharStr( c ), (long) tokbufp, (long) fp ) );
#endif
	outbuf = tokbufp;
	if( IoIS_IDENTIFIER( c ) )
		{
		quoted = mFalse;
		assert(isprint( c ));
		*outbuf++ = c;		/* transfer first character */
		}
	else
	if( ! (quoted = c == IoCH_DBL_QUOTE) )
		if( c == IoCH_ESCAPE )	/* escaped character */
			/* get escaped symbol */
			if( isprint( c = getc( fp ) ) )	
				*outbuf++ = c;	/* trf to output buffer */
			else	{
				*outbuf = '\0';	/* terminate output string */
			ErPLog( "%s read around \"%s\", line %d.\n",
					"Unprintable character",
					tokbufp, IoLineNo( fp ) );
				ErSet( IoREAD_ERROR );
				return	bs_ugly;	/* report error */
				}
		else			/* bogus first character */
			return	bs_bad;	/* report non-identifier */
	/* Transfer the rest of the identifier to outbuf (tokbufp). */
	for( ; ; )
		{
		/* escapes work even in quoted strings: */
		if( (c = getc( fp )) == IoCH_ESCAPE )
			c = getc( fp );	/* get escaped symbol */
		else
		if( quoted )
			{		/* processing a quoted string */
			if( c == IoCH_DBL_QUOTE )	/* marks the end */
				break;
			}
		else
		if( c == '\n' )
			break;		/* new-line ends identifier */

		else
		if( c == IoCOMMENT_CHAR )	/* process comment */
			{
			while( (c = getc( fp )) != EOF )
				if( c == '\n' )
					break;
			ErPLog( "%s encountered while looking for newline, line %d.\n",
					"End of file", IoLineNo( fp ));
			ErSet( IoREAD_ERROR );
			return bs_ugly;	/* EOF */
			}
		else
		if( ! IoIS_IDENTIFIER( c ) )	/* past the end; includes EOF */
			{
			if ( c == EOF )
				{
				ErPLog( "%s encountered in identifier, line %d.\n",
						"End of file", IoLineNo( fp ) );
				ErSet( IoREAD_ERROR );	/* premature EOF */
				return bs_ugly;	/* report error */
				}

				/* If 'c' in the symbol list, fall through */
			else	if( ( symbolist != NULL) && 
					( strchr( symbolist, c ) != NULL ) )
					{
					*outbuf++ = c;	/* transfer to output buffer */
					if( outbuf - tokbufp >= IoBUFSIZE )
						goto too_long;
					assert(isprint( c ));
					continue;	/* skip printability test; saves time */
					}
			else
				if( ungetc( c, fp ) == EOF )
					{
					ErPLog(
				"Unget failed after parsing identifier\n" );
					ErSet( IoREAD_ERROR );
					return bs_ugly;	/* report error */
					}
			break;
			}
		else	{		/* within identifier */
			*outbuf++ = c;	/* transfer to output buffer */
			if( outbuf - tokbufp >= IoBUFSIZE )
				goto too_long;
			assert(isprint( c ));
			continue;	/* skip printability test; saves time */
			}

		if( isprint( c ) )
			{
			*outbuf++ = c;	/* transfer to output buffer */
			if( outbuf - tokbufp >= IoBUFSIZE )
				{
too_long:			ErPLog( "Input line too long.\n" );
				ErSet( IoTOO_LONG );
				return	bs_ugly;	/* report error */
				}
			}
		else	{
			*outbuf = '\0';	/* terminate output string */
			ErPLog("Unprintable character read around \"%s\", line %d.\n",
				tokbufp, IoLineNo( fp ) );
			ErSet( IoREAD_ERROR );
			return	bs_ugly;	/* report error */
			}
		}
	assert(outbuf - tokbufp < IoBUFSIZE);
	*outbuf = '\0';			/* terminate output string */

	return bs_good;
	}

/**
	NmPool *IoGetList( FILE *fp, char *symlist )

	This routine reads in a comma-separated list of identifiers and
	stores the identifiers in a Name Pool.  White space and comments
	are allowed in the input as well as a char string "symlist" with
	special symbols to be allow as part of the identifiers name.
	If successful, a pointer to the Name Pool is returned.  Otherwise
	an error index is set and NULL is returned.
**/
NmPool *
#if STD_C
IoGetList( FILE *fp, const char *fname, char *symlist )
#else
IoGetList( fp, fname, symlist )
FILE *fp;
const char *fname;
char *symlist;
#endif
        {       static NmPool tokenlist;	/* store tokens from input */
        	char tokbufp[IoBUFSIZE];		/* stores each identifier */
		register int argct;		/* count of name pool */
		int c;
		
	NmInit( &tokenlist );
	argct = 0;
	do      {
		if( (c = IoNonSpaceGetChar( fp )) == EOF )
			{
			/* May be normal end of input. */
			return NULL;
			}
		switch( IoGetIdentifier( c, tokbufp, fp, symlist ) )
			{
		case bs_ugly :
			assert(ErIsSet());
			return NULL;
		case bs_bad :
			ErPLog( "Invalid identifier \"%s\" in file \"%s\".\n",
				tokbufp, fname );
			ErSet( IoREAD_ERROR );
			return NULL;
			}
		/* Add token name to name pool. */
		if( NmIndex( tokbufp, &tokenlist, mTrue ) == -1 )
			{
			assert(ErIsSet());
			return NULL;
			}
		/* Check for duplicates. */
		if( NmCount( &tokenlist ) != argct+1 )
			{ /* Last parameter name not unique. */
			  /* (not catastrophic) */
			argct--;
			ErPLog( "%s: \"%s\" in list, file: \"%s\".\n",
				"WARNING: Duplicate identifier",
				tokbufp, fname );
			}
		argct++;
		}
	while( (c = IoNonSpaceGetChar( fp )) == ',' );
        /* No comma, list is finished.  Put back last char. */

        if( ungetc( c, fp ) == EOF )
        	{
        	ErPLog("IoGetList: Unget failed");
        	ErSet( IoREAD_ERROR );
        	return NULL;
        	}

	return &tokenlist;
	}



/**
	const char *IoRdIdentifier( FILE *fp )

	Read an alphanumeric string from the specified open input stream
	and return a pointer to it in a static buffer.

	If an EOF or a right-curly brace is encountered, it is not
	considered an error since it may be normal termination of keyword
	input, and NULL is returned.  If an error occurs an appropriate
	error index will be set.
**/
const char *
#if STD_C
IoRdIdentifier( FILE *fp )
#else
IoRdIdentifier( fp )
FILE *fp;
#endif
	{
	char *p = IdentBuf;
	int c;
	MuvesBool quoted = mFalse;
	MuvesBool escaped = mFalse;
	const char *ErMODULE_NAME = "IoRdIdentifier";

	/* IoMAXLINELEN should be large enought to handle 99.9% of all      */
	/* Identifiers names. DmRealloc will be called if more space needed.*/
	/* 'buffer' is allocated only once. Will be free'd at end of run.   */
	/* Contents of buffer will be overwritten each time. Calling     */
	/* routine must be finished w/ buffer before next call...           */
	if( IdentBuf == NULL )
		{
		IdentLen = IoMAXLINELEN;

        	IdentBuf = (char *)(char *)DmCalloc(IdentLen, sizeof(char ));
                }
	p = IdentBuf;

	do	{
		switch( c = getc( fp ) )
			{
		case '}' : /* Normal termination of keyword input. */
			if( ungetc( c, fp ) == EOF )
				{
				ErPLog( "BUG: %s: %s.\n",
					"IoRdIdentifier",
					"Can't unget character" );
				ErSet( IoREAD_ERROR );
				goto failure;
				}
			goto check_buffer;
		case EOF : /* Possible normal termination of keyword input. */
			goto check_buffer;
		case IoCH_DBL_QUOTE :
			if (quoted)
				{
				goto check_buffer;
				}
			else
				{
				quoted = mTrue;
				}
			break;
		case IoCOMMENT_CHAR :
			/* We have a comment character, so burn rest of line. */
			while( (c = getc( fp )) != '\n' )
				if( c == EOF )
					goto check_buffer;
			break;
		case IoCH_ESCAPE :
			escaped = mTrue;
			c = getc( fp );
		default :
			if (quoted || escaped )
				{
				*p++ = c;
				escaped = mFalse;
				}
			else
				{
				if( isspace( c ) )
					{
					if( p > IdentBuf )
						goto null_terminate;
					else
						break; /* skip leading white space */
					}
				if( ! isalnum( c ) && c != '_' && c != '.' )
					{
					if( p == IdentBuf )
						{
						IoErParse( "identifier expected" );
						ErPLog( "%s: '%c':0x%x, at line %d.\n",
						"Encountered non-alphanumeric character",
							isprint( c ) ? c : '?', c,
							IoLineNo( fp ) );
						goto failure;
						}
					if( ungetc( c, fp ) == EOF )
						{
						ErPLog( "BUG: %s: %s.\n",
							"IoRdIdentifier",
							"Can't unget character" );
						ErSet( IoREAD_ERROR );
						goto failure;
						}
					goto check_buffer;
					}
				if( p == IdentBuf && ! isalpha( c ) )
					{
					IoErParse( "identifier expected" );
					ErPLog( "Encountered digit '%c', on line %d.\n",
						c, IoLineNo( fp ) );
					(void)ErLog("\tIdentifiers must start with a letter.\n");
					ErSet( IoBAD_SYNTAX );
					goto failure;
					}
				/* Stuff character in buffer. */
				*p++ = c;
				}
			}
                if( p - IdentBuf >= IdentLen )
                        {
                        /* Get more space for identifier */
                        IdentBuf = (char *)(char  *)DmRealloc(IdentBuf, (IdentLen + IoMAXLINELEN)*sizeof(char ));
                        /* Readjust position pointer and update buf length */
                        p = IdentBuf + IdentLen;
                        IdentLen += IoMAXLINELEN;
                        }
		} 
	while( 1 );  /* this could go until memory is depleted!! */
check_buffer:
	if( p > IdentBuf )
		{
null_terminate:
		if( p - IdentBuf > IdentLen )
			{
			p--;
			assert( p - IdentBuf == IdentLen );
			*p = '\0';
			ErPLog( "*** buffer too small for keyword.\n" );
			ErPLog( "Word truncated to \"%s\".\n", IdentBuf );
			ErSet( IoREAD_ERROR );
			}
		else
			*p = '\0';

		ErDEBUG( ErF( "returning \"%s\".", IdentBuf ) );

		return (const char *) IdentBuf;
		}
failure:
	return (const char *) NULL;
	}

/**
	const char *IoRdLabel( FILE *fp )

	Read an alphanumeric string including ' : [ ] , _ . '
	from the specified open input stream
	and return a pointer to it in a static buffer.

	If an EOF or a right-curly brace is encountered, it is not
	considered an error since it may be normal termination of keyword
	input, and NULL is returned.  If an error occurs an appropriate
	error index will be set.
**/
const char *
#if STD_C
IoRdLabel( FILE *fp )
#else
IoRdLabel( fp )
FILE *fp;
#endif
	{
	char *p = LabelBuf;
	int c;
	const char *ErMODULE_NAME = "IoRdLabel";

        /* IoMAXLINELEN should be large enought to handle 99.9% of all    */
        /* label names. DmRealloc will be called if more space needed.	  */
        /* 'LabelBuf' is allocated only once. Will be free'd at end of run. */
        /* Contents of buffer will be overwritten each time. Calling      */
        /* routine must be finished w/ buffer before next call...         */
        if( LabelBuf == NULL )
                {
                LabelLen = IoMAXLINELEN;

                LabelBuf = (char *)(char *)DmCalloc(LabelLen, sizeof(char ));
                }
	p = LabelBuf;

	do	{
		switch( c = getc( fp ) )
			{
		case '}' : /* Normal termination of keyword input. */
			if( ungetc( c, fp ) == EOF )
				{
				ErPLog( "BUG: %s: %s.\n",
					"IoRdLabel",
					"Can't unget character" );
				ErSet( IoREAD_ERROR );
				goto failure;
				}
			goto check_buffer;
		case EOF : /* Possible normal termination of keyword input. */
			goto check_buffer;
		case IoCOMMENT_CHAR :
			/* We have a comment character, so burn rest of line. */
			while( (c = getc( fp )) != '\n' )
				if( c == EOF )
					goto check_buffer;
			break;
		default :
			if( isspace( c ) )
				{
				if( p > LabelBuf )
					goto null_terminate;
				else
					break; /* skip leading white space */
				}
			if( ! isalnum( c ) && c != '_' && c != '.' 
			   && c != ':' && c != ',' && c != '[' && c != ']' )
				{
				if( p == LabelBuf )
					{
					IoErParse( "identifier expected" );
					ErPLog( "Encountered %s: '%c':0x%x\n",
						"invalid character in label",
						isprint( c ) ? c : '?', c );
					goto failure;
					}
				if( ungetc( c, fp ) == EOF )
					{
					ErPLog( "BUG: %s: %s.\n",
						"IoRdLabel",
						"Can't unget character" );
					ErSet( IoREAD_ERROR );
					goto failure;
					}
				goto check_buffer;
				}
			/* Stuff character in buffer. */
			*p++ = c;
			}
                if( p - LabelBuf >= LabelLen )
                        {
                        /* Get more space for identifier */
                        LabelBuf = (char *)(char  *)DmRealloc(LabelBuf, (LabelLen + IoMAXLINELEN)*sizeof(char ));
                        /* Readjust position pointer and update buf length */
                        p = LabelBuf + LabelLen;
                        LabelLen += IoMAXLINELEN;
                        }

		}
	while( 1 );
check_buffer:
	if( p > LabelBuf )
		{
null_terminate:
		if( p - LabelBuf > LabelLen )
			{
			p--;
			assert( p - LabelBuf == LabelLen );
			*p = '\0';
			ErPLog( "*** buffer too small for keyword.\n" );
			ErPLog( "Word truncated to \"%s\".\n", LabelBuf );
			ErSet( IoREAD_ERROR );
			}
		else
			*p = '\0';

		ErDEBUG( ErF( "returning \"%s\".", LabelBuf ) );

		return (const char *) LabelBuf;
		}
failure:
	return (const char *) NULL;
	}

/**
	MuvesBool IoRdKeyValue( FILE *fp, IoKeyValue *kvp )

	Read keyword assignment expression from the specified open input
	stream and return a keyword and value in the structure provided.
	An assignment expression must take the following form:

		keyword = value

	Whitespace may not be imbedded in the keyword or value token, but
	may be used as a separator on either side of the '=' symbol, this
	includes newlines.  Also, the "keyword" must be alpha-numeric, but
	the "value" can be any sequence of printable characters.

	Returns mTrue if successful, otherwise it returns mFalse and prints
	an error upon failure.  If either the keyword or the value can't
	be read, the corresponding field in the IoKeyValue structure will
	be set to NULL and if a definitive error is detected, as opposed
	to an EOF which could be OK, the error index will be set.

	Data type for retrieving keyword/value pair via IoRdKeyValue:

	typedef struct
		{
		const char *key;	// keyword
		const char *value;	// assigned value
		}
	IoKeyValue;
**/
MuvesBool
#if STD_C
IoRdKeyValue( FILE *fp, IoKeyValue *kvp )
#else
IoRdKeyValue( fp, kvp )
FILE *fp;
IoKeyValue *kvp;
#endif
	{
	assert( fp != NULL );
	assert( kvp != NULL );

	/* Read keyword. */
	if( (kvp->key = IoRdIdentifier( fp )) == NULL )
		return mFalse; /* error index set, or EOF or '}' */
	/* Skip over assignment operator. */
	if( ! IoRdSpecChar( fp, '=' ) )
		{
		kvp->value = NULL; /* indicate value not read */
		ErSet( IoBAD_SYNTAX );
		ErPLog( "Error on line %d\n", IoLineNo( fp ));
		return mFalse;
		}
	/* Read value. */
	if( (kvp->value = IoRdValue( fp )) == NULL )
		return mFalse;
	return mTrue;
	}

/**
        MuvesBool IoRdKeyVector( FILE *fp, IoKeyVector *kvp )

        Read keyword assignment expression from the specified open input
        stream and return a keyword and value in the structure provided.
        An assignment expression must take the following form:

                keyword = vector

        Whitespace may not be imbedded in the keyword or value token, but
        may be used as a separator on either side of the '=' symbol, this
        includes newlines.  Also, the "keyword" must be alpha-numeric, but
        the "vector" must be sequence of three numbers separated by spaces.

        Returns mTrue if successful, otherwise it returns mFalse and prints
        an error upon failure.  If either the keyword or the value can't
        be read, the corresponding field in the IoKeyValue structure will
        be set to NULL and if a definitive error is detected, as opposed
        to an EOF which could be OK, the error index will be set.

        Data type for retrieving keyword/value pair via IoRdKeyValue:

        typedef struct
                {
                const char  *key;         // keyword
                VmVect      *vector;      // assigned vector
                }
        IoKeyVector;
**/
MuvesBool
#if STD_C
IoRdKeyVector( FILE *fp, IoKeyVector *kvp )
#else
IoRdKeyVector( fp, kvp )
FILE *fp;
IoKeyVector *kvp;
#endif
        {
        assert( fp != NULL );
        assert( kvp != NULL );

        /* Read keyword. */
        if( (kvp->key = IoRdValue( fp )) == NULL )
                return mFalse; /* error index set, or EOF or '}' */
        /* Skip over assignment operator. */
        if( ! IoRdSpecChar( fp, '=' ) )
                {
                kvp->vector = NULL; /* indicate value not read */
                ErSet( IoBAD_SYNTAX );
                ErPLog( "Error on line %d\n", IoLineNo( fp ) );
                return mFalse;
                }
        /* Read value. */
        if( !(IoRdVec( fp, kvp->vector ) ) )
                return mFalse;
        return mTrue;
        }

MuvesBool
#if STD_C
IoRdLinear( FILE *fp, IoParamDbl *dblp )
#else
IoRdLinear( fp, dblp )
FILE *fp;
IoParamDbl *dblp;
#endif
	{
	assert( dblp != NULL );
	assert( dblp->key != NULL );
	IoInitLinear( dblp, dblp->key, dblp->skey );
	if( ! IoRdDbl( fp, dblp ) )
		return mFalse;
	return mTrue;
	}

MuvesBool
#if STD_C
IoRdMass( FILE *fp, IoParamDbl *dblp )
#else
IoRdMass( fp, dblp )
FILE *fp;
IoParamDbl *dblp;
#endif
	{
	assert( dblp != NULL );
	assert( dblp->key != NULL );
	IoInitMass( dblp, dblp->key, dblp->skey );
	if( ! IoRdDbl( fp, dblp ) )
		return mFalse;
	return mTrue;
	}

/**
	MuvesBool IoRdSpecChar( FILE *fp, int ch )

	Read the specified character from the specified input stream.

	Return mTrue for success.  Otherwise, return mFalse, and print
	and error.
**/
MuvesBool
#if STD_C
IoRdSpecChar( FILE *fp, int ch )
#else
IoRdSpecChar( fp, ch )
FILE *fp;
int ch;
#endif
	{
	int c;
	const char *ErMODULE_NAME = "IoRdSpecChar";

	ErDEBUG( ErF( "(0x%x,'%c')", fp, ch ) );

	do	{
		switch( c = getc( fp ) )
			{
		case EOF :
			IoErChrParse( ch );
			ErPLog( "Encountered end-of-file.\n" );
			return mFalse;
		case IoCOMMENT_CHAR :
			/* We have a comment character, so burn rest of line. */
			while( (c = getc( fp )) != '\n' )
				if( c == EOF )
					return mFalse;
			break;
		default :
			if( c == ch )
				break; /* got it, should fall out of loop */
			if( isspace( c ) )
				break; /* skip over white space */

			IoErChrParse( ch );
			if( isprint( c ) )
				ErPLog( "Encountered '%c' on line %d.\n", 
					c, IoLineNo( fp ) );
			else
				ErPLog( "Encountered character: 0x%x on line %d\n", 
					c, IoLineNo( fp ) );
			return mFalse;
			}
		}
	while( c != ch );

	ErDEBUG( ErF( "got '%c'", c ) );

	return mTrue;
	}

MuvesBool
#if STD_C
IoRdStress( FILE *fp, IoParamDbl *dblp )
#else
IoRdStress( fp, dblp )
FILE *fp;
IoParamDbl *dblp;
#endif
	{
	assert( dblp != NULL );
	assert( dblp->key != NULL );
	IoInitStress( dblp, dblp->key, dblp->skey );
	if( ! IoRdDbl( fp, dblp ) )
		return mFalse;
	return mTrue;
	}


MuvesBool
#if STD_C
Io_RdString( FILE *fp, IoParamStr *strp, IoStringArray *store,
	    const char *flstr )
#else
Io_RdString( fp, strp, store, flstr )
FILE *fp;
IoParamStr *strp;
IoStringArray *store;
const char *flstr;
#endif
	{	const char *sp;
	if( (sp = IoRdIdentifier( fp )) == NULL )
		return mFalse;
	strp->val = IoNewString(store, store->count, flstr, "%s", sp);
	return mTrue;
	}

MuvesBool
#if STD_C
IoRdTime( FILE *fp, IoParamDbl *dblp )
#else
IoRdTime( fp, dblp )
FILE *fp;
IoParamDbl *dblp;
#endif
	{
	assert( dblp != NULL );
	assert( dblp->key != NULL );
	IoInitTime( dblp, dblp->key, dblp->skey );
	if( ! IoRdDbl( fp, dblp ) )
		return mFalse;
	return mTrue;
	}

/**
	const char *IoRdValue( FILE *fp )

	Read a value from the specified open input stream and return a
	pointer to it in a static buffer.  The "value" can be any sequence
	of printable characters, except a space.

	Returns NULL and prints an error upon failure.
**/
const char *
#if STD_C
IoRdValue( FILE *fp )
#else
IoRdValue( fp )
FILE *fp;
#endif
	{
	static char buffer[IoMAXLINELEN];
	char *p = buffer;
	int c;
	const char *ErMODULE_NAME = "IoRdValue";

	do	{
		switch( c = getc( fp ) )
			{
		case '}' : /* Normal termination of keyword input. */
			goto check_buffer;
		case EOF :
			IoErParse( "identifier expected" );
			ErPLog( "Encountered end-of-file.\n" );
			goto check_buffer;
		case IoCOMMENT_CHAR :
			/* We have a comment character, so burn rest of line. */
			while( (c = getc( fp )) != '\n' )
				if( c == EOF )
					goto check_buffer;
			break;
		default :
			if( isspace( c ) )
				{
				if( p > buffer )
					goto null_terminate;
				else
					break; /* skip leading white space */
				}
			if( ! isgraph( c ) )
				{
				IoErParse( "value expected" );
				ErPLog( "Encountered %s: '%c':0x%x\n",
					"non-printing character",
					isprint( c ) ? c : '?', c );
				goto check_buffer;
				}
			/* Stuff character in buffer. */
			*p++ = c;
			}
		}
	while( p - buffer < IoMAXLINELEN );
check_buffer:
	if( p > buffer )
		{
null_terminate:
		if( p - buffer > IoMAXLINELEN )
			{
			p--;
			assert( p - buffer == IoMAXLINELEN );
			*p = '\0';
			ErPLog( "*** buffer too small for keyword.\n" );
			ErPLog( "Word truncated to \"%s\".\n", buffer );
			ErSet( IoREAD_ERROR );
			}
		else
			*p = '\0';

		ErDEBUG( ErF( "returning \"%s\".", buffer ) );

		return (const char *) buffer;
		}
failure:
	return (const char *) NULL;
	}

MuvesBool
#if STD_C
IoSkipKeyValues( FILE *fp )
#else
IoSkipKeyValues( fp )
FILE *fp;
#endif
	{	int nesting = 0;
		int c;
	do	{
		switch( c = getc( fp ) )
			{
		case EOF :
			IoErChrParse( IoSTARTCHR );
			break;
		case IoSTARTCHR :
			nesting++;
			break;
		case IoENDCHR :
			if( nesting > 0 )
				nesting--;
			else
				{
				IoErChrParse( IoSTARTCHR );
				return mFalse;
				}
			if( nesting == 0 )
				return mTrue;
			break;
		case IoCOMMENT_CHAR :
			/* We have a comment character, so burn rest of line. */
			while( (c = getc( fp )) != '\n' )
				if( c == EOF )
					return mFalse;
			break;
		default :
			if( isspace( c ) )
				break; /* skip over white space */

			if( nesting > 0 )
				break;
			IoErChrParse( IoSTARTCHR );
			if( isprint( c ) )
				ErPLog( "Encountered '%c'.\n", c );
			else
				ErPLog( "Encountered character: 0x%x\n", c );
			return mFalse;
			}
		}
	while( c != EOF );
	ErPLog( "Encountered end-of-file.\n" );
	return mFalse;
	}


MuvesBool
#if STD_C
IoRdVec( FILE *fp, IoParamVec *vecp )
#else
IoRdVec( fp, vecp )
FILE *fp;
IoParamVec *vecp;
#endif
	{
	char buffer[IoMAXLINELEN];
	char *p = buffer;
	int c;
	const char *ErMODULE_NAME = "IoRdVec";

	ErDEBUG( "entered" );

	do	{
		switch( c = getc( fp ) )
			{
		case '}' : /* Normal termination. */
			goto check_buffer;
		case EOF :
			IoErParse( "3-d vector expected" );
			ErPLog( "Encountered end-of-file.\n" );
			goto check_buffer;
		case IoCOMMENT_CHAR :
			/* We have a comment character, so burn rest of line. */
			while( (c = getc( fp )) != '\n' )
				if( c == EOF )
					goto check_buffer;
			goto check_buffer;
		default :
			if( c == '\n' )
				goto null_terminate;
			if( isspace( c ) )
				{
				if( p == buffer )
					break; /* skip leading white space */
				}

			/* Stuff character in buffer. */
			*p++ = c;
			}
		}
	while( p - buffer < IoMAXLINELEN );
check_buffer:
	if( p > buffer )
		{	VmVect val;
			double junk;
null_terminate:
		if( p - buffer > IoMAXLINELEN )
			{
			p--;
			assert( p - buffer == IoMAXLINELEN );
			*p = '\0';
			ErPLog( "*** buffer too small for %s.\n",
				"parameter double" );
			ErPLog( "Value truncated to \"%s\".\n", buffer );
			}
		else
			*p = '\0';
		if( sscanf( buffer, "%lg %lg %lg %lg", &val.x, &val.y, &val.z, &junk )
			!= 3 )
			{
			IoErParse( "3-d vector expected" );
			(void)ErLog("\t\tfor keyword \"%s\"\n", vecp->key );
			ErPLog( "Encountered \"%s\".\n", buffer );
			goto failure;
			}
		(void) IoSetVec( vecp, &val );

		ErDEBUG( ErF( "value is %g, %g, %g", val.x, val.y, val.z ) );

		return mTrue;
		}
failure:
	IoResetVec( vecp ); /* saftey net */
	return mFalse;
	}

MuvesBool
#if STD_C
IoRdVelocity( FILE *fp, IoParamDbl *dblp )
#else
IoRdVelocity( fp, dblp )
FILE *fp;
IoParamDbl *dblp;
#endif
	{
	assert( dblp != NULL );
	assert( dblp->key != NULL );
	IoInitVelocity( dblp, dblp->key, dblp->skey );
	if( ! IoRdDbl( fp, dblp ) )
		return mFalse;
	return mTrue;
	}

/**
	void IoPrParamBool( FILE *fp, const IoParamBool *dblp )

	Print out the specified boolean parameter to the specified output
	stream.
**/
void
#if STD_C
IoPrParamBool( FILE *fp, const IoParamBool *dblp )
#else
IoPrParamBool( fp, dblp )
FILE *fp;
const IoParamBool *dblp;
#endif
	{
	if( IoIsSetBool( (IoParamBool *) dblp ) )
		/* print out if value is set */
		(void) fprintf( fp, "\t%s = %s\t# boolean\n", dblp->key,
				dblp->val ? "true" : "false" );
	}

/**
	void IoPrParamDbl( FILE *fp, const IoParamDbl *dblp )

	Print out the specified double parameter to the specified output
	stream.
**/
void
#if STD_C
IoPrParamDbl( FILE *fp, const IoParamDbl *dblp )
#else
IoPrParamDbl( fp, dblp )
FILE *fp;
const IoParamDbl *dblp;
#endif
	{
	if( IoIsSetDbl( (IoParamDbl *) dblp ) ) /* print out if value is set */
		(void) fprintf( fp, "\t%s = %g\t# %s in %s\n",
				dblp->key, dblp->val*dblp->conv,
				dblp->type, dblp->units );
	}

/**
	void IoPrParamStr( FILE *fp, const IoParamStr *strp )

	Print out the specified string parameter to the specified output
	stream.
**/
void
#if STD_C
IoPrParamStr( FILE *fp, const IoParamStr *strp )
#else
IoPrParamStr( fp, strp )
FILE *fp;
const IoParamStr *strp;
#endif
	{
	if( IoIsSetString( (IoParamStr *) strp ) )
		/* print out if value is set */
		(void) fprintf( fp, "\t%s = %s\t# string\n",
				strp->key, strp->val );
	}

/**
	void IoPrParamVec( FILE *fp, const IoParamVec *vecp )

	Print out the specified 3-d vector parameter to the specified output
	stream.
**/
void
#if STD_C
IoPrParamVec( FILE *fp, const IoParamVec *vecp )
#else
IoPrParamVec( fp, vecp )
FILE *fp;
const IoParamVec *vecp;
#endif
	{
	if( IoIsSetVec( (IoParamVec *) vecp ) ) /* print out if value is set */
		(void) fprintf( fp, "\t%s = %g, %g, %g\t# %s in %s\n",
				vecp->key,
				vecp->val.x * vecp->conv,
				vecp->val.y * vecp->conv,
				vecp->val.z * vecp->conv,
				vecp->type, vecp->units );
	}


/*

	Functions relating read, parse, get, set, check, copy, print, reset,
	and initialize 'IoParamInt' type parameters.

*/
/*
	void IoResetInt( IoParamInt *bp )

	Clear int parameter at the specified address.
	This function clears memory for this parameter and marks it as unset.

 */
void
#if STD_C
IoResetInt( IoParamInt *bp )
#else
IoResetInt( bp  )
IoParamInt *bp;
#endif
	{
	bp->val = 0;
	bp->status = IoUnset;
	}

/*
	int IoSetInt( IoParamInt *bp, MuvesBool value )

	Set the int parameter at the specified address to the
	specified value.  This function takes care of storing the value
	and marks this parameter as set.  It returns the new value.
 */
int
#if STD_C
IoSetInt( IoParamInt *bp, int value )
#else
IoSetInt( bp, value )
IoParamInt *bp;
int value;
#endif
	{
	bp->status = IoSet;
	return bp->val = value;
	}

/*
 	int IoGetInt( IoParamInt *bp )

	Get int parameter from the address given by bp.
	This routine will succeed and return the requested parameter
	value if this parameter has been set.  If the parameter is not set
	it is considered a programming error.  An appropriate diagnostic
	will be printed, an assertion will trip (if enabled) and -1 will
	be returned.
 */
int
#if STD_C
IoGetInt( IoParamInt *bp )
#else
IoGetInt( bp )
IoParamInt *bp;
#endif
	{
	if( ! IoIsSetInt( bp ) )
		{
		ErPLog( "BUG: parameter \"%s\" not set.\n", bp->key );
		assert( IoIsSetInt( bp ) );
		return -1;
		}
	else
		return bp->val;
	}
/*
	int IoCopyInt( IoParamInt *tobp, IoParamInt *frombp )

	This function sets the value of the int parameter pointed
	to by it's first argument, to that of the second arg.  If all goes
	well, it returns the copied value, but if the second parameter was
	not set a programming error diagnostic is issued, the first
	parameter will be reset (invalidated), and -1 is returned.
 */
int
#if STD_C
IoCopyInt( IoParamInt *tobp, IoParamInt *frombp )
#else
IoCopyInt( tobp, frombp )
IoParamInt *tobp, *frombp;
#endif
	{
	if( ! IoIsSetInt( frombp ) )
		{
		ErPLog( "BUG: parameter \"%s\" not set.\n",
			frombp->key );
		assert( IoIsSetInt( frombp ) );
		IoResetInt( tobp );
		return -1;
		}
	return IoSetInt( tobp, IoGetInt( frombp ) );
	}

void
#if STD_C
IoInitInt( IoParamInt *ip, const char *key, const char *skey )
#else
IoInitInt( ip, key, skey )
IoParamInt *ip;
const char *key, *skey;
#endif
	{
	ip->key = key;
	ip->skey = skey;
	ip->param_type = IoTypeInteger;
	IoResetInt( ip );
	}

MuvesBool
#if STD_C
IoRdInt( FILE *fp, IoParamInt *ip )
#else
IoRdInt( fp, ip )
FILE *fp;
IoParamInt *ip;
#endif
	{
	char buffer[IoMAXLINELEN];
	char *p = buffer;
	int c;
	const char *ErMODULE_NAME = "IoRdInt";

	ErDEBUG( "entered" );

	do	{
		switch( c = getc( fp ) )
			{
		case '}' : /* Normal termination of keyword input. */
			goto check_buffer;
		case EOF :
			IoErParse( "integer expected" );
			ErPLog( "Encountered end-of-file.\n" );
			goto check_buffer;
		case IoCOMMENT_CHAR :
			/* We have a comment character, so burn rest of line. */
			while( (c = getc( fp )) != '\n' )
				if( c == EOF )
					goto check_buffer;
			break;
		default :
			if( isspace( c ) )
				{
				if( p > buffer )
					goto null_terminate;
				else
					break; /* skip leading white space */
				}
			if( ! isprint( c ) )
				{
				IoErParse( "integer expected" );
				ErPLog( "Encountered %s: 0x%x\n",
					"non-printing character", c );
				goto check_buffer;
				}
			/* Stuff character in buffer. */
			*p++ = c;
			}
		}
	while( p - buffer < IoMAXLINELEN );
check_buffer:
	if( p > buffer )
		{	int value;
null_terminate:
		if( p - buffer > IoMAXLINELEN )
			{
			p--;
			assert( p - buffer == IoMAXLINELEN );
			*p = '\0';
			ErPLog( "*** buffer too small for %s.\n",
				"parameter integer" );
			ErPLog( "Value truncated to \"%s\".\n", buffer );
			}
		else
			*p = '\0';
		if( sscanf( buffer, "%d", &value ) != 1 )
			{
			IoErParse( "integer expected" );
			ErPLog( "Encountered \"%s\".\n", buffer );
			goto failure;
			}
		(void) IoSetInt( ip, value );

		if( IoDebugging )
			{
			int junk = IoGetInt( ip );
			ErDEBUG( ErF( "value is %d", junk ) );
			}
		return mTrue;
		}
failure:
	IoResetInt( ip ); /* saftey net */
	return mFalse;
	}

/**
	MuvesBool IoParseInt( IoKeyValue *keyvp, IoParamInt *ip )

	Set the value of the IoParamInt structure from the string
	representation in the IoKeyValue structure.

	Return mTrue for success.  Otherwise, return mFalse and print
	an error.
**/
MuvesBool
#if STD_C
IoParseInt( IoKeyValue *keyvp, IoParamInt *ip )
#else
IoParseInt( keyvp, ip )
IoKeyValue *keyvp;
IoParamInt *ip;
#endif
	{
	int value;
	const char *ErMODULE_NAME = "IoParseInt";

	if( sscanf( keyvp->value, "%d", &value ) != 1 )
		{
		IoErParse( "integer expected" );
		ErPLog( "Encountered \"%s\".\n", keyvp->value );
		goto failure;
		}
	(void) IoSetInt( ip, value );

	ErDEBUG( ErF( "value is %d", IoGetInt( ip ) ) );

	return mTrue;
failure:
	IoResetInt( ip ); /* saftey net */
	return mFalse;
	}

/**
	MuvesBool IoParseBool( IoKeyValue *keyvp, IoParamBool *bp )

	Set the value of the IoParamBool structure from the string
	representation in the IoKeyValue structure.

	Return mTrue for success.  Otherwise, return mFalse and print
	an error.
**/
MuvesBool
#if STD_C
IoParseBool( IoKeyValue *keyvp, IoParamBool *bp )
#else
IoParseBool( keyvp, bp )
IoKeyValue *keyvp;
IoParamBool *bp;
#endif
	{	MuvesBool value;
	if( StrEq( keyvp->value, "true" ) )
	{
		value = mTrue;
	}
	else if( StrEq( keyvp->value, "false" ) )
	{
		value = mFalse;
	}
	else
	{
		IoErParse( "boolean 'true' or 'false' expected" );
		ErPLog( "Encountered \"%s\".\n", keyvp->value );
		goto failure;
	}
	(void) IoSetBool( bp, value );
#ifdef VDEBUG
	ErPLog( "IoParseBool: value is %d\n", IoGetBool( bp ) );
#endif
	return mTrue;
failure:
	IoResetBool( bp ); /* saftey net */
	return mFalse;
	}

void
#if STD_C
IoPrParamInt( FILE *fp, const IoParamInt *ip )
#else
IoPrParamInt( fp, ip )
FILE *fp;
const IoParamInt *ip;
#endif
	{
	if( IoIsSetInt( (IoParamInt *) ip ) ) /* print out if value is set */
		(void) fprintf( fp, "\t%s = %d\t# integer\n", ip->key,
				ip->val);
	}

/* 08-09-24 ch3: added function to print string value of int param (SCR1099) */
void
IoPrParamIntString PARAMS((FILE *fp, const IoParamInt *ip, char **strings))
{
	if( IoIsSetInt( (IoParamInt *) ip ) ) /* print out if value is set */
		fprintf( fp, "\t%s = %d\t# integer '%s'\n", ip->key,
				ip->val, strings[ip->val]);
}

/*
	int IoAddInt( IoParamInt *bp, int inc )

	Add 'inc' to the int parameter at the specified address.
	It returns the new value.
 */
int
#if STD_C
IoAddInt( IoParamInt *bp, int inc )
#else
IoAddInt( bp, inc )
	IoParamInt *bp;
	int inc;
#endif
	{
	if( ! IoIsSetInt( bp ) )
		{
		ErPLog( "BUG: parameter \"%s\" not set.\n", bp->key );
		assert( IoIsSetInt( bp ) );
		return -1;
		}

		return bp->val= bp->val + inc;
	}


/**
	IoParamType IoStrToType( const char *name )

	Return enum value associated with specified name of data type.
	If the name is not recognized, this routine prints an error and
	returns IoTypeInvalid.
**/
IoParamType
#if STD_C
IoStrToType( const char *name )
#else
IoStrToType( name )
const char *name;
#endif
	{
	if( StrEq( name, "boolean" ) )
		return IoTypeBoolean;
	else
	if( StrEq( name, "double" ) )
		return IoTypeDouble;
	else
	if( StrEq( name, "integer" ) )
		return IoTypeInteger;
	else
	if( StrEq( name, "string" ) )
		return IoTypeString;
	else
	if( StrEq( name, "vector" ) )
		return IoTypeVector;

	ErPLog( "*** Invalid name for data type: \"%s\"\n", name );
	return IoTypeInvalid;
	}

/**
	const char *IoTypeToStr( IoParamType type )

	Return the name associated with specified data type.
**/
const char *
#if STD_C
IoTypeToStr( IoParamType type )
#else
IoTypeToStr( type )
IoParamType type;
#endif
	{
	switch( type )
		{
	case IoTypeBoolean :
		return "boolean";
	case IoTypeDouble :
		return "double";
	case IoTypeInteger :
		return "integer";
	case IoTypeString :
		return "string";
	case IoTypeVector :
		return "vector";
		}
	ErPLog( "*** Invalid data type: \"%d\"\n", type );
	return (const char *) NULL;
	}

void
#if STD_C
IoCleanUp( void )
#else
IoCleanUp()
#endif
	{
	const char *ErMODULE_NAME = "IoCleanUp";

	ErDEBUG( "" );

	if( IdentBuf != NULL )
		{
		DmFree((genptr_t)IdentBuf );
		IdentBuf = NULL;
		IdentLen = 0;
		}
	if( LabelBuf != NULL )
		{
		DmFree((genptr_t)LabelBuf );
		LabelBuf = NULL;
		LabelLen = 0;
		}
	}

void IoPkgInit()
{
    static int done = 0;
    if (!done) {
	done = 1;
	ErPkgInit();
	IoPkgInit();
	
	NmPkgInit();
	
	#ifdef VDEBUG
	ErPLog("Io package initialized.\n");
	#endif
    }
}

/* 
 * const char *IoNewString(IoStringArray *array, int index, char *source,
 *                         char *format, ...)
 *
 * IoNewString() manages the creation and storage of an array of
 * strings. The index argument is the location that a new string
 * should be created. If the array is smaller than index, the array
 * will be expanded and all new string pointers will be intialized to
 * NULL. If a string already exists at the requested index, it will be
 * replaced. A pointer to the new string will be returned. The source
 * argument should indicate the source file name and line number of
 * the requesting function (use DmFLSTR macro). The format and
 * subsequent arguments are used to construct the new string using the
 * same technique as the printf() family of functions. The function
 * will always succeed.
 */

const char *
IoNewString(IoStringArray *array, int index, const char *source,
	    char *format, ...) {
	char buf[8*BUFSIZ]; /* hopefully big enough */
	va_list ap;
	char *name;
	if (index >= array->count) {
		array->strings = (char **)DmReallocm((void*) array->strings,
						     (index+1)*sizeof(char*),
						     source);
		while (array->count < index)
			array->strings[array->count++] = NULL;
		++array->count;
	}
	else if (array->strings[index] != NULL)
		DmFreem(array->strings[index], source);
	*buf = (char)0;		/* in case vsnprintf fails */
	va_start(ap, format);
	(void)vsnprintf(buf, 8*BUFSIZ, format, ap);
	va_end(ap);
	array->strings[index] = name = DmStrDupm(buf, source);
	return name;
}

/* 
 * IoFreeStringArray() frees all memory used by the string array. The
 * IoStringArray data structure is not assumed to be dynamically
 * allocated and is the calling function's responsibility to
 * deallocate if necessary.
 */
void
IoFreeStringArray(IoStringArray *array) {
	int i;
	if (array == NULL || array->strings == NULL)
		return;
	for (i = 0; i < array->count; ++i)
		if( array->strings[i] != NULL) {
			DmFree((void*)array->strings[i]);
		}
	DmFree((void*)array->strings);
	array->strings = NULL;
	array->count = 0;
}
