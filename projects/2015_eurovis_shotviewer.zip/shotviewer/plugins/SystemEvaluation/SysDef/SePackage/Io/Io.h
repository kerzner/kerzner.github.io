/**
	<Io.h> -- MUVES "Io" (input/output utilities) package definitions
**/

/*
	created:	88/08/12	D A Gwyn
	edited:		08/09/24	C Hunt
			added function prototype for IoPrParamIntString()
			(SCR1099)

	RCSid:		$Id: Io.h,v 1.37 2010/06/23 19:54:47 geoffs Exp $
*/

/**
	The Io package provides several functions of general utility
	for input, output, and associated operations.

	IMPORTANT:  Correct usage, unlike most other MUVES packages, is:

		#include <stdio.h>
		#include <Io.h>

	This is necessary because not all C environments support
	multiple inclusion of <stdio.h>, so <Io.h> must not contain it.
**/

#ifndef Io_H_INCLUDED
#define Io_H_INCLUDED			/* once-only latch */

#include	<Nm.h>
#include	<Vm.h>
#include	<std.h>			/* VLD/VMB standard C definitions */

#include <stdarg.h>		/* needed for IoNewString() */

#define	IoMAXLINELEN	8192	/* max parameter file input line length */

/* Data types for parameters used in threat packets, and various other
   data structures: */

typedef enum	/* Define states for 'status' field of data types. */
{
    IoUnset,	/* value invalid, not set */
    IoSet		/* value is set */
}
IoStatus;


typedef enum /* Enumerate supported types: */
{
    IoTypeInvalid = -1,
    IoTypeBoolean,
    IoTypeDouble,
    IoTypeInteger,
    IoTypeString,
    IoTypeVector,
    IoTypeSentinel
}
IoParamType;

typedef struct {	/* Easy (generic) access to keywords for 'IoParam' union. */
    const char *key;	/* official keyword name */
    const char *skey;	/* short alias for keyword */
    IoParamType param_type;		/* enumerated IoParamType */
}
IoParamCore;

typedef struct {
    const char *key;	/* official keyword name ("missile_yaw") */
    const char *skey;	/* short keyword name ("yaw") */
    IoParamType param_type;		/* enumerated IoParamType */
    const char *type;	/* parameter type ("linear","angle","area") */
    const char *units;	/* units of measure ("millimeters","degrees") */
    double conv;		/* conversion factor to get to units */
    double val;		/* double precision value of this parameter */
    IoStatus status;	/* IoSet if value has been filled in */
}
IoParamDbl;

typedef struct {
    const char *key;	/* official keyword name ("velocity_vec") */
    const char *skey;	/* short keyword name ("velvec") */
    IoParamType param_type;		/* enumerated IoParamType */
    const char *type;	/* parameter type ("direction","location") */
    const char *units;	/* units of measure ("millimeters","inches") */
    double conv;		/* conversion factor to get to units */
    VmVect val;		/* x, y, and z double-precision values */
    IoStatus status;	/* IoSet if entire vector has been filled in */
}
IoParamVec;

typedef struct {
    const char *key;	/* official keyword name ("keclass") */
    const char *skey;	/* short keyword name ("kcls") */
    IoParamType param_type;		/* enumerated IoParamType */
    const char *val;	/* parameter string ("AP", "HVAP") */
}
IoParamStr;

typedef struct {
    const char *key;	/* official keyword name */
    const char *skey;	/* short keyword name */
    IoParamType param_type;		/* enumerated IoParamType */
    MuvesBool val;		/* mTrue (1) or mFalse (0) value of parameter */
    IoStatus status;	/* IoSet if value has been filled in */
}
IoParamBool;

typedef struct {
    const char *key;	/* official keyword name */
    const char *skey;	/* short keyword name */
    IoParamType param_type;		/* enumerated IoParamType */
    int val;		/* integer value of this parameter */
    IoStatus status;	/* IoSet if value has been filled in */
}
IoParamInt;

/**
	Define a generic parameter type for convenience:

	typedef union
		{
		IoParamCore *corep; // generic access to  'key' and 'skey'
		IoParamBool *MuvesBoolp;
		IoParamDbl *dblp;
		IoParamInt *intp;
		IoParamStr *strp;
		IoParamVec *vecp;
		}
	IoParam;

	typedef struct
		{
		const char *key;	// official keyword name
		const char *skey;	// short alias for keyword
		}
	IoParamCore;
**/
typedef union {
    IoParamCore *corep;
    IoParamBool *MuvesBoolp;
    IoParamDbl *dblp;
    IoParamInt *intp;
    IoParamStr *strp;
    IoParamVec *vecp;
}
IoParam;

/* Data type for retrieving keyword/value pair via IoRdKeyValue. */
typedef struct {
    const char *key;	/* keyword */
    const char *value;	/* assigned value */
}
IoKeyValue;

/* Added IoKeyVector -- 02/18/2004 MJG */
/* Data type for retrieving keyword/value pair via IoRdKeyVector. */
typedef struct {
    const char *key;	/* keyword */
    IoParamVec *vector;	/* assigned vector */
}
IoKeyVector;

/*
    Data type to facilitate parsing a line into its comprising tokens.
*/
typedef struct {
    int nfields;		/* number of fields in input line */
    int linelen;		/* number of characters in input line */
    char **fields;		/* array of the actual fields */
}
IoLineTokens;

/* Increment and decrement macros for IoParamInt */
#define IoIncInt(a)	IoAddInt( (a), 1)
#define IoDecInt(a)	IoAddInt( (a), -1)

/* special characters allowed in identifiers */
#define IoCH_USCORE	'_'
#define IoCH_PERIOD	'.'
#define IoCH_ESCAPE	'\\'
#define IoCH_DBL_QUOTE	'\"'
#define IoCH_COLON	':'

#define IoIS_IDENTIFIER( c )	(isalnum( c )||(c)==IoCH_USCORE||\
				(c)==IoCH_PERIOD||(c)==IoCH_COLON)

#define IoBUFSIZE	512

/* Delimeters for keyword/value pairs in input files. */
#define IoSTARTCHR	'{'
#define IoENDCHR	'}'

extern void IoPkgInit();

#if STD_C
extern MuvesBool IoCopyBool( IoParamBool *tobp, IoParamBool *frombp );
extern MuvesBool IoGetBool( IoParamBool *bp );
extern MuvesBool IoParseDbl( IoKeyValue *keyvp, IoParamDbl *dblp );
extern MuvesBool IoSetBool( IoParamBool *bp, MuvesBool value );
extern const char *IoCopyString( IoParamStr *tostrp,
                                 const IoParamStr *fromstrp );
extern const char *IoGetString( const IoParamStr *strp );
extern const char *IoRdIdentifier( FILE *fp );
extern const char *IoRdLabel( FILE *fp );
extern const char *IoRdValue( FILE *fp );
extern const char *IoTypeToStr( IoParamType type );
extern MuvesBool IoSkipKeyValues( FILE *fp );
extern double IoCopyDbl( IoParamDbl *todblp, IoParamDbl *fromdblp );
extern double IoGetDbl( IoParamDbl *dblp );
extern double IoSetDbl( IoParamDbl *dblp, double value );
extern MuvesBool IoGetBool( IoParamBool *MuvesBoolp );
extern MuvesBool IoSetBool( IoParamBool *MuvesBoolp, MuvesBool value );
extern VmVect *IoCopyVec( IoParamVec *tovecp, IoParamVec *fromvecp );
extern VmVect *IoGetVec( IoParamVec *vecp );
extern VmVect *IoSetVec( IoParamVec *vecp, VmVect *valp );
extern void IoResetBool( IoParamBool *dbp );
extern void IoResetDbl( IoParamDbl *dblp );
extern void IoResetVec( IoParamVec *vecp );
extern MuvesBool IoRdAngle( FILE *fp, IoParamDbl *dblp );
extern MuvesBool IoRdBool( FILE *fp, IoParamBool *bp );
extern MuvesBool IoRdConst( FILE *fp, IoParamDbl *dblp );
extern MuvesBool IoRdDbl( FILE *fp, IoParamDbl *dblp );
extern MuvesBool IoRdDensity( FILE *fp, IoParamDbl *dblp );
extern MuvesBool IoRdBHN( FILE *fp, IoParamDbl *dblp );
extern MuvesBool IoRdKeyValue( FILE *fp, IoKeyValue *kvp );
extern MuvesBool IoRdKeyVector( FILE *fp, IoKeyVector *kvp );    /* Added 02/18/2004 MJG */
extern MuvesBool IoRdLinear( FILE *fp, IoParamDbl *dblp );
extern MuvesBool IoRdMass( FILE *fp, IoParamDbl *dblp );
extern MuvesBool IoRdSpecChar( FILE *fp, int ch );
extern MuvesBool IoRdStress( FILE *fp, IoParamDbl *dblp );
extern MuvesBool IoRdTime( FILE *fp, IoParamDbl *dblp );
extern MuvesBool IoRdVec( FILE *fp, IoParamVec *vecp );
extern MuvesBool IoRdVelocity( FILE *fp, IoParamDbl *dblp );
extern void IoInitAngle( IoParamDbl *dblp, const char *key, const char *skey );
extern void IoInitBool( IoParamBool *bp, const char *key, const char *skey );
extern void IoInitConst( IoParamDbl *dblp, const char *key, const char *skey );
extern void IoInitDbl( IoParamDbl *, const char *key, const char *skey,
                       const char *,const char *, double );
extern void IoInitDensity( IoParamDbl *dblp, const char *key,
                           const char *skey );
extern void IoInitBHN( IoParamDbl *dblp, const char *key,
                       const char *skey );
extern void IoInitLinear( IoParamDbl *dblp, const char *key, const char *skey );
extern void IoInitMass( IoParamDbl *dblp, const char *key, const char *skey );
extern void IoInitStdMass( IoParamDbl *dblp, const char *key, const char *skey );
extern void IoInitStress( IoParamDbl *dblp, const char *key, const char *skey );
extern void IoInitString( IoParamStr *strp, const char *key, const char *skey );
extern void IoInitTime( IoParamDbl *dblp, const char *key, const char *skey );
extern void IoInitVec( IoParamVec *, const char *, const char *, const char *,
                       const char *, double );
extern void IoInitVelocity( IoParamDbl *dblp, const char *key,
                            const char *skey );
extern void IoResetBool( IoParamBool *bp );
extern void IoResetVec( IoParamVec *vecp );
extern void IoPrParamBool( FILE *fp, const IoParamBool *dblp );
extern void IoPrParamDbl( FILE *fp, const IoParamDbl *dblp );
extern void IoPrParamStr( FILE *fp, const IoParamStr *strp );
extern void IoPrParamVec( FILE *fp, const IoParamVec *vecp );
extern void IoInitInt( IoParamInt *ip, const char *key, const char *skey );
extern void IoPrParamInt( FILE *fp, const IoParamInt *ip );
/* 08-09-24 ch3: added function prototype (SCR1099) */
extern void IoPrParamIntString(FILE *fp, const IoParamInt *ip, char **strings);
extern void IoResetInt( IoParamInt *bp );
extern int IoAddInt( IoParamInt *bp, int inc );
extern int IoSetInt( IoParamInt *bp, int value );
extern int IoGetInt( IoParamInt *bp );
extern int IoCopyInt( IoParamInt *tobp, IoParamInt *frombp );
extern MuvesBool IoRdInt( FILE *fp, IoParamInt *ip );
extern MuvesBool IoParseInt( IoKeyValue *keyvp, IoParamInt *ip );
extern MuvesBool IoParseBool( IoKeyValue *keyvp, IoParamBool *bp );
extern IoParamType IoStrToType( const char *name );
extern void IoRmblanks( char *b );
extern bs_type IoStrToInt(const char *, int *);
extern bs_type IoStrToDouble(const char *, double *);
extern IoLineTokens * IoTokenize(const char *str, const char *delimiter);
extern void IoLineTokensFree(IoLineTokens *o);
#else
extern MuvesBool IoCopyBool();
extern MuvesBool IoGetBool();
extern MuvesBool IoParseDbl();
extern MuvesBool IoSetBool();
extern const char *IoCopyString();
extern const char *IoGetString();
extern const char *IoRdIdentifier();
extern const char *IoRdLabel();
extern const char *IoRdValue();
extern const char *IoTypeToStr();
extern MuvesBool IoSkipKeyValues();
extern double IoCopyDbl();
extern double IoGetDbl();
extern double IoSetDbl();
extern VmVect *IoCopyVec();
extern VmVect *IoGetVec();
extern VmVect *IoSetVec();
extern void IoResetBool();
extern void IoResetDbl();
extern void IoResetVec();
extern MuvesBool IoRdAngle();
extern MuvesBool IoRdBool();
extern MuvesBool IoRdConst();
extern MuvesBool IoRdDbl();
extern MuvesBool IoRdDensity();
extern MuvesBool IoRdBHN();
extern MuvesBool IoRdKeyValue();
extern MuvesBool IoRdKeyVector();   /* Added 02/18/2004 MJG */
extern MuvesBool IoRdLinear();
extern MuvesBool IoRdMass();
extern MuvesBool IoRdSpecChar();
extern MuvesBool IoRdStress();
extern MuvesBool IoRd_String();
extern MuvesBool IoRdTime();
extern MuvesBool IoRdVec();
extern MuvesBool IoRdVelocity();
extern void IoInitAngle();
extern void IoInitBool();
extern void IoInitConst();
extern void IoInitDbl();
extern void IoInitDensity();
extern void IoInitBHN();
extern void IoInitLinear();
extern void IoInitMass();
extern void IoInitStdMass();
extern void IoInitPayload();
extern void IoInitProducts();
extern void IoInitStress();
extern void IoInitString();
extern void IoInitTime();
extern void IoInitVec();
extern void IoInitVelocity();
extern void IoResetBool();
extern void IoResetVec();
extern void IoPrParamBool();
extern void IoPrParamDbl();
extern void IoPrParamStr();
extern void IoPrParamVec();
extern void IoInitInt();
extern void IoPrParamInt();
/* 08-09-24 ch3: added function prototype (SCR1099) */
extern void IoPrParamIntString();
extern void IoResetInt();
extern int IoAddInt();
extern int IoSetInt();
extern int IoGetInt();
extern int IoCopyInt();
extern MuvesBool IoRdInt();
extern MuvesBool IoParseInt();
extern MuvesBool IoParseBool();
extern IoParamType IoStrToType();
extern void IoRmblanks();
extern bs_type IoStrToInt();
extern bs_type IoStrToDouble();
extern IoLineTokens * IoTokenize();
extern void IoLineTokensFree();
#endif

#define io_cpp_str(s) # s
#define io_cpp_xstr(s)  io_cpp_str(s)
#define IO_FLSTR __FILE__ ":" io_cpp_xstr(__LINE__)

/* SCR 1157: Io_*String() functions no longer do memory allocation */

typedef struct {
    char **strings;
    int count;
} IoStringArray;

extern const char *IoNewString PARAMS((IoStringArray *array,
                                       int index, const char *source,
                                       char *format, ...));
extern void IoFreeStringArray PARAMS((IoStringArray *array));

#define IoSTRING(arr,i,fmt,...) \
	((i) < (arr)->count && (arr)->strings[i] != NULL) ? \
	(arr)->strings[i] : IoNewString(arr,i,IO_FLSTR,fmt,__VA_ARGS__)
#define IoAddString(arr,str) \
	IoNewString(arr,(arr)->count,IO_FLSTR,"%s",str)

/* IoRdString must now pass a IoStringArray to store strings */
extern MuvesBool Io_RdString PARAMS(( FILE *fp, IoParamStr *strp,
                                      IoStringArray *store, const char *flstr ));
#define IoRdString(fp,strp,store) Io_RdString(fp,strp,store,IO_FLSTR)

/* IoResetString and IoSetString converted to macros: */
/*   extern void IoResetString( IoParamStr *strp ); */
/*   extern const char *IoSetString( IoParamStr *strp, const char *valp ); */

#define IoResetString(strp) (strp)->val = NULL
#define IoSetString(strp,valp) ((strp)->val = (valp))


#if ! STD_C
extern double difftime();
#endif

extern void	IoDecomment PARAMS(( char *b ));

#define	IoCOMMENT_CHAR	'#'

extern void	IoDeblank PARAMS(( char *b ));

#if STD_C
extern const char *IoDirCat( const char *s1, const char *s2 );
#else
extern const char *IoDirCat();
#endif

extern bs_type	IoGetLine PARAMS(( char *line_buffer, int size, FILE *fp ));

extern bs_type	IoGetTrim PARAMS(( char *line_buffer, int size, FILE *fp ));

extern bs_type	IoGetNonempty PARAMS(( char *line_buffer, int size, FILE *fp ));

extern const char	*IoCharStr PARAMS(( int c ));

#define	IoMAX_CharStr	3	/* for "EOF", "NUL", etc. */

extern const char	*IoStrStr PARAMS(( const char *string ));

extern const char	*IoStrPerror PARAMS(( void ));

extern const char	*IoInsert PARAMS(( const char *templateStr,
                                       const char *substituteStr ));

#define	IoMAX_InsStr	255	/* sufficient for commands, etc. */
/* IoMAX_InsStr is also the internal buffer size for IoStrStr(). */

extern MuvesBool	IoSafeName PARAMS(( const char *pathname ));

extern const char	*IoMUVES PARAMS(( void ));

extern FILE	*IoOpenFile PARAMS(( const char *mode, long errnum, ... ));

extern MuvesBool IoNewer PARAMS(( const char *path1, const char *path2 ));

extern const char	*IoVersion PARAMS(( void ));

extern MuvesBool	IoPending PARAMS(( int fd ));

extern void	IoNap PARAMS(( long usec ));

extern int IoLineNo PARAMS(( FILE *fp ));

extern bs_type IoGetIdentifier PARAMS(( register int c, char *tokbufp, register FILE *fp,
                                        char *symlist));

extern NmPool *IoGetList PARAMS(( FILE *fp, const char *fname, char *symlist ));

extern int IoNonSpaceGetChar PARAMS(( register FILE *fp ));

extern void IoErParse PARAMS(( const char *msg ));

/* SCR 1157: IoIsSet*() functions are now macros */
#define IoIsSetBool(bp) ((bp)->status == IoSet)
#define IoIsSetDbl(dblp) ((dblp)->status == IoSet)
#define IoIsSetString(strp) ((strp)->val != NULL)
#define IoIsSetVec(vecp) ((vecp)->status == IoSet)
#define IoIsSetInt(ip) ((ip)->status == IoSet)

/*
    Test for debug output

#define IoDEBUG_LineTokens	32
*/

#endif	/* Io_H_INCLUDED */
