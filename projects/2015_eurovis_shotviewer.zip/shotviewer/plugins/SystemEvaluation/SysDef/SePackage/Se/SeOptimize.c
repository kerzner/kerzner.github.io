/*
	SeOptimize.c -- MUVES Se (system evaluator) package expression optimizer

	created:	92/02/22	D A Gwyn (split off from SeCompile.c)
	updated:        00/06/30        C Hunt III
			added support for multiple occurrence bug fix
	edtied:		01/09/02	C Hunt III
			added level argument to SeFindMultOcc() call in
			SeOptimize()
*/
#ifndef lint
static char RCSid[] = "$Id: SeOptimize.c,v 1.22 2010/06/23 19:54:51 geoffs Exp $";
#endif

#ifndef DEBUG
#define NDEBUG
#endif

#include <assert.h>
#include <stdio.h>
#include <string.h>  /* 11-05-05 ch3: for strcpy() (VSL) */

#include <std.h>

#include <Ap.h>
#include <Dq.h>
#include <Er.h>
#include <stdio.h>
#include <common.h>   /* BRL-CAD 7.2.4+ no longer use config.h (SCR670) */
#include <Dm.h>
#include <bu.h>
#include <Nm.h>
#include <Se.h>

/* bizarrely, this include wasn't here before, even though genptr_t needs
   it... */
#include <Rt.h>

#include "SeDefs.h"

#ifndef SeDEBUG
#define SeDEBUG	0
#endif

extern int SeDebugging;
#define ErDebugging SeDebugging

/*
	void	SeOptimize( SeSysDef **exph )

	Optimizes the sysdef expression (sub)tree whose root node is
	pointed to by *exph.  (The double indirection allows the root
	pointer to be altered during optimization.)  This routine "never"
	fails; if an optimization cannot be performed, it is skipped.
	Thus no return status is necessary.

	Notice that earlier optimizations sometimes ensure that certain
	node types will not be visible in later stages of optimization
	nor at expression evaluation time.

	This function is for internal Se package use only.

	Currently implemented optimizations:

		Simple constant folding (e.g., 0-7 => [-7]).
		Constant-function folding (e.g., reldif(3,4) => [0.25]).
		Reductions:
			(e) => e	// SeNT_EXPR is vestigial
			~e => !e	// eliminate alternative form
			e&f => e*f	// ditto
			e>f => f<e	// reorder to aid optimization
			!e<!f => f<e
			@(e<f) => e<f	// < is nonnegative
			?(e<f) => e<f	// < is 0 or 1
			!e&!f => !(e|f)	// DeMorgan's law
			!e|!f => !(e&f)	// ditto
			!!e => e	// law of double negation
			@@e => @e	// abs is idempotent
			@?e => ?e	// ? is nonnegative
			??e => ?e	// ? is idempotent
			1-e => !e	// definition of P(!e)
			e|0 => e
			e|1 => 1
			e^0 => e
			e^1 => !e
			e+0 => e
			e-0 => e
			e*0 => 0
			e*1 => e
			e/1 => e
			// in the following,	k is any constant:
			k|e => e|k	// | is commutative
			k<<e => e<<k	// << is commutative
			k>>e => e>>k	// >> is commutative
			k^e => e^k	// ^ is commutative
			k+e => e+k	// + is commutative
			k*e => e*k	// * is commutative
			_random_normal(k,0) => k
			// in the following,	n is any non-zero constant:
			e/n => e*(1/n)	// * is usually faster than /
			// in the following,	z is any constant <  0,
			//			Z is any constant <= 0,
			//			O is any constant >= 1, and
			//			o is any constant >  1:
			@e<Z => 0
			z<@e => 1
			?e<Z => 0
			z<?e => 1
			?e<o => 1
			O<?e => 0
			(e<f)<Z => 0
			z<(e<f) => 1
			(e<f)<o => 1
			O<(e<f) => 0

	Possible future optimizations:

		More difficult reductions, e.g. ?e&?e => ?e, ?e&~?e => 0.
		(These require subtree matching.)

		Combine commutation and association to bring constants
		together.
 */

void
#if STD_C
SeOptimize( register SeSysDef **exph )
#else
SeOptimize( exph )
register SeSysDef **exph;
#endif
	{
	register SeSysDef *expp;
	register MuvesBool improved;	/* keeps track of when to stop iterating */
	char tmpstr[20];	/* temporary string for constant text */

	assert(exph != NULL);
	expp = *exph;
#if SeDEBUG
#if STD_C
	ErPLog( "SeOptimize(&%p)\n", (pointer) expp );
#else
	ErPLog( "SeOptimize(&0x%lx)\n", (long) expp );
#endif
#endif
	assert(expp != NULL);

	/* Depth first.  This is IMPORTANT. */
	/* 06-30-00 ch3  added checks for call to fix multiple occurrences */
	if( expp->type == SeNT_AND || expp->type == SeNT_OR )
		{
		ApT_EnvVar *envp;
		if ((envp=ApGetEnvVar("FixMultipleOccurrences")) != NULL
			&& envp->val)
			{
			/* find any multiple occurrences in expression */
			/* 01-09-02 ch3: added level argument for debugging */
			SeFindMultOcc(exph, 0);
			if (ErIsSet())
				return;
			expp = *exph;
			}
		}
	if( SeIS_UNARY_OP( expp->type ) || expp->type == SeNT_EXPR )
		{
		if( expp->type == SeNT_ANOT )
			{
#if SeDEBUG
			ErPLog( "\tChange ANOT to NOT\n" );
#endif
			expp->type = SeNT_NOT;	/* preferred */
			}
#if SeDEBUG
		ErPLog( "\tOptimize child of UNARY-OP[%d]\n", expp->type );
#endif
		assert(expp->o.lhsp == NULL);
		assert(expp->o.rhsp != NULL);
		SeOptimize( &expp->o.rhsp );
		}
	else
	if( expp->type == SeNT_EVAL )
		{
#if SeDEBUG
		ErPLog( "\tOptimize child of EVAL[%d]\n", expp->type );
#endif
		assert(expp->o.rhsp != NULL);
		SeOptimize( &expp->o.rhsp );
		}
	else
	if( SeIS_BINARY_OP( expp->type )
	 || expp->type == SeNT_RUNIF || expp->type == SeNT_RNORM )
		{
		/* 06-30-00 ch3  removed AND to PROD optimization */
		/*if( expp->type == SeNT_AND ) */
		/*	{ */
#if SeDEBUG
		/*	ErPLog( "\tChange AND to PROD\n" ); */
#endif
		/*	expp->type = SeNT_PROD;	** preferred */
		/*	} */
		/*else*/ if( expp->type == SeNT_GT )
			{
			register SeSysDef *old_rhsp = expp->o.rhsp;

#if SeDEBUG
			ErPLog( "\tConvert GT to LT\n" );
#endif
			expp->type = SeNT_LT;
			expp->o.rhsp = expp->o.lhsp;
			expp->o.lhsp = old_rhsp;
			}
#if SeDEBUG
		ErPLog( "\tOptimize children of %s[%d]\n",
			expp->type == SeNT_RUNIF ? "RAND-UNIF" :
			expp->type == SeNT_RNORM ? "RAND-NORM" :
			"BINARY-OP", expp->type );
#endif
		assert(expp->o.lhsp != NULL);
		SeOptimize( &expp->o.lhsp );
		assert(expp->o.rhsp != NULL);
		SeOptimize( &expp->o.rhsp );
		}
	else
	if( expp->type == SeNT_FNCALL )
		{	SeArgExp *np;
			SeValue fake;	/* dummy component value array */
			register double	eval;	/* evaluated function result */
#if SeDEBUG
		ErPLog( "\tOptimize arguments of FNCALL\n" );
#endif
		assert(expp->f.argexps != NULL);
		assert(! DqIsEmpty( expp->f.argexps ));
		DqEACH( expp->f.argexps, np, SeArgExp )
			{
			assert(np->expp != NULL);
			SeOptimize( &np->expp );
			}
#if SeDEBUG
		ErPLog( "\tTest for constant-valued FNCALL\n" );
#endif
		assert(expp->f.index >= 0);
		assert(expp->f.index < NmCount(&SeFunctions));
		assert(SeFnDfn[expp->f.index] != NULL);
		if( ! SeFnDfn[expp->f.index]->foldable )
			return;	/* no constant folding; that's all we can do */
		/* Test each argument for constancy. */
		assert(expp->f.argexps != NULL);
		assert(! DqIsEmpty( expp->f.argexps ));
		DqEACH( expp->f.argexps, np, SeArgExp )
			{
			assert(np->expp != NULL);
			if( np->expp->type != SeNT_CONSTANT )
				return;	/* no constant folding; that's all */
			}
		/* Constant-function folding: */
#if SeDEBUG
		ErPLog( "\tFold constant-valued FNCALL\n" );
#endif
		eval = SeEvlExpression( expp, &fake, (double *) NULL,
					SeTypeUnset, (const char *) NULL );
					/* call me.. */
		/* Discard the constant arguments and free resources. */
		while( (np = DqTPop( expp->f.argexps, SeArgExp )) != NULL )
			{
			assert(np->expp != NULL);
			assert(np->expp->type == SeNT_CONSTANT);
			SeExpFree( np->expp );	/* eat them */
			if( SeDebugging )
				np->expp = NULL; /* safety net */
			DmFree((genptr_t)np );
			}
		DqClose( expp->f.argexps );
		if( SeDebugging )
			expp->f.argexps = NULL;
		expp->type = SeNT_CONSTANT;
		expp->n.index = -1;
		expp->n.value = eval;
		/* 11-05-05 ch3: replace text (VSL) */
		DmFree(expp->core.text);
		sprintf(tmpstr, "%g", eval);
		expp->core.text = DmStrDup(tmpstr);
		return;	/* this node is as improved as it can get */
		}
	/* Nothing we do at the current node will cause us to have reason
	   to revisit its descendants. */

	/* Optimizations: */
#if SeDEBUG
	ErPLog( "\tOptimize node type %d\n", expp->type );
#endif
	do	{
		improved = mFalse;

		if( SeIS_UNARY_OP( expp->type ) )
			{
			SeValue fake;	/* dummy component value array */
			register double	eval;	/* evaluated expression */

			assert(expp->o.lhsp == NULL);
			assert(expp->o.rhsp != NULL);
			if( expp->o.rhsp->type == SeNT_CONSTANT )
				{
				/* Simple constant folding: */
#if SeDEBUG
				ErPLog( "\tApply UNARY-OP[%d] to constant\n",
					expp->type );
#endif
				eval = SeEvlExpression( expp, &fake,
						(double *) NULL, SeTypeUnset,
						(const char *) NULL );
				SeExpFree( expp->o.rhsp );

				if( SeDebugging )
					expp->o.rhsp = NULL; /* safety net */

				expp->type = SeNT_CONSTANT;
				expp->n.index = -1;
				expp->n.value = eval;
				/* 11-05-05 ch3: replace text (VSL) */
				DmFree(expp->core.text);
				sprintf(tmpstr, "%g", eval);
				expp->core.text = DmStrDup(tmpstr);
				improved = mTrue;
				}
			}
		else
		if( SeIS_BINARY_OP( expp->type ) )
			{
			SeValue fake;	/* dummy component value array */
			register double	eval;	/* evaluated expression */

			assert(expp->o.lhsp != NULL);
			assert(expp->o.rhsp != NULL);
			if( expp->o.lhsp->type == SeNT_CONSTANT )
				if( expp->o.rhsp->type == SeNT_CONSTANT )
					{
					/* Simple constant folding: */
#if SeDEBUG
					ErPLog(
					"\tApply BINARY-OP[%d] to constant\n",
						expp->type );
#endif
					eval = SeEvlExpression( expp, &fake,
						(double *) NULL, SeTypeUnset,
						(const char *) NULL );
					SeExpFree( expp->o.lhsp );
					SeExpFree( expp->o.rhsp );
					if( SeDebugging )
						{
						expp->o.lhsp = NULL; /* safety net */
						expp->o.rhsp = NULL;
						}
					expp->type = SeNT_CONSTANT;
					expp->n.index = -1;
					expp->n.value = eval;
					/* 11-05-05 ch3: replace text (VSL) */
					DmFree(expp->core.text);
					sprintf(tmpstr, "%g", eval);
					expp->core.text = DmStrDup(tmpstr);
					improved = mTrue;
					}
				else	{
					/* Transpose constant to RHS,
					   to assist further optimization: */
					switch( expp->type )
						{	register SeSysDef *tmp;

					/* Commutative operators: */
					/* 06-30-00 ch3  added case for AND */
					/*               since AND is no */
					/*               longer begin */
					/*               replaced with the */
					/*               PRODuct operator */
					case SeNT_AND :
					case SeNT_PROD :
					case SeNT_OR :
					case SeNT_MIN :
					case SeNT_MAX :
					case SeNT_XOR :
					case SeNT_SUM :
#if SeDEBUG
						ErPLog(
					"\tTranspose BINARY-OP[%d] operands\n",
							expp->type );
#endif
						tmp = expp->o.lhsp;
						expp->o.lhsp = expp->o.rhsp;
						expp->o.rhsp = tmp;
						improved = mTrue; /* (maybe) */
						break;

					/* Noncommutative, too hard for now: */
					case SeNT_DIFF :
					case SeNT_QUOT :
					case SeNT_LT :
						break;

					default:
						if( SeDebugging )
						    ErPLog("%s: %s %s\n",
					 		"SeOptimize: BUG",
							"illegal binary type",
							SeCvtToStr(expp->type)
							);
						break;
						}
					}
			}

		/* Node-type specific reductions: */
		switch( expp->type )
			{	register SeSysDef *rexp;	/* -> RHS exp */

		case SeNT_EXPR :
#if SeDEBUG
			ErPLog( "\tEliminate SeNT_EXPR node\n" );
#endif
			assert(expp->o.lhsp == NULL);
			assert(expp->o.rhsp != NULL);
			*exph = expp->o.rhsp;	/* bypass this node */
			expp->o.rhsp = NULL;	/* don't free too far */
			SeExpFree( expp );	/* eat me */
			expp = *exph;		/* prepare for more work */
			improved = mTrue;
			break;

		case SeNT_NOT :
			assert(expp->o.lhsp == NULL);
			rexp = expp->o.rhsp;
			assert(rexp != NULL);
			if( rexp->type == SeNT_NOT )
				{
#if SeDEBUG
				ErPLog( "\tEliminate NOT NOT\n" );
#endif
				assert(rexp->o.lhsp == NULL);
				assert(rexp->o.rhsp != NULL);
				*exph = rexp->o.rhsp;	/* bypass these nodes */
				rexp->o.rhsp = NULL;	/* don't free too far */
				SeExpFree( expp );	/* eat two nodes */
				expp = *exph;		/* prepare for more */
				improved = mTrue;
				}
			break;

		case SeNT_ABS :
			assert(expp->o.lhsp == NULL);
			rexp = expp->o.rhsp;
			assert(rexp != NULL);
			if( rexp->type == SeNT_ABS
			 || rexp->type == SeNT_BOOL
			 || rexp->type == SeNT_LT )
				{
#if SeDEBUG
				ErPLog( "\tEliminate useless ABS\n" );
#endif
				assert(rexp->o.lhsp == NULL);
				assert(rexp->o.rhsp != NULL);
				*exph = rexp;		/* bypass this node */
				expp->o.rhsp = NULL;	/* don't free too far */
				SeExpFree( expp );	/* eat me */
				expp = *exph;		/* prepare for more */
				improved = mTrue;
				}
			break;

		case SeNT_BOOL :
			assert(expp->o.lhsp == NULL);
			rexp = expp->o.rhsp;
			assert(rexp != NULL);
			if( rexp->type == SeNT_BOOL
			 || rexp->type == SeNT_LT )
				{
#if SeDEBUG
				ErPLog( "\tEliminate useless BOOL\n" );
#endif
				assert(rexp->o.lhsp == NULL);
				assert(rexp->o.rhsp != NULL);
				*exph = rexp;		/* bypass this node */
				expp->o.rhsp = NULL;	/* don't free too far */
				SeExpFree( expp );	/* eat me */
				expp = *exph;		/* prepare for more */
				improved = mTrue;
				}
			break;

		/* 06-30-00 ch3  added case for AND since AND is no longer */
		/*               begin replaced with the PRODuct operator */
		case SeNT_AND :
		case SeNT_PROD :
			assert(expp->o.lhsp != NULL);
			rexp = expp->o.rhsp;
			assert(rexp != NULL);
			if( rexp->type == SeNT_CONSTANT )
				{
				if( rexp->n.value == 0.0 )
					{
#if SeDEBUG
					ErPLog( "\tEliminate mult. by 0\n" );
#endif
					*exph = rexp;	/* bypass this node */
					expp->o.rhsp = NULL;  /* not too much */
					SeExpFree( expp );	/* eat me */
					expp = *exph;	/* prepare for more */
					improved = mTrue;
					}
				else
				if( rexp->n.value == 1.0 )	/* sure it is */
					{
#if SeDEBUG
					ErPLog( "\tEliminate mult. by 1\n" );
#endif
					*exph = expp->o.lhsp;	/* pass me by */
					expp->o.lhsp = NULL;  /* not too much */
					SeExpFree( expp );	/* eat me */
					expp = *exph;	/* prepare for more */
					improved = mTrue;
					}
				}
			else
			if( rexp->type == SeNT_NOT
			 && expp->o.lhsp->type == SeNT_NOT )
				{	register SeSysDef *lexp = expp->o.lhsp;
#if SeDEBUG
				ErPLog( "\tApply DeMorgan's law #1\n" );
#endif
				assert(lexp->o.lhsp == NULL);
				assert(lexp->o.rhsp != NULL);
				assert(rexp->o.lhsp == NULL);
				assert(rexp->o.rhsp != NULL);
				/* Two nodes undergo identity-change surgery: */
				expp->type = SeNT_NOT;
				expp->o.lhsp = NULL;
				rexp->type = SeNT_OR;
				rexp->o.lhsp = lexp->o.rhsp;	/* transfer */
				/* Third node is assassinated: */
				lexp->o.rhsp = NULL;	/* don't free too far */
				SeExpFree( lexp );	/* eat it */
				assert(expp == *exph);	/* no change here */
				improved = mTrue;
				}
			break;

		case SeNT_OR :
			assert(expp->o.lhsp != NULL);
			rexp = expp->o.rhsp;
			assert(rexp != NULL);
			if( rexp->type == SeNT_CONSTANT )
				{
				if( rexp->n.value == 0.0 )
					{
#if SeDEBUG
					ErPLog( "\tEliminate OR with 0\n" );
#endif
					*exph = expp->o.lhsp;	/* pass me by */
					expp->o.lhsp = NULL;  /* not too much */
					SeExpFree( expp );	/* eat me */
					expp = *exph;	/* prepare for more */
					improved = mTrue;
					}
				else
				if( rexp->n.value == 1.0 )	/* sure it is */
					{
#if SeDEBUG
					ErPLog( "\tEliminate OR with 1\n" );
#endif
					*exph = rexp;	/* bypass this node */
					expp->o.rhsp = NULL;  /* not too much */
					SeExpFree( expp );	/* eat me */
					expp = *exph;	/* prepare for more */
					improved = mTrue;
					}
				}
			else
			if( rexp->type == SeNT_NOT
			 && expp->o.lhsp->type == SeNT_NOT )
				{	register SeSysDef *lexp = expp->o.lhsp;
#if SeDEBUG
				ErPLog( "\tApply DeMorgan's law #2\n" );
#endif
				assert(lexp->o.lhsp == NULL);
				assert(lexp->o.rhsp != NULL);
				assert(rexp->o.lhsp == NULL);
				assert(rexp->o.rhsp != NULL);
				/* Two nodes undergo identity-change surgery: */
				expp->type = SeNT_NOT;
				expp->o.lhsp = NULL;
				/* 06-30-00 ch3  changed PROD to AND to */
				/*               because it is no longer */
				/*               replaced with PROD */
				rexp->type = SeNT_AND;	/* aka AND */
				rexp->o.lhsp = lexp->o.rhsp;	/* transfer */
				/* Third node is assassinated: */
				lexp->o.rhsp = NULL;	/* don't free too far */
				SeExpFree( lexp );	/* eat it */
				assert(expp == *exph);	/* no change here */
				improved = mTrue;
				}
			break;

		case SeNT_DIFF :
#define	lexp	rexp	/* kludge to share register */
			lexp = expp->o.lhsp;
			assert(lexp != NULL);
			assert(expp->o.rhsp != NULL);
			if( lexp->type == SeNT_CONSTANT
			 && lexp->n.value == 1.0 )
				{
#if SeDEBUG
				ErPLog( "\tConvert 1-expr to !expr\n" );
#endif
				/* This node undergoes a change of identity: */
				SeExpFree( lexp );	/* eat 1.0 node */
				assert(expp == *exph);	/* no change here */
				expp->type = SeNT_NOT;
				expp->o.lhsp = NULL;
				assert(expp->o.rhsp != NULL);	/* unchanged */
				improved = mTrue;
				break;	/* now try for SeNT_NOT optimizations */
				}
			/* else FALL THROUGH into following case */
#undef	lexp		/* end of kludge */
		/*FALLTHRU*/   
		case SeNT_SUM :
/*		case SeNT_DIFF :	 (if it falls through from above) */
			assert(expp->o.lhsp != NULL);
			rexp = expp->o.rhsp;
			assert(rexp != NULL);
			if( rexp->type == SeNT_CONSTANT )
				if( rexp->n.value == 0.0 )
					{
#if SeDEBUG
					ErPLog( "\tEliminate %s of 0\n",
						expp->type == SeNT_SUM ?
						"addition" :
						"subtraction" );
#endif
					*exph = expp->o.lhsp;	/* pass me by */
					expp->o.lhsp = NULL;  /* not too much */
					SeExpFree( expp );	/* eat me */
					expp = *exph;	/* prepare for more */
					improved = mTrue;
					}
			break;

		case SeNT_XOR :
			assert(expp->o.lhsp != NULL);
			rexp = expp->o.rhsp;
			assert(rexp != NULL);
			if( rexp->type == SeNT_CONSTANT )
				if( rexp->n.value == 0.0 )
					{
#if SeDEBUG
					ErPLog( "\tEliminate XOR with 0\n" );
#endif
					*exph = expp->o.lhsp;	/* pass me by */
					expp->o.lhsp = NULL;  /* not too much */
					SeExpFree( expp );	/* eat me */
					expp = *exph;	/* prepare for more */
					improved = mTrue;
					}
				else if( rexp->n.value == 1.0 )	/* sure it is */
					{
#if SeDEBUG
					ErPLog( "\tEliminate XOR with 1\n" );
#endif
					/* Node undergoes change of identity: */
					expp->type = SeNT_NOT;
					assert(expp->o.lhsp != NULL);
					expp->o.rhsp = expp->o.lhsp;
					expp->o.lhsp = NULL;
					SeExpFree( rexp );	/* eat 1 */
					assert(expp == *exph);	/* still here */
					improved = mTrue;
					}
			break;

		case SeNT_QUOT :
			assert(expp->o.lhsp != NULL);
			rexp = expp->o.rhsp;
			assert(rexp != NULL);
			if( rexp->type == SeNT_CONSTANT )
				if( rexp->n.value == 1.0 )	/* sure it is */
					{
#if SeDEBUG
					ErPLog( "\tEliminate div. by 1\n" );
#endif
					*exph = expp->o.lhsp;	/* pass me by */
					expp->o.lhsp = NULL;  /* not too much */
					SeExpFree( expp );	/* eat me */
					expp = *exph;	/* prepare for more */
					improved = mTrue;
					}
				else if( rexp->n.value != 0.0 )
					{
#if SeDEBUG
					ErPLog( "\tChange div. to mul.\n" );
#endif
					/* Node undergoes change of identity: */
					expp->type = SeNT_PROD;
					rexp->n.value = 1.0 / rexp->n.value;
					assert(expp == *exph);	/* still here */
					improved = mTrue;
					}
				/* NOTE:  Division by 0 might never be executed,
				   so don't warn about it here. */
			break;

		case SeNT_LT :
			{	register SeSysDef *lexp = expp->o.lhsp;
			rexp = expp->o.rhsp;
			assert(lexp != NULL);
			assert(rexp != NULL);
			if( lexp->type == SeNT_NOT
			 && rexp->type == SeNT_NOT )
				{
#if SeDEBUG
				ErPLog( "\tSwitch sense of LT\n" );
#endif
				assert(lexp->o.lhsp == NULL);
				assert(lexp->o.rhsp != NULL);
				assert(rexp->o.lhsp == NULL);
				assert(rexp->o.rhsp != NULL);
				expp->o.lhsp = rexp->o.rhsp;	/* promote    */
				expp->o.rhsp = lexp->o.rhsp;	/*   and swap */
				/* Intermediate NOT nodes are assassinated: */
				lexp->o.rhsp = NULL;	/* don't free too far */
				rexp->o.rhsp = NULL;	/* don't free too far */
				SeExpFree( lexp );	/* eat left */
				SeExpFree( rexp );	/* and right */
				assert(expp == *exph);	/* no change here */
				improved = mTrue;
				}
			else if( lexp->type == SeNT_CONSTANT )
				{
				if( lexp->n.value < 0.0
				 && (rexp->type == SeNT_ABS
				  || rexp->type == SeNT_BOOL
				  || rexp->type == SeNT_LT) )
					{
#if SeDEBUG
					ErPLog( "\tReduce const<0 LT MuvesBool\n" );
#endif
					/* Node undergoes change of identity: */
					expp->type = SeNT_CONSTANT;
					expp->n.index = -1;
					expp->n.value = 1.0;
					/* 11-05-05 ch3: replace text (VSL) */
					DmFree(expp->core.text);
					strcpy(tmpstr, "1.0");
					expp->core.text = DmStrDup(tmpstr);
					/* Operand nodes are assassinated: */
					SeExpFree( lexp );	/* eat left */
					SeExpFree( rexp );	/* and right */
					assert(expp == *exph);	/* still here */
					improved = mTrue;
					}
				else if( lexp->n.value >= 1.0
				 && (rexp->type == SeNT_BOOL
				  || rexp->type == SeNT_LT) )
					{
#if SeDEBUG
					ErPLog( "\tReduce const>=1 LT MuvesBool\n" );
#endif
					/* Node undergoes change of identity: */
					expp->type = SeNT_CONSTANT;
					expp->n.index = -1;
					expp->n.value = 0.0;
					/* 11-05-05 ch3: replace text (VSL) */
					DmFree(expp->core.text);
					strcpy(tmpstr, "0.0");
					expp->core.text = DmStrDup(tmpstr);
					/* Operand nodes are assassinated: */
					SeExpFree( lexp );	/* eat left */
					SeExpFree( rexp );	/* and right */
					assert(expp == *exph);	/* still here */
					improved = mTrue;
					}
				}
			else if( rexp->type == SeNT_CONSTANT )
				if( rexp->n.value <= 0.0
				 && (lexp->type == SeNT_ABS
				  || lexp->type == SeNT_BOOL
				  || lexp->type == SeNT_LT) )
					{
#if SeDEBUG
					ErPLog( "\tReduce MuvesBool LT const<=0\n" );
#endif
					/* Node undergoes change of identity: */
					expp->type = SeNT_CONSTANT;
					expp->n.index = -1;
					expp->n.value = 0.0;
					/* 11-05-05 ch3: replace text (VSL) */
					DmFree(expp->core.text);
					strcpy(tmpstr, "0.0");
					expp->core.text = DmStrDup(tmpstr);
					/* Operand nodes are assassinated: */
					SeExpFree( lexp );	/* eat left */
					SeExpFree( rexp );	/* and right */
					assert(expp == *exph);	/* still here */
					improved = mTrue;
					}
				else if( rexp->n.value > 1.0
				 && (lexp->type == SeNT_BOOL
				  || lexp->type == SeNT_LT) )
					{
#if SeDEBUG
					ErPLog( "\tReduce MuvesBool LT const>1\n" );
#endif
					/* Node undergoes change of identity: */
					expp->type = SeNT_CONSTANT;
					expp->n.index = -1;
					expp->n.value = 1.0;
					/* 11-05-05 ch3: replace text (VSL) */
					DmFree(expp->core.text);
					strcpy(tmpstr, "1.0");
					expp->core.text = DmStrDup(tmpstr);
					/* Operand nodes are assassinated: */
					SeExpFree( lexp );	/* eat left */
					SeExpFree( rexp );	/* and right */
					assert(expp == *exph);	/* still here */
					improved = mTrue;
					}
			/* if both operands constant, will get folded anyway */
			}
			break;

		case SeNT_RNORM :
			assert(expp->o.lhsp != NULL);	/* mean */
			rexp = expp->o.rhsp;		/* standard deviation */
			assert(rexp != NULL);
			if( rexp->type == SeNT_CONSTANT
				&& rexp->n.value == 0.0 )
				{	/* evaluation would just yield mean */
#if SeDEBUG
				ErPLog( "\tEliminate RNORM with std dev 0\n" );
#endif
				*exph = expp->o.lhsp;	/* pass me by */
				expp->o.lhsp = NULL;	/* not too much */
				SeExpFree( expp );	/* eat me */
				expp = *exph;	/* prepare for more */
				improved = mTrue;
				}
			break;

		/* I was unable to think of any easy optimizations for these: */
		case SeNT_MIN :
		case SeNT_MAX :
		case SeNT_RUNIF :
			break;

		/* Just leave this one alone: */
		case SeNT_LISTNAME :
			break;

		/* The following cannot possibly be optimized: */
		case SeNT_SYSNAME :
		case SeNT_COMPNAME :
		case SeNT_CONSTANT :
		case SeNT_LIST :
		case SeNT_PARAM :
		case SeNT_QUALSYS :
		case SeNT_QUALCOMP :
		case SeNT_QUALOP :
		case SeNT_CQUALIFIER :
			break;

		/* The following was already optimized in depth-first pass: */
		case SeNT_FNCALL :
			break;

		case SeNT_UNSET :
			if( SeDebugging )
				ErPLog( "SeOptimize: BUG: type unset.\n" );
			break;

		/* 06-30-00 ch3  added case for new multiple occurrence op */
		/* The following was already optimized in depth-first pass: */
		case SeNT_MULTOCC :
			break;

		default:
			if( SeDebugging )
			    ErPLog( "SeOptimize: BUG: illegal type \"%s\"\n",
				SeCvtToStr(expp->type) );
			break;
			}
		}
	while( improved );	/* end of "do" loop */
	}
