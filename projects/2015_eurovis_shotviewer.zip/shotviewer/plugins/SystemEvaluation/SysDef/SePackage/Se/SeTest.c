/*
	SeTest.c -- MUVES "Se" (system evaluator) package test

	created:	88/01/12	G S Moss
	updated:        02/07/27        C Hunt III
			added support for ORCA node type to SePrSysDef()
			(SCR446)
*/
#ifndef lint
static char RCSid[] = "$Id: SeTest.c,v 1.23 2010/06/23 19:54:51 geoffs Exp $";
#endif

#include <assert.h>	/* always active for test */
#include <stdio.h>

#ifdef __STDC__
#include <stdlib.h>	/* for EXIT_* */
#endif

#include <std.h>

#include <Er.h>
#ifndef COMPILE_FOR_VSL
#include <Fa.h>
#endif
#include <Io.h>
#include <stdio.h>
#include <common.h>   /* BRL-CAD 7.2.4+ no longer use config.h (SCR670) */
#include <Dm.h>
#include <Nm.h>
#include <Rt.h>
#include <Sc.h>
#include <Se.h>

#include "SeDefs.h"	/* for SeTesting, SeSysDef, etc. */

#ifdef COMPILE_FOR_VSL
NmPool RtComponents;		/* component name pool */
#endif

#ifndef STATIC
#define STATIC static
#endif

#ifndef	SeDEBUG
#define SeDEBUG	0
#endif

#define	TOLERANCE	0.0001		/* tolerance for rel. diff. testing */

/*
	double	RelDif( double a, double b )

	Computes the relative difference of two quantities (0 if same).

	[Borrowed from VLD/VMB library.]
 */

static double
#if STD_C
RelDif( double a, double b )
#else
RelDif( a, b )
double	a, b;
#endif
	{
	double	c = Abs( a );
	double	d = Abs( b );
	d = Max( c, d );
	return d == 0.0 ? 0.0 : Abs( a - b ) / d;
	}

/*
	void SePrSysDef( SeSysDef *sysdefp )

	Prints a system expression subtree to the standard output.
 */
static int level = 0;			/* expression level, for indentation */
/*ARGSUSED*/
STATIC void
#if STD_C
SePrSysDef( SeSysDef *sysdefp )
#else
SePrSysDef( sysdefp )
SeSysDef *sysdefp;
#endif
	{	register int col;	/* column counter for indentation */
	level++;
	for( col = 0; col < level; col++ )
		(void) printf( " " );
	if( sysdefp == NULL )
		{
		ErPLog( "BUG: null (sub)expression pointer.\n" );
		(void) printf( "NULL\n" );
		}
	else
	switch( sysdefp->type )
		{
	case SeNT_SYSNAME :
		{	register const char *name;
		if( (name = NmName( sysdefp->c.index, &SeSystems )) == NULL )
			ErPLog( "BUG: bad component index (%d).\n",
				sysdefp->c.index );
		else
			(void) printf( "[%s]\n", name );
		break;
		}
	case SeNT_COMPNAME :
		{	register const char *name;
		if( (name = NmName( sysdefp->c.index, &SeComponents )) == NULL )
			ErPLog( "BUG: bad component index (%d).\n",
				sysdefp->c.index );
		else
			(void) printf( "<%s>\n", name );
		break;
		}
	case SeNT_CONSTANT :
		(void) printf( "{%f}\n", sysdefp->n.value );
		break;
	case SeNT_FNCALL :
		{	register const char *name;
		if( (name = NmName( sysdefp->f.index, &SeFunctions )) == NULL )
			ErPLog( "BUG: bad function definition index (%d).\n",
				sysdefp->f.index );
		else
			{	SeArgExp *np;
			(void) printf( "%s(\n", name );
			DqEACH( sysdefp->f.argexps, np, SeArgExp )
				{
				if(np != DqFirst(sysdefp->f.argexps, SeArgExp))
					{
					for( col = 0; col < level; col++ )
						(void) printf( " " );
					(void) printf( ",\n" );
					}
				SePrSysDef( np->expp );
				}
			for( col = 0; col < level; col++ )
				(void) printf( " " );
			(void) printf( ")\n" );
			}
		break;
		}
	case SeNT_PARAM :
		(void) printf( "$%d\n", sysdefp->p.index );
		break;
	case SeNT_EXPR :
		(void) printf( "%s\n", SeTtbl[SeNT_LF_PAREN].ts );
		SePrSysDef( sysdefp->o.rhsp );
		for( col = 0; col < level; col++ )
			(void) printf( " " );
		(void) printf( "%s\n", SeTtbl[SeNT_RT_PAREN].ts );
		break;
	case SeNT_NOT :
	case SeNT_ANOT :
	case SeNT_ABS :
	case SeNT_BOOL :
		(void) printf( "%s\n", SeTtbl[sysdefp->type].ts );
		SePrSysDef( sysdefp->o.rhsp );
		break;
	case SeNT_LIST :
	case SeNT_AND :
	case SeNT_XOR :
	case SeNT_OR :
	case SeNT_MIN :
	case SeNT_MAX :
	case SeNT_SUM :
	case SeNT_DIFF :
	case SeNT_PROD :
	case SeNT_QUOT :
	case SeNT_LT :
	case SeNT_GT :
		(void) printf( "%s\n", SeTtbl[sysdefp->type].ts );
		SePrSysDef( sysdefp->o.lhsp );
		SePrSysDef( sysdefp->o.rhsp );
		break;
	case SeNT_RUNIF :
		(void) printf( "RANDOM-UNIFORM\n" );
		SePrSysDef( sysdefp->o.lhsp );
		SePrSysDef( sysdefp->o.rhsp );
		break;
	case SeNT_RNORM :
		(void) printf( "RANDOM-NORMAL\n" );
		SePrSysDef( sysdefp->o.lhsp );
		SePrSysDef( sysdefp->o.rhsp );
		break;
	case SeNT_MOFN:
		(void) printf( "M-OF-N\n" );
		SePrSysDef( sysdefp->o.lhsp );
		SePrSysDef( sysdefp->o.rhsp );
		break;
	case SeNT_PKD:
		(void) printf( "PKD\n" );
		SePrSysDef( sysdefp->o.lhsp );
		SePrSysDef( sysdefp->o.rhsp );
		break;
	/* 02-07-27 ch3: added support for ORCA node type */
	case SeNT_ORCA:
		(void) printf( "ORCA\n" );
		SePrSysDef( sysdefp->o.lhsp );
		SePrSysDef( sysdefp->o.rhsp );
		break;
	case SeNT_EVAL :
		(void) printf( "EVAL\n" );
		SePrSysDef( sysdefp->o.lhsp );
		SePrSysDef( sysdefp->o.rhsp );
		break;
	case SeNT_UNSET:
		ErPLog( "BUG: node type unset.\n" );
		(void) printf( "Node type unset\n" );
		break;
	default :
		ErPLog( "BUG: illegal node type (%s).\n",
			SeCvtToStr(sysdefp->type) );
		(void) printf( "Unknown node type %s\n",
				SeCvtToStr(sysdefp->type) );
		break;
		}
	level--;
	return;
	}

/*
	void SePrtAllSystems( void )

	Prints all system definitions to the standard output.
 */
STATIC void
#if STD_C
SePrtAllSystems( void )
#else
SePrtAllSystems()
#endif
	{	register int sys, nsys = NmCount( &SeSystems );
	for( sys = 0; sys < nsys; sys++ )
		if( SeDataSystem[sys] != NULL )
			{
			(void) printf( "SYSTEM:%s\n",
					NmName( sys, &SeSystems ) );
			assert(level == 0);
			SePrSysDef( SeDataSystem[sys]->sysdef );
			assert(level == 0);
			}
	}

/*
	void SePrtFunctions( void )

	Prints all function definitions to the standard output.
 */
STATIC void
#if STD_C
SePrtFunctions( void )
#else
SePrtFunctions()
#endif
	{	register int fnc, nfnc = NmCount( &SeFunctions );
	for( fnc = 0; fnc < nfnc; fnc++ )
		if( SeFnDfn[fnc] != NULL )
			{
			(void) printf( "FUNCTION:%s\n",
					NmName( fnc, &SeFunctions ) );
			assert(level == 0);
			SePrSysDef( SeFnDfn[fnc]->funcdefp );
			assert(level == 0);
			}
	}

/*
	MuvesBool SeEvlAllSystems( SeValue *valp, SeTypeID type )

	Prints results of evaluating each system definition.
 */
STATIC MuvesBool
#if STD_C
SeEvlAllSystems( SeValue *valp, SeTypeID type )
#else
SeEvlAllSystems( valp, type )
SeValue *valp;
SeTypeID type;
#endif
	{	register int sys, nsys = NmCount( &SeSystems );
	for( sys = 0; sys < nsys; sys++ )
		{
		register const char *name = NmName( sys, &SeSystems );
		assert(name != NULL);	/* else Nm pkg is screwed up */
		if( SeDataSystem[sys] == NULL )
			ErPLog(
			"BUG: Null SeDataSystem[] entry for system \"%s\".\n",
				name );
		else
		if( SeDataSystem[sys]->sysdef == NULL )
			ErPLog( "BUG: Null sysdef pointer for system \"%s\".\n",
				name );
		else	{	double value;	/* expression evaluation */
			assert(! ErIsSet());
			value = SeSysEval( sys, valp, (double *) NULL, type,
					   (const char *) NULL );
			(void) printf( "%s->value=%f\n", name, value );
			if( ErIsSet() )
				{
				assert(RelDif( value, 1.0 ) < TOLERANCE);
				return	mFalse;
				}
			assert(RelDif(SeDataSystem[sys]->save.value,value)<TOLERANCE);
			}
		}
	return	mTrue;
	}

/*
	MuvesBool SeEvlStates( SeValue *valp )

	Prints results of evaluating each state vector definition.
 */
STATIC MuvesBool
#if STD_C
SeEvlStates( SeValue *valp )
#else
SeEvlStates( valp )
SeValue *valp;
#endif
	{	register int state, nstate = NmCount( &SeStates );
	for( state = 0; state < nstate; state++ )
		{	register const char *name = NmName( state, &SeStates );
		assert(name != NULL);	/* else Nm pkg is screwed up */
		if( SeStDef[state] == NULL )
			ErPLog( "BUG: Null SeStDef[] entry for state \"%s\".\n",
				name );
		else
		if( SeStDef[state]->defs == NULL )
			ErPLog( "BUG: Null defs pointer for state \"%s\".\n",
				name );
		else	{	double *values;	/* vector evaluation */
				SeTypeID type1, type2; /* type of vector */
				int len1, len2; /* length of vector */
				const char **names; /* member names */
			assert(! ErIsSet());
			if(  (values = SeStEval( name, valp, &type1, &len1 ))
				== NULL
			  || (names = SeStQuery( name, &type2, &len2 ))
				== NULL )
				return mFalse;
			if( type1 != type2 )
				{
				ErPLog( "BUG: SeStEval() and SeStQuery() " );
				ErLog( "%s for state vector \"%s\".\n",
					"return different vector types",
					name );
				return mFalse;
				}
			if( len1 != len2 )
				{
				ErPLog( "BUG: SeStEval() and SeStQuery() " );
				ErLog( "%s for state vector \"%s\".\n",
					"return different vector lengths",
					name );
				return mFalse;
				}
			printf( "EVALUATED STATE: %s\n\t", name );
			while( *names != NULL )
				printf( " %s=%g",
					*names++, *values++ );
			printf( "\n" );
			if( ErIsSet() )
				return	mFalse;
			}
		}
	return	mTrue;
	}

/*
	SeTest main program.

	Usage:	SeTest component_list_name sysdef_file_name states_file_name
 */
static char compot[BUFSIZ];	/* (stupid name to work around "lint") */
static char statename[SeBUFSIZE];
#define ST_DIMENSION	32
static char *states[ST_DIMENSION];

int
#if STD_C
main( int argc, char **argv )
#else
main( argc, argv )
int argc;
char **argv;
#endif
	{	register int i, nstates, ncomps;
		SeValue *valuesp = NULL; /* allocated component value table */
		char *iscritical = NULL; /* allocated criticality flag array */
		FILE *compfp, *statesfp;
		bs_type success;	/* result from SeStParse() */

#ifdef COMPILE_FOR_VSL
	// ApPkgInit();
        DqPkgInit();
#endif
	ErPkgInit();
#ifndef COMPILE_FOR_VSL
	FaPkgInit();
#endif
	IoPkgInit();
	
	NmPkgInit();
#ifdef COMPILE_FOR_VSL
        NmInit (&RtComponents);
#else
	RtPkgInit();
#endif
	SePkgInit();
	
	ErPrefix( ErSimple( argv[0] ) );
	if( argc != 4 )
		{
		ErPLog( "Usage:\tSeTest comps sysdef states\n" );
		return	EXIT_FAILURE;
		}
	SeTesting = mTrue;		/* get standard defs from local dir. */
	/* Test exercising SeStParse() without preceding by "sysdef"
		processing. */
	if( (statesfp = SeStOpen( argv[3] )) == NULL )
		{
		if( ErIsSet() )
			ErPrint();
		return	EXIT_FAILURE;
		}
	/* Note: SeStackp won't be used during the following: */
	for(	nstates = 0;
		(success = SeStNextName( statesfp, statename )) == bs_good;
		nstates++
		)
		{
		(void) printf( "%s\n", statename );
		(void) fflush( stdout );
		if( nstates >= ST_DIMENSION )
			{
			ErPLog( "Too many states; limit %d\n", ST_DIMENSION );
			return	EXIT_FAILURE;
			}
		states[nstates] = DmStrDup(statename );
		}
	if( success == bs_ugly )
		{
		ErPrint();
		return	EXIT_FAILURE;
		}
	SeStClose( statesfp );
	statesfp = NULL;
	assert(NmCount( &RtComponents ) == 0);
	/* Add fake target component names from input file. */
	if( (compfp = fopen( argv[1], "r" )) == NULL )
		{
		ErPLog( "couldn't open component name file \"%s\"\n", argv[1] );
		return	EXIT_FAILURE;
		}
	for( ; ; )
		{
		switch( IoGetNonempty( compot, BUFSIZ, compfp ) )
			{
		case bs_good:		/* add to name pool */
			if( NmIndex( compot, &RtComponents, mTrue ) < 0 )
				{
				ErPLog( "couldn't add component \"%s\": %s\n",
					compot, ErString() );
				return	EXIT_FAILURE;
				}
			continue;
		case bs_bad:		/* normal EOF */
			break;
		case bs_ugly:		/* I/O error */
			ErPLog( "error while reading \"%s\": %s\n",
				argv[1], ErString() );
			return	EXIT_FAILURE;
			}
		break;			/* EOF => end loop */
		}
	(void) fclose( compfp );
	compfp = NULL;

	/* Parse and compile "sysdef" file. */
	if( SeSysOpen( argv[2], mTrue ) == NULL )
		{
		ErPLog( "Compiler error: file (%s).\n", argv[2] );
		i = 0;
		goto bad_sysopen;
		}
	/* Print any qualified components. */
	for( i = NmCount( &RtComponents ); --i >= 0; )
		{	const DqNode *listp;
		if( (listp = SeGetQualList( i )) != NULL )
			{	SeQalNode *np;
			printf( "QUALIFIERS FOR COMPONENT: %s\n",
				NmName( i, &SeComponents ) );
			DqEACH( listp, np, SeQalNode )
				printf( "%s:\t%s\n",
					SePrsBaseName( np->index ),
					SePrsQualName( np->index ) );
			}
		}
	/* Process the "states" file. */
	if( (statesfp = SeStOpen( argv[3] )) == NULL )
		{
		ErPLog( "Parser error: file (%s).\n", argv[3] );
		return	EXIT_FAILURE;
		}
	for( i = 0; i < nstates; i++ )
		{	register int comp;
		if( ! SeStCompile( statesfp, states[i] ) )
			{
			ErPrint();
			ErPLog( "Compiler error: state (%s), file (%s).\n",
				states[i], argv[3] );
			goto bad_statescompile;
			}
		/* Make up a component value table. */
		if( (ncomps = NmCount( &SeComponents )) < 0 )
			{
			ErPrint();
			return	EXIT_FAILURE;
			}
		valuesp = (SeValue *)DmRealloc(valuesp, (ncomps)*sizeof(SeValue));
		(void) printf( "STATE: %s:\n", states[i] );
		if( ! SeStCompile( statesfp, states[i] ) )
			{
			ErPLog( "Compiler error: state (%s), file (%s).\n",
				states[i], argv[3] );
			goto bad_statescompile;
			}
		}
#if 0 /* XXX - SeStIsCritical relies on Ap package which is not being used. */
	if( (iscritical = SeStIsCritical()) == NULL )
		{
		ErPrint();
		goto bad_statescompile;
		}
#endif
	for( i = 0; i < nstates; i++ )
		{	register int comp;
		(void) printf( "STATE: %s:\n", states[i] );
#if 0 /* XXX */
                for( comp = 0; comp < ncomps; comp++ )
                        (void) printf( "\tcomponent %s: %s\n",
                                        NmName( comp, &SeComponents ),
                                        iscritical[comp] ? "true" : "false"
                                        );
#endif
		DmFree((genptr_t)states[i] );
		}

	for( i = 0; i < ncomps; i++ )
		{
		valuesp[i].type = SeTypeFRF;
		valuesp[i].value = 0.5;
		}
	/* Evaluate state vectors before systems. */
	if( ! SeEvlStates( valuesp ) )
		{
		ErPrint();
		return	EXIT_FAILURE;
		}
	/* Clear values for systems and process "states" with system
		evaluation first. */
	SeSysReset();
	if( ! SeEvlAllSystems( valuesp, SeTypeFRF ) )
		{
		ErPrint();
		return	EXIT_FAILURE;
		}
	SePrtFunctions();
	SePrtAllSystems();
	if( ! SeEvlStates( valuesp ) )
		{
		ErPrint();
		return	EXIT_FAILURE;
		}
	SeStClose( statesfp );
	if( ! SeSysClose() || ! SeStFree() )
		{
		ErPrint();
		return	EXIT_FAILURE;
		}
	statesfp = NULL;

	NmClear( &RtComponents );
	DmFree((genptr_t)valuesp );

	return	EXIT_SUCCESS;
bad_statescompile:
	SeStClose( statesfp );
	statesfp = NULL;
	(void) SeStFree();
bad_sysopen:
	for( ; i < nstates; i++ )
		DmFree((genptr_t)states[i] );
	if( valuesp != NULL )
		DmFree((genptr_t)valuesp );
	if( SeDataSystem != NULL )
		(void) SeSysClose();
	NmClear( &RtComponents );
	return EXIT_FAILURE;
	}
