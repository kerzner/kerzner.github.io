/**
	<Se.h> -- MUVES "Se" (System evaluation) package I/F definitions
**/

/*
	created:	88/03/25	G S Moss
	updated:        00/05/30        C Hunt III
			added changes to support multiple occurrence bug fix
	edited:         01/03/18        C Hunt III
			added prototypes for SeRegisterQualComp(),
			SeStompSeQualp(), SeRegisterNewQualComp()
	RCSid:		$Id: Se.h,v 1.26 2010/06/23 19:54:51 geoffs Exp $
*/
/**
	The Se package provides a facility to define and evaluate
	measures of effectiveness for a target after it is damaged by a
	shot.  Measures of effectiveness may be defined in terms of
	system functionalities or component damage levels.  Evaluation
	of system functionality is guided by expressions specified in a
	system definition ("sysdef") file.  The user may request the
	reporting of state vectors that are defined in a "states" file.
	State vectors are specified as named, and typed, arrays.  All
	members of a particular vector are evaluated via definitions in
	the sysdef file to a value of the specified type (e.g. boolean).
	Each member may be a system or component; it is not expected
	that mixing these objects within a vector will be meaningful,
	but this is not prohibited by the Se package.

	IMPORTANT:  Use of this package requires the following header
	files to be included as follows:

		#include <stdio.h>
		#include <Se.h>

	This is necessary because not all C environments support
	multiple inclusion of <stdio.h>, so <Se.h> cannot contain it.


	System definitions (contents of "sysdef" files) are described by
	the following BNF grammar.  Newlines are required between
	definitions, but are treated as white space elsewhere.  White
	space is ignored, except that space characters may appear inside
	identifiers when escaped or when the identifer is in double
	quotes.  Although not shown in the grammar, a comment starting
	with an unquoted '#' causes the rest of the line to be skipped.

	sysdef-file	::=	{ definition NL }*

	definition	::=	system-def	# _* reserved for MUVES
			|	function-def	# _* reserved for MUVES
			|	list-def	# _* reserved for MUVES

	system-def	::=	system-name '=' expression

	function-def	::=	function-name '(' parameter-list ')' '='
					expression

	list-def	::=	list-name '=' member-list

	system-name	::=	identifier

	function-name	::=	identifier

	parameter-list	::=	parameter { ',' parameter }*

	parameter	::=	identifier

	list-name	::=	identifier


	A "states" file consists of one or more state definitions.
	These must have at least one newline as a separator, as well as
	other optional white space.

	states-file	::=	{ state-def NL }+

	A state definition consists of an identifier, followed by a type
	specifier, followed by an equals sign and finally a vector.
	[NOTE that any of the above pieces can be separated by white
	space, but it is required where explicitly stated.  This holds
	mTrue for the entire grammar.]

	state-def	::=	state-name WS type '=' vector

	state-name	::=	identifier

	A vector is expressed as a left brace followed by one or more
	members and a right brace; if it has a single member, the braces
	are optional.  If more than one member, they must have
	intervening separators.

	vector		::=	'{' member-list '}'
			|	member-name

	member-list	::=	member-name { ',' member-name }*

	member-name	::=	system-name	| qualified-system-name
			|	component-name	| qualified-component-name
			|	list-name	| qualified-list-name

	component-name			::= identifier

	qualified-component-name	::= qualified-identifier

	qualified-system-name		::= qualified-identifier

	qualified-list-name		::= qualified-identifier

	A type specifier can be one of: "lof", "frf", "pk", "killed" or "hit".

	type		::=	'lof'
			|	'frf'
			|	'pk'
			|	'killed'
			|	'hit'


	The following definitions are common to all Se package grammars.
	Note that identifiers may contain digits, but must not qualify
	as constants.

	In evaluating an expression, Se will substitute component values
	for component names; component values typically represent either
	fractional remaining functionality, loss of function or probablility
	of kill of the corresponding component.  Nominally "Boolean"
	operations in expressions are evaluated as the probabilities of
	the corresponding Boolean combinations of events having
	individual probabilities given by the operands.  Other operators
	have their ordinary arithmetic meaning.  This hybrid approach
	permits "fault trees" to be easily expressed, while allowing for
	much more general methods of evaluation.

	expression	::=	system-name | qualified-system-name
			|	component-name | qualified-component-name
			|	parameter	# in function definition
			|	function-call
			|	constant
			|	unary-operator expression
			|	expression binary-operator expression
			|	'(' expression ')'

	function-call	::=	function-name '(' argument-list ')'

	argument-list	::=	argument { ',' argument }*

	argument	::=	expression

	constant	::=	{ digit }+
			|	{ digit }+ '.' { digit }*
			|	'.' { digit }+

	unary-operator	::=	'!'	# not
			|	'~'	# not (alternate)
			|	'@'	# absolute-value
			|	'?'	# 1 if operand > 0, 0 otherwise
				# Note: use "0 - e" in place of "-e"

	binary-operator	::=	'&'	# and
			|	'|'	# or ("survivor sum rule")
			|	'<<'	# minimum
			|	'>>'	# maximum
			|	'^'	# exclusive-or
			|	'+'	# sum
			|	'-'	# difference
			|	'*'	# product
			|	'/'	# quotient
			|	'<'	# less-than (result is 0 or 1)
			|	'>'	# greater-than (ditto)

	qualified-identifier ::= identifier '[' identifier ']'

	Identifiers are not allowed to contain spaces.  This is a MUVES
	policy; the Se parser will permit escaped or quoted spaces, but
	since some input file parsers do not except spaces in component
	names, a consistent policy seems the most prudent.

	identifier	::=	{ ident-char }+	# mustn't match constant
			|	'"' { quoted-symbol }+ '"'

	ident-char	::=	letter
			|	digit
			|	'_'
			|	'.'
			|	escaped-symbol

	quoted-symbol	::=	<any printable character except '"'>
			|	escaped-symbol

	escaped-symbol	::=	'\' symbol

	symbol		::=	<any printable character>

	letter		::=	<'A' .. 'Z'>
			|	<'a' .. 'z'>

	digit		::=	<'0' .. '9'>


	White space is one or more of: <space>, <tab> or <newline>.

	WS		::=	{ <tab> | <space> | NL }+

	NL		::=	<newline character>


	Operator Precedence, in decreasing order (and associativity):

		Unary operators (right to left)

			!  ~  @  ?

		Binary operators (left to right)

			&
			^
			|
			<<  >>
			*  /
			+  -
			<  >


	Example system definition file (not realistic!):

	# Sample "sysdef" (system definition) file for testing MUVES
	# Definition of master power.
	master_power = 0.5 >>		# Value at least 0.5 for this system
		!(	( engine_power
			& cable_3w103
			& cable_2w108
			& voltage_regulator
			& ~ hull_networks_box[mobility]
			& cable_2w101
			& engine_disconnect_panel
			& (cable_3w102-1 ^ cable_3w102\-2)
			* cable_2w157
			+ cable_2w158
			) | ? batteries
		)
		& terminal_boards
		& @cable_2w154\-2w155
		& hull_distribution_box[mobility]

	# Definition of engine power.
	engine_power =  fuel_supply_system
		& driver\'s_master_panel
		& cable_\2w104\
		& hull_networks_box[mobility]
		& cable_2w105\-9
		& electronic_control_unit[mobility]
		& compressor
		& recuperator
		& combustor
		& power_turbine
		& planetary_output_shafts_and_bearing
		& accessory_gearbox
		& turbine_oil_lines
		& oil_pump
		& oil_filter
		& 1st_oil_reservoir
		& 1st_turbine_oil_cooler
		& oil_lines_to_cooler
		& oil_lines_to_alternator
		& alternator
		& air_cleaner
		& engine_air_outlet_duct
		& bleed_air_shutoff_valve

	# Parameterized function definition:
	Power(alpha) =	alpha * (!master_power &  engine_power) +
		alpha * ( master_power & !engine_power)

	# Definition of fuel supply system
	fuel_supply_system = left_rear_fuel_tank
		& right_rear_fuel_tank
		& rear_fuel_tank_interconnect
		& (f.line\-l.r._tank_to_tee |
		   f.line\-r.r._tank_to_tee)
		& f.line_tee
		& f.line\-tee_to_pif
		& primary_inline_filter
		& fuel\-water_separator
		& f.line\-fws_to_eif
		& engine_inline_filter
		& f.line\-eif_to_emfs
		& electromechanical_fuel_system
		& f.line\-emfs_to_fuel_nozzle
		& fuel_nozzle

	# Definition of Mobility.
	Mobility = Power(0.4) | (0.2 * fuel_supply_system)

	Example states file:

	# Sample states (state vector) file for testing MUVES
	DegradedStates lof =
		{
		Mobility, Firepower, Commo, Ammo, Acquisition
		}

	Crew = Commander, Gunner, Loader, Driver

	PersonnelCasualties killed = Crew

	PersonnelHits hit = Crew[hit]

	Mobility frf = Mobility
**/

#ifndef Se_H_INCLUDED
#define Se_H_INCLUDED

#include <std.h>	/* for MuvesBool, bs_type, STD_C */

#include <Dq.h>		/* for DqNode */
#include <Nm.h>		/* for NmPool */

typedef enum {
    SeNoFail,
    SeFail2,
    SeFail3,
    SeFail_Sentinel
} SeFailEnum;

/* 11-04-17 ch3: added container for parse and compile variables (VSL) */
typedef struct {
    int SeLnNo;		/* current line number being parsed in file */
    long SeLnAddr;		/* file offset of beginning of text line */
    DqNode *SeStackp;	/* queued-up tokens from parser */
    MuvesBool SeResName;	/* "define reserved names" flag */
    FILE *fp;		/* sysdef file handle pointer */
    char *str;		/* alternative sysdef string pointer */
    int pos;		/* position into sysdef string */
    int len;		/* length of sysdef string */
    NmPool argnames; 	/* store arguments to function def. */
    SeFailEnum error;	/* any error that may occur during initialize */
    MuvesBool interactive;	/* interactive mode (not normal batch mode) */
    char *errmsg;		/* pointer buffer to put error message into */
    int errloc;		/* location of error within input string */
    MuvesBool allow_comps;	/* allow for #COMP: at begin of file (VSL) */
    MuvesBool find_comps;	/* look for #COMP: at begin of file (VSL) */

    MuvesBool parsing;	/* if mTrue, do not compile, just parse;
				   i.e., do not push tokens onto queue */
    int lastLnNo;		/* line number of last line parsed */
    long lastLnAddr;	/* file offset beginning of last line parsed */

    /* counter used to recognize a list element from an argument list */
    int SeFuncCnt;
    void *appPtr;
    MuvesBool allow_table;	/* allow for #TABLE: in file (VSL) */
    char *etable;		/* pointer to etable file name if present */
    MuvesBool allow_encode;  /* allow systems to be encoded (VSL) */
} SeParseVars;

/**
	The Se package relies on the RtComponents name pool to determine
	what identifiers name target components (as opposed to systems);
	RtComponents must remain valid throughout the operation of the
	Se functions, up to and including the close/free routines.
	An identifier that does not match any target component name is
	assumed to specify a system; it is an error if there is no
	corresponding system definition in the "sysdef" file.

	Unless stated otherwise, all Se functions register an
	appropriate error index via ErSet() before returning an error
	indication.  In the case of functions that return type double,
	-1.0 is returned to indicate an error, but since this may be a
	valid value, ErIsSet() must be used to test for validity in that
	case.
**/
/* 05-30-00 ch3  added function prototypes for SeGetQualName() because */
/*               needs to be called from new multiple occurrence routine */
#if STD_C
extern NmPool *SeSysOpen( const char *sysdef_file, MuvesBool optimize );
extern SeParseVars *SeSysInit(const char *libstr, MuvesBool interactive_mode, void *ptr);
extern MuvesBool SeInitComps(SeParseVars *vars);
extern void SeSysTerm(SeParseVars *vars);
extern MuvesBool SeSysReadFile(SeParseVars *vars, const char *sysdef_file);
extern MuvesBool SeSysAdd(SeParseVars *vars, const char *sysdef_str);
extern MuvesBool SeSysCheck(void);
extern const DqNode *SeGetQualList( int comp_index );
extern const char *SePrsBaseName( int comp_index );
extern const char *SePrsQualName( int comp_index );
extern const char *SeGetQualName( const char *compname, const char *qualif );
#else
extern NmPool *SeSysOpen();
extern SeParseVars *SeSysInit();
extern void SeSysTerm();
extern MuvesBool SeSysReadFile();
extern bs_type SeSysAdd();
extern MuvesBool SeSysCheck();
extern const DqNode *SeGetQualList();
extern const char *SePrsBaseName();
extern const char *SePrsQualName();
extern const char *SeGetQualName();
#endif

#if 0
/* Name of built-in list of critical components */
#define SeCRIT_CMP_LIST	"_critical_components"
#endif

typedef struct {
    DqNode link;
    int index;  /* SeComponents name pool index to qualified component */
}
SeQalNode;

extern NmPool SeSystems;	/* target system names from sysdef exprs */
extern NmPool SeComponents;	/* RtComponents name pool plus qualified
					instances of those components */
extern NmPool SeFunctions;	/* function definition names from sysdef */
extern NmPool SeStates;		/* state vector definition names from states */
extern NmPool SeQualifiers;	/* system qualifiers */
extern NmPool SeLists;		/* lists for aliasing from state vectors */

extern DqNode **SeSysComps;	/* linked lists containing sorted RtComponent
				   ids for each system in SeSystems name pool. */

extern DqNode **SeStateComps;	/* linked lists containing RtComponent ids for
				   all elements of each state vector analyzed. */


/* Define data types for evaluated component damage. */
typedef enum {
    SeTypeUnset = -1,
    SeTypeFRF,		/* fractional remaining functionality */
    SeTypeLOF,		/* loss of function */
    SeTypeHit,		/* 1 if hit, else 0 */
    SeTypeKilled,		/* 1 if killed, else 0 */
    SeTypeNotKilled,	/* 0 if killed, else 1 */
    SeTypePKChebyshev,	/* Iterates to within a given confidence
					the value of PK*/
    SeTypePKIterate,	/* Iterates N times to evaluate a PK*/
    SeTypeScalar,		/* for values like residual pen */
    SeTypePK,		/* probability of kill */
    SeTypePS,		/* probability of survivability */
    SeTypeSentinel
}
SeTypeID;

typedef struct at_value {
    float value;
    SeTypeID type;
}
SeValue;

/* 01-03-18 ch3: added prototype for new function for SeTcl.c */
#if STD_C
extern MuvesBool SeRegisterNewQualComp( const char *qualname );
#else
extern MuvesBool SeRegisterNewQualComp();
#endif

/* 01-03-18 ch3: added prototype for function that was static for SeTcl.c */
#if STD_C
extern MuvesBool SeRegisterQualComp( const char *qualname, int ci );
#else
extern MuvesBool SeRegisterQualComp();
#endif

#if STD_C
extern double SeSysEval( int sys_index, const SeValue *valp, const double *argp,
                         SeTypeID type, const char *qualifier );
#else
extern double SeSysEval();
#endif

#define SeBUFSIZE	512


#if STD_C
extern void SeSysReset( void );
#else
extern void SeSysReset();
#endif


#if STD_C
extern MuvesBool SeSysClose( void );
#else
extern MuvesBool SeSysClose();
#endif


/* 01-03-18 ch3: added prototype for function that was static for SeTcl.c */
#if STD_C
extern void SeStompSeQualp( void );
#else
extern void SeStompSeQualp();
#endif


#if STD_C
extern FILE *SeStOpen( const char *states_file );
#else
extern FILE *SeStOpen();
#endif


#if STD_C
extern bs_type SeStNextName( FILE *fp, char *state_namep );
#else
extern bs_type SeStNextName();
#endif


#if STD_C
extern MuvesBool SeStCompile( FILE *fp, const char *statename );
#else
extern MuvesBool SeStCompile();
#endif


#if STD_C
extern const char **SeStQuery( const char *statename, SeTypeID *typep,
                               int *lengthp );
#else
extern const char **SeStQuery();
#endif


#if STD_C
extern const char *SeStrType( SeTypeID type );
extern double *SeStEval( const char *statename, const SeValue *valp,
                         SeTypeID *typep, int *lengthp );
#else
extern const char *SeStrType();
extern double *SeStEval();
#endif


#if STD_C
extern MuvesBool SeSysCritical( const char *sysname, char **iscriticalp);
extern int SeSysInsert( const char *name );
extern void SeSysDelete( const char *name );
#else
extern MuvesBool SeSysCritical();
extern int SeSysInsert();
extern void SeSysDelete();
#endif

extern char *SeIsCritical;
#if STD_C
extern char *SeStIsCritical( void );
#else
extern char *SeStIsCritical();
#endif


#if STD_C
extern void SeStClose( FILE *fp );
#else
extern void SeStClose();
#endif


#if STD_C
extern MuvesBool SeStFree( void );
#else
extern MuvesBool SeStFree();
#endif

#if STD_C
extern MuvesBool SeGetSysList( void );
#else
extern MuvesBool SeGetSysList( );
#endif

extern void SePkgInit();

#endif		/* Se_H_INCLUDED */
