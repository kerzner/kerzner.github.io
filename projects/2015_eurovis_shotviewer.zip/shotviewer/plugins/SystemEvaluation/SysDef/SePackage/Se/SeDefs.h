/*
	SeDefs.h -- MUVES "Se" (System evaluation) package private definitions

	prerequisite:	<ctype.h>	if SeIS_IDENTIFIER() is used

	created (as part of Se.h):	88/03/25	G S Moss
	updated:                        00/06/21        C Hunt III
			added support for multiple occurrence bug fix
	updated:                        00/06/27        C Hunt III
			added another change for multiple occurrence bug fix
	updated:                        01/09/02        C Hunt III
			added additional debugging related changes
	updated:                        01/12/04        C Hunt III
			added temporary expression node type for multiple
			occurrence
	updated:                        02/07/27        C Hunt III
			added orca node type for new _orca function (SCR446)
	updated:                        03/09/12        C Hunt III
			renamed and renumbered serveral of the SEDBG_xx flags,
			made changes during the testing of AJEM SCR414
			(multiple occurrence expression substitution bug)
	updated:	05/03/22-05/09/12	C Hunt III
			renumbered, renamed, added and reordered SEDBG_xx flags,
			made changes during the testing of SCR579
	updated:	08/07/22	C Hunt III
			added definition for SeSyDStart that will contain the
			start index within SeDataSystems[] of the user sysdefs
			(from the sysdef file) (SCR813)

	RCSid:		$Id: SeDefs.h,v 1.30 2010/06/23 19:54:51 geoffs Exp $
 */

#ifndef SEDEFS_H
#define SEDEFS_H

#include <std.h>	/* for MuvesBool, bs_type, STD_C */

#include <Dq.h>		/* for DqNode */
#include <Se.h>

#define SeSTREAM	RnShotAssessmentStream

/*
	The following are token types, used to discriminate among SeSysDef
	union node types.  WARNING: do not change these definitions unless
	you are careful to reflect the changes in the Se[Lo|Hi][U|Bi]nary
	macros and the SeTtbl table (in SeParse.c).
 */
typedef enum {
    SeNT_UNSET = -1,	/* out-of-band initializer */

    /* delimiters */
    SeNT_ASSIGNMENT,
    SeNT_DBL_QUOTE,
    SeNT_LF_PAREN,
    SeNT_RT_PAREN,
    SeNT_LF_SQUARE,
    SeNT_RT_SQUARE,
    SeNT_LF_CURLY,
    SeNT_RT_CURLY,
    SeNT_CMA,		/* function arg separator */

    /* unary operator nodes */
    SeNT_NOT,
    SeNT_ANOT,		/* alternate NOT operator */
    SeNT_ABS,
    SeNT_BOOL,		/* "positivity" operator ('?') */

#define SeLoUnary	SeNT_NOT
#define SeHiUnary	SeNT_BOOL

#define	SeIS_UNARY_OP( t )	((t) >= SeLoUnary && (t) <= SeHiUnary )

    /* binary operator nodes */
    SeNT_AND,	/* first binary operator (see SeLoBinary */
    SeNT_OR,
    SeNT_MIN,
    SeNT_MAX,
    SeNT_XOR,
    SeNT_SUM,
    SeNT_DIFF,
    SeNT_PROD,
    SeNT_QUOT,
    SeNT_LT,
    SeNT_GT,
    SeNT_LTEQ,
    SeNT_GTEQ,
    SeNT_QUALOP,
    SeNT_LIST,	/* last binary operator nodes (see SeHiBinary) */

#define SeLoBinary	SeNT_AND
#define SeHiBinary	SeNT_LIST

#define SeIS_BINARY_OP( t )	((t) >= SeLoBinary && (t) <= SeHiBinary )

#define SeNTOKENS	SeNT_LIST+1	/* number of token types above */

    /* other nodes */
    SeNT_SYSNAME,	/* system node */
    SeNT_LISTNAME,	/* list node */
    SeNT_COMPNAME,	/* critical component node */
    SeNT_PARAM,	/* function parameter in body of definition */
    SeNT_CONSTANT,	/* constant node */
    SeNT_EXPR,	/* compiled expression node */
    SeNT_FUNCNAME,	/* function definition node */
    SeNT_ARGUMENT,	/* function definition argument */
    SeNT_FNCALL,	/* function call node */
    SeNT_QUALCOMP,	/* qualified critical component node */
    SeNT_CQUALIFIER,/* critical component qualifier */
    SeNT_DUMMY,	/* SeIdentiferGet() doesn't push these */
    SeNT_RUNIF,	/* implements _random_uniform() */
    SeNT_RNORM,	/* implements _random_normal() */
    SeNT_MOFN,	/* implements _MofN() */
    SeNT_EVAL,	/* implements _eval() */
    SeNT_QUALSYS,	/* qualified system */
    SeNT_QUALIST,	/* qualified list */
    /* 06-21-00 ch3  added new multiple occurrence operator */
    SeNT_MULTOCC,	/* multiple occurrance expression */
    /* 05-31-01 ch3  added new Pkd operator */
    SeNT_PKD,       /* implements _Pkd() */
    /* 07-27-02 ch3  added new orca operator */
    SeNT_ORCA,       /* implements _orca() */
    /* 12-04-01 ch3  added temporary expression node type for used */
    /*               exclusively by the multiple occurrence routine */
    SeNT_TMPEXPR    /* temporary expression node */
}
SeNodeCategory;

/*
	The SeSysDef data structure is a union for storing objects which
	are building blocks for compiled expression trees.  These objects
	may be unary or binary operators, components, systems, or numeric
	constants.  In the case of binary operators, the lhsp and rhsp
	fields will point to left- and right-hand-side subexpressions.
	Unary operators will have only a valid rhsp field which points
	to the subexpression; lhsp will be NULL.  The operator nodes will
	organize the SeSysDef nodes into an expression tree once the
	expression is compiled.  Leaf nodes can be either component or
	system nodes which contain the respective (RtComponents or
	SeSystems) name pool index, or they can be numeric constants
	and contain the represented value.  The compiled expression trees
	are used to evaluate systems and are accessible by indexing into
	the SeDataSystem array with a systems name pool index.

 */
typedef	struct corepart {
    SeNodeCategory type; /* to differentiate among union members */
    char *text;	 /* input text */
}
SeCorePart;

typedef union sesysdef SeSysDef;	/* incomplete type for forward ref. */
union sesysdef {
    SeNodeCategory type;	/* easy access to node type */
    SeCorePart core;	/* easy access to core part */
    struct	opnode {
        SeCorePart core;
        SeSysDef *lhsp;	/* left-hand-side (LHS) operand */
        SeSysDef *rhsp;	/* right-hand-side (RHS) or unary operand */
    }
    o;
    struct	fncallnode {
        /* SeNT_FNCALL */
        SeCorePart core;
        int index;	/* corr. function def. name pool index */
        DqNode *argexps; /* list of compiled argument expressions */
    }
    f;
    struct	compnode {
        /* SeNT_COMPNAME, SeNT_SYSNAME, SeNT_QUALSYS, SeNT_QUALIST,
           SeQUALCOMP, SeNT_CQUALIFIER, or SeNT_SUBEXPR */
        SeCorePart core;
        char *text;
        int index;	/* component or system name pool index */
    }
    c;
    struct	numnode {
        /* SeNT_CONSTANT */
        SeCorePart core;
        int index;	/* system name pool index for variable defs */
        double value;	/* numeric constant */
    }
    n;
    struct	paramnode {
        /* SeNT_PARAM */
        SeCorePart core;
        int index;	/* corresponding arg. name pool index */
    }
    p;
};


/* single-character symbols associated with token types */
#define SeCH_ESCAPE	'\\'
#define SeCH_ASSIGNMENT	'='
#define SeCH_DBL_QUOTE	'\"'
#define SeCH_LF_PAREN	'('
#define SeCH_RT_PAREN	')'
#define SeCH_LF_SQUARE	'['
#define SeCH_RT_SQUARE	']'
#define SeCH_LF_CURLY	'{'
#define SeCH_RT_CURLY	'}'
#define SeCH_NOT	'!'
#define SeCH_ANOT	'~'	/* alternate symbol for NOT */
#define SeCH_ABS	'@'
#define SeCH_BOOL	'?'
#define SeCH_AND	'&'
#define SeCH_OR		'|'
#define SeCH_MIN	':'	/* represents '<<' */
#define SeCH_MAX	';'	/* represents '>>' */
#define SeCH_XOR	'^'
#define SeCH_SUM	'+'
#define SeCH_DIFF	'-'
#define SeCH_PROD	'*'
#define SeCH_QUOT	'/'
#define SeCH_COMMA	','
#define SeCH_LT		'<'
#define SeCH_GT		'>'
#define SeCH_LTEQ	'%'
#define SeCH_GTEQ	'\''

/* WARNING:  There are no Standard-C characters remaining available.
   In the ASCII code set, there are the dollar_sign and accent_grave.
   Rather than building in ASCII dependence, for expansion past the
   Standard-C characters, the lexical token codes should be changed to
   sequentially-assigned integer values. */

#define SeISCUNARY_OP( c )	((c) == SeCH_NOT || (c) == SeCH_ANOT \
			      || (c) == SeCH_ABS || (c) == SeCH_BOOL)

#define SeISCBINARY_OP( c )	((c) == SeCH_AND || (c) == SeCH_OR \
			      || (c) == SeCH_MIN || (c) == SeCH_MAX \
			      || (c) == SeCH_LT  || (c) == SeCH_GT \
			      || (c) == SeCH_LTEQ || (c) == SeCH_GTEQ \
			      || (c) == SeCH_XOR || (c) == SeCH_SUM \
			      || (c) == SeCH_DIFF || (c) == SeCH_PROD \
			      || (c) == SeCH_QUOT)

/* single-character token equivalent strings, for SeTtbl */
#define SeTK_ASSIGNMENT	"="
#define SeTK_DBL_QUOTE	"\""
#define SeTK_LF_PAREN	"("
#define SeTK_RT_PAREN	")"
#define SeTK_LF_SQUARE	"["
#define SeTK_RT_SQUARE	"]"
#define SeTK_LF_CURLY	"{"
#define SeTK_RT_CURLY	"}"
#define SeTK_NOT	"!"
#define SeTK_ANOT	"~"	/* alternate symbol for NOT */
#define SeTK_ABS	"@"
#define SeTK_BOOL	"?"
#define SeTK_AND	"&"
#define SeTK_OR		"|"
#define SeTK_MIN	"<<"
#define SeTK_MAX	">>"
#define SeTK_XOR	"^"
#define SeTK_SUM	"+"
#define SeTK_DIFF	"-"
#define SeTK_PROD	"*"
#define SeTK_QUOT	"/"
#define SeTK_COMMA	","
#define SeTK_LT		"<"
#define SeTK_GT		">"
#define SeTK_LTEQ	"<="
#define SeTK_GTEQ	">="

/* special characters allowed in identifiers */
#define SeCH_USCORE	'_'
#define SeCH_PERIOD	'.'
#define SeCH_COLON	':'

#define SeIS_IDENTIFIER( c ) \
(isalnum( c )||(c)==SeCH_USCORE||(c)==SeCH_PERIOD||(c)==SeCH_COLON)

/* special character allowed in constants */
#define SeCH_DECIMAL_PT	SeCH_PERIOD


/*
	The SeSyDat data structure is used internally by the Se package
	to store the compiled system definition trees and the values of
	these expressions once they are computed.

	When each system is parsed with SeSysOpen(), an SeSyDat node is
	allocated and a pointer to it is placed in the SeDataSystem array.
	The SeDataSystem array is indexed by the corresponding SeSystems
	name pool indices.  At the completion of the compilation step,
	also directed by SeSysOpen(), the sysdef field is set to point to
	the compiled expression tree (see documentation for the SeSysDef
	type) and the state field is initialized to SeINVALID.  While a
	system is in the process of being evaluated (i.e. with
	SeEvlExpression() or SeCrtExpression()), the state field is set to
	SeEVALUATING; this is used to detect recursive system definitions.
	After a system is evaluated, the value field is set to the result
	and the state field is set to SeVALID.
 */
typedef struct {
    int state;	/* state of evaluation: */
#define SeINVALID	0	/* System not evaluated. */
#define SeVALID		1	/* Evaluation complete, value is valid. */
#define SeEVALUATING	2	/* Evaluation in progress. */
#ifdef COMPILE_FOR_VSL
    /* 11-12-13 ch3: added locked system state (VSL) */
#define SeLOCKED	3	/* System value locked by VSL:SeWrapper */
#endif
    SeValue save;	/* if SeVALID, value and type for the system */
    SeSysDef *sysdef; /* system definition */
}
SeSyDat;

extern SeSyDat **SeDataSystem;	/* dynamically-allocated array of
				   pointers to system SeSyDat structures */
/* 08-07-22 ch3: added start of user sysdefs variable (SCR813) */
extern int SeSyDStart;		/* start index of user sysdefs */

/* 12-04-02 ch3: added start of user functions variable (VSL) */
extern int SeFnDStart;		/* start index of user functions */

/*
	The SeFnDat data structure is used internally by the Se package
	to store the compiled function definition trees.

	When each function definition is parsed with SeSysOpen(), an
	SeFnDat node is allocated and a pointer to it is placed in the
	SeFnDfn array.  The SeFnDfn array is indexed by the corresponding
	SeFunctions name pool indices.  At the completion of the compilation
	step, also directed by SeSysOpen(), the funcdefp field points to
	the compiled expression tree (see documentation for the SeFncDef
	type) and the foldable field is set to the value returned from a
	call to SeIsFoldable( SeFnDfn[index]->funcdefp ).
 */
typedef struct {
    MuvesBool foldable;		/* is folding to a constant possible */
    SeSysDef *funcdefp;	/* function definition */
}
SeFnDat;
extern SeFnDat **SeFnDfn;	/* dynamically-allocated array of
				   pointers to function SeFnDat structures */
/*
	The SeStDat data structure is used internally by the Se package
	to store the compiled state vectors.

	When each state vector definition is compiled with SeStCompile(),
	an SeStDat node is allocated and a pointer to it is placed in the
	SeStDef array.  The SeStDef array is indexed by the corresponding
	SeStates name pool indices.  At the completion of the compilation
	step, also directed by SeStCompile(), the type field will contain
	the one of SeTypeID enumerated types, the length field will contain
	the number of members, and the names field will point to a
	dynamically-allocated, null-terminated array of pointers to
	character strings.

	As SeStEval() is called for each vector, the values field will be
	set to point to dynamically-allocated storage for the results.
	This storage is freed either by a call to SeStFree() or
	SeSysReset(); the latter because the results would no longer be
	valid.

 */
typedef struct {
    SeTypeID type;		/* data type */
    int length;		/* number of members in vector */
    double *values;		/* -> array of 'length' evaluated results */
    SeSysDef **defs;	/* -> array of member definitions */
    char **text;		/* -> array of member text reps */
}
SeStDat;
extern SeStDat **SeStDef;	/* dynamically-allocated array of
				   pointers to function SeStDat structures */

/*
	The SeLiDat data structure is used internally by the Se package
	to store the compiled lists.

	When each list definition is compiled with SeListCompile(),
	an SeLiDat node is allocated and a pointer to it is placed in the
	SeLiDef array.  The SeListDfn array is indexed by the corresponding
	SeLists name pool indices.  At the completion of the compilation
	step, also directed by SeListCompile(), a Dq list of SeLiMember nodes
	will be inserted in SeListDfn.

	This storage is freed either by a call to SeLiFree() or
	SeSysReset(); the latter because the results would no longer be
	valid.

 */
typedef struct {
    DqNode link;
    SeSysDef member;	/* compiled member node */
}
SeLiMember;
#define SeLiDat DqNode		/* queue of SeLiMember nodes */

extern SeLiDat **SeListDfn;	/* dynamically-allocated array of
				   pointers to SeLiDat structures */

/*
	The SeArgExp data structure is used internally by the Se package
	to store the compiled function call argument expressions.
 */
typedef struct {
    DqNode link;		/* doubly-linked SeArgExp list pointer */
    SeSysDef *expp;		/* compiled argument expression */
}
SeArgExp;

/*
	SeResName is set while defining MUVES library functions/systems,
	and is clear when defining user functions/systems.  In the former
	case, only "reserved" names (those starting with underscore) are
	permitted, and the the latter case only nonreserved names are
	permitted.  Thus MUVES can adoppt new standard functions without
	changing the interpretation of user definition files.
 */

/* 	The SeQalNode data structure is used by the Se package
	to store SeComponent name pool indices to qualified instances
	of a component.  SeQualp[] parallels the SeComponents and
	RtComponents name pools.  Non-null entries point to lists of
	qualified component indices into SeComponents name pool.

	typedef struct
		{
		DqNode link;
		int index;
		}
	SeQalNode;
*/
extern DqNode **SeQualp;	/* dynamically-allocated array of pointers
				   to DqLists of SeQalNode structs */

/*
	The SeToken data structure is used internally by the Se package
	to store the text tokens input by the parser.

	The parser organizes the SeToken nodes into a queue pointed to by
	SeStackp.  Later, when compilation takes place, the nodes are
	reorganized into an expression tree by gradually converting them to
	SeSysDef nodes and linking the result as left- or right-hand-side
	subexpressions onto the remaining SeToken nodes.  Compilation is
	complete when the last SeToken node in the queue is converted into
	an SeSysDef node.
 */
typedef struct {
    DqNode link;		/* doubly-linked SeToken list pointers */
    SeNodeCategory type;	/* identifies token type */
    char *text;		/* actual text of token */
    SeSysDef *lhsp;		/* left-hand-side (LHS) compiled expression */
    SeSysDef *rhsp;		/* right-hand-side (RHS) compiled expression */
}
SeToken;

/*
	The SeTokTbl data structure is used internally by the Se package
	to map the char representation of a recognized input token which
	happens to be a single-character symbol to its character string
	equivalent.  This is done merely for coding convenience; there is
	nothing special about the mapping.  SeTtbl is a statically
	initialized table (in SeParse.c) which makes this association for
	all single-character symbols.
 */
typedef struct {
    char tc;		/* SeCH_* value */
    const char *ts;		/* SeTK_* value */
}
SeTokTbl;

extern SeTokTbl SeTtbl[SeNTOKENS]; /* table of tokens known to parser */

/* 06-27-00 ch3  added following enum for SeOptimize() optimize argument */
typedef enum {
    SeOptimizeFalse,      /* don't do any optimizing */
    SeOptimizeTrue,       /* do optimizing */
    SeOptimizeNoSystem,   /* don't optimize systems */
    SeOptimizeSentinel
}
SeOptimizeEnum;

/* 11-04-29 ch3: return values for SeDefCompile() and SeSysCompile() (VSL) */
#define SeCompile_FAIL  -1
#define SeCompile_GOOD  -2

/* 06-21-00  added new function prototypes for new SeFindMultOcc() function */
/* 06-27-00  changed type of optimize argument for SeDefCompile() function */
/* internal "Se" package global functions: */
#if STD_C
extern DqNode *SeStkCompile( SeParseVars *vars, DqNode *stackp, NmPool *argnames );
extern SeSysDef *SeExpCopy( const SeSysDef *expp );
extern SeSysDef *SeTok2SysDef( SeParseVars *vars, DqNode *stackp );
extern SeSysDef **SeStAddMember( SeStDat *defp, const SeSysDef *sysdefp );
extern MuvesBool SeDefCompile( SeParseVars *vars, SeOptimizeEnum optimize );
extern MuvesBool SeListExpand( SeStDat *defp );
extern MuvesBool SeStGetDef( SeParseVars *vars, const char *statename );
extern bs_type SeDefGet( SeParseVars *vars );
extern char *SeSysTextRep( const SeSysDef *sysdefp );
extern char *SeTxtExpression( SeSysDef *sysdefp, int level );
extern const char *SeCvtToStr( SeNodeCategory type );
extern double SeEvlExpression( SeSysDef *, const SeValue *, const double *,
                               SeTypeID, const char *qualifier );
extern int SeStInsert( const char *name );
extern void Se1stLine( SeParseVars *vars );
extern void SeBuiltIn( void );
extern void SeExpFree( SeSysDef *expp );
extern void SeFlushStack( SeParseVars *vars );
extern void SeOptimize( SeSysDef **exph );
/* 01-09-02 ch3: for debugging added level argument, changed return from void */
extern MuvesBool  SeFindMultOcc( SeSysDef **expr, int level );
/* 11-05-23 ch3: two functions for checking if there is recursion (VSL) */
extern int SeFindSys(int index, int sysindex);
extern int SeFindSysExpr(SeSysDef *sysdefp, int sysindex);
#ifdef DEBUG
extern void SePrtExpression( SeSysDef *sysdefp, int level );
extern void SePrtKnownSystems( const char *header );
#endif
extern void SeSysValInit(void);  /* 11-04-05 ch3: new function (VSL) */
#else
extern DqNode *SeStkCompile();
extern SeSysDef *SeExpCopy();
extern SeSysDef *SeTok2SysDef();
extern SeSysDef **SeStAddMember();
extern MuvesBool SeDefCompile();
extern MuvesBool SeListExpand();
extern MuvesBool SeStGetDef();
extern bs_type SeDefGet();
extern char *SeSysTextRep();
extern char *SeTxtExpression();
extern const char *SeCvtToStr();
extern double SeEvlExpression();
extern int SeStInsert();
extern void Se1stLine();
extern void SeBuiltIn();
extern void SeExpFree();
extern void SeFlushStack();
extern void SeOptimize();
/* 01-09-02 ch3: changed return from void for debugging */
extern MuvesBool SeFindMultOcc();
/* 11-05-23 ch3: two functions for checking if there is recursion (VSL) */
extern int SeFindSys();
extern int SeFindSysExpr();
#ifdef DEBUG
extern void SePrtExpression();
extern void SePrtKnownSystems();
#endif
extern void SeSysValInit();  /* 11-04-05 ch3: new function (VSL) */
#endif

/* internal "Se" package global data: */
extern MuvesBool SeTesting;		/* set during SeTest (only) */
extern int SeLnNo;		/* # of current line being parsed in "sysdef" */
extern long SeLnAddr;		/* file offset of beginning of text line */
/* (On UNIX, off_t is synonymous with long.) */
extern int SeNComps;		/* saved length of RtComponents name pool */
extern int SeSyDLen;		/* current length of SeDataSystem array */
extern int SeFnDLen;		/* current length of SeFnDfn array */
extern int SeStDLen;		/* current length of SeStDef array */
extern int SeLiDLen;		/* current length of SeListDfn array */
#define SeSyD_LEN	16	/* initial allocation for SeDataSystem array */
#define SeFnD_LEN	4	/* initial allocation for SeFnDfn array */
#define SeStD_LEN	4	/* initial allocation for SeStDef array */
#define SeLiD_LEN	4	/* initial allocation for SeListDfn array */

#define	SeSTDDEF	"sysdef"	/* name of library sysdef file */


/* 00-06-21 ch3  added debugging flag bit masks */
/* 05-04-18 ch3: renumbered, renamed and reordered debug constants */
#define SEDBG_FINDMSGS 0x0004  /* messages in SeFindMultOcc() */
/* 03-09-12 ch3: renumbered SEDBG_NULLSYS to match SEDBG_ERRMSGS */
#define SEDBG_STSMSGS  0x0008  /* various status messages for MultOcc */
#define SEDBG_BADTYPE  0x0010  /* bad type found in SeMultOccTest() */
#define SEDBG_NULLSYS  0x0020  /* null system expression pointer messages */
#define SEDBG_MULTOCCS 0x0040  /* print multiple occurrent comps/systems */
#define SEDBG_ALLOCCS  0x0080  /* print all occurrence information */
/* 03-09-12 ch3: renumbered SEDBG_TSTEXPR to be unique */
#define SEDBG_ORANDTBL 0x0100  /* OR/AND table after SeProcessTable() */
#define SEDBG_SRTDTBL  0x0200  /* sorted summation table: SeBuildSumTables() */
#define SEDBG_PRTIEXPR 0x0400  /* print initial expression message */
#define SEDBG_PRTSEXPR 0x0800  /* print substituted expression message */
#define SEDBG_PRTNEXPR 0x1000  /* print new expression message */
#define SEDBG_FUTURE2  0x2000  /* for future use */
#define SEDBG_FUTURE3  0x4000  /* for future use */
#define SEDBG_FUTURE4  0x8000  /* for future use */
#define SEDBG_TSTEXPR  0x00010000  /* messages in SeMultOccTest() */
#define SEDBG_SYSEXPR  0x00020000  /* display systems: SeMultOccTest() */
#define SEDBG_SUBEXPR  0x00040000  /* messages in SeSubstituteExpressions() */
#define SEDBG_TMPEXPR  0x00080000  /* messages in SeTemporaryExpression() */
#define SEDBG_SUBOCCUR 0x00100000  /* occur[] contents in substitute */
#define SEDBG_ORANDND  0x00200000  /* OR/AND node in SeProcessTable() */
/* 03-09-12 ch3: renamed from SEDBG_COMPND, which was not used */
#define SEDBG_ORNODE   0x00400000  /* OR node messages in SeProcessTable() */
/* 01-09-02 ch3  added debugging flag bit masks */
/* 03-09-12 ch3: renamed from SEDBG_NEWEXPR */
#define SEDBG_OCCUR    0x00800000  /* occur[] contents after SeMultOccTest() */
/* 05-03-15 ch3: added more debugging flag bit masks */
#define SEDBG_YESMOSYS 0x01000000  /* print systems with multocc comps */
#define SEDBG_NOMOSYS  0x02000000  /* print systems with no multocc comps */
#define SEDBG_BLDEXPR  0x04000000  /* SeBuildNewExprTree() messages */
#define SEDBG_BLDBEXPR 0x08000000  /* SeBuildBitArrayExpr() messages */
#define SEDBG_PRTLVLS  0x10000000  /* level num instead of spaces in PRTxEXPR */
#define SEDBG_PRTSYS   0x20000000  /* print system expressions in new expr */
#define SEDBG_FREEMSGS 0x40000000  /* free memory messages */
#define SEDBG_LVLMSGS  0x80000000  /* level status message, for testing only */

typedef struct {
    NmPool	names;
    int	*id;
    int	len;
}
SeCompInfoList;
extern void SeSysCompList( SeSysDef *sysdefp, SeCompInfoList *list, int level );

#endif // SEDEFS_H
