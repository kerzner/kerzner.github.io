/*******************************************************************************
* SeTcl.c  MUVES "Se" (system evaluation) package TCL interface routines
*
* Contents:
*   se_tcl_init()          initialize the Se package TCL interface
*   se_tcl_help()          display Se package TCL command help information
*   se_tcl_types()         gets one damage type name or entire list
*   se_tcl_initcomps()     initialize the Se components
*   se_tcl_regqualcomp()   register a qualified component
*   se_tcl_getcomp()       gets an Se component by its index or all components
*   se_tcl_critcomps()     gets or sets the critical components
*
* Created:  01/03/20  C Hunt III
* Edited:   02/07/29  C Hunt III
*           added argument check and help usage message to se_tcl_initcomps()
* Edited:   03/06/02  K Bowman
*           changed include <strings.h> to <string.h> so that correct
*           definitions are included (corrected for SCR380)
*******************************************************************************/
#ifndef lint
static char RCSid[] = "$Id: SeTcl.c,v 1.10 2010/06/23 19:54:51 geoffs Exp $";
#endif

#include <stdio.h>
#include <string.h>  /* 03-06-02 kb: changed from strings.h */
#include <stdlib.h>
#include <tcl.h>
#include <tk.h>

#include <common.h>   /* BRL-CAD 7.2.4+ no longer use config.h (SCR670) */
#include <Dm.h>

#include <Dd.h>
#include <Dq.h>
#include <Rt.h>
#include <Se.h>
#include <SeDefs.h>
#include <raytrace.h>
/* controls debugging output */
extern int SeDebugging;
#define ErDebugging SeDebugging

/* global variables needed from Se.c */
extern int SeCritSz;


/* tcl command function prototypes */

int se_tcl_help(ClientData clientData, Tcl_Interp *interp, int objc,
	Tcl_Obj *const objv[]);

int se_tcl_types(ClientData clientData, Tcl_Interp *interp, int objc,
	Tcl_Obj *const objv[]);

int se_tcl_initcomps(ClientData clientData, Tcl_Interp *interp, int objc,
	Tcl_Obj *const objv[]);

int se_tcl_regqualcomp(ClientData clientData, Tcl_Interp *interp, int objc,
	Tcl_Obj *const objv[]);

int se_tcl_getcomp(ClientData clientData, Tcl_Interp *interp, int objc,
	Tcl_Obj *const objv[]);

int se_tcl_critcomps(ClientData clientData, Tcl_Interp *interp, int objc,
	Tcl_Obj *const objv[]);

int se_tcl_syscomps(ClientData clientData, Tcl_Interp *interp, int objc,
	Tcl_Obj *const objv[]);


static struct tclcmd {
	char *cmdName;
	int (*cmdFunc)();
	char *cmdDesc;
}  tcl_cmds[] = {
	"se_help", se_tcl_help,	
		"Prints this help message.",
	"se_types", se_tcl_types,
		"Gets one damage type name or entire list",
	"se_initcomps", se_tcl_initcomps,
		"Initialize the Se components",
	"se_regqualcomp", se_tcl_regqualcomp,
		"Register a qualified component",
	"se_getcomp", se_tcl_getcomp,
		"Gets an Se component by its index or all Se components",
	"se_critcomps", se_tcl_critcomps,
		"Gets or sets the critical components",
	"se_syscomps", se_tcl_syscomps,
		"Gets a list of a system's components",
	(char *)0, (int (*)())0, (char *)NULL
};


/*******************************************************************************
* se_tcl_init()  initialize the Se package TCL interface
*
* Arguments:
*   interp   pointer to the TCL interpreter information structure
*
* Returns: TCL_OK if successful, TCL_ERROR if not
*******************************************************************************/

int
se_tcl_init(Tcl_Interp *interp)
{
	struct tclcmd *tclcp;    /* tcl command information pointer */

	if (Tcl_PkgProvide(interp, "SeSupport", TCL_VERSION) == TCL_ERROR) {
		return TCL_ERROR;
	}

	for (tclcp = tcl_cmds; tclcp->cmdName != (char *)0; ++tclcp) {
		Tcl_CreateObjCommand(interp, tclcp->cmdName, tclcp->cmdFunc,
			(ClientData)NULL, (Tcl_CmdDeleteProc *)NULL);
	}

	return TCL_OK;

}  /* se_tcl_init() */


/*******************************************************************************
* se_tcl_help()  display Se package TCL command help information
*	
* Arguments:
*   clientData   client data
*   interp       pointer to the TCL interpreter information structure
*   objc         command argument object count
*   objv         pointer to an array of argument object pointers
*
* Returns: TCL_OK
*******************************************************************************/

int
se_tcl_help(ClientData clientData, Tcl_Interp *interp, int objc,
	Tcl_Obj *const objv[])
{
	register struct tclcmd *tclcp;

	Tcl_AppendResult(interp, "\nAvailable commands in the SeTcl package:\n"
		"(for individual command usage, use -help with command)\n\n",
		(char *)NULL);

	for (tclcp = tcl_cmds; tclcp->cmdName != (char *)0; ++tclcp) {
		Tcl_AppendResult(interp, "    ", tclcp->cmdName, " -- \n\t",
			tclcp->cmdDesc, "\n", (char *)NULL);
	}

	return TCL_OK;

}  /* se_tcl_help() */


/*******************************************************************************
* se_tcl_types()  gets one damage type name or entire list
*	
* Arguments:
*   clientData   client data
*   interp       pointer to the TCL interpreter information structure
*   objc         command argument object count
*   objv         pointer to an array of argument object pointers
*
* Returns: TCL_OK if successful, TCL_ERROR if error
*******************************************************************************/

int
se_tcl_types(ClientData clientData, Tcl_Interp *interp, int objc,
	Tcl_Obj *const objv[])
{
	Tcl_Obj *resultPtr;      /* pointer to result object */
	register int cat;        /* comp category index from DdCatNam */
	SeTypeID type;           /* system evaluation type id */
	int index;               /* integer index value */

	if (objc > 2 || objc > 1 && StrEq(Tcl_GetString(objv[1]), "-help")) {
		Tcl_SetResult(interp, "usage: se_types ?index?", TCL_STATIC);
		return TCL_ERROR;
	}

	resultPtr = Tcl_GetObjResult(interp);

	if (objc == 2) {  /* index specified? */
		if (Tcl_GetIntFromObj(interp, objv[1], &index) != TCL_OK) {
			return TCL_ERROR;
		}
		type = (SeTypeID)index;
		if (type >= (SeTypeID)0 && type < SeTypeSentinel) {
			Tcl_SetStringObj(resultPtr, (char *)SeStrType(type),
				-1);
		}
	} else {  /* return entire list */
		for (type = (SeTypeID)0; type < SeTypeSentinel; type++) {
			if (Tcl_ListObjAppendElement(interp, resultPtr,
					Tcl_NewStringObj((char *)
					SeStrType(type), -1)) != TCL_OK) {
				return TCL_ERROR;
			}
		}
	}

	return TCL_OK;

}  /* se_tcl_types() */


/*******************************************************************************
* se_tcl_initcomps()  initialize the Se components
*	
* Arguments:
*   clientData   client data
*   interp       pointer to the TCL interpreter information structure
*   objc         command argument object count
*   objv         pointer to an array of argument object pointers
*
* Returns: TCL_OK
*******************************************************************************/

int
se_tcl_initcomps(ClientData clientData, Tcl_Interp *interp, int objc,
	Tcl_Obj *const objv[])
{
        Tcl_Obj *resultPtr;  /* pointer to result object */
	register int count;  /* number of category names in pool */

	/* 02-07-29 ch3: added help usage message */
	if (objc > 1) {
		Tcl_SetResult(interp, "usage: se_initcomps", TCL_STATIC);
		return TCL_ERROR;
	}

	/* check if there is a ccmap */
	count = NmCount(&RtComponents);
	if (count == 0) {
		Tcl_SetResult(interp, "no ccmap has been loaded", TCL_STATIC);
		return TCL_ERROR;
	}

	/* check if there are any components defined */
	if (SeNComps > 0) {
		SeStompSeQualp();        /* remove entries in SeQualp[] */
		NmClear(&SeComponents);  /* remove them first */
	}

	/* duplicate the components name pool */
	if (!NmDup(&RtComponents, &SeComponents)) {
		Tcl_SetResult(interp, "error duplicating name pool",
			TCL_STATIC);
		return TCL_ERROR;
	}
	SeNComps = count;

	/* allocate and initialize component qualifier pointers array */
	SeQualp = (DqNode **)DmCalloc(count, sizeof(DqNode *));

        resultPtr = Tcl_GetObjResult(interp);
	/*Tcl_SetBooleanObj(resultPtr, mTrue);*/
	Tcl_SetIntObj(resultPtr, NmCount(&SeComponents));
	return TCL_OK;

}  /* se_tcl_initcomps() */


/*******************************************************************************
* se_tcl_regqualcomp()  register a qualified component
*	
* Arguments:
*   clientData   client data
*   interp       pointer to the TCL interpreter information structure
*   objc         command argument object count
*   objv         pointer to an array of argument object pointers
*
* Returns: TCL_OK if successful, TCL_ERROR if error
*******************************************************************************/

int
se_tcl_regqualcomp(ClientData clientData, Tcl_Interp *interp, int objc,
	Tcl_Obj *const objv[])
{
	char *compname;        /* pointer to component name */
	char *qualifier;       /* pointer to qualifier name */
	const char *qualname;  /* pointer to qualified component name */
	Tcl_Obj *resultPtr;    /* pointer to result object */
	int compindx;          /* index of component base name */
	int status;            /* return status variable */

	if (objc != 3 || objc > 1 && StrEq(Tcl_GetString(objv[1]), "-help")) {
		Tcl_SetResult(interp, "usage: se_regqualcomp component "
			"qualifier", TCL_STATIC);
		return TCL_ERROR;
	}

        compname = Tcl_GetString(objv[1]);
	if (compname[0] == '\0') {
		Tcl_SetResult(interp, "no component name specified",
			TCL_STATIC);
		return TCL_ERROR;
	}
        qualifier = Tcl_GetString(objv[2]);
	if (qualifier[0] == '\0') {
		Tcl_SetResult(interp, "no qualifier name specified",
			TCL_STATIC);
		return TCL_ERROR;
	}

	qualname = SeGetQualName(compname, qualifier);

	compindx = NmIndex(compname, &SeComponents, mFalse);
	if (compindx < 0) {
		Tcl_SetResult(interp, "component not found", TCL_STATIC);
		return TCL_ERROR;
	} else {
		status = SeRegisterQualComp(qualname, compindx);
	}

	resultPtr = Tcl_GetObjResult(interp);
	Tcl_SetBooleanObj(resultPtr, status);
	return TCL_OK;

}  /* se_tcl_regqualcomp() */


/*******************************************************************************
* se_tcl_getcomp()  gets an Se component by its index or all components
*	
* Arguments:
*   clientData   client data
*   interp       pointer to the TCL interpreter information structure
*   objc         command argument object count
*   objv         pointer to an array of argument object pointers
*
* Returns: TCL_OK if successful, TCL_ERROR if error
*******************************************************************************/

int
se_tcl_getcomp(ClientData clientData, Tcl_Interp *interp, int objc,
	Tcl_Obj *const objv[])
{
	Tcl_Obj *resultPtr;      /* pointer to result object */
	register int count;      /* number of category names in pool */
	int index;               /* integer index value */

	if (objc > 2 || objc > 1 && StrEq(Tcl_GetString(objv[1]), "-help")) {
		Tcl_SetResult(interp, "usage: se_getcomp ?index?", TCL_STATIC);
		return TCL_ERROR;
	}

	resultPtr = Tcl_GetObjResult(interp);
	count = NmCount(&SeComponents);

	if (objc == 2) {  /* index specified? */
		if (Tcl_GetIntFromObj(interp, objv[1], &index) != TCL_OK) {
			return TCL_ERROR;
		}

		if (index >= 0 && index < count) {
			Tcl_SetStringObj(resultPtr, (char *)NmName(index,
				&SeComponents), -1);
		}
	} else {  /* return entire list */
		for (index = 0; index < count; index++) {
			if (Tcl_ListObjAppendElement(interp, resultPtr,
					Tcl_NewStringObj((char *)NmName(index,
					&SeComponents), -1)) != TCL_OK) {
				return TCL_ERROR;
			}
		}
	}
	return TCL_OK;

}  /* se_tcl_getcomp() */


/*******************************************************************************
* se_tcl_critcomps()  gets or sets the critical components
*
* Arguments:
*   clientData   client data
*   interp       pointer to the TCL interpreter information structure
*   objc         command argument object count
*   objv         pointer to an array of argument object pointers
*
* Returns: TCL_OK if successful, TCL_ERROR if error
*******************************************************************************/

int
se_tcl_critcomps(ClientData clientData, Tcl_Interp *interp, int objc,
	Tcl_Obj *const objv[])
{
        Tcl_Obj *resultPtr;      /* pointer to result object */
        int count;               /* number of items in list object */
	char *name;              /* pointer to a name string */
	char *qual;              /* pointer to qualifier string */
        register int index;      /* loop index variable */
	Tcl_Obj *itemPtr;        /* pointer to one item in list */
	int itemcount;           /* count for item in list */
	char buffer[SeBUFSIZE];  /* temporary string buffer */
	Tcl_Obj *compPtr;        /* pointer to component name object */
	Tcl_Obj *qualPtr;        /* pointer to qualifier name object */
	register int compindx;   /* component index into RtComponents */

        if (objc > 2 || objc > 1 && StrEq(Tcl_GetString(objv[1]), "-help")) {
                Tcl_SetResult(interp, "usage: cp_critcomps "
			"?mFalse|mTrue|component_name_list?", TCL_STATIC);
                return TCL_ERROR;
        }

        resultPtr = Tcl_GetObjResult(interp);

        /* see if there is no critial array yet */
        if (SeIsCritical == NULL) {
                SeCritSz = NmCount(&SeComponents);
                if (SeCritSz == 0) {
                        Tcl_SetResult(interp, "components not initialized",
				TCL_STATIC);
			return TCL_ERROR;
                }
		if (objc == 1) {  /* just read critical components? */
			Tcl_SetResult(interp, "critical components not set",
				TCL_STATIC);
			return TCL_ERROR;
		}
                SeIsCritical = (char *)DmCalloc(SeCritSz, sizeof(char));
                if (SeIsCritical == NULL) {
                        Tcl_SetResult(interp, "error allocating memory",
				TCL_STATIC);
			return TCL_ERROR;
                }
		for (index = 0; index < SeCritSz; index++) {
			SeIsCritical[index] = mFalse;
		}
		DdIsCritical = SeIsCritical;
        }

	if (objc == 1) {  /* just read critical components? */
		count =  NmCount(&RtComponents);
		/* do non-qualified components (name only) */
		for (index = 0; index < count; index++) {
			if (SeIsCritical[index]) {
				if (Tcl_ListObjAppendElement(interp,
						resultPtr, Tcl_NewStringObj(
						(char *)NmName(index,
						&SeComponents), -1))
						!= TCL_OK) {
					return TCL_ERROR;
				}
			} 
		}
		/* do qualified components (each a list of name/qualifier) */
		for (; index < SeCritSz; index++) {
			if (SeIsCritical[index]) {
				itemPtr = Tcl_NewObj();
				if (Tcl_ListObjAppendElement(interp,
						itemPtr, Tcl_NewStringObj(
						(char *)SePrsBaseName(index),
						-1)) != TCL_OK) {
					return TCL_ERROR;
				}
				if (Tcl_ListObjAppendElement(interp,
						itemPtr, Tcl_NewStringObj(
						(char *)SePrsQualName(index),
						-1)) != TCL_OK) {
					return TCL_ERROR;
				}
				if (Tcl_ListObjAppendElement(interp,
						resultPtr, itemPtr) != TCL_OK) {
					return TCL_ERROR;
				}
			}
		}
		return TCL_OK;
	}

        if (Tcl_ListObjLength(interp, objv[1], &count) != TCL_OK) {
                return TCL_ERROR;
	}

	if (count == 1) {
		/* check for special command options */
		name = Tcl_GetString(objv[1]);

		if (StrEq(name, "false")) {
			for (index = SeCritSz; --index >= 0; ) {
				SeIsCritical[index] = mFalse;
			}
			Tcl_SetBooleanObj(resultPtr, mTrue);
			return TCL_OK;
		} else if (StrEq(name, "true")) {
			for (index = SeCritSz; --index >= 0; ) {
				/* use special flag for s2ReadDesFile() */
				SeIsCritical[index] = mTrue;
			}
			Tcl_SetBooleanObj(resultPtr, mTrue);
			return TCL_OK;
		}
	}

	for (index = 0; index < count; index++) {
		if (Tcl_ListObjIndex(interp, objv[1], index, &itemPtr)
				!= TCL_OK) {
			return TCL_ERROR;
		}

		if (Tcl_ListObjLength(interp, itemPtr, &itemcount) != TCL_OK) {
			return TCL_ERROR;
		}
		if (itemcount < 1 || itemcount > 2) {
			sprintf(buffer, "list item index %d contains wrong "
				"number of items", index);
			Tcl_SetResult(interp, buffer, TCL_VOLATILE);
			return TCL_ERROR;
		}

		if (itemcount == 1) {
			/* component with no qualifer */
			name = Tcl_GetString(itemPtr);
			qual = "";
		} else {  /* itemcount == 2 */
			/* component with qualified */
			if (Tcl_ListObjIndex(interp, itemPtr, 0, &compPtr)
					!= TCL_OK) {
				return TCL_ERROR;
			}
			if (Tcl_ListObjIndex(interp, itemPtr, 1, &qualPtr)
					!= TCL_OK) {
				return TCL_ERROR;
			}
			name = Tcl_GetString(compPtr);
			qual = Tcl_GetString(qualPtr);
		}
		if (name[0] == '\0') {
			sprintf(buffer, "component name %d not specified",
				index);
			Tcl_SetResult(interp, buffer, TCL_VOLATILE);
			return TCL_ERROR;
		}
		if (qual[0] != '\0') {
			name = (char *)SeGetQualName(name, qual);
		}
		compindx = NmIndex(name, &SeComponents, mFalse);
		if (compindx < 0) {
			sprintf(buffer, "component %d '%s' not found", index,
				name);
			Tcl_SetResult(interp, buffer, TCL_VOLATILE);
			return TCL_ERROR;
		} else {
			SeIsCritical[compindx] = mTrue;
		}
	}
	return TCL_OK;

}  /* se_tcl_critcomps() */

/*******************************************************************************
* se_tcl_syscomps()  gets a list of a system's components
*
* Arguments:
*   clientData   client data
*   interp       pointer to the TCL interpreter information structure
*   objc         command argument object count
*   objv         pointer to an array of argument object pointers
*
* Returns: TCL_OK if successful, TCL_ERROR if error
*******************************************************************************/

MuvesBool
get_compids(RtRegionList *list, Tcl_Interp *interp, Tcl_Obj *res)
{
	int i, j;
	int *ids, len = 0, id;

	if (list == NULL)
		return mTrue;

	ids = (int *)DmMalloc(sizeof(int) * list->count);
	for (i = 0; i < list->count; i++) {
		id = list->regions[i]->reg_regionid == 0
			? -list->regions[i]->reg_aircode
			: list->regions[i]->reg_regionid;

		/* see if id is not in the array */
		for (j = 0; j < len && id != ids[j]; j++)
			;

		/* if not in array then added to array and Tcl list */
		if (j == len) {
			ids[len++] = id;
			if (Tcl_ListObjAppendElement(interp, res,
					Tcl_NewIntObj(id)) != TCL_OK) {
				DmFree(ids);
				return mFalse;
			}
		}
	}
	DmFree(ids);
	return mTrue;
}

int
se_tcl_syscomps(ClientData clientData, Tcl_Interp *interp, int objc,
	Tcl_Obj *const objv[])
{
	Tcl_Obj *resultPtr;	/* pointer to result object */
	Tcl_Obj *clPtr;		/* pointer to list object */
	Tcl_Obj *objPtr;	/* pointer to a Tcl object */
	char *el_name;		/* pointer to state element name */
	int el_index;		/* index of state element */
	SeSysDef *element;	/* pointer to state element */
	SeCompInfoList list;	/* component information list */
	int i;			/* loop index variable */

	if (objc != 2) {
		Tcl_SetResult(interp, "usage: se_syscomps "
			"system_name|component_name", TCL_STATIC);
		return TCL_ERROR;
	}

	resultPtr = Tcl_GetObjResult(interp);
	el_name = Tcl_GetString(objv[1]);
	if ((el_index = NmIndex(el_name, &SeSystems, mFalse)) >= 0) {
		if ((element = SeDataSystem[el_index]->sysdef) == NULL) {
			Tcl_AppendResult(interp, "element '", el_name, "' has "
				"no system definition", NULL);
			return TCL_ERROR;
		}
		list.len = 0;
		list.id = NULL;
		NmInit(&list.names);
		SeSysCompList(element, &list, 0);
		for (i = 0; i < NmCount(&list.names); i++) {
			objPtr = Tcl_NewObj();
			if (!get_compids(RtRegList(list.id[i]), interp,
					objPtr)) {
				return TCL_ERROR;
			}
			clPtr = Tcl_NewObj();
			if (Tcl_ListObjAppendElement(interp, clPtr,
					Tcl_NewStringObj(NmName(i, &list.names), -1))
					!= TCL_OK) {
				return TCL_ERROR;
			}
			if (Tcl_ListObjAppendElement(interp, clPtr,
					Tcl_NewIntObj(list.id[i]))
					!= TCL_OK) {
				return TCL_ERROR;
			}
			if (Tcl_ListObjAppendElement(interp, clPtr, objPtr)
					!= TCL_OK) {
				return TCL_ERROR;
			}
			if (Tcl_ListObjAppendElement(interp, resultPtr, clPtr)
					!= TCL_OK) {
				return TCL_ERROR;
			}
		}
		DmFree(list.id);
	} else  {
		ErClear();  /* clear error set by NmIndex() */
		if ((el_index = NmIndex(el_name, &SeComponents, mFalse)) >= 0) {
			objPtr = Tcl_NewObj();
			if (!get_compids(RtRegList(el_index), interp, objPtr)) {
				return TCL_ERROR;
			}
			clPtr = Tcl_NewObj();
			if (Tcl_ListObjAppendElement(interp, clPtr,
					Tcl_NewStringObj(el_name, -1))
					!= TCL_OK) {
				return TCL_ERROR;
			}
			if (Tcl_ListObjAppendElement(interp, clPtr,
					Tcl_NewIntObj(el_index)) != TCL_OK) {
				return TCL_ERROR;
			}
			if (Tcl_ListObjAppendElement(interp, clPtr, objPtr)
					!= TCL_OK) {
				return TCL_ERROR;
			}
			if (Tcl_ListObjAppendElement(interp, resultPtr, clPtr)
					!= TCL_OK) {
				return TCL_ERROR;
			}
		} else {
			ErClear();  /* clear error set by NmIndex() */
			Tcl_AppendResult(interp, "element '", el_name,
				"' not found ", NULL);
			return TCL_ERROR;
		}
	}
	return TCL_OK;

}  /* se_tcl_syscomps() */


/* SeTcl.c */
