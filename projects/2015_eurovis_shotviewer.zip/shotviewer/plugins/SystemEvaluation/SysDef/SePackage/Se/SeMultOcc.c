/*
	SeMultOcc.c -- MUVES "Se" (system evaluation) package
			multiple occurrence handler

	created:        00/05/16        C Hunt III
	edited:		01/08/28	C Hunt III
			Corrected calculation for SeBitArrSize in SeFixMultOcc()
	edited:		01/08/29	C Hunt III
			Corrected size on memcpy() in SeAddSumEntry()
			Added additional/modified debug statements
			Added level for debugging to SeProcessNode()
	edited:		01/09/02	C Hunt III
			Added initialization value for SeSysDef
			Added level argument to SeProcessNode() and
			SeFindMultOcc() for debugging
			Added a return value to SeFindMultOcc() for debugging
	edited:		01/09/05	C Hunt III
			Added debugging code to SeProcessNode() and
			SeAddOrAndTable()
	edited:		01/10/04	C Hunt III
			Added check to see if first entry in table was removed
			in SeAddOrAndTable()
	edited:		01/12/06	C Hunt III
			Added new temporary expression substitution optimization
			to simplify very complex expressions so that this
			algorithm can handle the expression
			Added additional debugging statements
	edited:		01/12/08	C Hunt III
			Added more Se node expression types in SePrintExprTree
	edited:		03/09/05	C Hunt III
			Added fix flag to SeFindMultOcc() so that an error
			message is not displayed if the expression was fix
			(AJEM SCR414)
	edited:		03/09/08	C Hunt III
			Modified and added debug output, including the output
			of the occurrence arrays, also added header argument to
			SePrintExprTree(), which is used for printing the
			original expresion, substituted expression and final
			(corrected, i.e. new) expression (AJEM SCR414)
	edited:		03/09/10	C Hunt III
			The code that substituted expressions that did not
			contain multiple occurrences was not working correctly,
			with certain expressions, the wrong expression was
			substituted, or was not substituted at all; to correct
			the problem, the following changes were made:
			Replaced SysDef pointer arrays SeCompList and SeTmpExpr
			with structure arrays that will contain a pointer to a
			copy of the expression node of the original expression
			node, used counter for use when building the final
			(corrected) expression, and a pointer to the original
			expression node (SeTmpExpr only) which is used to track
			when an sub-expression (including system) is found in
			multiple nodes within the original expression;
			The substituted expression is now a copy of the original
			expression (this was necessary so that the expression
			nodes of the original expression are properly freed and
			so that the nodes in the substituted expression to not
			contain pointers to nodes in the freed original
			expression;
			Corrected a bug in the SeSubstituteExpression() where
			if an expression contained multiple occurrent components
			on both sides of the expression, but neither side
			contained the same component, that the entire expression
			is now substituted with a temporary expression node (the
			problem that occurred was that a system expression that
			contained multiple occurrent components that was found
			in mulitple places in the expression was substituted
			with different temporary expression nodes, causing the
			fix multiple occurrence routine to incorrectly process
			the expression);
			Added code to SeTemporaryExpression() to check for a
			matching system (by system index), a qualified operator
			by expression pointer (within the left side pointer)
	edited:		03/09/11	C Hunt III
			Removed code the made a copy of system expressions and
			qualified operator expressions, code was added to
			SeTemporaryExpression() to make the first copy of the
			expression, the used counter is used when building the
			new (corrected) expression where the first time, the
			copy made is used and subsequent uses make a new copy of
			the expression;
			Removed code to process an SeNT_EXPR node type since
			this node type is removed during the substitution step
	edited:		05/02/14	C Hunt III
			changed all debug constants for printing expression to
			SEDBG_SRTDTBL; added error messages; added debug
			messages (AJEM SCR573)
	edited:		05/02/15	C Hunt III
			added SeCheckExprTree() to check expression for validity
			all several calls to the function - after the problem
			was corrected, calls to this function were commented
			(AJEM SCR573)
	edited:		05/02/18	C Hunt III
			corrected a debug message; changed all debug constants
			for print summation table to SEDBG_SUMTBL; added debug
			messages (AJEM SCR573)
	edited:		05/02/19	C Hunt III
			corrected a problem with expression nodes that contained
			only a component, this caused a problem when processing
			the node where the component index was not being
			obtained properly - a zero was used which causes the
			build new expresion routine to build a bad expression;
			calls to SeCheckExprTree() were conditioned on the
			CHECK_EXPR define (AJEM SCR573)
	edited:		05/03/22-05/08/25	C Hunt III
			Made the following changes for SCR579:
			- corrected logic for substituting temporary expression
			  nodes (i.e. to correctly identify when systems and
			  expressions should be substituted)
			- modified test code to also identify multiple occurrent
			  systems and components/systems that are only multiple
			  occurrent within another system (so that these systems
			  can be substituted and processed separately) and to
			  process the substituted expression (i.e. handle
			  temporary expression nodes)
			- modified processing code to reduce memory requirements
			  (reduced OR/AND table entries; eliminate need to store
			  summation table, which required the OR/AND table
			  linked list to be converted to an array; identify
			  multiple occurrent OR/AND table entries since non-
			  multiple occurrent entries do not need to be processed
			  when creating the sorted summation table and can be
			  added to the final expression afterward)
			- other corrections: cloned only the main system
			  expression node and not system's entire expression
			  tree when creating a temporary expression node;
			  deallocate unused component nodes and temporary
			  expressions nodes; remove extra expression nodes that
			  contain only a qualified component name
			- other changes: modified function headers to use
			  PARAMS macro; modified debug flags; replaced spaces
			  with tabs; removed end of line spaces; fixed long
			  lines
			- added time to correct expression to debug output if
			  time is greater than 0 seconds
	edited:		12/10/22	C Hunt
			corrected compiler warnings (VSL)
*/
#ifndef lint
static char RCSid[] = "$Id: SeMultOcc.c,v 1.20 2010/06/23 19:54:51 geoffs Exp $";
#endif

#ifndef DEBUG
#define NDEBUG
#endif

#include <assert.h>
#include <stdio.h>
#include <string.h>
#include <time.h>	/* 05-08-25 ch3: for time functions */

#ifdef __STDC__
#include <stdlib.h>
#else
extern double atof();
#endif

#include <std.h>

#include <Dq.h>
#include <Er.h>
#include <stdio.h>
#include <common.h>   /* BRL-CAD 7.2.4+ no longer use config.h (SCR670) */
#include <Dm.h>
#include <Nm.h>
#include <Rt.h>
#include <Se.h>

#include "SeDefs.h"
typedef void* genptr_t;
#ifndef STATIC
#define STATIC static
#endif

#ifndef SeDEBUG
#define SeDEBUG 0
#endif

/* 05-02-19 ch3: added define to disable check expression calls */
#define CHECK_EXPR 0
#define ErDebugging SeDebugging

#define BITARR_ELEM_SIZE       (sizeof(unsigned) * 8)
#define ARRAY_SIZE             500  /* intial array sizes */
/* calculate size of a sum table entry */
/* (for bit array, initial sign and current sign factor) */
/* 01-08-29 ch3: replaced sizeof(int) with 1 (for sign factor), since
 *               SumEntrySize is in number of unsigned words, not bytes */
#define SumEntrySize           (SeBitArrSize + 1)
/* from bit array pointer (unsigned *), return sum entry's sign factor */
/* 01-08-29 ch3: removed (unsigned *) from bitarr, it's not necessary */
#define SumSignFactor(bitarr)  (*(int *)(bitarr + SeBitArrSize))


/* OCCUR  type of occurrence array element */

typedef unsigned char OCCUR;	/* type of occurrence arrays */


/* SeOccurEnum  occurrence value enumeration */

typedef enum
{
	NO_OCCUR,		/* did not occur in expression */
	YES_OCCUR,		/* occurred one time in expression */
	SYSMULT_OCCUR,		/* occurred multiple times, but in a system */
	MULT_OCCUR,		/* occurred multiple times in expression */
	SIZE_OCCUR		/* size of this enumeration */
} SeOccurEnum;


/* SeSysInfoEnum  test expression system information enumeration */

typedef enum
{
	NONE_SYSINFO,		/* no system information */
	SEEN_SYSINFO,		/* system has been seen in expression */
	SIZE_SYSINFO		/* size of this enumeration */
} SeSysInfoEnum;


/* SeSysSubInfoEnum  expression system substitute information enumeration */

typedef enum
{
	NONE_SUBINFO,		/* no system substitute information */
	TEMP_SUBINFO,		/* system replaced with temporary node */
	CANT_SUBINFO,		/* system can't be replaced with temp node */
	SIZE_SUBINFO		/* size of this enumeration */
} SeSysSubInfoEnum;


/* SeOrAndNode  structure definition for a node of OR/AND table */

typedef struct
{
	DqNode link;		/* links for OR/AND table */
	unsigned *bitarr;	/* pointer to component bit array */
	MuvesBool multocc;		/* entry is multiple occurence (05-05-04 ch3) */
} SeOrAndNode;


/* SeSumTbl  structure definition for the sorted summation table index */

typedef struct
{
	unsigned **arrayp;	/* pointer to array of bit array pointers */
	int max_size;		/* current maximum size of array */
	int size;		/* size of array (number of current entries */
} SeSumTbl;


/* 03-09-10 ch3: added new structures SeCompListInfo/SeTmpExprInfo that contain
 *               a pointer to a copy of the original expression, a pointer to
 *               the original expression (SeTmpExprInfo) and copy used counters
 */
/* SeCompListInfo  structure definition for holding component node info */

typedef struct
{
	SeSysDef *copy;		/* pointer to copy of component node */
	int used;		/* number of times expression is used */
} SeCompListInfo;

/* SeTmpExprInfo  structure definition for holding temporary expression info */

typedef struct
{
	SeSysDef *node;		/* pointer to original expression node */
	SeSysDef *copy;		/* pointer to copy of expression */
	int used;		/* number of times expression is used */
} SeTmpExprInfo;


STATIC SeOccurEnum SeMultOccTest PARAMS((SeSysDef *expr, OCCUR *occur,
	OCCUR *sysoccur, char *qualifier, int level));
/* 01-12-06 ch3: replaced SeSubstituteSystems with SeSubstituteExpressions */
STATIC SeSysDef *SeSubstituteExpressions PARAMS((SeSysDef *expr,
	char *qualifier, OCCUR *occur, OCCUR *sysoccur, int level));
/* 01-12-06 ch3: added SeTemporaryExpression() */
STATIC SeSysDef *SeTemporaryExpression PARAMS((SeSysDef *expr, int level));
STATIC SeSysDef *SeFixMultOccur PARAMS((SeSysDef *expr));
STATIC MuvesBool SeAddSumEntry PARAMS((SeSumTbl *sum_tbl, unsigned *bitarr,
	int sign_factor));
/* 01-08-29 ch3: added level argument for debugging */
/* 01-09-02 ch3: changed return from void to MuvesBool for debugging */
STATIC MuvesBool SeProcessNode PARAMS((SeSysDef *expr, DqNode *table, int level));
STATIC MuvesBool SeMakeOrAndArray PARAMS((unsigned ***or_and_array,
	int *or_and_size, int *or_and_count, DqNode *or_and_tbl, OCCUR *occur));
STATIC MuvesBool SeBuildSortedSumTable PARAMS((SeSumTbl *sorted_sum_tbl,
	unsigned **or_and_array, int or_and_count));
STATIC SeSysDef *SeBuildNewExprTree PARAMS((SeSumTbl *sorted_sum_tbl,
	unsigned **or_and_array, int or_and_size, int or_and_start));
STATIC SeSysDef *SeBuildBitArrayExpr PARAMS((unsigned *bitarr,
	SeNodeCategory type));
STATIC SeSysDef *SeFinishProdExpr PARAMS((SeSysDef *expr, int signfactor,
	MuvesBool firstexpr, SeNodeCategory *type));
STATIC MuvesBool SeAddOrAndTable PARAMS((DqNode *table, SeOrAndNode *newentry));
STATIC int SeCmpBitArrays PARAMS((unsigned *bitarr1, unsigned *bitarr2));
STATIC int SeSetBitArrays PARAMS((unsigned *bitarr1, unsigned *bitarr2));
STATIC unsigned SeGetBit PARAMS((unsigned *bitarr, int index));
STATIC void SeSetBit PARAMS((unsigned *bitarr, int index));
/* 03-09-10 ch3: added header argument */
STATIC void SePrintExprTree PARAMS((SeSysDef *expr, int level, char *header,
	MuvesBool sys_exprs));
/* 05-02-15 ch3: added header argument */
#if CHECK_EXPR
STATIC void SeCheckExprTree PARAMS((SeSysDef *expr, int level, char *header));
#endif


extern int SeDebugging;

STATIC short SeNumComponents;  /* number of components */
/* 01-12-06 ch3: added new substituted expression array size and number */
STATIC short SeTmpExprSize;    /* size of temporary expression array */
STATIC short SeNumTmpExprs;    /* number of temporary expressions */
STATIC short SeBitArrSize;     /* unsigned size of component bit arrays */
STATIC short SeNumSystems;     /* number of systems (05-03-22 ch3) */
/* 05-04-15 ch3 */
STATIC short SeNumLeafNodes;   /* number of leaf nodes (components + temps) */
/* 05-04-08 ch3 */
STATIC short SeNumBits;        /* number of bits in reduced bit arrays */
STATIC int *SeExpandBitMap;  /* expand bit from reduced bit mapping array */
/* 01-09-02 ch3: added initialization value */
/* 03-09-10 ch3: changed type from SeSysDef * */
STATIC SeCompListInfo *SeCompList = NULL; /* pointer to component info array */
/* 01-12-06 ch3: added pointer to substituted expression array */
/* 03-09-10 ch3: changed type from SeSysDef * */
STATIC SeTmpExprInfo *SeTmpExpr = NULL;  /* pointer to temporary info array */
/* 05-03-22 ch3: added system information array pointer */
STATIC char *SeSysInfo;
STATIC char *SeSysSubInfo;
/* map left and right occurrence values to an occurrence value */
STATIC OCCUR SeMapOccur[SIZE_OCCUR][SIZE_OCCUR] =
{
	{
		NO_OCCUR,	/* NO_OCCUR, NO_OCCUR */
		YES_OCCUR,	/* NO_OCCUR, YES_OCCUR */
		YES_OCCUR,	/* NO_OCCUR, SYSMULT_OCCUR */
		MULT_OCCUR	/* NO_OCCUR, MULT_OCCUR */
	},
	{
		YES_OCCUR,	/* YES_OCCUR, NO_OCCUR */
		MULT_OCCUR,	/* YES_OCCUR, YES_OCCUR */
		MULT_OCCUR,	/* YES_OCCUR, SYSMULT_OCCUR */
		MULT_OCCUR	/* YES_OCCUR, MULT_OCCUR */
	},
	{
		YES_OCCUR,	/* SYSMULT_OCCUR, NO_OCCUR */
		MULT_OCCUR,	/* SYSMULT_OCCUR, YES_OCCUR */
		MULT_OCCUR,	/* SYSMULT_OCCUR, SYSMULT_OCCUR */
		MULT_OCCUR	/* SYSMULT_OCCUR, MULT_OCCUR */
	},
	{
		MULT_OCCUR,	/* MULT_OCCUR, NO_OCCUR */
		MULT_OCCUR,	/* MULT_OCCUR, YES_OCCUR */
		MULT_OCCUR,	/* MULT_OCCUR, SYSMULT_OCCUR */
		MULT_OCCUR	/* MULT_OCCUR, MULT_OCCUR */
	}
};


/*
	SeFindMultOcc(SeSysDef **expr, int level)

	This function will look for a multiple occurrence in the
	expression by SeMultOccTest() for the expression.  When a
	multiple occurrence is found, SeSubstituteExpressions() is
	called to substitute non-multiple occurrent expressions and
	multiple occurrent systems with no multiple occurrences with
	temporary expression nodes to simplify the expression.  The
	substituted expression will then be corrected by calling
	SeFixMultOccur().  If the top level expression does not contain
	a multiple occurrence, no action is preformed.

	This function is called from SeOptimize() and if a lower part of
	the expression (i.e. one side only) contains a multiple
	occurrence, this will be handled by SeOptimize() which
	recursively processes the expression and will call this routine
	again at each level of the expression tree.

	This function is for internal Se package use only.

	RETURN: no value is returned by this function
 */

/* 01-09-02 ch3: added level argument, changed return from void for debugging */
/* 03-09-05 ch3: added fix flag for checking when an expression was fix */
/* 05-03-22 ch3: changed way multiple occurrences detected, look at systems */
/* 05-04-17 ch3: added code to free unused comp nodes/temp exprs */
MuvesBool
SeFindMultOcc PARAMS((
	SeSysDef **expr,	/* pointer to the expression tree to search */
	int level))		/* call level, for testing only, 01-09-02 ch3 */
{
	OCCUR *occur;		/* component occured flags */
	OCCUR *sysoccur;	/* system occured flags */
	SeSysDef *tmpexpr;	/* temporary expression pointer */
	int index;		/* loop index variable */
	MuvesBool left, right;	/* result of multiple occurrence test call */
	int status;		/* return status for debugging, 01-09-02 ch3 */
	MuvesBool fix;		/* fix mult occ flag (03-09-05 ch3) */
	time_t time1;		/* start time (05-08-25 ch3) */
	time_t time2;		/* end time (05-08-25 ch3) */

	/* allocate arrays and initialize elements */
	if (level == 0)  /* 01-09-02 ch3: added for debugging */
	{
		time(&time1);  /* record start time (05-08-25 ch3) */
		SeNumComponents = NmCount(&SeComponents);
		/* 01-12-06 ch3: initialize new temporary expression vars */
		SeNumTmpExprs = 0;
		/* 05-04-15 ch3: added number of leaf nodes */
		SeNumLeafNodes = SeNumComponents;
		SeTmpExprSize = ARRAY_SIZE;
		/* 05-03-22 ch3: added substitute system support */
		SeNumSystems = NmCount(&SeSystems);
	}
	occur = (OCCUR *)DmCalloc(SeNumComponents, sizeof(OCCUR));
	sysoccur = (OCCUR *)DmCalloc(SeNumSystems, sizeof(OCCUR));
	if (level == 0)  /* 01-09-02 ch3: added for debugging */
	{
		/* 03-09-10 ch3: changed type from SeSysDef * */
		SeCompList = (SeCompListInfo *)DmCalloc(SeNumComponents,
			sizeof(SeCompListInfo));
		/* 01-12-06 ch3: allocate new temporary expression array */
		/* 03-09-10 ch3: changed type from SeSysDef * */
		SeTmpExpr = (SeTmpExprInfo *)DmCalloc(SeTmpExprSize,
			sizeof(SeTmpExprInfo));
		/* 05-03-22 ch3: allocate new substitute info system array */
		SeSysInfo = (char *)DmCalloc(SeNumSystems, sizeof(char));
		SeSysSubInfo = (char *)DmCalloc(SeNumSystems, sizeof(char));

		if (SeDebugging & SEDBG_SYSEXPR)
		{
			int i;
			ErPLog("SeFindMultOcc: SeDataSystem=%p \n",
				SeDataSystem);
			for (i = 0; i < SeNumSystems; i++)
				ErPLog("SeMultOccTest: SeDataSystem[%d]=%-8p "
					"'%s'%s'\n", i, SeDataSystem[i],
					NmName(i, &SeSystems),
					SeDataSystem[i] == NULL ? ""
					: SeDataSystem[i]->sysdef->core.text);
		}
	}
	status = mFalse;  /* 01-09-02 ch3: added for debugging */

	/* if expression is an AND or an OR type, */
	/* test each side for a multiple occurrence */
	if (SeDebugging & SEDBG_FINDMSGS)
		ErPLog("SeFindMultOcc: Expr Type: %d %s\n", (*expr)->type,
			(*expr)->core.text);
	/* 05-02-15 ch3: added call to validate original expression */
#if CHECK_EXPR
	SeCheckExprTree(*expr, 0, "Original");
#endif
	/* 05-05-02 ch3: removed check for node type, unnecessary */
	if (SeMultOccTest(*expr, occur, sysoccur, NULL, 0) == MULT_OCCUR)
	{
		if (SeDebugging & SEDBG_OCCUR)
		{
			ErPLog("SeFindMultOcc: occur[]\n");
			for (index = 0; index < SeNumComponents; index++)
				ErLog("%d", occur[index]);
			ErLog("\n");
			ErPLog("SeFindMultOcc: sysoccur[]\n");
			for (index = 0; index < SeNumSystems; index++)
				ErLog("%d", sysoccur[index]);
			ErLog("\n");
			ErPLog("SeFindMultOcc: sysinfo[]\n");
			for (index = 0; index < SeNumSystems; index++)
				ErLog("%d", SeSysInfo[index]);
			ErLog("\n");
		}

		/* check each component to see if it is on both sides */
		fix = mFalse;  /* 03-09-05 ch3: added flag initialization */
		for (index = 0; index < SeNumComponents; index++)
		{
			if (occur[index] == MULT_OCCUR)
			{
				fix = mTrue;
				break;
			}
		}
		if (!fix)
		{
			for (index = 0; index < SeNumSystems; index++)
			{
				if (sysoccur[index] == MULT_OCCUR)
				{
					fix = mTrue;
					break;
				}
			}
		}
		if (fix)
		{
			/* we have a multiple occurrence */
			/* 05-02-15 ch3: added call to validate initial
			 *               expression */
#if CHECK_EXPR
			SeCheckExprTree(*expr, 0, "Initial");
#endif
			/* 05-02-14 ch3: changed debug flag constant */
			if (SeDebugging & SEDBG_PRTIEXPR)
				SePrintExprTree(*expr, 0, "Initial", mTrue);

			/* first substitute all system expressions */
			/* 01-12-06 ch3: replaced SeSubstituteSystems */
			/* create 'multiple occurrent' comps array */
			if (SeDebugging & SEDBG_MULTOCCS)
			{
				MuvesBool flag;

				flag = mFalse;
				for (index = 0; index < SeNumComponents;
					index++)
				{
					if (occur[index] == MULT_OCCUR)
					{
						if (!flag)
						{
							ErPLog("SeFindMultOcc: "
								"comps\n");
							flag = mTrue;
						}
						ErLog(" %s:%d", NmName(index,
							&SeComponents), index);
					}
				}
				if (flag)
				{
					ErLog("\n");
				}
				flag = mFalse;
				for (index = 0; index < SeNumSystems; index++)
				{
					if (sysoccur[index] == MULT_OCCUR)
					{
						if (!flag)
						{
							ErPLog("SeFindMultOcc: "
								"systems\n");
							flag = mTrue;
						}
						ErLog(" %s:%d", NmName(index,
							&SeSystems), index);
					}
				}
				if (flag)
				{
					ErLog("\n");
				}
			}
			tmpexpr = SeSubstituteExpressions(*expr, NULL, occur,
				sysoccur, 0);
			if (tmpexpr == NULL)
			{
				/* 05-02-14 ch3: added debug message */
				if (SeDebugging)
					ErPLog("SeFindMultOcc: "
						"substitute error\n");
				/* unexpected error */
				ErSet(SeSTCORRUPT);
				return mFalse;
			}
			if (tmpexpr != *expr)
			{
				if (SeDebugging & SEDBG_STSMSGS)
					ErPLog("SeFindMultOcc: SeExpFree(%p)\n",
						*expr);
				/* free system node and substitute */
				SeExpFree(*expr);
				*expr = tmpexpr;
			}
			/* 05-02-15 ch3: added call to validate substituted
			 *               expression */
#if CHECK_EXPR
			SeCheckExprTree(*expr, 0, "Substituted");
#endif
			/* 05-02-14 ch3: changed debug flag constant */
			if (SeDebugging & SEDBG_PRTSEXPR)
				SePrintExprTree(*expr, 0, "Substituted", mTrue);

			if (!(SeDebugging & SEDBG_LVLMSGS))
			{
				/* now fix the expression */
				tmpexpr = SeFixMultOccur(*expr);
				assert(tmpexpr != NULL);
				if (tmpexpr != NULL)
				{
					*expr = tmpexpr;
#ifdef DEBUG
					/* 05-02-14 ch3: changed debug
					 *               flag constant */
					if (SeDebugging)
						SePrtExpression(*expr, 0);
#endif
					/* 03-09-05 ch3: added flag set */
					fix = mTrue;
				}
				else
				{
					/* 05-02-14 ch3: added debug
					 *               message */
					ErLog("SeFindMultOcc: Error fixing "
						"expression\n");
					ErSet(SeSTCORRUPT);
					fix = mFalse;
				}
			}
			else  /* special debugging code */
			{
				/* 01-09-02 ch3: added debugging code */
				/* let's check each side for multocc */
				left = SeFindMultOcc(&(*expr)->o.lhsp,
					level + 1);
				right = SeFindMultOcc(&(*expr)->o.rhsp,
					level + 1);
				if (level == 0)
					ErLog("SeNumComponents = %d\n",
						SeNumComponents);
				ErLog("MultOcc: %s-%d (%d, %d)\n",
					(*expr)->core.text, level,
					(int)left, (int)right);
				for (index = 0; index < SeNumComponents;
						index++)
					if (occur[index] == MULT_OCCUR)
					{
						ErLog(" %d-%s(%d)", index,
							NmName(index,
							&SeComponents),
							occur[index]);
					}
				for (index = 0; index < SeNumSystems; index++)
					if (sysoccur[index] == MULT_OCCUR)
					{
						ErLog(" %d-%s(%d)", index,
							NmName(index,
							&SeSystems),
							sysoccur[index]);
					}
				ErLog("\n");
				status = mTrue;
				/* 03-09-05 ch3: added error set */
				ErSet(SeMULTOCCTEST);
				/* don't actually fix expression */
			}
		}
		/* 05-08-25 ch3: added output of time to process expression */
		if (fix && (SeDebugging & SEDBG_STSMSGS))
		{
			int secs;

			time(&time2);
			secs = (int)difftime(time2, time1);
			if (secs > 0)
			{
				ErPLog("SeFindMultOcc: Time to process MultOcc "
					"expression = %d secs\n", secs);
			}
		}
		/* 03-09-05 ch3: added check for fix flag */
		if (!fix && (SeDebugging & SEDBG_FINDMSGS))
			ErPLog("SeFindMultOcc: No MultOcc Fixed: %s\n",
				(*expr)->core.text);
	}
	else if (SeDebugging & SEDBG_FINDMSGS)
		ErPLog("SeFindMultOcc: No MultOcc: %d, %s\n", (*expr)->type,
			(*expr)->core.text);

	/* deallocate arrays */
	DmFree((genptr_t)occur);
	DmFree((genptr_t)sysoccur);
	if (level == 0)  /* 01-09-02 ch3: added for debugging */
	{
		/* 05-04-17 ch3: added code to free unused component nodes */
		for (index = 0; index < SeNumComponents; index++)
		{
			tmpexpr = SeCompList[index].copy;
			if (tmpexpr != NULL)
			{
				if (SeCompList[index].used == 0)
				{
					/* component node was not used */
					if (SeDebugging & SEDBG_FREEMSGS)
					{
						ErPLog("SeFindMultOcc: COMP "
							"(%d) not used; %p=%d,"
							"%s\n",
							tmpexpr->c.index,
							tmpexpr, tmpexpr->type,
							tmpexpr->core.text);
					}
					SeExpFree(tmpexpr);
				}
				else if (SeDebugging & SEDBG_FREEMSGS)
				{
					ErPLog("SeFindMultOcc: COMP (%d) used "
						"%d times; %p=%d,%s\n",
						tmpexpr->c.index,
						SeCompList[index].used,
						tmpexpr, tmpexpr->type,
						tmpexpr->core.text);
				}
				SeCompList[index].copy = NULL;
			}
		}
		DmFree((genptr_t)SeCompList);

		/* 05-04-17 ch3: added code to free unused temp expressions */
		for (index = 0; index < SeNumTmpExprs; index++)
		{
			tmpexpr = SeTmpExpr[index].copy;
			if (SeTmpExpr[index].used == 0)
			{
				/* temporary expression was not used */
				if (SeDebugging & SEDBG_FREEMSGS)
					ErPLog("SeFindMultOcc: TMPEXPR not "
						"used; %p=%d,%s\n", tmpexpr,
						tmpexpr->type,
						tmpexpr->core.text);

				SeExpFree(tmpexpr);
			}
			else if (SeDebugging & SEDBG_FREEMSGS)
			{
				ErPLog("SeFindMultOcc: TMPEXPR used %d times; "
					"%p=%d,%s\n", SeTmpExpr[index].used,
					tmpexpr, tmpexpr->type,
					tmpexpr->core.text);
			}
			SeTmpExpr[index].copy = NULL;
		}
		/* 01-12-06 ch3: free new temporary expression array */
		DmFree((genptr_t)SeTmpExpr);

		/* 05-03-22 ch3: allocate new system info arrays */
		DmFree((genptr_t)SeSysInfo);
		DmFree((genptr_t)SeSysSubInfo);
	}
	return status;  /* 01-09-02 ch3: added for debugging */

}  /* SeFindMultOcc() */


/*
	SeOccurEnum SeMultOccTest(SeSysDef *expr, OCCUR *occur,
		OCCUR *sysoccur, char *qualifier, int level)

	This function will test the expression argument for components
	and systems that are occurrent, multiple occurrent or multiple
	occurrent in a system only.

	If the expression type is an AND or an OR operator, both the
	left and the right side of the expression will be tested by
	calling this function recusively.  The resulting component and
	system occurrent values are combined and returned to the level
	above.

	If the expression is a component or qualified component (i.e.
	leaf node), then the component is marked as occurrent.  A copy
	of all component expression nodes found are made for when the
	expression is fixed for multiple occurrences.

	If the expression is a system or qualified system and the system
	has been seen before, then the system is marked as occurrent.
	Otherwise, the system is marked as being seen and the expression
	of the system is tested.  The system is marked as occurrent and
	each of the components and systems that are multiple occurrent
	within the expression of the system are marked as multiple
	occurrent in a system only.

	If the expression is a qualified operator node, the qualifier is
	passed down to the expression of the qualified operator node.

	If the expression is an special expression that contains a
	qualifier component, the component is processed as described
	above.  Otherwise, the expression of the expression is tested.

	If the expression is a temporary expresion node and the
	expression being tested is a substituted expression, then the
	temporary expression node is processed as a component (i.e. leaf
	node) described above.  Otherwise, the expression tree is
	corrupted and the error flag is set and an error is returned.

	All other node types (including the special multiple occurrent
	node type) are unacceptible and a not acceptible status is
	returned.

	This function is for internal Se package use only.

	RETURN: MULT_OCCUR if a multiple occurrence was found
		YES_OCCUR if a leaf node was found
		NO_OCCUR if expression is not acceptible
		NO_OCCUR and ErIsSet() if an error found
 */

/* 05-03-20 ch3: added code to process systems one time only */
/* 05-03-22 ch3: changed method to combine left/right occur, added systems */
/* 05-04-14 ch3: modified return values from simple boolean value */
/* 05-04-14 ch3: added code for new 'system-multiple occurrence' to systems */
/* 05-04-14 ch3: added code to process temp expr nodes for substituted expr */
/* 05-04-15 ch3: modified to use SeNumLeafNodes instead of SeNumComponents */
SeOccurEnum
SeMultOccTest PARAMS((
	SeSysDef *expr,		/* pointer to the expression tree to test */
	OCCUR *occur,		/* pointer to array of comp occurrences */
	OCCUR *sysoccur,	/* pointer to array of system occurrences */
	char *qualifier,	/* pointer to qualifier string */
	int level))		/* call level of function - for testing only */
{
	const char *basename;	/* pointer to the base component name */
	const char *qualname;	/* pointer to the qaulifier name */
	int index;		/* component/system index variable */
	OCCUR *loccur;		/* pointer to left side occurrence comps */
	OCCUR *roccur;		/* pointer to right side occurrence comps */
	OCCUR *lsysoccur;	/* pointer to left side occurrence systems */
	OCCUR *rsysoccur;	/* pointer to right side occurrence systems */
	SeOccurEnum multocc;	/* mult occ between left/right flag */

	switch (expr->type)
	{
	case SeNT_AND:
	case SeNT_OR:
		if (SeDebugging & SEDBG_TSTEXPR)
			ErPLog("SeMultOccTest(%d): AND/OR: %p=%d,%s\n", level,
				expr, expr->type, expr->core.text);

		/* allocate/initialize left and right side occurrence arrays */
		loccur = (OCCUR *)DmCalloc(SeNumLeafNodes, sizeof(OCCUR));
		roccur = (OCCUR *)DmCalloc(SeNumLeafNodes, sizeof(OCCUR));
		lsysoccur = (OCCUR *)DmCalloc(SeNumSystems, sizeof(OCCUR));
		rsysoccur = (OCCUR *)DmCalloc(SeNumSystems, sizeof(OCCUR));

		/* check both left and right hand side expressions */
		SeMultOccTest(expr->o.lhsp, loccur, lsysoccur, qualifier,
			level + 1);
		if (SeDebugging & SEDBG_OCCUR)
		{
			ErPLog("SeMultOccTest(%d): loccur[] ", level);
			for (index = 0; index < SeNumLeafNodes; index++)
				ErLog("%d", loccur[index]);
			ErLog("\n");
			ErPLog("SeMultOccTest(%d): lsysoccur[] ", level);
			for (index = 0; index < SeNumSystems; index++)
				ErLog("%d", lsysoccur[index]);
			ErLog("\n");
		}

		SeMultOccTest(expr->o.rhsp, roccur, rsysoccur, qualifier,
			level + 1);
		if (SeDebugging & SEDBG_OCCUR)
		{
			ErPLog("SeMultOccTest(%d): roccur[] ", level);
			for (index = 0; index < SeNumLeafNodes; index++)
				ErLog("%d", roccur[index]);
			ErLog("\n");
			ErPLog("SeMultOccTest(%d): rsysoccur[] ", level);
			for (index = 0; index < SeNumSystems; index++)
				ErLog("%d", rsysoccur[index]);
			ErLog("\n");
		}

		/* now look for multiple occurrent components */
		multocc = YES_OCCUR;
		for (index = 0; index < SeNumLeafNodes; index++)
		{
			if ((occur[index] = SeMapOccur[loccur[index]]
				[roccur[index]]) == MULT_OCCUR)
			{
				/* we have a multiple occurrent component */
				multocc = MULT_OCCUR;
			}
		}
		if (SeDebugging & SEDBG_OCCUR)
		{
			ErPLog("SeMultOccTest(%d): occur[%c] ", level,
				multocc == MULT_OCCUR ? 'M' : '-');
			for (index = 0; index < SeNumLeafNodes; index++)
				ErLog("%d",  occur[index]);
			ErLog("\n");
		}

		/* now look for multiple occurrent systems */
		for (index = 0; index < SeNumSystems; index++)
		{
			if ((sysoccur[index] = SeMapOccur[lsysoccur[index]]
				[rsysoccur[index]]) == MULT_OCCUR)
			{
				/* we have a multiple occurrent system */
				multocc = MULT_OCCUR;
			}
		}
		if (SeDebugging & SEDBG_OCCUR)
		{
			ErPLog("SeMultOccTest(%d): sysoccur[%c] ", level,
				multocc == MULT_OCCUR ? 'M' : '-');
			for (index = 0; index < SeNumSystems; index++)
				ErLog("%d", sysoccur[index]);
			ErLog("\n");
		}

		/* deallocate arrays */
		DmFree((genptr_t)loccur);
		DmFree((genptr_t)roccur);
		DmFree((genptr_t)lsysoccur);
		DmFree((genptr_t)rsysoccur);

		return multocc;

	case SeNT_COMPNAME:
	case SeNT_QUALCOMP:
		if (SeDebugging & SEDBG_TSTEXPR)
			ErPLog("SeMultOccTest(%d): COMPNAME/QUALCOMP: %p=%d,%s"
				"\n", level, expr, expr->type, expr->core.text);
		index = expr->c.index;

		if (index >= SeNumComponents)
		{
			if (SeDebugging)
				ErPLog("%s: component index (%d) not in name "
					"pool.\n", "SeMultOccTest: BUG", index);
			ErSet(SeSTCORRUPT);
			return NO_OCCUR;
		}

		/* check if this is a qualified expression */
		if (qualifier != NULL)
		{
			basename = SePrsBaseName(index);
			qualname = SeGetQualName(basename, qualifier);
			index = NmIndex(qualname, &SeComponents, mFalse);
		}

		/* set flag that component has occurred */
		occur[index] = YES_OCCUR;
		/* 03-09-10 ch3: added code to make a copy of the expression as
		 *               the new expression with substitutes is built
		 *               for the multiple occurrence routine; also reset
		 *               the used counter, which will be used when the
		 *               substituted expressions are put back in when
		 *               the expression is built
		 */
		if (SeCompList[index].copy == NULL)
		{
			SeCompList[index].copy = SeExpCopy(expr);
			SeCompList[index].used = 0;
			if (SeDebugging & SEDBG_TSTEXPR)
				ErPLog("SeMultOccTest(%d): SeCompList[%d]=%p,"
					"%d,%s (%p)\n", level, index, expr,
					expr->type, expr->core.text,
					SeCompList[index].copy);
		}
		return YES_OCCUR;

	case SeNT_SYSNAME:
	case SeNT_QUALSYS:
		if (SeDebugging & SEDBG_TSTEXPR)
			ErPLog("SeMultOccTest(%d): SYSNAME/QUALSYS: %p=%d,%s"
				"\n", level, expr, expr->type, expr->core.text);
		if (SeDebugging & SEDBG_TSTEXPR)
			ErPLog("SeMultOccTest: system index=%d count=%d\n",
				expr->c.index, SeNumSystems);
		index = expr->c.index;
		if (index >= SeNumSystems)
		{
			if (SeDebugging & SEDBG_TSTEXPR)
				ErPLog("%s: system index (%d) not in name "
					"pool.\n", "SeMultOccTest: BUG",
					expr->c.index);
			ErSet(SeSTCORRUPT);
			return NO_OCCUR;
		}

		if (SeDataSystem[index] == NULL)
		{
			if (SeDebugging)
				ErPLog("SeMultOcctest: system '%s' undefined."
					"\n", NmName(expr->c.index,
					&SeSystems));
			ErSet(SeSTCORRUPT);
			return NO_OCCUR;
		}

		if (SeDebugging & SEDBG_SYSEXPR)
		{
			ErPLog("SeMultOccTest: sysdef=%p \n",
				SeDataSystem[expr->c.index]->sysdef);
		}

		/* 05-03-20 ch3: added check to see if system was seen before */
		if (SeSysInfo[index] != NONE_SYSINFO)
		{
			/* this system has already been processed */
			if (SeDebugging & SEDBG_TSTEXPR)
				ErPLog("SeMultOccTest: system already processed"
					" index=%d\n", index);
			/* need to mark that system occurred */
			sysoccur[index] = YES_OCCUR;
			return MULT_OCCUR;
		}

		/* mark this system as seen and process it one time */
		SeSysInfo[index] = SEEN_SYSINFO;

		/* continue checking with system's expression */
		multocc = SeMultOccTest(SeDataSystem[index]->sysdef, occur,
			sysoccur, qualifier, level + 1);
		sysoccur[index] = YES_OCCUR;

		if (multocc == MULT_OCCUR)
		{
			if (SeDebugging & SEDBG_YESMOSYS)
				ErPLog("SeMultOccTest(%d): System (YES): %p=%d,"
					"%s [%d]=%d\n", level, expr, expr->type,
					expr->core.text, index,
					sysoccur[index]);
		}
		else if (multocc == YES_OCCUR)
		{
			if (SeDebugging & SEDBG_NOMOSYS)
				ErPLog("SeMultOccTest(%d): System (NO): %p=%d,"
					"%s [%d]=%d\n", level, expr, expr->type,
					expr->core.text, index,
					sysoccur[index]);
		}

		/* 05-04-14 ch3: set multiple occurrent to system multiple */
		for (index = 0; index < SeNumComponents; index++)
		{
			if (occur[index] == MULT_OCCUR)
			{
				/* demote to occurring in a system */
				occur[index] = SYSMULT_OCCUR;
			}
		}
		for (index = 0; index < SeNumSystems; index++)
		{
			if (sysoccur[index] == MULT_OCCUR)
			{
				/* demote to occurring in a system */
				sysoccur[index] = SYSMULT_OCCUR;
			}
		}

		return multocc;

	case SeNT_QUALOP:
		if (SeDebugging & SEDBG_TSTEXPR)
			ErPLog("SeMultOccTest(%d): QUALOP: %p=%d,%s\n", level,
				expr, expr->type, expr->core.text);
		/* get the new qualifier for the qualified expression */
		qualifier = expr->o.rhsp->core.text;

		/* continue checking the qualified expression */
		return SeMultOccTest(expr->o.lhsp, occur, sysoccur, qualifier,
			level + 1);

	case SeNT_EXPR:
		if (expr->o.rhsp->type == SeNT_COMPNAME)
		{
			/* a qualified component */
			index = expr->o.rhsp->c.index;
			if (SeDebugging & SEDBG_TSTEXPR)
				ErPLog("SeMultOccTest(%d): EXPR-COMPNAME: %p="
					"%d,%s,%d\n", level, expr, expr->type,
					expr->core.text, index);

			if (index >= SeNumComponents)
			{
				if (SeDebugging)
					ErPLog("%s: component index (%d,%s) "
						"not in name pool.\n",
						"SeMultOccTest: BUGe", index,
						expr->c.core.text);
				ErSet(SeSTCORRUPT);
				return NO_OCCUR;
			}

			/* set flag that component has occurred */
			occur[index] = YES_OCCUR;
			/* 03-09-10 ch3: added code to make a copy of the
			 *               expression as the new expression with
			 *               substitutes is built for the multiple
			 *               occurrence routine; also reset the used
			 *               counter, which will be used when the
			 *               substituted expressions are put back in
			 *               when the expression is built
			 */
			if (SeCompList[index].copy == NULL)
			{
				SeCompList[index].copy
					= SeExpCopy(expr->o.rhsp);
				SeCompList[index].used = 0;
				if (SeDebugging & SEDBG_TSTEXPR)
					ErPLog("SeMultOccTest(%d): EXPR-"
						"SeCompList[%d]=%p,%d,%s (%p)"
						"\n", level, index,
						expr->o.rhsp,
						expr->o.rhsp->type,
						expr->o.rhsp->core.text,
						SeCompList[index].copy);
			}
			return YES_OCCUR;
		}
		else
		{
			if (SeDebugging & SEDBG_TSTEXPR)
				ErPLog("SeMultOccTest(%d): EXPR: %p=%d,%s\n",
					level, expr, expr->type,
					expr->core.text);

			/* just go down to the next level */
			return SeMultOccTest(expr->o.rhsp, occur, sysoccur,
				qualifier, level + 1);
		}

	/* 05-02-14 ch3: added debug messages for unacceptible node types */
	case SeNT_MULTOCC:
		if (SeDebugging & SEDBG_BADTYPE)
			ErPLog("SeMultOccTest(%d): Found MULT-OCC: %d\n", level,
				expr->type);
		/*+++ MAY WANT TO PROCEED INTO EXPRESSION TO MARK MULTOCC */
		/*+++ WILL NEED TO IMPLEMENT ALL OF THE OTHER NODE TYPES */
		return NO_OCCUR;  /* expression is unacceptible */
	case SeNT_TMPEXPR:
		/* 05-04-14 ch3: added code to include tmp-nodes */
		index = expr->c.index;
		if (SeNumComponents + index >= SeNumLeafNodes)
		{
			if (SeDebugging)
				ErLog("(%d) Found Tmp %d (%p):%d\n", level,
					expr->type, expr, expr->c.index);
			if (SeDebugging & SEDBG_BADTYPE)
				ErPLog("SeMultOccTest(%d): Found TMP-EXPR: %d"
					"\n", level, expr->type);
			ErSet(SeSTCORRUPT);
			return NO_OCCUR;
		}

		if (SeDebugging & SEDBG_TSTEXPR)
			ErPLog("SeMultOccTest(%d): TMP-EXPR: %p=%d,%s"
				"\n", level, expr, expr->type, expr->core.text);

		/* set flag that component has occurred */
		occur[SeNumComponents + index] = YES_OCCUR;
		return YES_OCCUR;

	default:
		if (SeDebugging & SEDBG_BADTYPE)
			ErPLog("SeMultOccTest(%d): unacceptible type: %d\n",
				level, expr->type);
		return NO_OCCUR;  /* expression is unacceptible */
	}
}  /* SeMultOccTest() */


/*
	SeSubstituteExpressions(SeSysDef *expr, char *qualifier,
		OCCUR *occur, OCCUR *sysoccur, int level)

	This function will create a new expression from the expression
	argument, as this function descends each node of the expression,
	each node will be copied to the new expression or will be
	substituted with a temporary expression node if the expression
	does not contain multiple occurrences or the left or right side
	contains a system with multiple occurrences that are not multiple
	occurrent elsewhere in the top-level expression.

	The purpose of this substitution is to simplify the expression
	that will be processed by SeFixMultOcc().  This function will
	recusively descend the tree ending on a branch when a
	non-multiple occurrent expression is substituted with a
	temporary expression node.  The expression was already found to
	be valid for fixing (ANDs and ORs only) and does contain a
	multiple occurrence.

	If the expression is an AND or OR operator node type, this
	function will substitute the left side and/or right side and/or
	the expression node itself with temporary expression nodes by
	calling SeTemporaryExpresion() if they do not contain multiple
	occurrent components or systems, or contain a system with
	multiple occurrences not found elsewhere in the top-level
	expression tree.  If the left and/or right side contains
	multiple occurrent components or systems, then each side is
	substituted by calling this function recursively.
	
	If the expression is a component or qualified component, the
	expression node is copied.  If there is a qualfier, the index is
	adjusted to the index of the equivalent qualifier component.

	If the expression is a system or qualified system, the
	expression of the system is substituted by calling this function
	recursively.

	If the expression is a qualified operator, the qualifier is
	obtained from the node and the expression of the node is
	substituted by calling this function recursively passing down
	the qualifier to the next level.

	If the expression is an expression, then the expression
	is substituted by calling this function recursively.

	This function is for internal Se package use only.

	RETURN: a newly substituted expression pointer (copy or temporary node)
		or NULL if an error occurred
 */

/* 01-12-06 ch3: replaced SeSubstituteSystems() */
/* 05-04-11 ch3: replaced logic for decided when to replace with temp nodes */
SeSysDef *
SeSubstituteExpressions PARAMS((
	SeSysDef *expr,		/* pointer to the expression tree pointer */
	char *qualifier,	/* pointer to qualifier string */
	OCCUR *occur,		/* pointer to multiple occurrence components */
	OCCUR *sysoccur,	/* pointer to multiple occurrence systems */
	int level))		/* call level of function - for testing only */
{
	SeSysDef *newexpr;	/* pointer to new expr node (03-09-10 ch3) */
	SeSysDef *tmpexpr;	/* pointer to a temporary expression tree */
	int index;		/* loop index variable */
	OCCUR *loccur;		/* pointer to left side occurrence comps */
	OCCUR *roccur;		/* pointer to right side occurrence comps */
	OCCUR *lsysoccur;	/* pointer to left side occurrence systems */
	OCCUR *rsysoccur;	/* pointer to right side occurrence systems */
	MuvesBool multocc;		/* mult occ between left/right flag */
	MuvesBool left;		/* left side has multocc/continue down flag */
	MuvesBool right;		/* right side has multocc/continue down flag */
	int lsysindx;		/* left side system index */
	int rsysindx;		/* right side system index */
	SeOccurEnum lmultocc = NO_OCCUR;  /* left side mult occurrence flag */
	SeOccurEnum rmultocc = NO_OCCUR;  /* right side mult occurrence flag */
	MuvesBool flag;		/* flag for debug output */

	if (SeDebugging & SEDBG_SUBOCCUR)
	{
		ErPLog("SeSubstituteExpressions: occur[]\n");
		for (index = 0; index < SeNumComponents; index++)
			ErLog("%d", occur[index]);
		ErLog("\n");
		ErPLog("SeSubstituteExpressions: sysoccur[]\n");
		for (index = 0; index < SeNumSystems; index++)
			ErLog("%d", sysoccur[index]);
		ErLog("\n");
	}
	switch (expr->type)
	{
	case SeNT_AND:
	case SeNT_OR:
		if (SeDebugging & SEDBG_SUBEXPR)
			ErPLog("SeSubstituteExpressions(%d): AND/OR: %p=%d,%s"
				"\n", level, expr, expr->type, expr->core.text);

		left = right = mTrue;
		lsysindx = rsysindx = -1;
		/* check for a system on each side */
		if (expr->o.lhsp->type == SeNT_SYSNAME
			|| expr->o.lhsp->type == SeNT_QUALSYS)
		{
			/* there is a system on the left side,
			 * get the index of the system, */
			lsysindx = expr->o.lhsp->c.index;

			if (SeDebugging & SEDBG_SUBEXPR)
				ErPLog("SeSubstituteExpressions: Lsys:%d,%s:%d"
					"\n", lsysindx, expr->o.lhsp->core.text,
					SeSysSubInfo[lsysindx]);

			if (SeSysSubInfo[lsysindx] == TEMP_SUBINFO)
			{
				/* system is being replaced with temp-node;
				 * therefore, don't continue into system */
				left = mFalse;
			}
			else if (SeSysSubInfo[lsysindx] == CANT_SUBINFO)
			{
				/* system can't be substituted;
				 * therefore, no need for index */
				lsysindx = -1;
			}
		}
		if (expr->o.rhsp->type == SeNT_SYSNAME
			|| expr->o.rhsp->type == SeNT_QUALSYS)
		{
			/* there is a system on the right side,
			 * get the index of the system, */
			rsysindx = expr->o.rhsp->c.index;

			if (SeDebugging & SEDBG_SUBEXPR)
				ErPLog("SeSubstituteExpressions: Rsys:%d,%s:%d"
					"\n", rsysindx, expr->o.rhsp->core.text,
					SeSysSubInfo[rsysindx]);

			if (SeSysSubInfo[rsysindx] == TEMP_SUBINFO)
			{
				/* system is being replaced with temp-node;
				 * therefore, don't continue into system */
				right = mFalse;
			}
			else if (SeSysSubInfo[rsysindx] == CANT_SUBINFO)
			{
				/* system can't be substituted;
				 * therefore, no need for index */
				rsysindx = -1;
			}
		}
		if (left || right)
		{
			/* look down each side of expression */

			/* allocate left and right side occurrence arrays */
			loccur = (OCCUR *)DmCalloc(SeNumComponents,
				sizeof(OCCUR));
			roccur = (OCCUR *)DmCalloc(SeNumComponents,
				sizeof(OCCUR));
			lsysoccur = (OCCUR *)DmCalloc(SeNumSystems,
				sizeof(OCCUR));
			rsysoccur = (OCCUR *)DmCalloc(SeNumSystems,
				sizeof(OCCUR));

			/* get occurrences for left and right side expressions
			 * (don't care about the return values); the system
			 * information array needs to be reset before each call
			 */
			memset(SeSysInfo, NONE_SYSINFO, SeNumSystems);
			lmultocc = SeMultOccTest(expr->o.lhsp, loccur,
				lsysoccur, qualifier, level);
			memset(SeSysInfo, NONE_SYSINFO, SeNumSystems);
			rmultocc = SeMultOccTest(expr->o.rhsp, roccur,
				rsysoccur, qualifier, level);

			if (SeDebugging & SEDBG_OCCUR)
			{
				ErPLog("SeSubstituteExpressions: loccur[]\n");
				for (index = 0; index < SeNumComponents;
						index++)
					ErLog("%d", loccur[index]);
				ErLog("\n");
				ErPLog("SeSubstituteExpressions: roccur[]\n");
				for (index = 0; index < SeNumComponents;
						index++)
					ErLog("%d", roccur[index]);
				ErLog("\n");
				ErPLog("SeSubstituteExpressions: lsysoccur[]"
					"\n");
				for (index = 0; index < SeNumSystems; index++)
					ErLog("%d", lsysoccur[index]);
				ErLog("\n");
				ErPLog("SeSubstituteExpressions: rsysoccur[]"
					"\n");
				for (index = 0; index < SeNumSystems; index++)
					ErLog("%d", rsysoccur[index]);
				ErLog("\n");
			}
			/* check if there are multiple occurrence components
			 * on the left and right side and set the left and right
			 * flags if the components are found */
			left = right = mFalse;
			for (index = 0; index < SeNumComponents; index++)
			{
				if (occur[index] == MULT_OCCUR
					&& loccur[index] != NO_OCCUR)
				{
					/* a multiple occurrent component is on
					 * left side
					 */
					if (SeDebugging & SEDBG_SUBEXPR)
						ErLog(" L%d", index);
					left = mTrue;
				}
				if (occur[index] == MULT_OCCUR
					&& roccur[index] != NO_OCCUR)
				{
					/* a multiple occurrent component is on
					 * right side
					 */
					if (SeDebugging & SEDBG_SUBEXPR)
						ErLog(" R%d", index);
					right = mTrue;
				}
			}
			if ((SeDebugging & SEDBG_SUBEXPR) && (left || right))
				ErLog("\n");

			if (SeDebugging & SEDBG_SUBEXPR)
				ErPLog("SeSubstituteExpressions(%d): L=%d R=%d "
					"moL=%d moR=%d\n", level, left, right,
					lmultocc, rmultocc);

			/* check if there are multiple occurrence systems
			 * on the left and right side and set the left and right
			 * flags if the systems are found
			 *
			 * the left of right system will be ignored because
			 * if these are the only multiple occurrence, the
			 * systems will be replaced with a temporary (which
			 * will become the multiple occurrence) */
			if (lsysindx != -1)
			{
				/* 05-04-23 ch3: changed from YES_OCCUR */
				lsysoccur[lsysindx] = NO_OCCUR;
			}
			if (rsysindx != -1)
			{
				/* 05-04-23 ch3: changed from YES_OCCUR */
				rsysoccur[rsysindx] = NO_OCCUR;
			}
			flag = mFalse;  /* for debugging output */
			for (index = 0; index < SeNumSystems; index++)
			{
				if (sysoccur[index] == MULT_OCCUR
					&& lsysoccur[index] != NO_OCCUR)
				{
					/* a multiple occurrent system is on
					 * left side */
					if (SeDebugging & SEDBG_SUBEXPR)
						ErLog(" l%d", index);
					left = mTrue;
					flag = mTrue;
				}
				if (sysoccur[index] == MULT_OCCUR
					&& rsysoccur[index] != NO_OCCUR)
				{
					/* a multiple occurrent system is on
					 * right side */
					if (SeDebugging & SEDBG_SUBEXPR)
						ErLog(" r%d", index);
					right = mTrue;
					flag = mTrue;
				}
			}
			if ((SeDebugging & SEDBG_SUBEXPR) && flag)
				ErLog("\n");

			/* deallocate arrays */
			DmFree((genptr_t)loccur);
			DmFree((genptr_t)roccur);
			DmFree((genptr_t)lsysoccur);
			DmFree((genptr_t)rsysoccur);

			if (SeDebugging & SEDBG_SUBEXPR)
				ErPLog("SeSubstituteExpressions(%d): L=%d R=%d "
					"Lsys=%d Rsys=%d\n", level, left, right,
					lsysindx, rsysindx);

			/* check if no multiple occurrent components or systems
			 * on either side and any left or right system is not a
			 * multiple occurrent system */
			if (!left && !right
				&& (lsysindx == -1
				|| sysoccur[lsysindx] != MULT_OCCUR)
				&& (rsysindx == -1
				|| sysoccur[rsysindx] != MULT_OCCUR))
			{
				/* replace whole expression with temp node */
				return SeTemporaryExpression(expr, level + 1);
			}

		}
		if (lsysindx != -1 && lsysindx == rsysindx)
		{
			/* have an expression of SYS & SYS or SYS | SYS, which
			 * is equivalent to just SYS, therefore replace entire
			 * node with result for this system, thus eliminating
			 * the & or | node */
			if (left)
			{
				if (lsysindx != -1)
				{
					SeSysSubInfo[lsysindx] = CANT_SUBINFO;
				}
				return SeSubstituteExpressions(expr->o.lhsp,
					qualifier, occur, sysoccur, level + 1);
			}
			else  /* replace node with temporary expression node */
			{
				if (lsysindx != -1)
				{
					SeSysSubInfo[lsysindx] = TEMP_SUBINFO;
				}
				return SeTemporaryExpression(expr->o.lhsp,
					level + 1);
			}
		}

		/* create new expression node for AND/OR node */
		newexpr = (SeSysDef *)DmXalloc(SeSysDef);
		*newexpr = *expr;
		newexpr->core.text = DmStrDup(expr->core.text);

		if (left && lmultocc != NO_OCCUR)
		{
			/* continue down left expression */
			if (lsysindx != -1)
			{
				SeSysSubInfo[lsysindx] = CANT_SUBINFO;
			}
			newexpr->o.lhsp = SeSubstituteExpressions(expr->o.lhsp,
				qualifier, occur, sysoccur, level + 1);
		}
		else  /* replace expression with temporary expression node */
		{
			if (left)
			{
				/*+++ WILL NOT OCCUR UNTIL TEST ROUTINE MODIFIED
				 *    TO LOOK FOR MULTIPLE OCCURRENCES IN
				 *    UNACCEPTABLE EXPRESSIONS */
				ErPLog("SeFixMultOcc: left expression cannot "
					"be processed correctly!\n");
				/* just substitute with temporary node */
			}
			if (lsysindx != -1)
			{
				SeSysSubInfo[lsysindx] = TEMP_SUBINFO;
			}
			newexpr->o.lhsp = SeTemporaryExpression(expr->o.lhsp,
				level + 1);
		}

		if (right && rmultocc != NO_OCCUR)
		{
			/* continue down right expression */
			if (rsysindx != -1)
			{
				SeSysSubInfo[rsysindx] = CANT_SUBINFO;
			}
			newexpr->o.rhsp = SeSubstituteExpressions(expr->o.rhsp,
				qualifier, occur, sysoccur, level + 1);
		}
		else  /* replace expression with temporary expression node */
		{
			if (right)
			{
				/*+++ WILL NOT OCCUR UNTIL TEST ROUTINE MODIFIED
				 *    TO LOOK FOR MULTIPLE OCCURRENCES IN
				 *    UNACCEPTABLE EXPRESSIONS */
				ErPLog("SeFixMultOcc: right expression cannot "
					"be processed correctly!\n");
				/* just substitute with temporary node */
			}
			if (rsysindx != -1)
			{
				SeSysSubInfo[rsysindx] = TEMP_SUBINFO;
			}
			newexpr->o.rhsp = SeTemporaryExpression(expr->o.rhsp,
				level + 1);
		}

		/* no substitution for this expression, just return argument */
		if (SeDebugging & SEDBG_SUBEXPR)
			ErPLog("SeSubstituteExpressions(%d): AND/OR: return(%p,"
				"%d-%p,%d-%p)\n", level, newexpr, left,
				newexpr->o.lhsp, right, newexpr->o.rhsp);
		return newexpr;

	case SeNT_COMPNAME:
	case SeNT_QUALCOMP:
		if (SeDebugging & SEDBG_SUBEXPR)
			ErPLog("SeSubstituteExpressions(%d): COMP: %p=%d,%s"
				"\n", level, expr, expr->type, expr->core.text);

		/* 03-09-11 ch3: create a node in the new substituted expression
		 *               for the component node (the original component
		 *               node will be freed after the substitution is
		 *               complete
		 */
		/* create a new node for the component node */
		newexpr = SeExpCopy(expr);

		/* need to handle qualified expressions */
		if (qualifier != NULL)
		{
			const char *basename = SePrsBaseName(expr->c.index);
			const char *qualname = SeGetQualName(basename,
				qualifier);
			int index = NmIndex(qualname, &SeComponents, mFalse);

			/* the following can safely be done because we */
			/* are in the process of substituting any qualified */
			/* expressions */
			newexpr->c.index = index;
		}
		/* no substitution for this expression, just return argument */
		if (SeDebugging & SEDBG_SUBEXPR)
			ErPLog("SeSubstituteExpressions(%d): COMP: return(%p)"
				"\n", level, newexpr);
		return newexpr;

	case SeNT_SYSNAME:
	case SeNT_QUALSYS:
		/* substitute system expression for system */
		/* system index has already been validated */
		if (SeDebugging & SEDBG_SUBEXPR)
			ErPLog("SeSubstituteExpressions(%d): SYS: %p=%d,%s (%p)"
				"\n", level, expr, expr->type, expr->core.text,
				SeDataSystem[expr->c.index]->sysdef);

		/* if we see a system here, then the system was found to */
		/* have multiple occurrence components, otherwise the node */
		/* would have been replaced in the AND/OR case above */

		/* 03-09-11 ch3: removed the code the made a copy of the
		 *               system's expression before descending down into
		 *               the expression, this caused a problem where the
		 *               code could not detect the same expression
		 *               because the pointer to each copy was different
		 *               (a copy of the expression will be made later)
		 */
		newexpr = SeSubstituteExpressions(SeDataSystem[expr->c.index]
			->sysdef, qualifier, occur, sysoccur, level + 1);
		if (SeDebugging & SEDBG_SUBEXPR)
			ErPLog("SeSubstituteExpressions(%d): SYS: return(%p)"
				"\n", level, newexpr);
		return newexpr;


	case SeNT_QUALOP:
		/* if we see this node type here, then it was found to */
		/* have multiple occurrence components, otherwise the node */
		/* would have been replaced in the AND/OR case above */
		if (SeDebugging & SEDBG_SUBEXPR)
			ErPLog("SeSubstituteExpressions(%d): QUALOP: %p=%d,%s"
				"\n", level, expr, expr->type, expr->core.text);

		/* qualified expression, first get the qualifier */
		qualifier = expr->o.rhsp->core.text;

		/* 03-09-11 ch3: removed the code the made a copy of the
		 *               expression before descending down into the
		 *               expression, this caused a problem where the
		 *               code could not detect the same expression
		 *               because the pointer to each copy was different
		 *               (a copy of the expression will be made later)
		 */
		/* now continue descending down expression */
		newexpr = SeSubstituteExpressions(expr->o.lhsp, qualifier,
			occur, sysoccur, level + 1);
		if (SeDebugging & SEDBG_SUBEXPR)
			ErPLog("SeSubstituteExpressions(%d): QUALOP: return(%p)"
				"\n", level, newexpr);
		return newexpr;

	case SeNT_EXPR:
		/* if we see this node type here, then it was found to */
		/* have multiple occurrence components, otherwise the node */
		/* would have been replaced in the AND/OR case above */
		if (SeDebugging & SEDBG_SUBEXPR)
			ErPLog("SeSubstituteExpressions(%d): EXPR: %p=%d,%s"
				"\n", level, expr, expr->type, expr->core.text);

		/* 03-09-11 ch3: removed the special code that checked for a
		 *               qualified component, this will be handled at
		 *               the next level
		 *               (a copy of the expression will be made later)
		 */
		/* continue descending down expression */
		newexpr = SeSubstituteExpressions(expr->o.rhsp, qualifier,
			occur, sysoccur, level + 1);
		if (SeDebugging & SEDBG_SUBEXPR)
			ErPLog("SeSubstituteExpressions(%d): EXPR: return(%p)"
				"\n", level, newexpr);
		return newexpr;

	default:  /* this is a fatal error */
		if (SeDebugging)
			ErPLog("%s: expression tree type (%d) unexpected.\n"
				"SeSubstituteSystems: BUG", expr->type);
		ErSet(SeSTCORRUPT);
		return NULL;
	}
}  /* SeSubstituteExpressions() */


/*
	SeTemporaryExpression(SeSysDef *expr, int level)

	This function will create a temporary expression node or type
	SeNT_TMPEXPR for an expression that was found to not contain any
	components or systems that are multiple occurrent or is a system
	that contains multiple occurrences not found elsewhere in the
	top-level expression tree.  The pointer to the original
	expression node will be saved in the temporary expression array,
	If the expression pointer is already in the array, the same
	index will be used for the temporary expression node.

	The purpose of the temporary expression nodes is to simplify the
	expression tree because the temporary expression node will be
	treated as a single entity (i.e. component) by SeFixMultOcc().
	The original expression will be put back when the final
	expression is built.

	If the expression is a component or qualified component, the
	node is simply copied and returned (it is not necessary to
	create a temporary expresion node since a component node is
	already a single node).

	If the expression is an expression that only contains a
	qualifier componenet node, the component node is copied and
	returned similar to a component node above.  This will eliminate
	the extra expression node from the tree.

	Otherwise, the pointer of the expression is searched for in the
	temporary expression nodes already created.  A new temporary
	expresion node is created.  If the expression was found, the
	same temporary expression index is used for the new node.
	Otherwise, the expression is added to the temporary expression
	list with new temporary expression index.  If the expresion is a
	system or qualified system, the expression node of the system is
	copied.  If the expression is a qualified operator, the
	expression of the qualified operator is copied (this eliminates
	the extra qualified operator expression node, which is ok since
	the qualifier was passed down to levels below).  For other types
	of expressions, the entire expression is copied.  A pointer to
	the original expression is saved so that if the expression
	occurs elsewhere in the expression tree, the same temporary
	expression index can be used (which is required if the fix
	multiple occurrence is to work properly).

	This function is for internal Se package use only.

	RETURN: a pointer to the temporary expression node
		or copied component node
 */

/* 05-03-19 ch3: corrected code to remove EXPR-compname nodes */
SeSysDef *
SeTemporaryExpression PARAMS((
	SeSysDef *expr,		/* pointer to the expression tree pointer */
	int level))		/* call level of function - for testing only */
{
	register int index;	/* loop index variable */
	SeSysDef *tmpexpr;	/* pointer to temporary expression node */
	SeSysDef *copyexpr = NULL;  /* pointer to expr to copy (03-09-11 ch3) */

	if (SeDebugging & SEDBG_TMPEXPR)
		ErPLog("SeTemporaryExpression(%d): %p=%d,%s\n", level, expr,
			expr->type, expr->core.text);

	/* check if node is a component or expression node */
	/* 05-02-19 ch3: added component name check for expression node types */
	/* 05-03-19 ch3: moved expression node check to below */
	/* only expression nodes that contain a component should be copied, */
	/* regular expression nodes are processed by SeSubstituteExpression() */
	if (expr->type == SeNT_COMPNAME || expr->type == SeNT_QUALCOMP)
	{
		/* 03-09-10 ch3: added code to copy the node since the original
		 *               expression will be freed once the substituted
		 *               expression is built
		 */
		/* just copy, not necessary to replace with temporary node */
		copyexpr = SeExpCopy(expr);
		if (SeDebugging & SEDBG_TMPEXPR)
			/* 05-02-18 ch3: added missing level, added pointer */
			ErPLog("SeTemporaryExpression(%d): NOTMP,%p\n", level,
				copyexpr);
		return copyexpr;
	}
	/* 05-03-19 ch3: moved component name check for expression node types */
	if (expr->type == SeNT_EXPR && expr->o.rhsp->type == SeNT_COMPNAME)
	{
		/* just copy the component sub node (don't need expression
		 * node), not necessary to replace with temporary node */
		copyexpr = SeExpCopy(expr->o.rhsp);
		if (SeDebugging & SEDBG_TMPEXPR)
			ErPLog("SeTemporaryExpression(%d): NOTMPe,%p\n", level,
				copyexpr);
		return copyexpr;
	}

	/* see if this expression was already replaced */
	/* 03-09-10 ch3: if expression node contains a system, then must
	 *               compare index of system since the expression node
	 *               will be different for different nodes with the same
	 *               system; the same goes for qualified operators, must
	 *               compare the expression pointer of the operator;
	 *               these changes are necessary so that the multiple
	 *               occurrence fixing code will properly handle multiple
	 *               occurrences of entire substitured expressions from
	 *               systems and qualifier operators
	 */
	for (index = 0; index < SeNumTmpExprs; index++)
	{
		switch (SeTmpExpr[index].node->type)
		{
		case SeNT_SYSNAME:
		case SeNT_QUALSYS:
			/* for systems, compare system index */
			if (expr->c.index != SeTmpExpr[index].node->c.index)
				continue;
			break;
		case SeNT_QUALOP:
			/* for qualifier op, compare op expression pointers */
			if (expr->o.lhsp != SeTmpExpr[index].node->o.lhsp)
				continue;
			break;
		default:
			/* otherwise, compare expression pointers */
			if (expr != SeTmpExpr[index].node)
				continue;
			break;
		}
		/* if we get here, then we have a match, so exit loop */
		break;
	}
	/* index will be index of temporary expression within array */
	/* if (index == SeNumTmpExprs) then not found in array */

	/* create temporary expression node */
	tmpexpr = (SeSysDef *)DmXalloc(SeSysDef);
	tmpexpr->type = SeNT_TMPEXPR;
	tmpexpr->core.text = NULL;  /* not used */
	tmpexpr->c.index = index;

	if (index == SeNumTmpExprs)  /* not found in array? */
	{
		/* 03-09-11 ch3: changed the type of the SeTmpExpr[] array,
		 *               which now includes a pointer to the original
		 *               expression (so that comparisons work in
		 *               detecting the same expression), a pointer to
		 *               the copied expression (which will be used when
		 *               the final expression is built) and a used
		 *               counter that contains a counter of how many
		 *               times the new expression uses the copied
		 *               expression (the first time will use the copy
		 *               made here, subsequent uses will make an
		 *               additional copy)
		 */
		/* add current expression pointer to array */
		if (SeNumTmpExprs >= SeTmpExprSize)
		{
			/* first need to expand temporary expression array */
			SeTmpExprSize += ARRAY_SIZE;
			SeTmpExpr = (SeTmpExprInfo *)DmRealloc(SeTmpExpr,
				SeTmpExprSize * sizeof(SeTmpExprInfo));
		}
		SeTmpExpr[SeNumTmpExprs].node = expr;
		/* need to copy expression because the original expression */
		/* or node will be freed once SeSubstituteExpressions() */
		/* has completed */
		switch (expr->type)
		{
		case SeNT_SYSNAME:
		case SeNT_QUALSYS:
			/* 05-04-23 ch3: don't need to copy entire expression */
			copyexpr = expr;/*SeDataSystem[expr->c.index]->sysdef*/
			if (SeDebugging & SEDBG_TMPEXPR)
				ErPLog("SeTemporaryExpression(%d): SYS:%d-%p\n",
					level, expr->c.index, copyexpr);
			break;
		case SeNT_QUALOP:
			copyexpr = expr->o.lhsp;
			if (SeDebugging & SEDBG_TMPEXPR)
				ErPLog("SeTemporaryExpression(%d): QUALOP:%p\n",
					level, copyexpr);
			break;
		default:
			copyexpr = expr;
			if (SeDebugging & SEDBG_TMPEXPR)
				ErPLog("SeTemporaryExpression(%d): expr:%p\n",
					level, copyexpr);
			break;
		}
		SeTmpExpr[SeNumTmpExprs].used = 0;
		copyexpr = SeExpCopy(copyexpr);
		SeTmpExpr[SeNumTmpExprs++].copy = copyexpr;
	}

	if (SeDebugging & SEDBG_TMPEXPR)
		ErPLog("SeTemporaryExpression(%d): TMP %p=%d/%d (%p)\n",
			level, tmpexpr, index, SeNumTmpExprs, copyexpr);

	return tmpexpr;

}  /* SeTemporaryExpression() */


/*
	SeFixMultOccur(SeSysDef *expr)

	This function will fix an expression of AND operators, OR
	operators, components and temporary expression nodes that
	contain multiple occurrences of components and temporary
	expression nodes and fixes the expression so that it will
	produce the correct result when evaluated.

	The multiple occurrent components and temporary expression nodes
	are first identified by calling SeMultOccTest() for the
	substutited expression, which sets the occurrence values for the
	components and temporary expression nodes.  The system
	occurrence array needs to be passed, but the substituted
	expression will not have any systems, so this array will contain
	no information and is deallocated.

	A new linked list is created and the OR/AND table linked list is
	created for the expression tree by calling SeProcessNode().  The
	entries in the linked list are reduced and the linked list is
	converted into an array by calling SeMakeOrAndArray(), which
	also identifies the OR/AND table entries that contain multiple
	occurrences.
	
	The sorted summation table is created from the multiple
	occurrent entries in the OR/AND table array by calling
	SeBuildSortedSumTable().

	The new expression tree is created from the sorted summation
	table and the entries in the OR/AND table array that do not
	contain multiple occurrences by calling SeBuildNewExprTree().

	Before returned, the memory used by the original expression
	tree, component occurrence array, OR/AND table array and
	entries, the sorted summation table and the expansion bit
	mapping array is released.

	This function is for internal Se package use only.

	RETURN: pointer to the new expression
		NULL if an error occurred
 */

/* 05-04-08 ch3: added code to reduce OR/AND entries and make OR/AND array */
/* 05-04-14 ch3: added call to test substituted expr for mult occs */
SeSysDef *
SeFixMultOccur PARAMS((
	SeSysDef *expr))		/* expression to fix */
{
	OCCUR *occur;			/* component/tmp-node occured flags */
	OCCUR *sysoccur;		/* system occured flags */
	DqNode *or_and_tbl;		/* pointer to linked list master node */
	unsigned **or_and_array;	/* pointer to OR/AND table array */
	int or_and_size;		/* size of OR/AND table array */
	int or_and_count;		/* multocc entry count in array */
	SeSumTbl sorted_sum_tbl;	/* sorted summation table */
	SeOrAndNode *entry;		/* work pointer to an OR/AND entry */
	SeSysDef *newexpr;		/* pointer to new corrected expr */
	int index;			/* loop index variable */
	unsigned *bitarr;		/* pointer to a bit array (DEBUG) */
	int bit;			/* bit loop index variable (DEBUG) */

	/*==============*/
	/*  INITIALIZE  */
	/*==============*/

	/* calculate the number of bytes for the bit arrays */
	/* 01-08-28 ch3: corrected size of bit array calculation */
	/* 01-12-06 ch3: added SeNumTmpExprs to calculation */
	/* 05-04-15 ch3: added SeNumLeafNodes */
	SeNumLeafNodes = SeNumComponents + SeNumTmpExprs;
	SeBitArrSize = (SeNumLeafNodes - 1) / BITARR_ELEM_SIZE + 1;
	if (SeDebugging & SEDBG_STSMSGS)
		ErLog("SeNumComponents=%d SeNumTmpExprs=%d SeBitArrSize=%d\n",
			SeNumComponents, SeNumTmpExprs, SeBitArrSize);
	or_and_array = NULL;
	sorted_sum_tbl.arrayp = NULL;
	newexpr = NULL;
	/* 05-04-14 ch3: setup occur for substituted expression to process */
	occur = (OCCUR *)DmCalloc(SeNumLeafNodes, sizeof(OCCUR));
	sysoccur = (OCCUR *)DmCalloc(SeNumSystems, sizeof(OCCUR));
	SeMultOccTest(expr, occur, sysoccur, NULL, 0);
	DmFree((genptr_t)sysoccur);  /* don't need this */
	if (SeDebugging & SEDBG_ALLOCCS)
	{
		SeOccurEnum ioccur;
		MuvesBool flag;
		int tmpindx;
		SeSysDef *expr;

		for (ioccur = YES_OCCUR; ioccur < SIZE_OCCUR; ioccur++)
		{
			flag = mFalse;
			for (index = 0; index < SeNumComponents; index++)
			{
				if (occur[index] == ioccur)
				{
					if (!flag)
					{
						ErPLog("SeFixMultOcc: comps,%d"
							"\n", ioccur);
						flag = mTrue;
					}
					ErLog(" %s:%d", NmName(index,
						&SeComponents), index);
				}
			}
			if (flag)
			{
				ErLog("\n");
			}
			flag = mFalse;
			for (; index < SeNumLeafNodes; index++)
			{
				if (occur[index] == ioccur)
				{
					if (!flag)
					{
						ErPLog("SeFindMultOcc: tmp-expr"
							",%d\n", ioccur);
						flag = mTrue;
					}
					tmpindx = index - SeNumComponents;
					expr = SeTmpExpr[tmpindx].copy;
					if (expr->type == SeNT_SYSNAME
						|| expr->type == SeNT_QUALSYS)
					{
						ErLog(" Tmp%d,%s:%d", tmpindx,
							NmName(expr->c.index,
							&SeSystems),
							expr->c.index);
					}
					else
					{
						ErLog(" Tmp%d,%p", tmpindx,
							expr);
					}
				}
			}
			if (flag)
			{
				ErLog("\n");
			}
		}
	}
	if (SeDebugging & SEDBG_ORANDTBL)
	{
		ErPLog("SeFixMultOccur: occur[]\n");
		for (index = 0; index < SeNumLeafNodes; index++)
			ErLog("%d", occur[index]);
		ErLog("\n");
	}

	/*==================================*/
	/*  BUILD OR/AND TABLE LINKED LIST  */
	/*==================================*/

	/* create OR/AND table and start processing at top expression node */
	or_and_tbl = DqOpen();
	assert(or_and_tbl != NULL);
	if (or_and_tbl == NULL)
	{
		goto cleanup;
	}
	/* 01-08-29 ch3: added level argument for debugging */
	if (!SeProcessNode(expr, or_and_tbl, 0))  /* table is empty to start */
	{
		goto cleanup;  /* allocation error */
	}
	if (SeDebugging & SEDBG_ORANDTBL)
	{
		ErPLog("OR/AND Table:\n");
		index = 0;
		DqEACH(or_and_tbl, entry, SeOrAndNode)
		{
			ErLog("%d:", index++);
			/* display indexes of components with bit on */
			/* 01-12-06 ch3: added SeNumTmpExprs */
			for (bit = 0; bit < SeNumLeafNodes; bit++)
			{
				if (SeGetBit(entry->bitarr, bit))
				{
					ErLog(" %d", bit);
					if (occur[bit] == MULT_OCCUR)
						ErLog("M");
				}
			}
			ErLog("\n");
		}
		ErPLog("End OR/AND Table.\n");  /* 01-08-29 ch3: added */
	}

	/*====================================*/
	/*  REDUCE ENTRIES, MAKE OR/AND ARRAY */
	/*====================================*/

	/* 05-04-08 ch3: added this section of code */
	if (SeDebugging & SEDBG_STSMSGS)
	{
		ErLog("Building OR/AND table array...\n");
	}
	if (!SeMakeOrAndArray(&or_and_array, &or_and_size, &or_and_count,
		or_and_tbl, occur))
	{
		goto cleanup;  /* error - too many OR/AND entries */
	}

	if (SeDebugging & SEDBG_ORANDTBL)
	{
		ErPLog("Reduced OR/AND Table Array (%d:%dx%d):\n", or_and_size,
			or_and_count, SeBitArrSize);
		for (index = 0; index < or_and_size; index++)
		{
			ErLog("%d:", index);
			/* display indexes of components with bit on */
			for (bit = 0; bit < SeNumBits; bit++)
			{
				if (SeGetBit(or_and_array[index], bit))
				{
					ErLog(" %d", bit);
					if (occur[SeExpandBitMap[bit]]
							== MULT_OCCUR)
						ErLog("M");
				}
			}
			ErLog("\n");
		}
		ErPLog("End Reduced OR/AND Table (%d).\n", index);
	}

	/*================================*/
	/*  BUILD SORTED SUMMATION TABLE  */
	/*================================*/

	/* build sorted summation tables */
	sorted_sum_tbl.arrayp = (unsigned **)DmCalloc(ARRAY_SIZE,
		sizeof(unsigned *));
	sorted_sum_tbl.max_size = ARRAY_SIZE;
	sorted_sum_tbl.size = 0;  /* index is empty */

	/* build entries in summation tables from OR/AND table */
	if (SeDebugging & SEDBG_STSMSGS)  /* 01-08-29 ch3: added */
		ErLog("Building summation table...\n");
	if (!SeBuildSortedSumTable(&sorted_sum_tbl, or_and_array, or_and_count))
	{
		goto cleanup;  /* allocation or index expansion error */
	}
	/* 05-02-18 ch3: changed debug flag constant */
	if (SeDebugging & SEDBG_SRTDTBL)
	{
		ErPLog("Sorted Sum Table:\n");
		for (index = 0; index < sorted_sum_tbl.size; index++)
		{
			ErLog("%d:", index);
			bitarr = sorted_sum_tbl.arrayp[index];
			/* 01-12-06 ch3: added SeNumTmpExprs */
			for (bit = 0; bit < SeNumBits; bit++)
				if (SeGetBit(bitarr, bit))
					ErLog(" %d", SeExpandBitMap[bit]);
			ErLog(" [%d]\n", SumSignFactor(bitarr));
		}
		ErPLog("End Sorted Sum Table.\n");  /* 01-08-29 ch3: added */
	}

	/*=============================*/
	/*  BUILD NEW EXPRESSION TREE  */
	/*=============================*/

	/* build new expression tree */
	if (SeDebugging & SEDBG_STSMSGS)  /* 01-12-06 ch3: added */
		ErLog("Building new expression...\n");
	newexpr = SeBuildNewExprTree(&sorted_sum_tbl, or_and_array, or_and_size,
		or_and_count);
	if (newexpr == NULL)
	{
		if (SeDebugging)  /* 01-12-06 ch3: added */
			ErLog("Error building new expression tree.\n");
		goto cleanup;
	}

	if (SeDebugging & SEDBG_PRTNEXPR)
	{
		SePrintExprTree(newexpr, 0, "New Expression",
			(SeDebugging & SEDBG_PRTSYS) != 0);
		ErPLog("End New Expression.\n");  /* 01-08-29 ch3: added */
	}
	/* 05-02-15 ch3: added call to validate original expression */
#if CHECK_EXPR
	SeCheckExprTree(newexpr, 0, "New Expression");
#endif

	/*============*/
	/*  CLEAN-UP  */
	/*============*/

	if (SeDebugging & SEDBG_STSMSGS)  /* 05-02-14 ch3: added message */
		ErLog("Cleaning up...\n");
	/* now we can deallocate current expression tree */
	SeExpFree(expr);

cleanup:
	/* remove summation table entries and indexes */
	if (or_and_array != NULL)
	{
		for (index = 0; index < or_and_size; index++)
		{
			DmFree((genptr_t)or_and_array[index]);
		}
		DmFree((genptr_t)or_and_array);
	}
	if (sorted_sum_tbl.arrayp != NULL)
	{
		for (index = 0; index < sorted_sum_tbl.size; index++)
		{
			DmFree((genptr_t)sorted_sum_tbl.arrayp[index]);
		}
		DmFree((genptr_t)sorted_sum_tbl.arrayp);
	}
	if (SeExpandBitMap != NULL)
	{
		DmFree((genptr_t)SeExpandBitMap);
		SeExpandBitMap = NULL;
	}
	DmFree((genptr_t)occur);

	if (newexpr != NULL)
	{
		/* 05-02-15 ch3: added call to validate original expression */
#if CHECK_EXPR
		SeCheckExprTree(newexpr, 0, "Return");
#endif
		/* 05-02-14 ch3: added message */
		if (SeDebugging & SEDBG_STSMSGS)
			ErLog("Done.\n");
	}
	return newexpr;

}  /* SeFixMultOccur() */


/*
	SeProcessNode(SeSysDef *expr, DqNode *table, int level)

	This function will process an expresion tree and convert it into
	an OR/AND table.  The OR/AND table is a different way to
	represent the expression tree as a series of AND expressions of
	components and temporary expression nodes (entries) that are
	ORed together.  An AND expression is stored in a bit array with
	each bit representing a component and temporary expression node.
	The number of components plus the number of temporary expression
	nodes (i.e.  the number of leaf nodes) is used to dynamically
	define the size of the bit arrays.  The OR/AND table represents
	the OR expression of AND expressions.
	
	The type of expression at each node will be determined and the
	appropriate action will be performed to process an OR node, AND
	node, a component node or temporary expression node.  The tree
	has already been verified, so no other types of nodes will be
	encountered.  This function will be called recursively at each
	OR and AND expression node for each side.

	To process an OR operator expresion node, the table will be
	cloned to a second table.  The first and second tables will each
	be passed to process each side of the OR operator respectively.
	The entries in the second table will be detached and added to
	the first table by calling SeAddOrAndTable().  Finally the now
	empty second table will be closed.

	To process an AND operator expression node, the table will be
	passed to both sides of the AND operator sequentially.  This
	will AND the expressions on both sides to the entries already in
	the table.

	To process a component or temporary expression node, if the
	table is empty, a new entry will be added with the bit for the
	component or temporary expression node set.  Otherwise, the bit
	for the component or temporary expression node will be set in
	each of the entries in the table.  This is the equivalent of
	anding each entry with the component or temporary expression
	node.

	This function is for internal Se package use only.

	RETURN: mTrue if successful
		mFalse if memory allocation error occurred
 */

/* 01-08-29 ch3: added level argument for debugging */
MuvesBool
SeProcessNode PARAMS((
	SeSysDef *expr,		/* pointer to expression tree */
	DqNode *table,		/* pointer to table of entries built so far */
	int level))		/* call level of node (for debugging only) */
{
	DqNode *table2;		/* pointer to second table master node */
	SeOrAndNode *entry;	/* work pointer to table entry */
	SeOrAndNode *entry2;	/* work pointer to second table entry */
	int index;		/* loop index variable */
	int bit;		/* bit loop index variable */
	int count;		/* count variable */
	int compindx;		/* 01-12-06 ch3: adjusted comp/system index */

	if (expr->type == SeNT_OR)
	{
		if (SeDebugging & SEDBG_ORANDND)
			/* 01-08-29 ch3: added level */
			ErPLog("Node(%d): OR,%s\n", level, expr->core.text);

		/* create second table and copy every entry from first table */
		table2 = DqOpen();
		assert(table2 != NULL);
		if (table2 == NULL)
			return mFalse;  /* allocation error */
		count = 0;  /* 01-09-05 ch3: added for debugging */
		DqEACH(table, entry, SeOrAndNode)
		{
			/* allocate a new entry */
			entry2 = (SeOrAndNode *)DmXalloc(SeOrAndNode);
			assert(entry2 != NULL);
			if (entry2 == NULL)
				return mFalse;  /* allocation error */

			/* allocate a new bit array and copy bits */
			entry2->bitarr = (unsigned*)DmCalloc(SeBitArrSize,
				sizeof(unsigned));
			assert(entry2->bitarr != NULL);
			if (entry2->bitarr == NULL)
				return mFalse;  /* allocation error */
			for (index = 0; index < SeBitArrSize; index++)
				entry2->bitarr[index] = entry->bitarr[index];

			/* now append it to second table */
			DqAppend(table2, &entry2->link);
			count++;  /* 01-09-05 ch3: added */
		}

		if (SeDebugging & SEDBG_ORNODE)  /* 01-09-05 ch3: added */
			ErPLog("OR:Table2 entries = %d\n", count);

		/* call left side with first table */
		/* 01-08-29 ch3: added level argument for debugging */
		if (!SeProcessNode(expr->o.lhsp, table, level + 1))
			return mFalse;  /* allocation error */

		/* call right side with second table */
		/* 01-08-29 ch3: added level argument for debugging */
		if (!SeProcessNode(expr->o.rhsp, table2, level + 1))
			return mFalse;  /* allocation error */

		/* add entries from second table to first table */
		/* remove bit arrays that were not used */
		/* remove entries from the second table */
		count = 0;  /* 01-09-05 ch3: added for debugging */
		while ((entry2 = DqTPop(table2, SeOrAndNode)) != NULL)
		{
			/* add entry to first table */
			if (!SeAddOrAndTable(table, entry2))
			{
				/* entry with bit array was not added */
				/* to first table, so deallocate them */

				/* deallocate bit array */
				DmFree((genptr_t)entry2->bitarr);

				/* deallocate entry */
				DmFree((genptr_t)entry2);
			}
			count++;  /* 01-09-05 ch3: added */
		}
		/* now close second table (must be empty) */
		DqClose(table2);

		if (SeDebugging & SEDBG_ORANDND)
			/* 01-09-05 ch3: added level */
			ErPLog("Node(%d): Done-OR (%d)\n", level, count);

		return mTrue;  /* exit now */
	}
	else if (expr->type == SeNT_AND)
	{
		if (SeDebugging & SEDBG_ORANDND)
			/* 01-08-29 ch3: added level */
			ErPLog("Node(%d): AND,%s\n", level, expr->core.text);

		/* pass table to each side of operator */
		/* 01-08-29 ch3: added level argument for debugging */
		if (!SeProcessNode(expr->o.lhsp, table, level + 1))
			return mFalse;  /* allocation error */
		if (!SeProcessNode(expr->o.rhsp, table, level + 1))
			return mFalse;  /* allocation error */

		if (SeDebugging & SEDBG_ORANDND)
			/* 01-08-29 ch3: added level */
			ErPLog("Node(%d): Done-AND\n", level);

		return mTrue;  /* exit now */
	}
	/* 03-09-11 ch3: removed code for processing an SeNT_EXPR node type,
	 *               the substitute routine completely removes this node
	 *               type so that it is not necessary to check for it here
	 */

	/* else must be component or a temporarility substituted node */
	/* 01-12-06 ch3: added compindx (to include temporary expr index) */
	compindx = expr->c.index;
	if (expr->type == SeNT_TMPEXPR)
		compindx += SeNumComponents;  /* adjust index */
	if (SeDebugging & SEDBG_ORANDND)
		/* 01-08-29 ch3: added level */
		ErPLog("Node(%d): %p:%d,COMP/TMP#%d:%s\n", level, expr,
				expr->type, compindx, expr->core.text);

	if (DqIsEmpty(table))
	{
		/* nothing in table, so add first entry */

		/* allocate a new entry */
		entry = (SeOrAndNode *)DmXalloc(SeOrAndNode);
		assert(entry != NULL);
		if (entry == NULL)
			return mFalse;  /* allocation error */

		/* allocate a new bit array and reset bits */
		entry->bitarr = (unsigned*)DmCalloc(SeBitArrSize,
			sizeof(unsigned));
		assert(entry->bitarr != NULL);
		if (entry->bitarr == NULL)
			return mFalse;  /* allocation error */
		for (index = 0; index < SeBitArrSize; index++)
			entry->bitarr[index] = 0;

		/* set bit for this component */
		/* 01-12-06 ch3: replaced expr->c.index with compindx */
		SeSetBit(entry->bitarr, compindx);

		if (SeDebugging & SEDBG_ORANDND)
			/* 01-08-29 ch3: added level */
			ErPLog("Node(%d): SYS/COMPi#%d:%s\n", level,
				compindx, expr->core.text);

		/* now append it to the empty master table node */
		DqAppend(table, &entry->link);

		index = -1;
	}
	else  /* scan table and AND in this component */
	{
		index = 0;
		DqEACH(table, entry, SeOrAndNode)
		{
			/* AND in current component (set component's bit) */
			/* 01-12-06 ch3: replaced expr->c.index with compindx */
			SeSetBit(entry->bitarr, compindx);

			index++;
		}

		/* 01-08-29 ch3: moved outside loop and added level */
		if (SeDebugging & SEDBG_ORANDND)
			ErPLog("Node(%d): SYS/COMPi#%d:%s\n", level,
				compindx, expr->core.text);
	}

	if (SeDebugging & SEDBG_ORANDND)
		/* 01-08-29 ch3: modified */
		ErPLog("Node(%d): Done-COMP [%d]\n", level, index);
	return mTrue;

}  /* SeProcessNode() */


/*
	SeAddOrAndTable(DqNode *table, SeOrAndNode *newentry)

	This function will add a new entry to the OR/AND table linked
	list and is called by SeProcessNode().  If the new entry is
	already in the table, no action will be performed.  Also, there
	is no reason to keep subset entries (entries the contain all of
	the compenents and/or temporary expression nodes of another
	entry) as they do not add anything to the overall expression.
	
	Therefore, if the new entry is a superset, determined by calling
	SeSetBitArray(), to an entry already in the table, no action
	will be performed.  If there are entries that a subsets to the
	new entry, these subset entries will be removed from the table.
	The new entry will be inserted into the table in order (by the
	value of the bit array).

	This function is for internal Se package use only.

	RETURN: mTrue if entry was added to the table
		mFalse if entry was not added to the table
 */

MuvesBool
SeAddOrAndTable PARAMS((
	DqNode *table,			/* pointer to table to add to */
	SeOrAndNode *newentry))		/* pointer to new entry to add */
{
	SeOrAndNode *insert;		/* location to insert to node */
	SeOrAndNode *entry;		/* work pointer to table entry */
	SeOrAndNode *next;		/* pointer to next table entry */
	int result;			/* result variable */

	if (SeDebugging & SEDBG_ORNODE)  /* 01-09-05 ch3: added */
	{
		int bit;

		ErLog("AddNode: %p(%p) ", newentry, newentry->bitarr);
		/* display indexes of components with bit on */
		/* 01-12-06 ch3: added SeNumTmpExprs */
		for (bit = 0; bit < SeNumLeafNodes; bit++)
			if (SeGetBit(newentry->bitarr, bit))
				ErLog(" %d", bit);
		ErLog("\n");
	}

	insert = NULL;
	entry = DqFirst(table, SeOrAndNode);
	while (entry != (SeOrAndNode *)table)
	{
		/* get next entry from current in case entry is removed */
		next = DqFirst(&entry->link, SeOrAndNode);

		/* compare new entry with current table entry */
		result = SeCmpBitArrays(newentry->bitarr, entry->bitarr);

		/* 01-09-05 ch3: added */
		if (SeDebugging & SEDBG_ORNODE)
		{
			int bit;

			ErLog("CmpResult:%d:", result);
			/* display indexes of components with bit on */
			/* 01-12-06 ch3: added SeNumTmpExprs */
			for (bit = 0; bit < SeNumLeafNodes; bit++)
				if (SeGetBit(entry->bitarr, bit))
					ErLog(" %d", bit);
			ErLog("\n");
		}

		if (result == 0)  /* same as? */
			return mFalse;  /* entry is already in table */
		if (result < 0 && insert == NULL)  /* less than? */
			/* mark this spot for possible insertion */
			/* (insert new node to the left of this one) */
			insert = entry;

		/* check new entry for superset/subset with current */
		result = SeSetBitArrays(newentry->bitarr, entry->bitarr);

		/* 01-09-05 ch3: added */
		if (SeDebugging & SEDBG_ORNODE)
			ErLog("SetResult:%d (%p)\n", result, insert);

		if (result == 1)  /* a superset? */
			return mFalse;  /* entry is not necessary */
		if (result == -1)  /* a subset? */
		{
			/* deallocate bit array */
			DmFree((genptr_t)entry->bitarr);

			/* need to remove subset entry from table */
			DqDetach(table, &entry->link);
			/* deallocate entry */
			DmFree((genptr_t)entry);
			/* (can still use entry pointer value) */

			/* if table is now empty (entry was only */
			/* entry in table), then reset insert */
			/* point and exit loop, we are done */
			if (DqIsEmpty(table))
			{
				insert = NULL;
				break;
			}

			/* if insert point was just removed, then */
			/* set insert point to next node in table */
			if (insert == entry)
			{
				insert = next;
				/* if entry was at end of table, then */
				/* insert point will be at end of table */
			}
		}
		entry = next;
	}

	/* now the new entry needs to be inserted into the table */
	if (insert == NULL)
		/* if an insertion point not found, */
		/* insert at end of table (to the left of the master node) */
		insert = (SeOrAndNode *)table;

	/* insert to the left of node */
	DqL_Insert(&newentry->link, &insert->link);

	return mTrue;  /* entry and bit array was used, prevent their removal */

}  /* SeAddOrAndTable() */


/*
	SeSetBitArrays(unsigned *bitarr1, unsigned *bitarr2)

	This function will check if the first bit array is a subset or a
	superset to the second bit array and is called by
	SeAddOrAndTable().  If the first bit array is a superset of the
	second bit array, then the second bit array will be a subset of
	the first bit array.  This function assumes that the bit arrays
	have already been compared and are not the same.

	This function is for internal Se package use only.

	RETURN: 0 if the bit arrays are not sets of each other
		-1 if the first bit array is subset of the second
		1 if the first bit array is superset the second
 */

int
SeSetBitArrays PARAMS((
	unsigned *bitarr1,	/* pointer to first bit array */
	unsigned *bitarr2))	/* pointer to second bit array */
{
	unsigned *work;		/* pointer to working bit array */
	int index;		/* loop index variable */
	MuvesBool allzeros;		/* flag indicating all zeros were found */

	/* allocate working bit array */
	work = (unsigned*)DmCalloc(SeBitArrSize, sizeof(unsigned));
	assert(work != NULL);

	/* check if bitarr1 is subset of bitarr2 */
	allzeros = mTrue;
	for (index = 0; index < SeBitArrSize; index++)
	{
		work[index] = bitarr1[index] & bitarr2[index];
		work[index] ^= bitarr1[index];
		if (work[index] != 0)
		{
			/* non-zero indicates not a subset */
			allzeros = mFalse;
			break;  /* don't continue */
		}
	}
	if (allzeros)
	{
		DmFree((genptr_t)work);
		return -1;  /* bitarr1 is a subset of bitarr2 */
	}

	/* check if bitarr2 is subset of bitarr1 */
	allzeros = mTrue;
	for (index = 0; index < SeBitArrSize; index++)
	{
		work[index] = bitarr2[index] & bitarr1[index];
		work[index] ^= bitarr2[index];
		if (work[index] != 0)
		{
			/* non-zero indicates not a subset */
			allzeros = mFalse;
			break;  /* don't continue */
		}
	}
	if (allzeros)
	{
		DmFree((genptr_t)work);
		return 1;  /* bitarr1 is a superset of bitarr2 */
	}

	DmFree((genptr_t)work);
	return 0;  /* the bit arrays are not sets of each other */

}  /* SeSetBitArrays() */


/*
	MuvesBool SeMakeOrAndArray(unsigned ***or_and_array,
		int *or_and_size, int *or_and_count, DqNode *or_and_tbl,
		OCCUR *occur)

	This function converts the OR/AND linked list into an OR/AND
	array needed to create the sorted summation table.  As the
	conversion is being processed, the bit array entries are reduced
	to take less memory (and thus speed processing when the sorted
	summation table is created).

	When the OR/AND table was built, each element needed to be
	allocated large enough for all components and temporary
	expression nodes because it was not known before hand which
	components would be found in the expression (all tmeporary nodes
	would be found because they were in the expression in the first
	place), it is likely that only a small percentage of the
	components in the target are actually in the expression,
	therefore the bit array entries are reduced.

	This will be accomplished by identifing all the components (and
	temporary nodes) by ORing all of the OR/AND table entries
	together and counting them.  This count will be used to
	calculate the size of the new reduced table entries.  Conversion
	arrays will be create so that the bit indexes of the new bit
	array entries can be converted back to the indexes (which are
	actually component indexes) of the old bit array entries.

	The linked list is read, and each bit array entry is reduced
	into a newly allocated reduced size bit array that is put into
	the array.  The memory used by the original bit array is
	released, the entry node is detached and deallocated.  Finally,
	the OR/AND linked list is closed and the global bit array size
	variable is set to the new reduced bit array size.

	RETURN: mTrue if successful
		mFalse if error (too many multiple occurrences)
*/

/* 05-04-14 ch3: new function added */
/* 05-05-04 ch3: added check for entries that are multocc within OR/AND table */
MuvesBool
SeMakeOrAndArray PARAMS((
	unsigned ***or_and_array,	/* pointer to OR/AND table array */
	int *or_and_size,		/* size of OR/AND table array */
	int *or_and_count,		/* multocc count in OR/AND array */
	DqNode *or_and_tbl,		/* pointer to OR/AND linked list */
	OCCUR *occur))			/* pointer to occurrence array */
{
	SeOrAndNode *entry;		/* work pointer to an OR/AND entry */
	SeOrAndNode *entry2;		/* work pointer to an OR/AND entry */
	unsigned *bitarr;		/* pointer to a bit array */
	unsigned *bitarr2;		/* pointer to a bit array */
	int *reduce_bit_map;		/* reduced bit mapping array */
	SeOrAndNode *next;		/* pointer to next entry in table */
	int new_size;			/* new reduced bit array size */
	int index;			/* loop index variable */
	int bit;			/* bit loop index variable */
	MuvesBool multocc;			/* contains multiple occurrence flag */

	/*=======================*/
	/*  IDENTIFY COMPONENTS  */
	/*=======================*/

	/* identify components/temporary nodes actually in expression */
	bitarr = (unsigned *)DmCalloc(SeBitArrSize, sizeof(unsigned));
	bitarr2 = (unsigned *)DmCalloc(SeBitArrSize, sizeof(unsigned));
	*or_and_size = 0;
	DqEACH(or_and_tbl, entry, SeOrAndNode)
	{
		entry->multocc = mFalse;
		/* just OR all bits from all entries together */
		for (index = 0; index < SeBitArrSize; index++)
		{
			bitarr[index] |= entry->bitarr[index];
		}

		/* 05-05-04 ch3: added code to check for multoccs here */

		/* see if there are any multiple occurrences in entry */
		memset(bitarr2, 0, SeBitArrSize * sizeof(unsigned));
		if (SeDebugging & SEDBG_ORANDTBL)
		{
			ErLog("MultOccs:");
		}
		for (bit = 0; bit < SeNumLeafNodes; bit++)
		{
			if (SeGetBit(entry->bitarr, bit))
			{
				SeSetBit(bitarr2, bit);
				if (occur[bit] == MULT_OCCUR)
				{
					entry->multocc = mTrue;
					if (SeDebugging & SEDBG_ORANDTBL)
					{
						ErLog(" %d", bit);
					}
				}
			}
		}
		if (SeDebugging & SEDBG_ORANDTBL)
		{
			ErLog("\n");
		}

		/* determine if multiple occurrence with another entry */
		if (entry->multocc)
		{

			entry->multocc = mFalse;
			/* start at entry after current entry */
			DqEACH(or_and_tbl, entry2, SeOrAndNode)
			{
				if (entry2 != entry)
				{
					for (bit = 0; bit < SeBitArrSize; bit++)
					{
						if (bitarr2[bit]
							& entry2->bitarr[bit])
						{
							entry->multocc = mTrue;
							break;
						}
					}
					if (entry->multocc)
					{
						break;
					}
				}
			}
		}
		
		/* count this entry */
		(*or_and_size)++;
	}
	DmFree((genptr_t)bitarr2);

	/*==============*/
	/*  COUNT BITS  */
	/*==============*/

	/* count set bits and create reduction conversion array */
	reduce_bit_map = (int *)DmCalloc(SeNumLeafNodes, sizeof(int));
	SeNumBits = 0;
	for (bit = 0; bit < SeNumLeafNodes; bit++)
	{
		reduce_bit_map[bit] = SeGetBit(bitarr, bit) ? SeNumBits++ : -1;
	}
	if (SeDebugging & SEDBG_ORANDTBL)
	{
		ErLog("Reduced Conversion Array (%d):\n", SeNumBits);
		for (bit = 0; bit < SeNumLeafNodes; bit++)
		{
			if (SeGetBit(bitarr, bit))
			{
				ErLog(" %d:%d", bit, reduce_bit_map[bit]);
			}
		}
		ErLog("\n");
	}
	DmFree((genptr_t)bitarr);

	/*==========================*/
	/*  SETUP CONVERSION ARRAY  */
	/*==========================*/

	/* calculate new bit array size and create expand conversion array */
	new_size = (SeNumBits - 1) / BITARR_ELEM_SIZE + 1;
	SeExpandBitMap = (int *)DmCalloc(SeNumBits, sizeof(int));
	for (bit = 0; bit < SeNumLeafNodes; bit++)
	{
		if (reduce_bit_map[bit] != -1)
		{
			SeExpandBitMap[reduce_bit_map[bit]] = bit;
		}
	}
	if (SeDebugging & SEDBG_ORANDTBL)
	{
		ErLog("Expansion Conversion Array (%d):\n", new_size);
		for (bit = 0; bit < SeNumBits; bit++)
		{
			ErLog(" %d:%d", bit, SeExpandBitMap[bit]);
		}
		ErLog("\n");
	}

	/*===================================*/
	/*  CREATE ARRAY & FREE LINKED LIST  */
	/*===================================*/

	/* first put entries from linked list into array that contain
	 * multiple occurrent components/temp-nodes */
	*or_and_array = (unsigned **)DmCalloc(*or_and_size, sizeof(unsigned *));
	index = 0;
	DqEACH(or_and_tbl, entry, SeOrAndNode)
	{
		/* allocate new element, set bits from old, i.e. reduce entry */
		bitarr = (unsigned *)DmCalloc(new_size, sizeof(unsigned));
		for (bit = 0; bit < SeNumLeafNodes; bit++)
		{
			if (SeGetBit(entry->bitarr, bit))
			{
				SeSetBit(bitarr, reduce_bit_map[bit]);
			}
		}
		
		/* deallocate original bit array */
		DmFree((genptr_t)entry->bitarr);

		if (entry->multocc)
		{
			/* contains multiple occurrence, add to array */
			(*or_and_array)[index++] = bitarr;

			/* mark that bit array of entry was copied */
			entry->bitarr = NULL;
		}
		else	/* contains no multiple occurrence */
		{
			/* will add to end of array later */
			/* for now save reduced bit array in linked list */
			entry->bitarr = bitarr;
		}
	}
	*or_and_count = index;  /* save number of entries with multoccs */

	/* put the rest of the entries that did not contain multiple
	 * occurrences into the array, remove entries from linkied list,
	 * release memory and close linked list */
	while ((entry = DqTPop(or_and_tbl, SeOrAndNode)) != NULL)
	{
		if (entry->bitarr != NULL)
		{
			(*or_and_array)[index++] = entry->bitarr;
		}

		/* deallocate entry */
		DmFree((genptr_t)entry);
	}
	DqClose(or_and_tbl);

	/*============*/
	/*  CLEAN-UP  */
	/*============*/

	/* deallocate reduction conversion array, set new bit array size */
	DmFree((genptr_t)reduce_bit_map);
	SeBitArrSize = new_size;

	if (*or_and_count > 64)
	{
		/* code in SeBuildSortedSumTable() only allows 64 entries */
		ErPLog("There are too many OR/AND table entries to be "
			"processed (%d)!\n", *or_and_count);
		return mFalse;
	}
	return mTrue;

}  /* SeMakeOrAndArray() */


/*
	SeBuildSortedSumTable(DqNode *or_and_tbl,
		SeSumTbl *sorted_sum_tbl, int or_and_size,
		int or_and_count)

	This function will build a sorted summation table from the
	entries in the OR/AND table array that contain multiple
	occurrences.  This is performed by using an optimized process
	which includes the following steps: build a summation table
	using the equation L+R-L&R where the L is all the entries in the
	table already, the R is the new entry to add to the table and
	the L&R is all the entries in the table already ANDed with the
	new entry with a reversed sign to create a set of new entries;
	and sort the summation table and remove duplicate entries by
	adding the signs of the duplicate entries into a single entry.

	The sorted summation table can actually be built at the same
	time as the summation table by adding each entry to the sorted
	summation table in sorted order and if the entry already exists,
	just adding the sign to the entry's sign.  When complete, the
	memory used by the summation table can simply be releassed.

	The optimized process does not require the summation table to be
	stored.  A binary counter is used for the total number of
	summation table entries.  For each counter value, the bits that
	are on identify the components and/or temporary expression nodes
	should be in the entry.  The sign of the entry is determined by
	the number of bits that are on, odd for a positive sign, even
	for a negative sign.  Each entry is added to the sorted
	summation table by calling SeAddSumEntry().

	This function is for internal Se package use only.

	RETURN: mTrue if successful
		mFalse if failure (no allocate work bit array or expand indexes)
 */

/* 05-04-15 ch3: modified to use counter instead of old L+R-L&R method */
MuvesBool
SeBuildSortedSumTable PARAMS((
	SeSumTbl *sorted_sum_tbl,	/* pointer to sorted summation table */
	unsigned **or_and_array,	/* pointer to OR/AND table array */
	int or_and_count))		/* multocc count in OR/AND array */
{
	unsigned *work_bitarr;		/* pointer to working bit array */
	signed char work_sign;		/* working sign factor variable */
	int i, j;			/* loop index variables */
	MuvesBool success;			/* success return status flag */
	unsigned long sumtbl_size;	/* size of sum table */
	unsigned long count;		/* count through sum table */
	unsigned long mask;		/* bit mask variable */
	unsigned *bitarr;		/* pointer to a bit array */

	/* allocate working bit array */
	work_bitarr = (unsigned*)DmCalloc(SumEntrySize, sizeof(unsigned));
	assert(work_bitarr != NULL);
	if (work_bitarr == NULL)
		return mFalse;  /* memory allocation error */

	/* for each entry in OR/AND table, generate summation table entries */
	/* create an array from the OR/AND table queue */

	success = mTrue;
	sumtbl_size = 1L << or_and_count;
	if (SeDebugging & SEDBG_STSMSGS)  /* 01-08-29 ch3: added */
		ErPLog("SeBuildSortedSumTable: OrAndCount=%d SumTblSize=%ld(%d)"
			"\n", or_and_count, sumtbl_size - 1, SumEntrySize);
	for (count = 1; count < sumtbl_size; count++)
	{
		memset(work_bitarr, 0, SeBitArrSize * sizeof(unsigned));
		work_sign = -1;
		for (mask = 1, j = 0; j < or_and_count; mask <<= 1, j++)
		{
			if (count & mask)
			{
				work_sign = -work_sign;
				bitarr = or_and_array[j];
				for (i = 0; i < SeBitArrSize; i++)
					work_bitarr[i] |= bitarr[i];
			}
		}
		if (!SeAddSumEntry(sorted_sum_tbl, work_bitarr, work_sign))
		{
			success = mFalse;
			break;
		}
	}

	/* deallocate working bit array */
	DmFree((genptr_t)work_bitarr);

	return success;

}  /* SeBuildSortedSumTable() */


/*
	SeAddSumEntry(SeSumTbl *index_tbl, unsigned *bitarr,
		int sign_factor)

	This function will add a bit array and sign factor to the index
	table in sorted order and is called by SeBuildSortedSumTable().
	If the index table is empty, the new entry will be put at the
	beginning of the table.  Otherwise, a binary search is performed
	to find out if the entry already exists or where to insert the
	new entry.  If the entry exists, the new sign factor will be
	added to the entry found and the element's index will be
	returned.  If the index table needs to be expanded, its memory
	will be reallocated for a larger size.  Room will be made for
	the new element be shifting memory.  The new element will be
	inserted and it's index will be returned.

	This function is for internal Se package use only.

	RETURN: mTrue if successful
		mFalse if a failure occurred (array could not be expanded)
 */

/* 05-04-14 ch3: changed to return boolean status instead of pointer */
MuvesBool
SeAddSumEntry PARAMS((
	SeSumTbl *sum_tbl,	/* pointer to index table */
	unsigned *bitarr,	/* pointer to bit array to add */
	int sign_factor))	/* sign factor for this entry (+1 or -1) */
{
	int lo, hi;		/* low and high indexes for binary search */
	int mid;		/* middle index for binary search */
	int result;		/* return result status variable */
	unsigned **arrayp;	/* work array pointer */

	if (sum_tbl->size == 0)  /* table empty? */
	{
		/* insert element at beginning */
		mid = 0;
		arrayp = sum_tbl->arrayp;
	}
	else
	{
		/* binary search for item using sorted index */
		lo = 0;
		hi = sum_tbl->size;
		for (;;) {
			mid = lo + (hi - lo) / 2;
			result = SeCmpBitArrays(bitarr, sum_tbl->arrayp[mid]);
			if (lo == mid)
				break;
			if (result < 0)
				hi = mid;
			else
				lo = mid;
		}

		if (result == 0)  /* already in table? */
		{
			/* just add in new entry's sign factor */
			arrayp = sum_tbl->arrayp + mid;
			SumSignFactor(*arrayp) += sign_factor;

			return mTrue;
		}
		if (result > 0)  /* insert after this element? */
			mid++;

		/* check if expansion of table needed */
		if (sum_tbl->size >= sum_tbl->max_size)
		{
			sum_tbl->max_size += ARRAY_SIZE;
			arrayp = (unsigned **)DmRealloc(sum_tbl->arrayp,
				(sum_tbl->max_size)*sizeof(unsigned *));
			assert(arrayp != NULL);
			if (arrayp == NULL)
			{
				if (SeDebugging)
					ErLog("SeAddSumEntry: Insufficient "
						"memory \n");
				return mFalse;  /* insufficient memory */
			}
			sum_tbl->arrayp = arrayp;
		}

		/* make room for new element */
		arrayp = sum_tbl->arrayp + mid;
		if (mid < sum_tbl->size)  /* something to move? */
			memmove((void *)(arrayp + 1), (void *)arrayp,
				(sum_tbl->size - mid) * sizeof(unsigned *));
	}

	/* add new element to the table */
	sum_tbl->size++;
	*arrayp = (unsigned*)DmCalloc(SumEntrySize, sizeof(unsigned));
	assert(*arrayp != NULL);
	/* 01-08-29 ch3: bug fix, added sizeof(unsigned) to memcpy */
	memcpy(*arrayp, bitarr, SeBitArrSize * sizeof(unsigned));
	SumSignFactor(*arrayp) = sign_factor;

	return mTrue;

}  /* SeAddSumEntry() */


/*
	SeBuildNewExprTree(SeSumTbl *sorted_sum_tbl,
		unsigned **or_and_array, int or_and_size,
		int or_and_start)

	This function will build a new expression tree for the entries
	in the sorted summation table and the entries in the OR/AND
	table that do not contain multiple occurrences.

	For each entry in the sorted summation table, a base product
	expression will be built by calling SeBuildBitArrayExpr().  The
	sign factor of the entry will added to the base product
	expression as a product expression node by calling
	SeFinishProdExpr().  The product expression will be added as the
	right side to the expression built so far (the left side) as a
	sum or difference expresion node, determined by the sign factor
	of the entry.  This will continue until all of the entries have
	been processed.

	For each entry in the OR/AND table that does not contain
	multiple occurrences, an AND expression will be built by calling
	SeBuildBitArrayExpr().  The AND expression will be added as the
	right side to the expression built so far (the left side) as an
	OR expression node.  This will continue until all of the entries
	have been processed.

	To finish the expression tree, a MULTOCC expression node will be
	created to contain the expression built.  This expression node
	type simply identifies that the expression has been corrected by
	the fix multiple occurrences routine and the expression tree
	below is evaluated as any other expression would be.

	This function is for internal Se package use only.

	RETURN: pointer to product expression built
		NULL if an allocation error occurred
 */

/* 05-04-14 ch3: added code to add |/& trees for non-multocc OR/AND entries */
SeSysDef *
SeBuildNewExprTree PARAMS((
	SeSumTbl *sorted_sum_tbl,	/* pointer to sorted summation table */
	unsigned **or_and_array,	/* pointer to OR/AND table array */
	int or_and_size,		/* size of OR/AND table array */
	int or_and_start))		/* start of no multocc entries */
{
	unsigned *bitarr;  /* pointer to a component bit array */
	SeSysDef *leaf1;   /* pointer to a leaf node expression */
	SeSysDef *leaf2;   /* pointer to a leaf node expression */
	SeSysDef *root;    /* pointer to a root node expression */
	int signfactor;    /* sign factor of component entry */
	SeNodeCategory type = SeNT_UNSET;   /* expression node type variable */
	int index;         /* loop index variable */

	leaf1 = NULL;
	for (index = 0; index < sorted_sum_tbl->size; index++)
	{
		bitarr = sorted_sum_tbl->arrayp[index];
		signfactor = SumSignFactor(bitarr);
		if (signfactor != 0)
		{
			/* first build base expression of the components */
			leaf2 = SeBuildBitArrayExpr(bitarr, SeNT_PROD);
			assert(leaf2 != NULL);
			if (leaf2 == NULL)
				return NULL;

			type = SeNT_SUM;  /* set default node type */

			/* complete expression with its sign factor */
			leaf2 = SeFinishProdExpr(leaf2, signfactor,
			leaf1 == NULL, &type);
			assert(leaf2 != NULL);
			if (leaf2 == NULL)
			{
				/* deallocate expressions so far */
				/* new expression has been deallocated */
				if (leaf1 != NULL)
					SeExpFree(leaf1);
				return NULL;
			}

			/* 05-02-18 ch3: added debug message */
			if (SeDebugging & SEDBG_BLDEXPR)
				ErPLog("SeBuildNewExprTree(%d/%d): %d leaf1=%p "
					"leaf2=%p %s(%d)\n", index,
					sorted_sum_tbl->size, signfactor, leaf1,
					leaf2, SeTtbl[type].ts, type);
			/* create a sum or diff node to combine expressions */
			if (leaf1 == NULL)
			{
				/* none so far, so use one just built */
				leaf1 = leaf2;  /* make left side for next */
			}
			else  /* create node and combine */
			{
				/* allocate a new root node for expression */
				root = (SeSysDef *)DmXalloc(SeSysDef);
				assert(root != NULL);
				if (root == NULL)
				{
					/* deallocate expression so far */
					SeExpFree(leaf1);
					SeExpFree(leaf2);
					return NULL;
				}

				/* initialize root node for product */
				/* attach previous root/leaf with new leaf */
				root->core.type = type;
				root->core.text = DmStrDup(SeTtbl[type].ts);
				root->o.lhsp = leaf1;  /* expression so far */
				root->o.rhsp = leaf2;  /* new expression */

				leaf1 = root;  /* new left side */
			}
		}  /* if (signfactor != 0) */
	}  /* end for (index) */

	/* now add on the none multiple occurrent OR/AND table entries */
	for (index = or_and_start; index < or_and_size; index++)
	{
		bitarr = or_and_array[index];

		/* first build an AND expression of the components */
		leaf2 = SeBuildBitArrayExpr(bitarr, SeNT_AND);
		assert(leaf2 != NULL);
		if (leaf2 == NULL)
			return NULL;

		if (SeDebugging & SEDBG_BLDEXPR)
			ErPLog("SeBuildNewExprTree(%d/%d): leaf1=%p leaf2=%p "
				"%s(%d)\n", index, or_and_size, leaf1, leaf2,
				SeTtbl[SeNT_OR].ts, SeNT_OR);

		/* create an OR node to combine expressions */
		if (leaf1 == NULL)
		{
			/* none so far, so use one just built */
			leaf1 = leaf2;  /* make left side for next */
		}
		else  /* create node and combine */
		{
			/* allocate a new root node for expression */
			root = (SeSysDef *)DmXalloc(SeSysDef);
			assert(root != NULL);
			if (root == NULL)
			{
				/* deallocate expression so far */
				SeExpFree(leaf1);
				SeExpFree(leaf2);
				return NULL;
			}

			/* initialize root node for product */
			/* attach previous root/leaf with new leaf */
			root->core.type = SeNT_OR;
			root->core.text = DmStrDup(SeTtbl[SeNT_OR].ts);
			root->o.lhsp = leaf1;  /* expression so far */
			root->o.rhsp = leaf2;  /* new expression */

			leaf1 = root;  /* new left side */
		}
	}  /* end for (index) */

	/* now build top level multiple occurrence expression node */
	if (leaf1 != NULL)
	{
		root = (SeSysDef *)DmXalloc(SeSysDef);
		assert(root != NULL);
		if (root == NULL)
		{
			/* deallocate expression so far */
			SeExpFree(leaf1);
			return NULL;
		}

		/* initialize root node for product */
		/* attach previous root/leaf with new leaf */
		root->core.type = SeNT_MULTOCC;
		root->core.text = DmStrDup("Mult-Occ");  /* IS THIS CORRECT? */
		root->o.lhsp = NULL;   /* not used */
		root->o.rhsp = leaf1;  /* multiple occurrence expression */

		leaf1 = root;  /* return this node */
	}
	/* 05-02-18 ch3: added debug message */
	if (SeDebugging & SEDBG_BLDEXPR)
		ErPLog("SeBuildNewExprTree(): root=%p\n", type);
	return leaf1;  /* return the expression built */

}  /* SeBuildNewExprTree() */


/*
	SeBuildBitArrayExpr(unsigned *bitarr, SeNodeCategory type)

	This function will build an expression from a reduced bit array
	and is called by SeBuildNewExprTree().  Each bit in the reduced
	bit array represents a component or temporary expression node.
	The bit array will be scanned for bits that are turned on (each
	bit number is mapped back to the original unreduced bit number).
	As each component or temporary expression node is found, an
	operator expression of type indicated is built with the previous
	expression plus the new componenat or the expression that was
	represented by the temporary expression node.

	This function is for internal Se package use only.

	RETURN: pointer to expression built
		NULL if an allocation error occurred
 */

/* 05-04-08 ch3: modified to process reduced bit fields */
/* 05-04-14 ch3: added type argument, renamed function */
SeSysDef *
SeBuildBitArrayExpr PARAMS((
	unsigned *bitarr,	/* pointer to comp/temp bit array */
	SeNodeCategory type))	/* type of expression to build */
{
	SeSysDef *leaf1;	/* pointer to a leaf node expression */
	SeSysDef *leaf2;	/* pointer to a leaf node expression */
	SeSysDef *root;		/* pointer to a root node expression */
	SeSysDef *comp;		/* pointer to component node in old expr */
	register int bit;	/* bit loop index variable */
	register int index;	/* temporary index variable (03-09-11 ch3) */
	int *used;		/* pointer to used variable (03-09-11 ch3) */

	leaf1 = NULL;
	/* 01-12-06 ch3: added SeNumTmpExprs */
	for (bit = 0; bit < SeNumBits; bit++)
	{
		if (SeGetBit(bitarr, bit))  /* include component or system? */
		{
			/* 05-04-08 ch3: get actual bit index */
			index = SeExpandBitMap[bit];
			/* get component node from old expression tree */
			/* 01-12-06 ch3: added check for temporary expression */
			/* 03-09-11 ch3: since substituted expression contains
			 *               new copies of each of the nodes, used
			 *               checks were added to make a new copy
			 *               after the first copy is used
			 */
			if (index < SeNumComponents)
			{
				comp = SeCompList[index].copy;
				used = &SeCompList[index].used;
				if (SeDebugging & SEDBG_BLDBEXPR)
					ErLog("SeBuildBitArrayExpr(%d:%d): "
						"Comp=%p\n", bit, index, comp);
			}
			else
			{
				/* expression in temporary node is a copy, */
				/* will be used as is for the first reference */
				/* after that, a new copy will be made */
				index -= SeNumComponents;
				comp = SeTmpExpr[index].copy;
				used = &SeTmpExpr[index].used;
				if (SeDebugging & SEDBG_BLDBEXPR)
					ErLog("SeBuildBitArrayExpr(%d:%d): "
						"Tmp=%p(%d)\n", bit, index,
						comp, SeTmpExpr[index].used);
			}
			assert(comp != NULL);
			if (*used > 0)
			{
				/* already used, make new copy */
				comp = SeExpCopy(comp);
				if (SeDebugging & SEDBG_BLDBEXPR)
					ErLog("SeBuildBitArrayExpr(%d:%d): "
						"Copy=%p(%d)\n", bit, index,
						comp, *used);
			}
			(*used)++;  /* increment used count */

			if (leaf1 == NULL)  /* first component? */
			{
				/* 01-12-06 ch3: replaced code with call to */
				/*               SeExpCopy() to handle both */
				/*               components and temporary */
				/*               expressions. */
				/* 03-09-11 ch3: removed call to SeExpCopy(),
				 *               copied handled above */
				leaf1 = comp;
			}
			else  /* create an operator node */
			{
				/* 01-12-06 ch3: replaced code with call to */
				/*               SeExpCopy() to handle both */
				/*               components and temporary */
				/*               expressions. */
				/* 03-09-11 ch3: removed call to SeExpCopy(),
				 *               copied handled above */
				leaf2 = comp;

				/* next allocate a new root node */
				root = (SeSysDef *)DmXalloc(SeSysDef);

				/* initialize root node for product */
				/* attach previous root/leaf with new leaf */
				root->core.type = type;
				root->core.text = DmStrDup(SeTtbl[type].ts);
				root->o.lhsp = leaf1;
				root->o.rhsp = leaf2;

				/* set leaf to root for next component */
				leaf1 = root;
			}
		}  /* end if (SeGetBit()) */
	}  /* end for (bit) */
	if (leaf1 == NULL && SeDebugging)
		ErLog("SeBuildBitArrayExpr: No expression built\n");

	return leaf1;  /* return pointer to expression built */

}  /* SeBuildBitArrayExpr() */


/*
	SeFinishProdExpr(SeSysDef *expr, int signfactor, MuvesBool firstexpr,
		SeNodeCategory *type)

	This function will finish building a product expression by
	adding a constant leaf node to the expression built so far and
	is called by SeBuildNewExprTree().
	
	If the sign factor is +1, no additional constant node is
	necessary.  If this is not the first expression built and the
	sign factor is -1, a difference operator will be used to create
	a -1 so no additional constant node is necessary.  Otherwise, if
	this is the first expression built or the sign factor is
	positive, the sign factor will be used as is.  Otherwise, the
	sign factor will be made positive and a difference operator will
	be used.
	
	A constant node leaf will be created to hold the constant.  A
	root node will be created to complete the product expression.
	The remaining argument is a pointer to the type of node that
	should be above the expression finished.  The default will be a
	SUM operator.  If the product has a negative sign factor and
	this product expression is not the first one, then the operator
	will be changed to a DIFF operator (mainly to optimize the
	number of nodes with -1 sign factors).

	This function is for internal Se package use only.

	RETURN: pointer to final expression built
		NULL if an allocation error occurred
 */

SeSysDef *
SeFinishProdExpr PARAMS((
	SeSysDef *expr,		/* pointer to product expression built so far */
	int signfactor,		/* sign factor of product being built */
	MuvesBool firstexpr,		/* flag if this is the first product expr */
	SeNodeCategory *type))	/* pointer to node type to return */
{
	SeSysDef *newleaf;	/* pointer to a leaf node expression */
	SeSysDef *root;		/* pointer to a root node expression */
	char tmpstr[20];	/* temporary string for constant text */
	int factor;		/* sign factor value variable */

	if (signfactor == +1)
	{
		/* not necessary to add a constant to product expression */
		root = expr;  /* just set it to expression built so far */
	}
	else if (!firstexpr && signfactor == -1)
	{
		/* not necessary to add a constant to product expression */
		*type = SeNT_DIFF;  /* use difference operator for -1 */
		root = expr;  /* just set it to expression built so far */
	}
	else  /* add a constant node to the product expression */
	{
		if (firstexpr || signfactor > 0)
		{
			/* if this is the first expression, then we can't */
			/* use a difference operator, so instead we will */
			/* use the negative sign factor as is */
			/* also use sign factor as is if positive */
			factor = signfactor;
		}
		else  /* use positive sign factor with difference operator */
		{
			factor = -signfactor;
			*type = SeNT_DIFF;
		}

		/* allocate a new leaf node for constant */
		newleaf = (SeSysDef *)DmXalloc(SeSysDef);
		assert(newleaf != NULL);
		if (newleaf == NULL)
		{
			/* deallocate expression so far */
			SeExpFree(expr);
			return NULL;
		}

		/* initialize the constant leaf node */
		newleaf->core.type = SeNT_CONSTANT;
		sprintf(tmpstr, "%d", factor);
		newleaf->core.text = DmStrDup(tmpstr);
		newleaf->n.index = -1;
		newleaf->n.value = (double)factor;
		assert(newleaf->core.text != NULL);
		if (newleaf->core.text == NULL)
		{
			/* deallocate expression so far */
			SeExpFree(expr);
			SeExpFree(newleaf);
			return NULL;
		}

		/* allocate a new root node for expression */
		root = (SeSysDef *)DmXalloc(SeSysDef);
		assert(root != NULL);
		if (root == NULL)
		{
			/* deallocate expression so far */
			SeExpFree(expr);
			SeExpFree(newleaf);
			return NULL;
		}

		/* initialize root node for product */
		/* attach previous root/leaf with new leaf */
		root->core.type = SeNT_PROD;
		root->core.text = DmStrDup(SeTtbl[SeNT_PROD].ts);
		root->o.lhsp = expr;     /* expression built so far */
		root->o.rhsp = newleaf;  /* constant leaf */
	}
	return root;  /* return root node of product expression */

}  /* SeFinishProdExpr() */


/*
	SeCmpBitArrays(unsigned *bitarr1, unsigned *bitarr2)

	This support function will compare the first bit array to the
	second bit array to determine if the first bit array is the
	same, less than or greater than the second bit array.

	This function is for internal Se package use only.

	RETURN: 0 if the bit arrays are the same
		<0 if the first bit array is less than the second
		>0 if the first bit array is greater than the second
 */

int
SeCmpBitArrays PARAMS((
	unsigned *bitarr1,	/* pointer to first bit array */
	unsigned *bitarr2))	/* pointer to second bit array */
{
	int index;		/* loop index variable */
	int compare = 0;	/* compare result work variable */

	for (index = 0; index < SeBitArrSize; index++)
	{
		compare = bitarr1[index] - bitarr2[index];
		if (compare != 0)
			break;  /* doesn't compare, stop comparing */
	}
	return compare;  /* last compare value */

}  /* SeCmpBitArrays() */


/*
	SeGetBit(unsigned *bitarr, int index)

	This support function will test the indicated bit in a component
	bit array to see if the indicated is on.  First the proper
	element (group of bits) is obtained.  Then a mask is created and
	anded with the proper element.  The result will be non-zero if
	the bit is on, and zero if the bit is not on.

	This function is for internal Se package use only.

	RETURN: 0 if the bit is not set
		non-0 if bit is set (could be any actual value)
 */

unsigned
SeGetBit PARAMS((
	unsigned *bitarr,	/* pointer to bit array */
	int index))		/* index to desired bit */
{
	unsigned work;		/* work variable for an element */

	work = bitarr[index / BITARR_ELEM_SIZE];       /* get proper element */
	return work & 1U << index % BITARR_ELEM_SIZE;  /* test proper bit */

}  /* SeGetBit() */


/*
	SeSetBit(unsigned *bitarr, int index)

	This support function will set the indicated bit in a component
	bit array.  First a pointer to the proper element (group of
	bits) is obtained.  Then a mask is created and ored with the
	proper element to set the bit.

	This function is for internal Se package use only.

	RETURN: no value is returned by this function
 */

void
SeSetBit PARAMS((
	unsigned *bitarr,	/* pointer to bit array */
	int index))		/* index to desired bit */
{
	unsigned *work;		/* work pointer to an element */

	work = &bitarr[index / BITARR_ELEM_SIZE];  /* get proper element */
	*work |= 1U << index % BITARR_ELEM_SIZE;   /* set proper bit */

}  /* SeSetBit() */


/*
	SePrintExprTree(SeSysDef *expr, int level, char *header,
		MuvesBool sys_exprs)

	This debug function will print the expression tree.  This
	function will call itself recursively for operators with left
	and right side expression tree.  This function is only used for
	debugging.

	This function is for internal Se package use only.

	RETURN: no value is returned by this function
 */

/* 03-09-08 ch3: added header argument for printing at level 0 */
/* 05-03-19 ch3: modified to not print so many spaces */
/* 05-04-23 ch3: added option to print system expressions */
void
SePrintExprTree PARAMS((
	SeSysDef *expr,		/* pointer to expression tree to print */
	int level,		/* level of tree */
	char *header,		/* name of header to print at level 0 */
	MuvesBool sys_exprs))	/* descent into and print system expressions */
{
	int index;		/* loop index variable */

	if (level == 0 && header != NULL)
	{
		ErLog("SePrintExprTree-%s:\n", header);
	}
	if (SeDebugging & SEDBG_PRTLVLS)
	{
		ErLog("%p-%d ", expr, level);
	}
	else
	{
		ErLog("%p ", expr);
		for (index = 0; index < level; index++)
			ErLog(" ");
	}

	switch (expr->type)
	{
	case SeNT_MULTOCC:
		ErLog("MULTOCC:\n");
		SePrintExprTree(expr->o.rhsp, level + 1, NULL, sys_exprs);
		break;

	case SeNT_PROD:
		ErLog("*\n");
		SePrintExprTree(expr->o.lhsp, level + 1, NULL, sys_exprs);
		SePrintExprTree(expr->o.rhsp, level + 1, NULL, sys_exprs);
		break;

	case SeNT_SUM:
		ErLog("+\n");
		SePrintExprTree(expr->o.lhsp, level + 1, NULL, sys_exprs);
		SePrintExprTree(expr->o.rhsp, level + 1, NULL, sys_exprs);
		break;

	case SeNT_DIFF:
		ErLog("-\n");
		SePrintExprTree(expr->o.lhsp, level + 1, NULL, sys_exprs);
		SePrintExprTree(expr->o.rhsp, level + 1, NULL, sys_exprs);
		break;

	case SeNT_CONSTANT:
		ErLog("Constant:%g\n", expr->n.value);
		break;

	/* 01-12-08 ch3: added more types for testing BEGIN */
	case SeNT_AND:
		ErLog("&\n");
		SePrintExprTree(expr->o.lhsp, level + 1, NULL, sys_exprs);
		SePrintExprTree(expr->o.rhsp, level + 1, NULL, sys_exprs);
		break;

	case SeNT_OR:
		ErLog("|\n");
		SePrintExprTree(expr->o.lhsp, level + 1, NULL, sys_exprs);
		SePrintExprTree(expr->o.rhsp, level + 1, NULL, sys_exprs);
		break;

	case SeNT_EXPR:
		ErLog("EXPR\n");
		SePrintExprTree(expr->o.rhsp, level + 1, NULL, sys_exprs);
		break;

	case SeNT_COMPNAME:
	case SeNT_QUALCOMP:
		ErLog("Comp %d:%s(%d)\n", expr->type, expr->core.text,
			expr->c.index);
		break;

	case SeNT_SYSNAME:
	case SeNT_QUALSYS:
		ErLog("Sys %d:%s(%d)\n", expr->type, expr->core.text,
			expr->c.index);
		if (sys_exprs)
		{
			SePrintExprTree(SeDataSystem[expr->c.index]->sysdef,
				level + 1, NULL, sys_exprs);
		}
		break;

	case SeNT_TMPEXPR:
		ErLog("Tmp %d:%d\n", expr->type, expr->c.index);
		break;
	/* 01-12-08 ch3: added more types for testing END */

	default:
		ErLog("Type %d:%s\n", expr->type, expr->core.text);
		break;
	}
}  /* SePrintExprTree() */


/*
	SeCheckExprTree(SeSysDef *expr, int level, char *header)

	This debug function will check the expression tree.  This
	function will call itself for operators with left and right side
	expression tree.  This function is only used for debugging and
	if normally not compiled into the code.

	This function is for internal Se package use only.

	RETURN: no value is returned by this function
 */

/* 05-02-15 ch3: added function */
#if CHECK_EXPR
void
SeCheckExprTree PARAMS((
	SeSysDef *expr,		/* pointer to expression tree to check */
	int level,		/* level of tree */
	char *header))		/* name of header to print at level 0 */
{
	int index;		/* loop index variable */

	switch (expr->type)
	{
	case SeNT_MULTOCC:
		SeCheckExprTree(expr->o.rhsp, level + 1, header);
		break;

	case SeNT_PROD:
		SeCheckExprTree(expr->o.lhsp, level + 1, header);
		SeCheckExprTree(expr->o.rhsp, level + 1, header);
		break;

	case SeNT_SUM:
		SeCheckExprTree(expr->o.lhsp, level + 1, header);
		SeCheckExprTree(expr->o.rhsp, level + 1, header);
		break;

	case SeNT_DIFF:
		SeCheckExprTree(expr->o.lhsp, level + 1, header);
		SeCheckExprTree(expr->o.rhsp, level + 1, header);
		break;

	case SeNT_CONSTANT:
		break;

	case SeNT_AND:
		SeCheckExprTree(expr->o.lhsp, level + 1, header);
		SeCheckExprTree(expr->o.rhsp, level + 1, header);
		break;

	case SeNT_OR:
		SeCheckExprTree(expr->o.lhsp, level + 1, header);
		SeCheckExprTree(expr->o.rhsp, level + 1, header);
		break;

	case SeNT_EXPR:
		SeCheckExprTree(expr->o.rhsp, level + 1, header);
		break;

	case SeNT_COMPNAME:
	case SeNT_QUALCOMP:
		break;

	case SeNT_SYSNAME:
	case SeNT_QUALSYS:
		SeCheckExprTree(SeDataSystem[expr->c.index]->sysdef, level + 1,
			header);
		break;

	case SeNT_TMPEXPR:
		ErLog("(%d) Found Tmp %d (%p):%d\n", level, expr->type, expr,
			expr->c.index);
		break;

	default:
		ErLog("(%d) Type %d:%s\n", level, expr->type, expr->core.text);
		break;
	}

	if (level == 0)
	{
		ErLog("SeCheckExprTree: %s\n", header);
	}
}  /* SeCheckExprTree() */
#endif /*CHECK_EXPR*/


/* SeMultOcc.c */
