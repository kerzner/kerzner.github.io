/*
	SeParse.c -- MUVES "Se" (system evaluator) package

	created:	88/01/12	G S Moss
	edited:		02/07/27	C Hunt
			add support for SeNT_ORCA node type to SeListPromote()
			(SCR446)

	Note for maintainer:  Definite errors result in diagnostic messages
	to the error log at the LOWEST POSSIBLE LEVEL; therefore higher-level
	functions need not produce diagnostics when errors are reported by
	lower-level Se package functions.  The 3-way extended Boolean type
	bs_type is used by functions to report success/failure; bs_ugly means
	that an error was detected and logged; bs_bad means that the function
	did not achieve its "goal", but no actual error occurred and nothing
	was logged; and bs_good means that the goal was achieved without error.
	2-way ordinary Boolean (MuvesBool-valued) functions generally log an error
	before returning mFalse, and do not log anything before returning mTrue.
*/
#ifndef lint
static char RCSid[] = "$Id: SeParse.c,v 1.39 2010/06/23 19:54:51 geoffs Exp $";
#endif

#ifndef DEBUG
#define NDEBUG
#endif

#include <assert.h>
#include <ctype.h>
	#include <errno.h>
#include <stdio.h>
#include <string.h>

#include <std.h>
#ifndef SEEK_SET
#define	SEEK_SET	0
#endif

#include <Dq.h>
#include <Er.h>
#include <Io.h>
#include <stdio.h>
#include <common.h>   /* BRL-CAD 7.2.4+ no longer use config.h (SCR670) */
#include <Dm.h>
#include <Nm.h>
#include <Rt.h>
#include <Se.h>

#include "SeDefs.h"
typedef void* genptr_t;

extern int SeDebugging;
#define ErDebugging SeDebugging

#ifndef STATIC
#define STATIC static
#endif

#ifndef SeDEBUG
#define SeDEBUG	0
#endif

#if BUFSIZ < 512
#include "*** ERROR *** BUFSIZ < 512"
#endif

#ifndef StrBool
#define StrBool(x)	((x) ? "true" : "false")
#endif


/* Initialize table of recognized single-character tokens.  Initializers with
   TK_ in their names are null-terminated string-literal tokens and those
   with CH_ are character representations of the token (excluding the null
   terminator).  This table is used for convenience in identifying input
   tokens as either character or string variables; it facilitates internal
   handling of multi-character operators such as '<<' as single-character
   equivalents.

   WARNING:  Indexed by SeNT_* code value; must track SeDefs.h definitions.
 */
SeTokTbl SeTtbl[SeNTOKENS] =
	{
	{	SeCH_ASSIGNMENT,	SeTK_ASSIGNMENT	},
	{	SeCH_DBL_QUOTE,		SeTK_DBL_QUOTE	},
	{	SeCH_LF_PAREN,		SeTK_LF_PAREN	},
	{	SeCH_RT_PAREN,		SeTK_RT_PAREN	},
	{	SeCH_LF_SQUARE,		SeTK_LF_SQUARE	},
	{	SeCH_RT_SQUARE,		SeTK_RT_SQUARE	},
	{	SeCH_LF_CURLY,		SeTK_LF_CURLY	},
	{	SeCH_RT_CURLY,		SeTK_RT_CURLY	},
	{	SeCH_COMMA,		SeTK_COMMA	},
	{	SeCH_NOT,		SeTK_NOT	},
	{	SeCH_ANOT,		SeTK_ANOT	},
	{	SeCH_ABS,		SeTK_ABS	},
	{	SeCH_BOOL,		SeTK_BOOL	},
	{	SeCH_AND,		SeTK_AND	},
	{	SeCH_OR,		SeTK_OR		},
	{	SeCH_MIN,		SeTK_MIN	},
	{	SeCH_MAX,		SeTK_MAX	},
	{	SeCH_XOR,		SeTK_XOR	},
	{	SeCH_SUM,		SeTK_SUM	},
	{	SeCH_DIFF,		SeTK_DIFF	},
	{	SeCH_PROD,		SeTK_PROD	},
	{	SeCH_QUOT,		SeTK_QUOT	},
	{	SeCH_LT,		SeTK_LT		},
	{	SeCH_GT,		SeTK_GT		},
	{	SeCH_LTEQ,		SeTK_LTEQ	},
	{	SeCH_GTEQ,		SeTK_GTEQ	},
	{	SeCH_LF_SQUARE,		SeTK_LF_SQUARE	},
	{	SeCH_COMMA,		SeTK_COMMA	},
	};

#if STD_C
STATIC MuvesBool SeExprGet( SeParseVars *vars, char *tokbufp );
STATIC MuvesBool SeStGetElement( SeParseVars *vars, int c, char *tokbufp, SeStDat **stdefp );
STATIC MuvesBool SeStVecGet( SeParseVars *vars, SeStDat **stdefp );
STATIC bs_type SeArgListGet( SeParseVars *vars, int c, char *tokbufp );
STATIC bs_type SeFnCallGet( SeParseVars *vars, char *tokbufp );
STATIC bs_type SeParenExprGet( SeParseVars *vars, int c, char *tokbufp );
STATIC bs_type SeQalGet( SeParseVars *vars, char *tokbufp, MuvesBool compiling );
STATIC void SeNxtLine( SeParseVars *vars );
STATIC MuvesBool SePassEOL( SeParseVars *vars, MuvesBool allow_comps );
STATIC void SePrvLine( SeParseVars *vars );
STATIC void SePrtErrMsg( SeParseVars *vars, const char *format, ... );
STATIC void SePrtMsgSyntax( SeParseVars *vars, const char *problem );
STATIC void SePrtSyntax( SeParseVars *vars, const char *expected, int around );
#if SeDEBUG
STATIC MuvesBool SeEOBufferChk( FILE *fp, const char *p, const char *bp );
STATIC MuvesBool SeEOLineChk( FILE *fp );
STATIC void SePrtTokenStack( const char *label, DqNode *stackp );
#endif
STATIC int SeNonSpaceGetChar( SeParseVars *vars );
STATIC MuvesBool SePushToken( SeParseVars *vars, int type, const char *text );
STATIC MuvesBool SeRtParenGet( SeParseVars *vars );
STATIC bs_type SeIdentifierGet( SeParseVars *vars, int c, char *tokbufp, int type );
STATIC bs_type SeIdentifierRead(SeParseVars *vars, int *c, char *tokbufp);
#else
STATIC MuvesBool SeExprGet();
STATIC MuvesBool SeStGetElement();
STATIC MuvesBool SeStVecGet();
STATIC bs_type SeArgListGet();
STATIC bs_type SeFnCallGet();
STATIC bs_type SeParenExprGet();
STATIC bs_type SeQalGet();
STATIC void SeNxtLine();
STATIC MuvesBool SePassEOL();
STATIC void SePrvLine();
STATIC void SePrtErrMsg();
STATIC void SePrtMsgSyntax();
STATIC void SePrtSyntax();
#if SeDEBUG
STATIC MuvesBool SeEOBufferChk();
STATIC MuvesBool SeEOLineChk();
STATIC void SePrtTokenStack();
#endif
STATIC int SeNonSpaceGetChar();
STATIC MuvesBool SePushToken();
STATIC MuvesBool SeRtParenGet();
STATIC bs_type SeIdentifierGet();
STATIC bs_type SeIdentifierRead();
#endif

int SeGetc(SeParseVars *vars)
{
	if (vars->fp != NULL)
	{
		return getc(vars->fp);
	}
	else  /* get character from the string */
	{
		if (vars->pos < vars->len)
		{
			return vars->str[vars->pos++];
		}					
		else if (vars->pos == vars->len)  /* end of string? */
		{
			/* buffer doesn't have new line, so return one */
			vars->pos++;
			return '\n';
		}
		else  /* new line already returned */
		{
			return EOF;  /* end-of-string */
		}
	}
}

int SeUnGetc(SeParseVars *vars, int c)
{
	if (vars->fp != NULL)
	{
		return ungetc(c, vars->fp);
	}
	else  /* put character back into the string */
	{
		if (vars->pos == 0)
		{
			return EOF;  /* oops, back too far */
		}
		else
		{
			return vars->str[--vars->pos] = c;
		}
	}
}

int SeSeek(SeParseVars *vars, long offset)
{
	if (vars->fp != NULL)
	{
		return fseek(vars->fp, offset, SEEK_SET);
	}
	else  /* set position within string */
	{
		if (offset < 0 || offset > vars->len)
		{
			return -1;
		}
		else
		{
			vars->pos = offset;
			return 0;
		}
	}
}

long SeTell(SeParseVars *vars)
{
	if (vars->fp != NULL)
	{
		return ftell(vars->fp);
	}
	else  /* get position within string */
	{
		return vars->pos;
	}
}

void SeRewind(SeParseVars *vars)
{
	if (vars->fp != NULL)
	{
		rewind(vars->fp);
	}
	else  /* set position to beginning of string */
	{
		vars->pos = 0;
	}
}


/*
	bs_type SeArgListGet( SeParseVars *vars, int c, char *tokbufp )

	This routine tests whether c is a left parenthesis, and if so
	attempts to parse a function definition parameter list from stream fp.
	tokbufp must point to a scratch buffer of SeBUFSIZE bytes.  If
	successful, the parameter list is returned in the specified name pool.

	RETURN: bs_good for success

		bs_bad if c is not a left parenthesis

		bs_ugly, print a message on the error log, and set an error
		index if c is a left parenthesis, but the parameter list cannot
		be parsed
 */
STATIC bs_type
#if STD_C
SeArgListGet( SeParseVars *vars, int c, char *tokbufp )
#else
SeArgListGet( c, tokbufp, fp, argnames )
int c;
char *tokbufp;
register FILE *fp;
NmPool *argnames;
#endif
	{	register SeToken *tokenp;
		register int argct;
	assert(tokbufp != NULL);
#if SeDEBUG == 4
#if STD_C
	ErPLog( "SeArgListGet('%s',%p,%p,%p)\n",
		IoCharStr( c ),
		(pointer) tokbufp, (pointer) vars->fp, (pointer) &vars->argnames );
#else
	ErPLog( "SeArgListGet('%s',0x%lx,0x%lx,0x%lx)\n",
		IoCharStr( c ), (long) tokbufp, (long) vars->fp, (long) argnames );
#endif
#endif
	if( c != SeCH_LF_PAREN )
		return	bs_bad;

	/* Promote previous token from SeNT_SYSNAME to SeNT_FUNCNAME. */
	assert(vars->SeStackp != NULL);
	assert(!DqIsEmpty(vars->SeStackp));
	tokenp = DqLast( vars->SeStackp, SeToken );
	assert(tokenp->type == SeNT_SYSNAME);
	tokenp->type = SeNT_FUNCNAME;

	/* Place the parameter list in the name pool. */
	argct = 0;
	do
		{
		assert(NmCount( &vars->argnames ) == argct);
		/* Get first character of the next parameter name. */
		if( (c = SeNonSpaceGetChar( vars )) == EOF )
			{
			SePrtSyntax( vars, "parameter", c );
			ErSet( SeSYNIDENT );
			return	bs_ugly;
			}
		/* Process parameter. */
		switch( SeIdentifierGet( vars, c, tokbufp, SeNT_DUMMY ) )
			{
		case bs_ugly :
			assert(ErIsSet());
			return bs_ugly;
		case bs_bad :
			SePrtSyntax( vars, "parameter", c );
			ErSet( SeSYNIDENT );
			return bs_bad;
			}
		/* Add parameter name to pool. */
		if( NmIndex( tokbufp, &vars->argnames, mTrue ) == -1 )
			{
			assert(ErIsSet());
			return bs_ugly;
			}
		/* Check for duplicates. */
		if( NmCount( &vars->argnames ) != argct+1 )
			{ /* Last parameter name not unique. */
				//EEE
			ErSet( SeDUPARGNAME );
			return bs_bad;
			}
		argct++;
		}
	while( (c = SeNonSpaceGetChar( vars )) == SeCH_COMMA );

	/* No comma, parameter list is finished; should have right paren. */
	if( c != SeCH_RT_PAREN )
		{
		SePrtSyntax( vars, "comma or right parenthesis", c );
		ErSet( SeSYNRTPAREN );
		return bs_bad;
		}
	return bs_good;
	}

/*
	bs_type SeDefGet( SeParseVars *vars )

	This routine is called whenever a system or function definition is
	expected to begin with the next valid input token on stream fp, i.e.
	for system_name=expression or function_name(parameter-list)=expression
	in a "sysdef" file.  SeDefGet() attempts to parse the system or
	function definition.  If a function definition is encountered, its
	parameter list is returned in the specified name pool which should
	be initialized by the caller.

	This function is for internal Se package use only.

	RETURN: bs_good if a system or function definition was successfully
		parsed

		bs_bad if an EOF is immediately detected; this is typically
		not an error, though this decision must be made at a higher
		level, so the error index is cleared for this condition

		bs_ugly, print a message to the error log, and set the error
		index if a syntax error or storage allocation problem arises;
		some error handling is done by the lower-level routines
 */
bs_type
#if STD_C
SeDefGet( SeParseVars *vars )
#else
SeDefGet( fp, argnames )
FILE *fp;
NmPool *argnames;
#endif
	{	char *tokbufp;		/* -> allocated scratch storage */
		register int c;		/* input character */
		long save_erindex;	/* holds ErIndex during NmIndex call */
#if SeDEBUG == 4
#if STD_C
	ErPLog( "SeDefGet(%p,%p)\n", (pointer) vars->fp, (pointer) &vars->argnames );
#else
	ErPLog( "SeDefGet(0x%lx,0x%lx)\n", (long) vars->fp, (long) argnames );
#endif
#endif
	/* Get first character of system-name or function-name. */
	if( (c = SeNonSpaceGetChar( vars )) == EOF )
		return	bs_bad;		/* Normal EOF, not an error. */
	if (vars->find_comps)  /* only from VSL */
	{
		/* at this point, all #COMP: lines have been processed */
		if (!SeInitComps(vars))
		{
			return bs_bad;
		}
		vars->find_comps = mFalse;
	}
	tokbufp = (char *)DmCalloc(SeBUFSIZE, sizeof(char ));
	/* Process System-name, if we have one. */
	switch( SeIdentifierGet( vars, c, tokbufp, SeNT_SYSNAME ) )
		{
	case bs_ugly :
		goto ret_free;
	case bs_bad :
		SePrtSyntax( vars, "identifier", c );
		ErSet( SeSYNIDENT );
		goto ret_free;
		}
	/* Check for proper use (or nonuse) of reserved identifier. */
	if( (tokbufp[0] == '_') ^ vars->SeResName )
		{
		SePrtSyntax( vars, vars->SeResName ? "reserved name"
					   : "nonreserved name", c );
		ErSet( SeSYNIDENT );
		goto ret_free;
		}
		
	/* Get argument list or assignment-operator. */
	c = SeNonSpaceGetChar( vars );
	/* Process parenthesized-argument list, if we have one. */
	switch( SeArgListGet( vars, c, tokbufp ) )
		{
	case bs_ugly :
		assert(ErIsSet());
		goto ret_free;
	case bs_good :
		c = SeNonSpaceGetChar( vars ); /* get assignment operator */
		break;
	case bs_bad :
		/* Make sure System-name names a system, not a component. */
		save_erindex = ErIndex;	/* following "failure" is non-error */
		/* 13-10-23 ch3: changed from SeComponents, okay for MUVES (VSL) */
		if( NmIndex( tokbufp, &RtComponents, mFalse ) >= 0 )
			{
			SePrtSyntax( vars, "system or function name", c );
			ErSet( SeCOMPNAME );
			goto ret_free;
			}
		ErSet( save_erindex );	/* restore previous state */
		break; /* not a function call, must be a system def. */
		}
	if( c != SeCH_ASSIGNMENT )
		{
		SePrtSyntax( vars, "assignment operator", c );
		ErSet( SeSYNASSOP );
		goto ret_free;
		}
	if( ! SePushToken( vars, SeNT_ASSIGNMENT, SeTK_ASSIGNMENT ) )
		goto ret_free;

	/* Get expression onto tokbufp stack. */
	if( ! SeExprGet( vars, tokbufp ) )
		goto ret_free;

	DmFree((genptr_t)tokbufp );
#if SeDEBUG == 1
	SePrtTokenStack( "Return from SeDefGet()", vars->SeStackp );
#endif
	return	bs_good;		/* report success */

	/* Error handling: */
ret_free:
	DmFree((genptr_t)tokbufp );
ret_ugly:
	SeFlushStack(vars);
	assert(ErIsSet());
	return	bs_ugly;		/* report error */
	}
/*
	MuvesBool SeEOLineChk( FILE *fp )

	This routine is used after an expression is parsed to check the input
	line to see if any extraneous stuff follows.  Trailing white space (WS)
	and end-of-line comments are allowed, but anything else is a syntax
	error.

	If the stream read pointer is already positioned at the next line, we're
	home free so nothing is done; otherwise, the rest of the line is scanned
	and SeNxtLine() is called before returning to ensure that the stream
	read pointer is at the beginning of the next line and the relevant
	parser status variables (i.e., SeLnAddr and SeLnNo) reflect this.

	RETURN: mFalse and print a syntax error if the EOL check fails

		mTrue otherwise
 */
#if SeDEBUG
STATIC MuvesBool
#if STD_C
SeEOLineChk( register FILE *fp )
#else
SeEOLineChk( fp )
register FILE *fp;
#endif
	{	register int c;
	assert(fp != NULL);
#if STD_C
	ErPLog( "SeEOLineChk(%p)\n", (pointer) fp );
#else
	ErPLog( "SeEOLineChk(0x%lx)\n", (long) fp );
#endif
	if( ftell( fp ) == vars->SeLnAddr )
		return	mTrue;	/* at beginning of next line to be scanned */
	/* check for trailing garbage on current line */
	for( ; ; )
		{
		switch( c = getc( fp ) )
			{
		case IoCOMMENT_CHAR:		/* trailing comment is OK */
			if( !SePassEOL( vars ) )	/* skip rest of line */
				return mFalse;	/* EOF */
			/*FALLTHROUGH*/
		case '\n':			/* tail of line was OK */
			SeNxtLine( vars );
			return	mTrue;		/* report okay */
		default:			/* (includes EOF) */
			if( ! isspace( c ) )	/* trailing WS is OK */
				{	/* extra stuff found: syntax error */
				char *msgbuf;	/* -> diagnostic message */
				char *allo = (char *)DmCalloc(BUFSIZ, sizeof(char ));
				if( allo == NULL )
					msgbuf = "garbage on end of line";
				else
					(void) sprintf( msgbuf = allo,
			"\"%s\" follows expression, end-of-line expected",
							IoCharStr( c ) );
				SePrtMsgSyntax( vars, msgbuf );
				if( c != EOF
				 && SePassEOL( vars ) )	/* skip rest */
					SeNxtLine( vars );
				if( allo != NULL )
					DmFree((genptr_t)allo );
				return	mFalse;	/* report error */
				}
			}
		}
	}
#endif

/*
	MuvesBool SeEOBufferChk( FILE *fp, const char *p, const char *bp )

	This routine is used after an identifier is parsed to check the
	input buffer (bp) to see if any extraneous stuff follows starting
	from the position in the buffer pointed to by p.  Trailing white
	space (WS) and end-of-line comments are allowed, but anything else
	is a syntax error.

	SeNxtLine() is called before returning to insure that the relevant
	parser position variables (i.e. SeLnAddr and SeLnNo) reflect that
	the parser is done with the buffered line.

	RETURN: mFalse and print a syntax error if appropriate

		mTrue otherwise
 */
#if SeDEBUG
STATIC MuvesBool
#if STD_C
SeEOBufferChk( FILE *fp, register const char *p, const char *bp )
#else
SeEOBufferChk( fp, p, bp )
FILE *fp;
register const char *p;	/* -> bp[.] */
const char *bp;	/* buffer being checked */
#endif
	{
	assert(fp != NULL);
	assert(p != NULL);
	assert(bp != NULL);
#if STD_C
	ErPLog( "SeEOBufferChk(%p,%p,%p)\n",
		(pointer) vars->fp, (pointer) p, (pointer) bp );
#else
	ErPLog( "SeEOBufferChk(0x%lx,0x%lx,0x%lx)\n",
		(long) fp, (long) p, (long) bp );
#endif
	assert(p >= bp);
	/* check for trailing garbage at end of buffer */
	for( ; *p != '\0' && *p != IoCOMMENT_CHAR; )
						/* trailing comment is OK */
		if( ! isspace( *p++ ) )		/* trailing WS is OK */
			{	/* extra stuff found: syntax error */
			char *msgbuf;	/* -> diagnostic message */
			char *allo = (char *)DmCalloc(BUFSIZ, sizeof(char ));
			/* (On UNIX, off_t is synonymous with long:) */
			(void) fseek( vars->fp, vars->SeLnAddr + (long)(p - bp), SEEK_SET );
			if( allo == NULL )
				msgbuf = "garbage on end of line";
			else
				(void) sprintf( msgbuf = allo,
			"\"%s\" follows identifier, end-of-line expected",
						IoCharStr( (int)p[-1] ) );
			SePrtMsgSyntax( vars, msgbuf );
			SeNxtLine( vars );
			if( allo != NULL )
				DmFree((genptr_t)allo );
			return	mFalse; /* error */
			}
	/* no non-WS in tail => OK */
	SeNxtLine( vars );
	return	mTrue;
	}
#endif

/*
	bs_type SeFnCallGet( SeParseVars *vars, char *tokbufp )

	This routine tests whether the next input token is a left
	parenthesis, and if so attempts to parse a function call
	argument list from stream fp.  tokbufp must point to a scratch
	buffer of SeBUFSIZE bytes.  argnames points to a name pool of
	parameters which is nonempty when parsing a function definition.

	RETURN: bs_good for success

		bs_bad if the next token is not a left parenthesis

		bs_ugly, print a message on the error log, and set an error
		index if the next token is a left parenthesis, but the parameter
		list cannot be parsed
 */
STATIC bs_type
#if STD_C
SeFnCallGet( SeParseVars *vars, char *tokbufp )
#else
SeFnCallGet( tokbufp, fp, argnames )
char *tokbufp;
register FILE *fp;
NmPool *argnames;
#endif
	{	int c;
		register SeToken *tokenp;
	assert(tokbufp != NULL);
#if SeDEBUG == 4
#if STD_C
	ErPLog( "SeFnCallGet(%p,%p,%p)\n",
		tokbufp, vars->fp, &vars->argnames );
#else
	ErPLog( "SeFnCallGet(0x%lx,0x%lx,0x%lx)\n",
		(long) tokbufp, (long) fp, (long) argnames );
#endif
#endif
	if( (c = SeNonSpaceGetChar( vars )) == EOF )
		return	bs_bad;		/* normal EOF, not an error */
	else
	if( c != SeCH_LF_PAREN )
		{
		if( SeUnGetc(vars, c) == EOF )
			{
			SePrtErrMsg(vars, "Unget failed where function call "
				"argument list was allowed.");
			ErSet( SeUNGET );
			return bs_ugly;		/* report error */
			}
		return	bs_bad;
		}

	/* Promote previous token from SeNT_SYSNAME to SeNT_FNCALL. */
	assert(vars->SeStackp != NULL);
	assert(!DqIsEmpty(vars->SeStackp));
	tokenp = DqLast( vars->SeStackp, SeToken );
	assert(tokenp->type == SeNT_SYSNAME);
	tokenp->type = SeNT_FNCALL;
	vars->SeFuncCnt++;

	/* Push the left parenthesis token on the stack. */
	if( ! SePushToken( vars, SeNT_LF_PAREN, SeTK_LF_PAREN ) )
		return bs_ugly;
	/* Push the expression list on the stack. */
	do
		{ /* Get an expression. */
		if( ! SeExprGet( vars, tokbufp ) )
			return	bs_ugly;
		if(	(c = SeNonSpaceGetChar( vars )) == SeCH_COMMA
		    &&	! SePushToken( vars, SeNT_CMA, SeTK_COMMA ) )
			return bs_ugly;
		}
	while( c == SeCH_COMMA );

	/* No comma, argument list is finished; put back look-ahead. */
	if( SeUnGetc(vars, c) == EOF )
		{
		SePrtErrMsg(vars, "Unget failed at end of function call "
			"argument list.");
		ErSet( SeUNGET );
		return bs_ugly;		/* report error */
		}

	vars->SeFuncCnt--;
	/* Push the right parenthesis token on the stack. */
	if( ! SeRtParenGet( vars ) )
		return	bs_ugly;
	else
		return	bs_good;
	}

/*
	int SeNonSpaceGetChar( SeParseVars *vars )

	This routine returns the next non-white-space character from stream fp.
	Comments are skipped over and parser position variables are kept current
	with SeNxtLine().  Multi-character operators such as '<<' are mapped to
	single-character equivalents, for ease of handling.

	RETURN: the next valid non-white-space character on the input stream

		EOF if end-of-file is encountered (this is not handled as an
		error, because it may be a normal situation), and also if an
		attempt to "unread" a character fails (should never happen).
 */
STATIC int
#if STD_C
SeNonSpaceGetChar( SeParseVars *vars )
#else
SeNonSpaceGetChar( fp )
register FILE *fp;
#endif
	{	register int c;
#if SeDEBUG == 4
#if STD_C
	ErPLog( "SeNonSpaceGetChar(%p)\n", (pointer) vars->fp );
#else
	ErPLog( "SeNonSpaceGetChar(0x%lx)\n", (long) fp );
#endif
#endif
	do	{
		if( (c = SeGetc(vars)) == IoCOMMENT_CHAR )
			/* skip rest of line */
			c = SePassEOL( vars, mTrue ) ? '\n' : EOF;
		if( c == '\n' )
			SeNxtLine( vars );
		else if( c == '<' || c == '>' )
			{		/* test for multi-character operators */
			register int peekc = SeGetc(vars);	/* look ahead */
			if( peekc == EOF )
				return c;	/* we'll see EOF next time */
			else if( peekc == c )	/* '<<' or '>>' */
				{	/* second character remains consumed */
				assert(peekc == c);
				return	c == '<' ? SeCH_MIN : SeCH_MAX;
				}
			else if( peekc == '=' )	/* '<=' or '>=' */
				{	/* second character remains consumed */
				assert(peekc == '=');
				return	c == '<' ? SeCH_LTEQ : SeCH_GTEQ;
				}
			else if( SeUnGetc(vars, peekc) == EOF )
				{
				SePrtErrMsg(vars, "Unget of '%s' after '%c' "
					"failed; parsing terminated",
					IoCharStr( peekc ), c );
				ErSet( SeUNGET );
				return EOF;	/* give up on file */
				}
			else if( SeDebugging )
				{
				assert(c == SeCH_LT || c == SeCH_GT);
				}
			}
		}
	while( isspace( c ) );
	return	c;			/* may be EOF */
	}

/*
	MuvesBool SePassEOL( SeParseVars *vars )

	Move the stream read pointer past the next newline.

	RETURN:	mFalse if EOF seen before newline (message printed and error
		index set)

		mTrue otherwise
 */
STATIC MuvesBool
#if STD_C
SePassEOL( SeParseVars *vars, MuvesBool allow_comps )
#else
SePassEOL( fp )
register FILE *fp;
#endif
	{	int	c;
		static char *comp_id = "COMP:";
		static char *etable = "TABLE:";
		MuvesBool find_table = vars->allow_table;
		int i = 0;

	while( (c = SeGetc(vars)) != EOF )
	{
		/* 11-06-03 ch3: check for special "#COMP:xxxxx" syntax (VSL) */
		if (allow_comps && vars->find_comps)
		{
			if (comp_id[i] == '\0')
			{
				/* end of COMP: keyword, now read comp name */
				bs_type status;
				char *tokbufp = (char *)DmCalloc(SeBUFSIZE,
					sizeof(char));
				status = SeIdentifierRead(vars, &c, tokbufp);
				if (status != bs_good)
				{
					/* just ignore error, assume no comp */
					ErClear();
				}
				else
				{
					/* add to RtComponents name pool */
					if (NmIndex(tokbufp, &RtComponents,
						mTrue) == -1)
					{
						assert(ErIsSet());
						/* 11-07-12 ch3; fix mem leak */
						DmFree(tokbufp);
						return mFalse;
					}

					/* terminated by newline or comment? */
					if (c == '\n' || c == IoCOMMENT_CHAR )
					{
						/* at end of line */
						/* 11-07-12 ch3; fix mem leak */
						DmFree(tokbufp);
						return mTrue;  /* done */
					}
				}
				/* done looking for component name */
				DmFree(tokbufp);
				allow_comps = mFalse;  /* now find newline */
			}
			else if (c == comp_id[i])
			{
				i++;
				find_table = mFalse;
			}
			else
			{
				/* didn't find "#COMP:" so stop looking */
				allow_comps = mFalse;
			}
		}
		if (find_table)
		{
			if (etable[i] == '\0')
			{
				if (vars->etable == NULL)
				{
					vars->etable = DmMalloc(SeBUFSIZE);
				}
				i = 0;
				while (c != '\n')
				{
					vars->etable[i++] = c;
					if ((c = SeGetc(vars)) == EOF)
					{
						break;
					}
				}
				vars->etable[i] = '\0';
				vars->allow_table = mFalse;
			}
			else if (c == etable[i])
			{
				i++;
				allow_comps = mFalse;
			}
			else
			{
				/* didn't find "#TABLE:" so stop looking */
				find_table = mFalse;
			}
		}
					
		if ( c == '\n' )
			return mTrue;
	}
	SePrtMsgSyntax( vars,
			"End of file encountered while looking for newline" );
	ErSet( SeSYNPREMEOF );	/* premature EOF */
	return mFalse;
	}


/*
	MuvesBool SePushToken( SeParseVars *vars, int type, const char *text )

	This routine places an input token (text) on the parser stack.
	The type argument is an integer identifier for the kind of token
	that text is understood to represent.

	The parsing flag indicates that the input is being scanned but not
	compiled, so if parsing is set, this routine does nothing.  Otherwise,
	SePushToken() allocates an SeToken node and a buffer to copy text
	into, fills in the SeToken node, and appends it to SeStackp.

	RETURN: mTrue if either parsing is set or the token has been
		allocated and placed on the parser stack

		mFalse, print out a message on the error log, and set an
		error index if storage cannot be allocated
 */
STATIC MuvesBool
#if STD_C
SePushToken( SeParseVars *vars, int type, const char *text )
#else
SePushToken( type, text )
int type;
const char *text;
#endif
	{	register SeToken *tokenp;
	assert(type >= 0);
	assert(text != NULL);
#if SeDEBUG == 2
	ErPLog( "SePushToken:\tTOKEN %2d\t%s\n", type, text );
#endif
	if( vars->parsing )
		return	mTrue;
	tokenp = (SeToken  *)DmXalloc(SeToken);
	tokenp->text = DmStrDup(text );
	tokenp->type = (SeNodeCategory)type;
	tokenp->lhsp = tokenp->rhsp = NULL;
	assert(vars->SeStackp != NULL);
	DqAppend( vars->SeStackp, &tokenp->link );
	return	mTrue;
	}

/*
	void SeFlushStack( SeParseVars *vars )

	This routine clears the parse stack.  It is invoked from SeDefGet(),
	or SeSysCompile() when an attempt to parse an expression fails.
 */
void
#if STD_C
SeFlushStack( SeParseVars *vars )
#else
SeFlushStack()
#endif
	{	register SeToken *tokenp;
	assert(vars->SeStackp != NULL);
#if SeDEBUG == 4
	ErPLog( "SeFlushStack\n" );
#endif
	while( (tokenp = DqTPop( vars->SeStackp, SeToken )) != NULL )
		{
		assert(tokenp->text != NULL);
		DmFree((genptr_t)tokenp->text );
		if( tokenp->lhsp != NULL )
			SeExpFree( tokenp->lhsp );
		if( tokenp->rhsp != NULL )
			SeExpFree( tokenp->rhsp );
		if( SeDebugging )
			{
			tokenp->type = SeNT_UNSET;	/* safety net */
			tokenp->text = NULL;
			tokenp->lhsp = tokenp->rhsp = NULL;
			}

		DmFree((genptr_t)tokenp );
		}
	assert(DqIsEmpty( vars->SeStackp ));
	return;
	}

/*
	void SePrtErrMsg( SeParseVars *vars, const char *problem )

	This routine is called when a syntax error is found by the parser
	to print a diagnostic to the error log indicating the line and
	character in the input stream fp where the error was detected.

	First, a message is printed denoting the line number and problem
	(which should be a string that describes the error).  Next, the
	offending line is output followed by a line that is blank
	except for a caret which points to the offending character's
	position in the input line.
 */
/* 11-04-22 ch3: new function to intercept ErPLog() calls (VSL) */
STATIC void
SePrtErrMsg( SeParseVars *vars, const char *format, ... )
{
	va_list			ap;

	va_start( ap, format );

	if (vars->errmsg != NULL)
	{
		vsprintf(vars->errmsg, format, ap);
		vars->errloc = -1;
	}
	else
	{
		ErPVLog(format, ap);
		ErLog("\n");
	}
}

/*
	void SePrtMsgSyntax( SeParseVars *vars, const char *problem )

	This routine is called when a syntax error is found by the parser
	to print a diagnostic to the error log indicating the line and
	character in the input stream fp where the error was detected.

	First, a message is printed denoting the line number and problem
	(which should be a string that describes the error).  Next, the
	offending line is output followed by a line that is blank
	except for a caret which points to the offending character's
	position in the input line.
 */
STATIC void
#if STD_C
SePrtMsgSyntax( SeParseVars *vars, const char *problem )
#else
SePrtMsgSyntax( fp, problem )
FILE 	*fp;
const char *problem;
#endif
	{	register char *errbuf;	/* temporary copy of offending line */
		long curaddr;		/* current fp offset (UNIX assumed) */
		static const char syntax[] = "Syntax error: line %d: %s";

	assert(problem != NULL);
	curaddr = SeTell(vars) - 1L;

	/* 11-04-22 ch3: check if put error into buffer (VSL) */
	if (vars->errmsg != NULL)
	{
		sprintf(vars->errmsg, syntax, vars->SeLnNo, problem);
		vars->errloc = curaddr;  /* offset into entire string */
		return;
	}

	ErPLog( syntax, vars->SeLnNo, problem );
	ErLog(":\n");
	if (SeSeek(vars, vars->SeLnAddr) != 0)	/* beginning of line */
		{
		if( SeDebugging )
			{
			extern int errno;
			ErPLog( "%s seek failed (offset=%ld errno=%d).\n",
			"SePrtSyntax:", vars->SeLnAddr, errno );
			}
		else
			ErPLog( "Seek failed while printing %s\n",
					"syntax error message." );
		}
	else
		{	bs_type bsret;
		errbuf = (char *)DmCalloc(SeBUFSIZE, sizeof(char ));
		if( (bsret = IoGetLine( errbuf, SeBUFSIZE, vars->fp )) == bs_good )
			{	register int i, n = (int) (curaddr - vars->SeLnAddr);
			assert(n >= 0 && n < SeBUFSIZE);
			(void) ErLog( "%s\n", errbuf );
			for( i = 0; i < n; i++ )
				{
				if( errbuf[(int)i] == '\t' )
					(void) ErLog( "\t" );
				else
					(void) ErLog( " " );
				}
			(void) ErLog( "^\n" );
			}
		if( bsret == bs_ugly )
			ErPLog( "BUG: SePrtMsgSyntax: Error reading file.\n" );
		DmFree((genptr_t)errbuf );
		}
	}

/*
	void SePrtSyntax( SeParseVars *vars, const char *expected, int around )

	This routine is called when a syntax error is found by the parser
	to print a diagnostic to the error log indicating the line and
	character in the input stream fp where the error was detected.

	First, a message is printed denoting the line number.  Then, if
	expected is non-NULL, a description of the token that the parser
	expected to be next is added to the message.  Also, the character
	around (which may be EOF) that was read instead of an acceptable
	input token is added to the message.  Next, the offending line is
	output followed by a line that is blank except for a caret which
	points to the offending character's position in the input line.
 */
STATIC void
#if STD_C
SePrtSyntax( SeParseVars *vars, const char *expected, int around )
#else
SePrtSyntax( fp, expected, around )
FILE *fp;
const char *expected;
int around;
#endif
	{	static const char expstr[] = " expected";
		static const char arstr[] = " around \"";
		static const char endstr[] = "\"";
		char *msgbuf;		/* -> buffer allocated for message */
		int msglen;		/* # bytes allocated for message */
	msglen = sizeof arstr - 1 + IoMAX_CharStr + sizeof endstr - 1 + 1;
	if( expected != NULL )
		msglen += strlen( expected ) + sizeof expstr - 1;
	msgbuf = (char *)DmCalloc(msglen, sizeof(char ));
	if( expected != NULL )
		(void) strcat( strcat( strcpy( msgbuf, expected ),
						expstr ),
					arstr );
	else
		(void) strcpy( msgbuf, arstr );
	(void) strcat( strcat( msgbuf, IoCharStr( around ) ), endstr );
	SePrtMsgSyntax( vars, msgbuf );
	DmFree((genptr_t)msgbuf );
	return;
	}

#if SeDEBUG
STATIC void
#if STD_C
SePrtTokenStack( const char *label, DqNode *stackp )
#else
SePrtTokenStack( label, stackp )
const char *label;
DqNode *stackp;
#endif
	{	register SeToken *tokenp;
	if( label != NULL )
		ErPLog( "%s:\n", label );
	DqEACH( stackp, tokenp, SeToken )
		ErPLog( "\t\"%s\" [%s]\n",
			tokenp->text, SeCvtToStr( tokenp->type ) );
	}
#endif

/*
	MuvesBool SeRtParenGet( SeParseVars *vars )

	This routine attempts to read a right parenthesis as the next valid
	non-whitespace character in the input stream and insert it in the parser
	token stack.

	RETURN: mTrue for success

		mFalse, print a diagnostic to the error log, and set an error
		index if either the right parenthesis is not found to be
		the next non-whitespace, non-comment character or the attempt
		to add it to the stack (SePushToken()) fails
 */
STATIC MuvesBool
#if STD_C
SeRtParenGet( SeParseVars *vars )
#else
SeRtParenGet( fp )
register FILE *fp;
#endif
	{	register int c;
#if SeDEBUG == 4
#if STD_C
	ErPLog( "SeRtParenGet(%p)\n", (pointer) vars->fp );
#else
	ErPLog( "SeRtParenGet(0x%lx)\n", (long) fp );
#endif
#endif
	if( (c = SeNonSpaceGetChar( vars )) == SeCH_RT_PAREN )
		return	SePushToken( vars, SeNT_RT_PAREN, SeTK_RT_PAREN );
	/* Handle syntax error. */
	if( c != EOF )
		SePrtSyntax( vars, "right parenthesis", c );
	else	{
		SePrvLine(vars);
		SePrtMsgSyntax( vars, "right parenthesis expected" );
		}
	ErSet( SeSYNRTPAREN );
	return	mFalse;
	}

/*
	bs_type SeIdentifierGet( SeParseVars *vars, int c, char *tokbufp, int type )

	This routine decides whether c is the start of an identifier token
	and if so, attempts to read the remainder of the token from input
	stream fp, copy it into the buffer pointed to by tokbufp, and
	insert it in the parser token stack with the specified type (with
	the exception of SeNT_DUMMY tokens which don't get saved).

	c is a character which has just been read, but not pigeonholed yet.
	To qualify as starting an identifier, it could be a double-quote mark,
	an escape symbol, or a valid identifier character.  tokbufp must
	point to enough storage to hold the identifier (SeBUFSIZE bytes).

	RETURN: bs_good for success

		bs_bad if the input token is not a legal identifier

		bs_ugly, print a message on the error log, and set an error
		index if the identifier token cannot be placed on the parser
		stack (side effect of SePushToken() failure) or if the
		identifier contains improper characters (e.g. escaped controls)
 */

STATIC bs_type
#if STD_C
SeIdentifierGet( SeParseVars *vars, int c, char *tokbufp, int type )
#else
SeIdentifierGet( c, tokbufp, fp, type )
register int c;
char *tokbufp;
register FILE *fp;
int type;
#endif
	{
	bs_type status;

	assert(tokbufp != NULL);
#if SeDEBUG == 4
#if STD_C
	ErPLog( "SeIdentifierGet('%s',%p,%p,%d) line=%d, addr=%ld\n",
		IoCharStr( c ), (pointer) tokbufp, (pointer) vars->fp,
		type, vars->SeLnNo, vars->SeLnAddr );
#else
	ErPLog( "SeIdentifierGet('%s',0x%lx,0x%lx,%d) line=%d, addr=%ld\n",
		IoCharStr( c ), (long) tokbufp, (long) fp, type,
		vars->SeLnNo, vars->SeLnAddr );
#endif
#endif
	/* 11-06-03 ch3: replaced code with function call (VSL) */
	status = SeIdentifierRead(vars, &c, tokbufp);
	if (status != bs_good)
		return status;

	/* SeNT_DUMMY types don't get pushed on the stack. */
	if( type == SeNT_DUMMY )
		return bs_good;

	/* Push all other tokens on stack. */
	if( SePushToken( vars, type, tokbufp ) )
		return	bs_good;	/* report success */
	else
		return	bs_ugly;	/* report error */
	}

/* 11-06-03 ch3: created function from parts of SeIdentifierGet() (VSL) */
STATIC bs_type
#if STD_C
SeIdentifierRead(SeParseVars *vars, int *c, char *tokbufp)
#else
SeIdentifierRead(vars, c, tokbufp)
SeParseVars *vars;
register int *c;
char *tokbufp;
#endif
	{	register char *outbuf;	/* -> tokbufp[.] for "output" */
		register MuvesBool quoted;	/* identifier is in "..." */
	outbuf = tokbufp;
	if( SeIS_IDENTIFIER( *c ) )
		{
		quoted = mFalse;
		assert(isprint( *c ));
		*outbuf++ = *c;		/* transfer first character */
		}
	else
	if( ! (quoted = *c == SeCH_DBL_QUOTE) )
		if( *c == SeCH_ESCAPE )	/* escaped character */
			if( isprint( *c = SeGetc(vars) ) )	/* get escaped symbol */
				*outbuf++ = *c;	/* transfer to output buffer */
			else	{
				SePrtSyntax( vars, "printable character", *c );
				ErSet( SeSYNIDENT );
				return	bs_ugly;	/* report error */
				}
		else			/* bogus first character */
			return	bs_bad;	/* report non-identifier */
	/* Transfer the rest of the identifier to outbuf (tokbufp). */
	for( ; ; )
		{
		/* escapes work even in quoted strings: */
		if( (*c = SeGetc(vars)) == SeCH_ESCAPE )
			*c = SeGetc(vars);	/* get escaped symbol */
		else
		if( quoted )
			{		/* processing a quoted string */
			if( *c == SeCH_DBL_QUOTE )	/* marks the end */
				break;
			}
		else
		if( *c == '\n' )
			{
			SeNxtLine( vars );
			break;		/* new-line ends identifier */
			}
		else
		if( *c == IoCOMMENT_CHAR )	/* process comment */
			{
			/* skip rest of line */
			if( ! SePassEOL( vars, mFalse ) )
				return bs_ugly;	/* EOF */
			SeNxtLine( vars );
			break;
			}
		else
		if( ! SeIS_IDENTIFIER( *c ) )	/* past the end; includes EOF */
			{
			if ( *c == EOF )
				{
				SePrtErrMsg(vars, "Syntax error: End of file "
					"encountered in identifier, current "
					"buffer \"%s\"", outbuf);
				ErSet( SeSYNPREMEOF );	/* premature EOF */
				return bs_ugly;	/* report error */
				}
			else
				if( SeUnGetc(vars, *c) == EOF )
					{
					SePrtErrMsg(vars, "Unget failed after "
						"parsing identifier");
					ErSet( SeUNGET );
					return bs_ugly;	/* report error */
					}
			break;
			}
		else	{		/* within identifier */
			*outbuf++ = *c;	/* transfer to output buffer */
			if( outbuf - tokbufp >= SeBUFSIZE )
				goto too_long;
			assert(isprint( *c ));
			continue;	/* skip printability test; saves time */
			}

		if( isprint( *c ) )
			{
			*outbuf++ = *c;	/* transfer to output buffer */
			if( outbuf - tokbufp >= SeBUFSIZE )
				{
too_long:			SePrtMsgSyntax( vars, "Input line too long" );
				ErSet( SeTOOLONG );
				return	bs_ugly;	/* report error */
				}
			}
		else	{
			SePrtSyntax( vars, "printable character", *c );
			ErSet( SeSYNIDENT );
			return	bs_ugly;	/* report error */
			}
		}
	assert(outbuf - tokbufp < SeBUFSIZE);
	*outbuf = '\0';			/* terminate output string */
	return bs_good;
	}

/*
	bs_type SeConstGet( SeParseVars *vars, int c, char *tokbufp )

	This routine decides whether c is the start of a numeric token
	and if so, attempts to read the remainder of the token from input
	stream fp, copy it into the buffer pointed to by tokbufp, and
	insert it in the parser token stack with type SeNT_CONSTANT.

	c is a character which has just been read, but not pigeonholed yet.
	To qualify as starting a numeric token, it could be a either a decimal
	point or a digit.  tokbufp must point to enough storage to hold the
	constant (SeBUFSIZE bytes).  If the token is found to be an identifier
	(identifiers may begin with one or more digits or periods), the input
	stream is reset to point to the same place it was when SeConstGet() was
	invoked, and mFalse is returned.

	RETURN: bs_good for success

		bs_bad if the input token is not a legal numeric constant
		(if the token is found to be an identifier, the stream was
		successfully reset to its initial state)

		bs_ugly, print a message on the error log, and set an error
		index if the token is found to be an identifier and the
		stream could not be reset to its initial state

		bs_ugly, print a message on the error log, and set an error
		index if an improper character is found in the token

		bs_ugly, print a message on the error log, and set an error
		index if the constant token cannot be placed on the parser
		stack (side effect of SePushToken() failure)
 */
STATIC bs_type
#if STD_C
SeConstGet( SeParseVars *vars, int c, char *tokbufp )
#else
SeConstGet( c, tokbufp, fp )
register int c;
char *tokbufp;
register FILE *fp;
#endif
	{	register char *outbuf;	/* -> tokbufp[.] for "output" */
		register MuvesBool decimal;	/* decimal point seen */
		long init_offset;	/* records initial stream position */
	assert(tokbufp != NULL);
#if SeDEBUG == 4
#if STD_C
	ErPLog( "SeConstGet('%s',%p,%p) line=%d, addr=%ld\n",
		IoCharStr( c ), (pointer) tokbufp, (pointer) vars->fp,
		vars->SeLnNo, vars->SeLnAddr );
#else
	ErPLog( "SeConstGet('%s',0x%lx,0x%lx) line=%d, addr=%ld\n",
		IoCharStr( c ), (long) tokbufp, (long) fp, vars->SeLnNo, vars->SeLnAddr );
#endif
#endif
	outbuf = tokbufp;
	if( ! (decimal = c == SeCH_DECIMAL_PT)
	 && ! isdigit( c ) )
		return	bs_bad;		/* report non-constant */
	init_offset = SeTell(vars);	/* remember position for later reset */
	/* Transfer the constant to outbuf (tokbufp). */
	for( ; ; )
		{
		*outbuf++ = c;		/* transfer to output buffer */
		if( outbuf - tokbufp >= SeBUFSIZE )
			{
			SePrtMsgSyntax( vars, "Input line too long" );
			ErSet( SeTOOLONG );
			return	bs_ugly;	/* report error */
			}
		if( (c = SeGetc(vars)) == '\n' )
			{
			SeNxtLine( vars );
			break;		/* new-line ends constant */
			}
		else
		if( c == IoCOMMENT_CHAR )	/* process comment */
			{
			/* skip rest of line */
			if( ! SePassEOL( vars, mFalse ) )
				return bs_ugly;	/* EOF */
			SeNxtLine( vars );
			break;
			}
		else
		if( ! decimal && c == SeCH_DECIMAL_PT )
			decimal = mTrue;
		else
		if( !isdigit( c ) )
			{
			if( SeIS_IDENTIFIER( c ) || c == SeCH_ESCAPE )
				{	/* oops, this is really an identifier */
				if (SeSeek(vars, init_offset) != 0)
					{

					if(SeDebugging)
						{	
						extern int errno;
						ErPLog(
			"SeConstGet: seek failed (offset=%ld errno=%d).\n",
						init_offset, errno );
						}
					else
					   ErPLog( "Identifier seek failed.\n" );

					ErSet( SeBADSEEK );
					return	bs_ugly;
					}
				return	bs_bad;	/* report non-constant */
				}
			if ( c == EOF )
				{
				SePrtMsgSyntax( vars,
					"End of file encountered in constant" );
				ErSet( SeSYNPREMEOF );	/* premature EOF */
				return bs_ugly;	/* report error */
				}
			else
			if( SeUnGetc(vars, c) == EOF )
				{
				SePrtErrMsg(vars, "Unget failed after parsing "
					"constant");
				ErSet( SeUNGET );
				return bs_ugly;	/* report error */
				}
			if(	! isspace( c ) && c != SeCH_RT_PAREN
			    &&	! SeISCBINARY_OP( c ) && c != SeCH_COMMA )
				{
				SePrtSyntax( vars, "digit or decimal point", c );
				ErSet( SeSYNCONST );
				return	bs_ugly;
				}
			break;	/* random char, including EOF */
			}
		}
	assert(outbuf - tokbufp < SeBUFSIZE);
	*outbuf = '\0';			/* terminate output string */
	if( SePushToken( vars, SeNT_CONSTANT, tokbufp ) )
		return	bs_good;	/* report success */
	else
		return	bs_ugly;	/* report error */
	}

/*
	bs_type SeParenExprGet( SeParseVars *vars, int c, char *tokbufp )

	This routine tests whether c is a left parenthesis, and if so
	attempts to parse a parenthesized expression from stream fp.
	tokbufp must point to a scratch buffer of SeBUFSIZE bytes.
	argnames is a name pool of arguments which is nonempty when
	parsing a function definition.

	RETURN: bs_good for success

		bs_bad if c is not a left parenthesis

		bs_ugly, print a message on the error log, and set an error
		index if c is a left parenthesis, but the expression cannot
		be parsed
 */
STATIC bs_type
#if STD_C
SeParenExprGet( SeParseVars *vars, int c, char *tokbufp )
#else
SeParenExprGet( c, tokbufp, fp, argnames )
int c;
char *tokbufp;
register FILE *fp;
NmPool *argnames;
#endif
	{
	assert(tokbufp != NULL);
#if SeDEBUG == 4
#if STD_C
	ErPLog( "SeParenExprGet('%s',%p,%p,%p)\n",
		IoCharStr( c ), (pointer) tokbufp,
		vars->fp, &vars->argnames );
#else
	ErPLog( "SeParenExprGet('%s',0x%lx,0x%lx,0x%lx)\n",
		IoCharStr( c ), (long) tokbufp, (long) fp, (long) argnames );
#endif
#endif
	if( c != SeCH_LF_PAREN )
		return	bs_bad;
	/* Parse a parenthesized expression. */
	if(   !	SePushToken( vars, SeNT_LF_PAREN, SeTK_LF_PAREN )
	   || !	SeExprGet( vars, tokbufp )
	   || ! SeRtParenGet( vars )
		)
		return	bs_ugly;
	else
		return	bs_good;
	}

/*
	bs_type SeOpUnaryGet( SeParseVars *vars, int c )

	This routine tests whether c is a unary operator, and if so attempts
	to place it on the parser stack.

	RETURN: bs_good for success

		bs_bad if c is not a unary operator

		bs_ugly, print a diagnostic to the error log, and set an error
		index if the attempt to add the token to the stack fails

 */
STATIC bs_type
#if STD_C
SeOpUnaryGet( SeParseVars *vars, int c )
#else
SeOpUnaryGet( c )
register int c;
#endif
	{	register int i;		/* indexes SeTtbl[] */
#if SeDEBUG == 4
	ErPLog( "SeOpUnaryGet('%s')\n", IoCharStr( c ) );
#endif
	for( i = SeLoUnary; i <= SeHiUnary; i++ )
		{
		assert(i < Elements( SeTtbl ));	/* bounds check */
		assert(SeTtbl[i].ts != NULL);
		if( c == SeTtbl[i].tc )
			return	SePushToken( vars, i, SeTtbl[i].ts )
				? bs_good : bs_ugly;
		}
	return	bs_bad;			/* op not in table */
	}


/*

	void SeListPromote( SeParseVars *vars )

	Examine stack and if it qualifies as a list definition, promote it
	to one by changing the type of the first node.

*/
STATIC void
#if STD_C
SeListPromote( SeParseVars *vars )
#else
SeListPromote()
#endif
	{	SeToken *systokp;
		MuvesBool leftofassign = mFalse;
#if SeDEBUG == 4
	SePrtTokenStack( "SeListPromote()", vars->SeStackp );
#endif
	DqREVEACH( vars->SeStackp, systokp, SeToken )
		{
		switch( systokp->type )
			{
		case SeNT_LISTNAME :
			if( systokp == DqFirst( vars->SeStackp, SeToken ) )
				return; /* already promoted */
			break;
		
		/* The following nodes could be members, or if they are the
		   first node, and left of an assignment operator, they need
		   to be promoted. */
		case SeNT_SYSNAME :
		case SeNT_QUALSYS :
		case SeNT_QUALIST :
			if( systokp == DqFirst( vars->SeStackp, SeToken ) )
				{
				if( ! leftofassign )
					{
					if (vars->errmsg == NULL)
					{
					ErPLog( "BUG: SeListPromote: no %s node found in stack.\n",
						SeCvtToStr( SeNT_ASSIGNMENT ) );
					}
					return;
					}
				systokp->type = SeNT_LISTNAME;
				return;
				}
			break;

		/* The following node types could be part of a list: */
		case SeNT_ASSIGNMENT :
			leftofassign = mTrue;
			/*FALLTHROUGH*/
		case SeNT_DBL_QUOTE :
		case SeNT_LIST :
		case SeNT_QUALOP :
		case SeNT_CQUALIFIER :
		case SeNT_COMPNAME :
		case SeNT_QUALCOMP :
		case SeNT_LF_SQUARE :
		case SeNT_RT_SQUARE :
			break;

		/* The following node types could NOT be part of a list: */
		case SeNT_LF_PAREN :
		case SeNT_RT_PAREN :
		case SeNT_LF_CURLY :
		case SeNT_RT_CURLY :
		case SeNT_CMA :
		case SeNT_NOT :
		case SeNT_ANOT :
		case SeNT_ABS :
		case SeNT_BOOL :
		case SeNT_AND :
		case SeNT_OR :
		case SeNT_MIN :
		case SeNT_MAX :
		case SeNT_XOR :
		case SeNT_SUM :
		case SeNT_DIFF :
		case SeNT_PROD :
		case SeNT_QUOT :
		case SeNT_LT :
		case SeNT_GT :
		case SeNT_PARAM :
		case SeNT_CONSTANT :
		case SeNT_EXPR :
		case SeNT_FUNCNAME :
		case SeNT_ARGUMENT :
		case SeNT_FNCALL :
		case SeNT_RUNIF :
		case SeNT_RNORM :
		case SeNT_MOFN :
		case SeNT_PKD :
		case SeNT_ORCA :  /* 02-07-27 ch3: added to support _orca() */
		case SeNT_EVAL :
			break;
		default :
			if (vars->errmsg == NULL)
			{
			ErPLog( "BUG: SeListPromote: %s type not handled.\n",
				SeCvtToStr( systokp->type ) );
			}
			return;
			}
		}
	}

/*
	MuvesBool SeBinOpExpGet( SeParseVars *vars, char *tokbufp )

	This routine is called after an operand (expression) has been
	parsed to determine if the expression is complete or if a binary
	operator remains on the input stream fp.  There may be multiple
	binary operators in an expression, so this routine can recurse
	(indirectly through SeExprGet()).  SeBinOpExpGet() fetches the
	next input token and attempts to parse it as a binary operator
	followed by an operand.  tokbufp must point to enough storage
	for any input token (SeBUFSIZE bytes).  argnames is a name pool
	of arguments which is nonempty when parsing a function definition.

	NOTE: SeBinOpExpGet(), unlike most similar routines in this module,
	returns mTrue when it fails to find the target token (binary operator).
	This is because SeBinOpExpGet() is called only after an operand has
	just been parsed which is a whole expression in itself; therefore an
	infix binary operator and its right operand is never required to
	complete an expression.

	RETURN: mTrue if EOF is detected, the next valid character on the
		input stream indicates the end of an expression, or a
		binary operator-operand pair is parsed

		mFalse, print a message on the error log, and set an error
		index if the parsed tokens cannot be placed on the stack
		or if a syntax error is detected

 */
STATIC MuvesBool
#if STD_C
SeBinOpExpGet( SeParseVars *vars, char *tokbufp )
#else
SeBinOpExpGet( tokbufp, fp, argnames )
char *tokbufp;
register FILE *fp;
NmPool *argnames;
#endif
	{	register int c;		/* potential binary op symbol */
		register int i;		/* indexes SeTtbl[] */
	assert(tokbufp != NULL);
#if SeDEBUG == 4
#if STD_C
	ErPLog( "SeBinOpExpGet(%p,%p,%p)\n",
		tokbufp, vars->fp, &vars->argnames );
#else
	ErPLog( "SeBinOpExpGet(0x%lx,0x%lx,0x%lx)\n",
		(long) tokbufp, (long) fp, (long) argnames );
#endif
#endif
	if( (c = SeNonSpaceGetChar( vars )) == EOF )
		return	mTrue;		/* normal EOF, not an error */
	for( i = SeLoBinary; i <= SeHiBinary; i++ )
		{
		assert(i < Elements( SeTtbl ));	/* bounds check */
		assert(SeTtbl[i].ts != NULL);
		if( c == SeTtbl[i].tc )
			{
			if( (i == SeNT_LIST ) && (vars->SeFuncCnt == 0) )
				SeListPromote(vars);
			return	   SePushToken( vars, i, SeTtbl[i].ts )
				&& SeExprGet( vars, tokbufp );
					/* rt operand */
			}
		}
	/* There may be a syntactic error; check for end of expression. */
	/* Only comma, ), or an identifier may occur next. */
	if(	c != SeCH_RT_PAREN && ! SeIS_IDENTIFIER( c )
	   &&	c != SeCH_DBL_QUOTE && c != SeCH_ESCAPE && c != SeCH_COMMA
		)
		{
		SePrtSyntax( vars, "possible binary operator", c );
		ErSet( SeSYNST );
		return	mFalse;		/* report error */
		}
	else
	/* No binary-operator, expression is finished; put back look-ahead. */
	if( SeUnGetc(vars, c) == EOF )
		{
		SePrtErrMsg(vars, "Unget failed where optional binary operator "
			"was allowed");
		ErSet( SeUNGET );
		return mFalse;		/* report error */
		}
	return	mTrue;			/* report success (not binary op) */
	}

/*
	MuvesBool SeExprGet( SeParseVars *vars, char *tokbufp )

	This routine is called whenever an expression is expected to begin
	with the next valid input token on stream fp.  SeExprGet() attempts
	to parse that expression.  tokbufp must point to enough storage for
	any token (SeBUFSIZE bytes).  This routine may recurse, since
	expressions may be composed of sub-expressions.  argnames is a name
	pool which is nonempty when parsing a function definition.

	RETURN: mTrue if an expression was successfully parsed

		mFalse, print a message to the error log, and set the error
		index if a syntax error, end of file, or storage allocation
		problem arises; some error handling is done by the lower-level
		routines
 */
STATIC MuvesBool
#if STD_C
SeExprGet( SeParseVars *vars, char *tokbufp )
#else
SeExprGet( tokbufp, fp, argnames )
char *tokbufp;
register FILE *fp;
NmPool *argnames;
#endif
	{	register int c;		/* input character */
top:
	assert(tokbufp != NULL);
#if SeDEBUG == 4
#if STD_C
	ErPLog( "SeExprGet(%p,%p,%p) line=%d, addr=%ld\n",
		(pointer) tokbufp, (pointer) vars->fp, (pointer) &vars->argnames,
		vars->SeLnNo, vars->SeLnAddr );
#else
	ErPLog( "SeExprGet(0x%lx,0x%lx,0x%lx) line=%d, addr=%ld\n",
		(long) tokbufp, (long) fp, (long) argnames, vars->SeLnNo, vars->SeLnAddr );
#endif
#endif
	/* Start to get an expression. */
	c = SeNonSpaceGetChar( vars );	/* may be EOF */
	/* Process unary-operator, if we have one. */
	switch( SeOpUnaryGet( vars, c ) )
		{
	case bs_ugly :
		assert(ErIsSet());
		return	mFalse;
	case bs_good :
		goto top;	/* return SeExprGet( tokbufp, fp, argnames ); */
		}
	/* Process parenthesized-expression, if we have one. */
	switch( SeParenExprGet( vars, c, tokbufp ) )
		{
	case bs_ugly :
		assert(ErIsSet());
		return	mFalse;
	case bs_good :
		return	SeBinOpExpGet( vars, tokbufp );
		}
	/* unary-expression || binary-expression; starts with const or ident */
	/* Must process constants before identifiers, because
	   "123.456" looks like an identifier according to our syntax rules. */
	switch( SeConstGet( vars, c, tokbufp ) )
		{
	case bs_ugly :
		assert(ErIsSet());
		return	mFalse;
	case bs_good :
		return	SeBinOpExpGet( vars, tokbufp );
		}
	/* Process identifiers. */
	switch( SeIdentifierGet( vars, c, tokbufp, SeNT_SYSNAME ) )
		{
	case bs_good :
		{
		/* Check to see if we have a list, and if so promote it. */
		if( NmIndex( tokbufp, &SeLists, mFalse ) >= 0 )
			{	SeToken *tokenp;
			/* Promote previous token from SeNT_SYSNAME to
			   SeNT_LISTNAME. */
			assert(vars->SeStackp != NULL);
			assert(!DqIsEmpty(vars->SeStackp));
			tokenp = DqLast( vars->SeStackp, SeToken );
			assert(tokenp->type == SeNT_SYSNAME);
			tokenp->type = SeNT_LISTNAME;
			}
		else
			ErClear(); /* OK if not a list. */
			
		if( NmIndex( tokbufp, &vars->argnames, mFalse ) >= 0 )
			{ /* We have a function parameter, not a system.
			     Promote previous token from SeNT_SYSNAME to
			     SeNT_PARAM. */
				SeToken *tokenp;
			assert(vars->SeStackp != NULL);
			assert(!DqIsEmpty(vars->SeStackp));
			tokenp = DqLast( vars->SeStackp, SeToken );
			assert(tokenp->type == SeNT_SYSNAME);
			tokenp->type = SeNT_PARAM;
			}
		else
			{
			ErClear(); /* OK if not a function parameter. */
			if(	SeFnCallGet(vars, tokbufp) == bs_ugly
			   ||	SeQalGet( vars, tokbufp, mTrue ) == bs_ugly )
				{
				assert(ErIsSet());
				return	mFalse;
				}
			}
		return	SeBinOpExpGet( vars, tokbufp );
		}
	case bs_ugly :
		assert(ErIsSet());
		return	mFalse;
		}
	ErSet( SeSYNEXPR );
	SePrtSyntax( vars, "expression", c );
	return	mFalse;
	}

/*
	void Se1stLine( SeParseVars *vars )

	Rewind stream fp and reset parser position variables to
	point to the first line of the associated file.

	This function is for internal Se package use only.

	NOTE:  SeLnNo and SeLnAddr give the line number of the current
	line being parsed and file offset of the beginning of that line,
	respectively.  The purpose of these variables is to assist in the
	printing of the current line in syntax error messages.  Likewise,
	lastLnNo and lastLnAddr give this information for the last line
	parsed in case we need to back up after crossing a line boundary
	in performing a single-token look ahead.  XXX -- these variables
	should perhaps be cloned per each file open so that interleaved
	use of parsing functions on multiple files will not confuse this
	mechanism, though such usage is not anticipated.
 */
void
#if STD_C
Se1stLine( SeParseVars *vars )
#else
Se1stLine( fp )
FILE *fp;
#endif
	{
	SeRewind(vars);
	vars->lastLnNo = vars->SeLnNo = 1;	/* current line is first line */
	vars->lastLnAddr = vars->SeLnAddr = 0L;	/* beginning of file */
	assert(SeTell(vars) == 0L);		/* beginning of file */
	}

/*
	void SeNxtLine( SeParseVars *vars )

	Update parser position variables (see NOTE in Se1stLine()) to point
	to the next line in the file associated with stream fp.
 */
STATIC void
#if STD_C
SeNxtLine( SeParseVars *vars )
#else
SeNxtLine( fp )
FILE *fp;
#endif
	{
	vars->lastLnAddr = vars->SeLnAddr;	/* save file offset of last line parsed */
	vars->lastLnNo = vars->SeLnNo;	/* save number of last line parsed */
	vars->SeLnNo++;		/* current line is next line */
	vars->SeLnAddr = SeTell(vars); /* file offset to start of next line */
	}

/**
	const char *SePrsBaseName( int comp_index )

	SePrsBaseName() returns a pointer to the base component name for
	the qualified component having the specified SeComponents name
	pool index.  It is considered an error if the corresponding
	component does not have a qualifier.  The pointer returned is
	only valid until the next call to SePrsBaseName().

	SePrsBaseName() returns null and sets the error index if an error
	occurs.
**/
const char *
#if STD_C
SePrsBaseName( int index )
#else
SePrsBaseName( index )
int index;
#endif
	{	const char *name;
		static char buffer[SeBUFSIZE];
	assert(NmCount( &SeComponents ) > 0);
	assert(index > -1);
	assert(index < NmCount( &SeComponents ));
	name = NmName( index, &SeComponents );
	assert(name != NULL);
	(void) strncpy( buffer, name, SeBUFSIZE );
	assert(strlen(buffer) < SeBUFSIZE);
	if(	(name = strtok( buffer, SeTK_LF_SQUARE )) == NULL
	   ||	strtok( (char *) NULL, SeTK_RT_SQUARE ) == NULL )
		{
		ErSet( SeNOTQUALIFIED );
		return (const char *) NULL;
		}
	return name;
	}

/**
	const char *SePrsQualName( int comp_index )

	SePrsQualName() returns a pointer to the qualifier string for
	the specified SeComponents name pool index.  It is considered
	an error if the corresponding component does not have a qualifier.
	The pointer returned is only valid until the next call to
	SePrsQualName().

	SePrsQualName() returns null and sets the error index if an error
	occurs.
**/
const char *
#if STD_C
SePrsQualName( int index )
#else
SePrsQualName( index )
int index;
#endif
	{	const char *name;
		static char buffer[SeBUFSIZE];
	assert(NmCount( &SeComponents ) > 0);
	assert(index > -1);
	assert(index < NmCount( &SeComponents ));
	name = NmName( index, &SeComponents );
	assert(name != NULL);
	(void) strncpy( buffer, name, SeBUFSIZE );
	assert(strlen(buffer) < SeBUFSIZE);
	if(	strtok( buffer, SeTK_LF_SQUARE ) == NULL
	   ||	(name = strtok( (char *) NULL, SeTK_RT_SQUARE )) == NULL )
		{
		ErSet( SeNOTQUALIFIED );
		return (const char *) NULL;
		}
	return name;
	}

/*
	void SePrvLine( SeParseVars *vars )

	Restore parser position variables (see NOTE in Se1stLine()) to point
	to the previous line.
 */
STATIC void
#if STD_C
SePrvLine( SeParseVars *vars )
#else
SePrvLine()
#endif
	{
	vars->SeLnNo = vars->lastLnNo;	/* restore current line number */
	vars->SeLnAddr = vars->lastLnAddr;	/* restore file offset */
	}

/*
	bs_type SeQalGet( SeParseVars *vars, int c, char *tokbufp, MuvesBool compiling )

	This routine tests whether the next input token is a left
	square bracket, and if so attempts to parse a qualifier
	from stream fp. tokbufp must point to a scratch buffer of
	SeBUFSIZE bytes.  If compiling is mTrue, push tokens on stack.

	RETURN: bs_good for success

		bs_bad if the next token is not a left square bracket

		bs_ugly, print a message on the error log, and set an error
		index if the next token is a left square bracket, but the
		qualifier can not be parsed
 */
STATIC bs_type
#if STD_C
SeQalGet( SeParseVars *vars, char *tokbufp, MuvesBool compiling )
#else
SeQalGet( tokbufp, fp, compiling )
char *tokbufp;
register FILE *fp;
MuvesBool compiling;
#endif
	{	int c;
		register SeToken *tokenp;
	assert(tokbufp != NULL);
#if SeDEBUG == 4
#if STD_C
	ErPLog( "SeQalGet(%p,%p,%s)\n",
		(pointer) tokbufp, (pointer) vars->fp, StrBool(compiling) );
#else
	ErPLog( "SeQalGet(0x%lx,0x%lx,%s)\n",
		(long) tokbufp, (long) fp, StrBool(compiling) );
#endif
#endif
	/* Attempt to get left square bracket. */
	if( (c = SeNonSpaceGetChar( vars )) == EOF )
		return	bs_bad;		/* normal EOF, not an error */
	else
	if( c != SeCH_LF_SQUARE )
		{
		if( SeUnGetc(vars, c) == EOF )
			{
			SePrtErrMsg(vars, "Unget failed where optional "
				"qualifier was allowed.");
			ErSet( SeUNGET );
			return bs_ugly;		/* report error */
			}
		return	bs_bad;
		}

	if( ! compiling )
		goto justparsing;

	/* Previous token is either tagged as a system or list.  If it is
	   tagged as a system, it could be a component.  Differentiate
	   and fix tags to show qualified status. */
	assert(vars->SeStackp != NULL);
	assert(!DqIsEmpty(vars->SeStackp));
	tokenp = DqLast( vars->SeStackp, SeToken );
	if( tokenp->type == SeNT_SYSNAME )
		{
		if( NmIndex( tokenp->text, &RtComponents, mFalse ) == -1 )
			{ /* Promote previous token from SYSNAME to QUALSYS. */
			ErClear();
			tokenp->type = SeNT_QUALSYS;
			}
		else
			{ /* Promote previous token from SeNT_SYSNAME to
			     SeNT_QUALCOMP. */
			tokenp->type = SeNT_QUALCOMP;
			}
		}
	else
	if( tokenp->type == SeNT_LISTNAME )
		{
		tokenp->type = SeNT_QUALIST;
		SeListPromote(vars);
		}

	/* Push the left bracket token on the stack. */
	if( ! SePushToken( vars, SeNT_LF_SQUARE, SeTK_LF_SQUARE ) )
		return bs_ugly;

justparsing:
	/* Parse the qualifier (and push token on the stack if compiling). */
	if( (c = SeNonSpaceGetChar( vars )) == EOF )
		{
		SePrtSyntax( vars, "qualifier", c );
		ErSet( SeSYNIDENT );
		return	bs_ugly;
		}
	/* Process argument. */
	switch( SeIdentifierGet( vars, c, tokbufp,
			compiling ? SeNT_CQUALIFIER : SeNT_DUMMY ) )
		{
	case bs_ugly :
		assert(ErIsSet());
		return bs_ugly;
	case bs_bad :
		SePrtSyntax( vars, "qualifier", c );
		ErSet( SeSYNIDENT );
		return bs_bad;
		}
	/* Get right square bracket. */
	if(	(c = SeNonSpaceGetChar( vars )) == EOF
	    ||	c != SeCH_RT_SQUARE )
		{
		SePrtSyntax( vars, "right square bracket", c );
		ErSet( SeSYNIDENT ); /* XXX */
		return	bs_ugly;
		}

	if( ! compiling )
		return bs_good;

	/* Push the right bracket token on the stack. */
	if( ! SePushToken( vars, SeNT_RT_SQUARE, SeTK_RT_SQUARE ) )
		return bs_ugly;
	return	bs_good;
	}

/*
	SeSysDef **SeStAddMember( SeStDat *defp, const SeSysDef *sysdefp )

	Add the specified member definition to the specified vector
	definition.  The expression node or tree is copied, not referenced.
	CAUTION: only use this before 'values' array has been allocated.
	RETURN: The address of the new member if successful.

		NULL if out of memory; in this case the previous
		contents of the specified SeStDat structure will be
		left untouched
 */
SeSysDef **
#if STD_C
SeStAddMember( SeStDat *defp, const SeSysDef *sysdefp )
#else
SeStAddMember( defp, sysdefp )
SeStDat *defp;
const SeSysDef *sysdefp;
#endif
	{	SeSysDef **defs = defp->defs; /* save for error recovery */
		char **text = defp->text;
	assert(defp->length != 0 || defp->defs == NULL);
#if SeDEBUG == 4
	ErPLog( "SeStAddMember(%s)\n", sysdefp->core.text ); 
#endif

	/* Enlarge defs array to fit new member plus null-terminator. */
	defp->defs = (SeSysDef * *)DmRealloc(defs, (defp->length+2)*sizeof(SeSysDef *));
	/* Enlarge text rep array to fit new member plus null-terminator. */
	defp->text = (char *  *)DmRealloc(text, (defp->length+2)*sizeof(char * ));
	if( (defp->defs[defp->length] = SeExpCopy( sysdefp )) == NULL )
		return NULL; /* error index not set */
	defp->text[defp->length] = SeTxtExpression( (SeSysDef *)sysdefp, 0);

	defp->length++;
	defp->defs[defp->length] = NULL; /* null-terminate */
	defp->text[defp->length] = NULL; /* null-terminate */
	return &defp->defs[defp->length-1];
	}

/*
	MuvesBool SeStGetDef( SeParseVars *vars, const char *statename )

	This routine is called to parse and compile the named state
	definition from the states file associated with the stream fp
	and store it in the SeStDef array and SeStates name pool.

	A state vector definition is expected to begin with the next
	valid input token on stream fp.  SeStGet() attempts to parse
	state vector definitions until one matching statename is
	found.

	This function is for internal Se package use only.

	RETURN: mTrue if a matching state vector definition was
		successfully parsed and compiled.

		mFalse, print a message to the error log, and set the
		error index if EOF, a syntax error, or a storage
		allocation problem arises; some error handling is done
		by the lower-level routines
 */
MuvesBool
#if STD_C
SeStGetDef( SeParseVars *vars, const char *statename )
#else
SeStGetDef( fp, statename )
FILE *fp;
const char *statename;
#endif
	{	char *namep;	/* buffer next state vector name from file */
		int index;	/* name pool index for state vector */
	assert(statename != NULL);
	assert(statename[0] != 0);
#if SeDEBUG == 2
	ErPLog( "SeStGetDef(%s)\n", statename );
#endif
	namep = (char *)DmCalloc(SeBUFSIZE, sizeof(char ));
	for( ; ; )
		{	int c;
		/* get state vector name */
		if( (c = SeNonSpaceGetChar( vars )) == EOF )
			{
			ErPLog( "State vector (%s) not found in states file\n",
				statename );
			ErSet( SeSTUNDEF );
			goto freemem;
			}
		/* Process state vector name. */
		switch( SeIdentifierGet( vars, c, namep, SeNT_DUMMY ) )
			{
		case bs_ugly :
			assert(ErIsSet());
			ErPLog( "%s (%s) in states file\n",
				"Error while searching for state vector",
				statename );
			goto freemem;
		case bs_bad :
			SePrtSyntax( vars, "state vector name", c );
			ErSet( SeSYNIDENT );
			goto freemem;
			}

		if( StrEq( statename, namep ) )
			break;		/* found matching state vector */

		/* wrong name: bypass expression for this definition */
		if( ! SeStVecGet( vars, (SeStDat **) NULL ) )
			{
			assert(ErIsSet());
			ErPLog( "%s (%s) in states file\n",
				"Error while parsing state vector definition",
				namep );
			goto freemem;
			}
		}
	assert(StrEq( statename, namep ));
	DmFree((genptr_t)namep );

	/* Insert the state vector definition if it is not already recorded. */
	if( (index = SeStInsert( statename )) == -1 )
		{
		assert(ErIsSet());	/* out of memory */
		ErPLog( "Cannot handle state vector (%s): %s\n",
			statename, ErString() );
		goto return_err;
		}
	/* If not already defined, compile the definition for this state
		vector. */
	if( SeStDef[index] == NULL )
		{
		if( ! SeStVecGet( vars, &SeStDef[index] ) )
			{
			assert(ErIsSet());
			ErPLog( "%s (%s) in states file\n",
				"Error while compiling state vector definition",
				statename );
			goto return_err;
			}
		}
	else	{	/* definition already compiled;
			   don't leave fp in middle of states spec */
		if( ! SeStVecGet( vars, (SeStDat **) NULL ) )
			{
			assert(ErIsSet());
			ErPLog( "%s state vector (%s) in states file\n",
				"Error while reparsing definition for",
				statename );
			goto return_err;
			}
		}
	return	mTrue;

	/* Error handling: */
freemem:
	DmFree((genptr_t)namep );
oom:
	if( namep == NULL )
		ErPLog( "Not enough memory to scan states file\n" );
	assert(ErIsSet());
	return mFalse;
return_err:
	assert(ErIsSet());
	return mFalse;
	}

/**
	bs_type SeStNextName( FILE *fp, char *state_namep )

	SeStNextName() parses the state vector definition in the states
	file associated with the stream pointer (fp) returned by a
	previous call to SeStOpen().  The name of the state vector
	is returned implicitly in the buffer pointed to by state_namep
	which should be capable of holding up to SeBUFSIZE characters.
	This function should be called repeatedly to get the names of
	all state vector definitions in the file; it is not used to
	compile the file for evaluation, but simply to extract the
	names of the state vectors so that the caller can determine
	what state vectors are defined by the states file.  A return
	code of bs_good means success, bs_bad indicates a normal EOF,
	and bs_ugly indicates that an error was reported to the error
	log and the error index is set.

	SeStNextName() must not be called again following an error or
	EOF indication or after using SeStCompile() on the same file,
	unless SeStOpen() is called first.
**/
bs_type 
#if STD_C
SeStNextName( FILE *fp, char *state_namep )
#else
SeStNextName( fp, state_namep )
FILE *fp;
char *state_namep;
#endif
	{	int c;
	assert(state_namep != NULL);
#if SeDEBUG == 4
	ErPLog( "SeStNextName()\n" );
#endif
	SeParseVars *vars = (SeParseVars *)DmCalloc(1, sizeof(SeParseVars));
	vars->fp = fp;

	/* Get state vector name. */
	if( (c = SeNonSpaceGetChar( vars )) == EOF )
	{
		DmFree(vars);
		return bs_bad; /* normal EOF */
	}

	/* Process state vector name. */
	switch( SeIdentifierGet( vars, c, state_namep, SeNT_DUMMY ) )
		{
	case bs_ugly :
		goto return_err;
	case bs_bad :
		SePrtSyntax( vars, "state vector name", c );
		ErSet( SeSYNIDENT );
		goto return_err;
		}

	/* Parse remainder of definition to advance stream pointer to
		next one. */
	if( ! SeStVecGet( vars, (SeStDat **) NULL ) )
		goto return_err;

	DmFree(vars);
	return bs_good;

	/* Error handling: */
return_err:
	DmFree(vars);
	ErPLog( "Error encountered while parsing states file.\n" );
	assert(ErIsSet());
	return bs_ugly;
	}

/*
	MuvesBool SeStGetElement( SeParseVars *vars, int c, char *tokbufp, SeStDat **stdefp )

	This routine is called to parse and, if stdefp is non-null,
	compile one element of a state vector definition from the states file
	associated with the stream fp.

	RETURN: mTrue if the element of the state vector definition was
		successfully parsed (and compiled).

		mFalse, print a message to the error log, and set the
		error index if EOF, a syntax error, or a storage
		allocation problem arises

 */
STATIC MuvesBool
#if STD_C
SeStGetElement( SeParseVars *vars, int c, char *tokbufp, SeStDat **stdefp )
#else
SeStGetElement( c, tokbufp, fp, stdefp )
int c;
char *tokbufp;
FILE *fp;
SeStDat **stdefp;
#endif

	{	const char *namep = NULL;
		DqNode *cmpstackp;
		SeSysDef *sysdefp;
	switch( SeIdentifierGet( vars, c, tokbufp,
			stdefp == NULL ? SeNT_DUMMY : SeNT_SYSNAME ) )
		{
	case bs_ugly :
		return mFalse;
	case bs_bad :
		SePrtSyntax( vars, "vector element", c );
		return mFalse;
		}

	/* Get qualifier. */
	if( SeQalGet( vars, tokbufp, stdefp != NULL ) == bs_ugly )
		{
		assert(ErIsSet());
		return mFalse;
		}
	if( stdefp == NULL )
		return mTrue; /* not compiling, so we're done */

	if(	(cmpstackp = SeStkCompile( vars, vars->SeStackp, (NmPool *) NULL ))
		== NULL
	   ||	(sysdefp = SeTok2SysDef( vars, cmpstackp )) == NULL )
		{
		assert(ErIsSet());
		return mFalse;
		}

	switch( sysdefp->type )
		{
	case SeNT_EXPR : /* Qualified component. */
		assert( sysdefp->o.rhsp != NULL );
		assert( sysdefp->o.rhsp->type == SeNT_COMPNAME );
		namep = NmName( sysdefp->o.rhsp->c.index, &SeComponents );
		break;
	case SeNT_COMPNAME :
		namep = NmName( sysdefp->c.index, &SeComponents );
		break;
	case SeNT_QUALOP :
		switch( sysdefp->o.lhsp->type )
			{
		case SeNT_QUALSYS :
			namep = NmName( sysdefp->o.lhsp->c.index, &SeSystems );
			assert( namep != NULL );
			if( SeDataSystem[sysdefp->o.lhsp->c.index] == NULL )
				{	int mi;
				/* Not really a system, maybe its a list. */
				if( (mi = NmIndex( namep, &SeLists, mFalse ))
					== -1 )
					{
					ErPLog( "*** %s \"%s\" in state vector.\n",
						"Unknown identifier", namep );
					return mFalse;
					}
				/* promote system node to list node. */
				sysdefp->o.lhsp->type = SeNT_LISTNAME;
#if SeDEBUG
				if( ! StrEq( sysdefp->core.text, namep ) )
					ErPLog( "SeStGetElement: *** text=%s != name=%s\n",
						sysdefp->core.text, namep );
#endif
				sysdefp->o.lhsp->c.index = mi;
				}
			break;
		case SeNT_LISTNAME :
			namep = NmName( sysdefp->o.lhsp->c.index, &SeLists );
			break;
		default :
			ErPLog( "BUG: SeStGetElement: '%s' is left operand.\n",
				SeCvtToStr(sysdefp->o.lhsp->type) );
			return mFalse;
			}
		break;
	case SeNT_LISTNAME :
		namep = NmName( sysdefp->c.index, &SeLists );
		break;
	case SeNT_SYSNAME :
		namep = NmName( sysdefp->c.index, &SeSystems );
		if( SeDataSystem[sysdefp->c.index] == NULL )
			{	int mi;
			/* Not really a system, maybe its a list. */
			if( (mi = NmIndex( namep, &SeLists, mFalse )) == -1 )
				{
				ErPLog( "*** %s \"%s\" in state vector.\n",
					"Unknown identifier", namep );
				return mFalse;
				}
			/* promote system node to list node. */
			sysdefp->type = SeNT_LISTNAME;
			assert( StrEq( sysdefp->core.text, namep ) );
			sysdefp->c.index = mi;
			}
		break;
	case SeNT_UNSET :
		ErPLog( "BUG: SeStGetElement: vector element type unset.\n" );
		return mFalse;
	default :
		ErPLog( "BUG: SeStGetElement: unexpected type (%s) %s.\n",
			SeCvtToStr(sysdefp->type), "for vector element" );
		return mFalse;
		}
	assert( namep != NULL );
#if SeDEBUG
	ErPLog( "SeStGetElement: Adding %s: name=%s text=%s\n",
		SeCvtToStr( sysdefp->type ), namep, sysdefp->core.text );
#endif

	/* Add element to list. */
	if( SeStAddMember( *stdefp, sysdefp ) == NULL )
		{
		SeExpFree( sysdefp );
		return mFalse;
		}
	SeExpFree( sysdefp ); /* SeStAddMember() makes its own copy */
	return mTrue;
	}

/*
	MuvesBool SeStVecGet( SeParseVars *vars, SeStDat **stdefp )

	This routine is called to parse and, if stdefp is non-null,
	compile the state vector definition from the states file
	associated with the stream fp.  After compiling a state
	vector, an SeStDat node is allocated and its address is
	placed in stdefp.  The new node is filled in with the type
	and length of the vector and a pointer to a Dq list of element
	names.

	A state vector type field is expected to begin with the next
	valid input token on stream fp.  SeStVecGet() attempts to
	parse the definition beginning with the type specifier.

	This function is for internal Se package use only.

	RETURN: mTrue if the state vector definition was
		successfully parsed (and compiled).

		mFalse, print a message to the error log, and set the
		error index if EOF, a syntax error, or a storage
		allocation problem arises
 */
STATIC MuvesBool
#if STD_C
SeStVecGet( SeParseVars *vars, SeStDat **stdefp )
#else
SeStVecGet( fp, stdefp )
FILE *fp;
SeStDat **stdefp;
#endif
	{	int c;
		SeTypeID type = SeTypeUnset;
		MuvesBool ret = mTrue;
		char *tokbufp;
		register char *outbuf;
		register SeTypeID tid;
	tokbufp = (char *)DmCalloc(SeBUFSIZE, sizeof(char ));
	/* Parse type specifier token. */
	if( (c = SeNonSpaceGetChar( vars )) == EOF )
		{
		SePrtSyntax( vars, "type", c );
		goto syntax_err;
		}
	outbuf = tokbufp;
	*outbuf++ = c;
	while( (c = SeGetc(vars)) != EOF && islower( c ) )
		*outbuf++ = c;
	if( c == EOF )
		{
		SePrtSyntax( vars, "type", c );
		goto syntax_err;
		}
	*outbuf = '\0'; /* null terminate */

	for( tid = (SeTypeID)0; tid < SeTypeSentinel; tid++ )
		if( StrEq( tokbufp, SeStrType( tid ) ) )
			type = tid;
	if( type == SeTypeUnset )
		{
		ErPLog( "Valid types for state vectors are:" );
		for( tid = (SeTypeID)0; tid < SeTypeSentinel; tid++ )
			(void) ErLog( " %s", SeStrType( tid ) );
		(void) ErLog( "\n" );
		SePrtSyntax( vars, "state vector type", c );
		goto syntax_err;
		}
	/* Get assignment operator. */
	if( (c = SeNonSpaceGetChar( vars )) != SeCH_ASSIGNMENT )
		{
		SePrtSyntax( vars, "assignment operator", c );
		goto syntax_err;
		}
	/* If compiling, allocate SeStDat node and initialize it. */
	if( stdefp != NULL )
		{ /* Need to compile vector. */
		*stdefp = (SeStDat  *)DmXalloc(SeStDat);
		(*stdefp)->text = NULL;
		(*stdefp)->defs = NULL;
		(*stdefp)->type = type;
		(*stdefp)->length = 0;
		(*stdefp)->values = NULL;
		}
	/* Get left curly brace or single element. */
	if( (c = SeNonSpaceGetChar( vars )) != SeCH_LF_CURLY )
		{
		/* No delimiters, check for single element. */
		if( ! SeStGetElement( vars, c, tokbufp, stdefp ) )
			goto freemem_err;
		else
			goto freebuf; /* got single element */
		}
	/* Build a Dq list of vector elements. */
	do
		{
		/* Get first character of the next element. */
		if( (c = SeNonSpaceGetChar( vars )) == EOF )
			{
			SePrtSyntax( vars, "vector element", c );
			goto freemem_err;
			}
		/* Process element. */
		if( ! SeStGetElement( vars, c, tokbufp, stdefp ) )
			goto freemem_err;
		}
	while( (c = SeNonSpaceGetChar( vars )) == SeCH_COMMA );
	assert(stdefp == NULL || (*stdefp)->defs != NULL);

	/* Get right curly. */
	if( c != SeCH_RT_CURLY )
		{
		SePrtSyntax( vars, "right curly", c );
		goto freemem_err;
		}
	goto freebuf;
/* Error handling: */
freemem_err:
	if( stdefp != NULL )
		{	
		assert( *stdefp != NULL );
		if( (*stdefp)->defs != NULL )
			{
			DmFree((genptr_t)(*stdefp)->defs);
			}
		if( (*stdefp)->text != NULL )
			{	register char **textp;
			for( textp = (*stdefp)->text; *textp != NULL; textp++ )
				DmFree((genptr_t)*textp );
			DmFree((genptr_t)(*stdefp)->text );
			}
		DmFree((genptr_t)*stdefp );
		*stdefp = NULL;
		}
syntax_err:
	if( ErIsSet() )
		goto fatal_err;
	ErSet( SeSYNVECTOR );
	ret = mFalse;
	goto freebuf;
fatal_err:
	ErPLog( "Error encountered while parsing states file.\n" );
	assert(ErIsSet());
	ret = mFalse;
freebuf:
	if( tokbufp != NULL )
		DmFree((genptr_t)tokbufp );
	return ret;
	}
