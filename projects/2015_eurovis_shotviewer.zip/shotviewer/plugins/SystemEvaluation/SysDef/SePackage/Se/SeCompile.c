/*
	SeCompile.c -- MUVES "Se" (system evaluator) package compilation phase

	created:	88/01/12	G S Moss
	updated:        00/06/21        C Hunt III
			added support for multiple occurrences bug fix
	edited:		02/07/27        C Hunt III
			added support for ORCA node type SeCvtToStr().
			SeIsFoldable(). and SeBuiltIn() (SCR446)
	updated:        03/09/10        C Hunt III
			added SeNt_TMPEXPR node type to SeCvtToStr(),
			discovered this problem during testing of AJEM SCR414
			(multiple occurrence expression substitution bug)
	edited:		12/10/22	C Hunt
			corrected compiler warnings (VSL)
*/
#ifndef lint
static char RCSid[] = "$Id: SeCompile.c,v 1.49 2010/06/23 19:54:51 geoffs Exp $";
#endif

#ifndef DEBUG
#define NDEBUG
#endif

#include <assert.h>
#include <stdio.h>
#include <string.h>

#ifdef __STDC__
#include <stdlib.h>
#else
extern double atof();
#endif

#include <std.h>

#include <Dq.h>
#include <Er.h>
#include <stdio.h>
#include <common.h>   /* BRL-CAD 7.2.4+ no longer use config.h (SCR670) */
#include <bu.h>
#include <Dm.h>
#include <Nm.h>
#include <Rt.h>
#include <Se.h>

#include "SeDefs.h"

#ifndef STATIC
#define STATIC static
#endif

#ifndef SeDEBUG
#define SeDEBUG 0
#endif

extern int SeDebugging;
#define ErDebugging SeDebugging

#if STD_C
STATIC MuvesBool SeFnCompile( SeParseVars *vars, MuvesBool optimize );
STATIC MuvesBool SeListCompile( SeParseVars *vars );
STATIC MuvesBool SeSysCompile( SeParseVars *vars, MuvesBool optimize );
STATIC int SeFnInsert( const char *name );
STATIC int SeListInsert( const char *name );
STATIC SeSysDef *SeDoTokSysDef( SeToken *tokenp, NmPool *argnames );
STATIC void SeTokFree( SeToken *tokenp );
#else
STATIC MuvesBool SeFnCompile();
STATIC MuvesBool SeListCompile();
STATIC MuvesBool SeSysCompile();
STATIC int SeFnInsert();
STATIC int SeListInsert();
STATIC SeSysDef *SeDoTokSysDef();
STATIC void SeTokFree();
#endif

#if SeDEBUG
#if STD_C
STATIC void SeDbgStack( const char *msg, DqNode *stackp, NmPool *argnames );
#else
STATIC void SeDbgStack();
#endif
#else	/* !SeDEBUG */
#define	SeDbgStack( msg, stackp, argnames )	/* no-op */
#endif	/* SeDEBUG */

#define SeUnOpCombine( str, expr )\
	DqREVEACH( stackp, tokenp, SeToken )\
		if(	tokenp != DqLast( stackp, SeToken )\
		    &&	(expr)\
			)\
			{\
			if( (tokenp->rhsp = SeDoTokSysDef( DqTDetach( stackp,\
					DqNext( stackp, &tokenp->link ),\
					SeToken ), argnames )) == NULL )\
				goto flushstack;\
			else\
			if( tokenp->rhsp->type == SeNT_LISTNAME )\
				{\
				ErPLog( "*** %s on list name \"%s\".\n",\
				    "Illegal operation",\
				    NmName(tokenp->rhsp->c.index,&SeLists));\
				ErSet( SeILLREFLIST );\
				goto flushstack;\
				}\
			}

#define SeBinOpCombine( str, expr )\
	DqEACH( stackp, tokenp, SeToken )\
		if(	tokenp != DqFirst( stackp, SeToken )\
		    &&	tokenp != DqLast( stackp, SeToken )\
		    &&	(expr)\
			)\
			{\
			if( (tokenp->lhsp = SeDoTokSysDef( DqTDetach( stackp,\
					DqPred( stackp, &tokenp->link ),\
					SeToken ), argnames )) == NULL \
			 || (tokenp->rhsp = SeDoTokSysDef( DqTDetach( stackp,\
					DqNext( stackp, &tokenp->link ),\
					SeToken ), argnames )) == NULL )\
				goto flushstack;\
			else\
			if( tokenp->lhsp->type == SeNT_LISTNAME )\
				{\
				ErPLog( "*** %s on list name \"%s\".\n",\
				    "Illegal operation",\
				    NmName(tokenp->lhsp->c.index,&SeLists));\
				ErSet( SeILLREFLIST );\
				goto flushstack;\
				}\
			else\
			if( tokenp->rhsp->type == SeNT_LISTNAME )\
				{\
				ErPLog( "*** %s on list name \"%s\".\n",\
				    "Illegal operation",\
				    NmName(tokenp->rhsp->c.index,&SeLists));\
				ErSet( SeILLREFLIST );\
				goto flushstack;\
				}\
			}

/*
	const char *SeCvtToStr( SeNodeCategory type )

	Converts a token index to a 19-character text string to support
	debugging.
 */
const char *
#if STD_C
SeCvtToStr( SeNodeCategory type )
#else
SeCvtToStr( type )
SeNodeCategory type;
#endif
	{	register char *str;
		static char buffer[32];
	switch( type )
		{
	case SeNT_SYSNAME :
		str = "SYSTEM-NAME";
		break;
	case SeNT_LISTNAME :
		str = "LIST-NAME";
		break;
	case SeNT_FUNCNAME :
		str = "FUNCTION-DEF-NAME";
		break;
	case SeNT_PARAM :
		str = "FUNCTION-DEF-PARAM";
		break;
	case SeNT_FNCALL :
		str = "FUNCTION-CALL";
		break;
	case SeNT_COMPNAME :
		str = "COMPONENT-NAME";
		break;
	case SeNT_QUALCOMP :
		str = "QUALIFIED-COMPONENT";
		break;
	case SeNT_QUALSYS :
		str = "QUALIFIED-SYSTEM";
		break;
	case SeNT_QUALIST :
		str = "QUALIFIED-LIST";
		break;
	case SeNT_CQUALIFIER :
		str = "COMPONENT-QUALIFIER";
		break;
	case SeNT_CONSTANT :
		str = "CONSTANT";
		break;
	case SeNT_EXPR :
		str = "EXPRESSION";
		break;
	case SeNT_ASSIGNMENT :
		str = "ASSIGNMENT-OPERATOR";
		break;
	case SeNT_LF_PAREN :
		str = "LEFT-PARENTHESIS";
		break;
	case SeNT_RT_PAREN :
		str = "RIGHT-PARENTHESIS";
		break;
	case SeNT_QUALOP :
		str = "COMP-QUAL-OPERATOR";
		break;
	case SeNT_LF_SQUARE :
		str = "LEFT-SQR-BRACKET";
		break;
	case SeNT_RT_SQUARE :
		str = "RIGHT-SQR-BRACKET";
		break;
	case SeNT_LIST :
		str = "LIST-MEMBER-SEPARATOR";
		break;
	case SeNT_CMA :
		str = "COMMA-SEPARATOR";
		break;
	case SeNT_NOT :
		str = "NOT-OPERATOR";
		break;
	case SeNT_ANOT :
		str = "ALT-NOT-OPERATOR";
		break;
	case SeNT_ABS :
		str = "ABS-OPERATOR";
		break;
	case SeNT_BOOL :
		str = "BOOL-OPERATOR";
		break;
	case SeNT_AND :
		str = "AND-OPERATOR";
		break;
	case SeNT_OR :
		str = "OR-OPERATOR";
		break;
	case SeNT_MIN :
		str = "MIN-OPERATOR";
		break;
	case SeNT_MAX :
		str = "MAX-OPERATOR";
		break;
	case SeNT_XOR :
		str = "XOR-OPERATOR";
		break;
	case SeNT_SUM :
		str = "SUM-OPERATOR";
		break;
	case SeNT_DIFF :
		str = "DIFF-OPERATOR";
		break;
	case SeNT_PROD :
		str = "PROD-OPERATOR";
		break;
	case SeNT_QUOT :
		str = "QUOT-OPERATOR";
		break;
	case SeNT_LT :
		str = "LT-OPERATOR";
		break;
	case SeNT_GT :
		str = "GT-OPERATOR";
		break;
	case SeNT_LTEQ :
		str = "LTEQ-OPERATOR";
		break;
	case SeNT_GTEQ :
		str = "GTEQ-OPERATOR";
		break;
	case SeNT_RUNIF :
		str = "RANDOM-UNIFORM-FUNCTION";
		break;
	case SeNT_RNORM :
		str = "RANDOM-NORMAL-FUNCTION";
		break;
	case SeNT_MOFN :
		str = "M-OF-N-FUNCTION";
		break;
	case SeNT_PKD :
		str = "PKD-FUNCTION";
		break;
	/* 02-07-27 ch3: added support for ORCA node type */
	case SeNT_ORCA :
		str = "ORCA-FUNCTION";
		break;
	case SeNT_EVAL :
		str = "EVAL-FUNCTION";
		break;
	/* 06-21-00 ch3  added support for new muliple occurrence operator */
	case SeNT_MULTOCC :
		str = "MULT-OCC";
		break;
	/* 09-10-03 ch3  added support for temporary expression operator */
	case SeNT_TMPEXPR :
		str = "TMP-EXPR";
		break;
	default :
		(void) sprintf( buffer, "*** UNKNOWN value %d", type );
		return (const char *) buffer;
		}
	return	(const char *) str;
	}

#if SeDEBUG
/*
	void SeDbgStack( const char *msg, DqNode *stackp, NmPool *argnames )

	Print a message followed by the token stack to the error log.
 */
/*ARGSUSED*/
STATIC void
#if STD_C
SeDbgStack( const char *msg, DqNode *stackp, NmPool *argnames )
#else
SeDbgStack( msg, stackp, argnames )
const char *msg;
DqNode *stackp;
NmPool *argnames;
#endif
	{	register SeToken *tokenp;
	assert(msg != NULL);
	assert(msg[0] != 0);
	ErPLog( "%s\n", msg );
	assert(stackp != NULL);
	DqEACH( stackp, tokenp, SeToken )
		{
		assert(tokenp != NULL);
		ErPLog(	"\tTOKEN:%s->\t%s\n",
				SeCvtToStr( tokenp->type ),
				tokenp->text == NULL ? "*** NULL ***"
						     : tokenp->text
				);
		if( tokenp->type == SeNT_FUNCNAME )
			{	register int ct;
				register int i;
			assert(argnames != NULL);
			ct = NmCount( argnames );
			for( i = 0; i < ct; i++ )
				ErPLog( "\t\tARG[%d]: %s\n",
					i, NmName( i, argnames ) );
			}
		}
	return;
	}
#endif	/* SeDEBUG */

/*
	MuvesBool SeDefCompile( SeParseVars *vars, SeOptimizeEnum optimize )

	SeStackp is assumed to contain either a function, system or
	list definition (func_name(param[s])=expr or sys_name=expr or
	list_name=member1,member2,...) represented as a stack of input
	tokens.  SeDefCompile calls the appropriate routine to handle
	the compilation, and passes in the optimization request from
	the caller.

	(06-21-00 ch3)  The type of the optimize argument was changed
	from MuvesBool to SeOptimize.  To support the multiple occurrence
	bug fix changes, this function needs to be called so that
	systems will not be optimized but functions will be.  To
	support this, the new value 'NoSystem' will be used.

	This function is for internal Se package use only.

	RETURN: positive index of new system just compiled
		SeCompile_FAIL if error occurred
		SeCompile_GOOD if successful compile of function or list
 */
/* 11-04-29 ch3: changed return value (VSL) */
int
#if STD_C
SeDefCompile( SeParseVars *vars, SeOptimizeEnum optimize )
#else
SeDefCompile( argnames, optimize )
NmPool *argnames;
SeOptimizeEnum optimize;
#endif
	{	SeToken *deftokp;
	assert(vars->argnames != NULL);
	assert(vars->SeStackp != NULL);
#if SeDEBUG == 2
	SeDbgStack( "SeDefCompile", vars->SeStackp, &vars->argnames );
#endif
	deftokp = DqFirst( vars->SeStackp, SeToken );

	switch( deftokp->type )
		{
	case SeNT_SYSNAME :
		assert( NmCount( &vars->argnames ) == 0 );
		/* 06-21-00 ch3  only optimize for True */
		return SeSysCompile( vars, optimize == SeOptimizeTrue );
	case SeNT_FUNCNAME :
		/* 06-21-00 ch3  optimize for True and NoSystem */
		/* 11-04-29 ch3: updated return value (VSL) */
		return SeFnCompile( vars, optimize != SeOptimizeFalse )
			? SeCompile_GOOD : SeCompile_FAIL;
	case SeNT_LISTNAME :
		/* 11-04-29 ch3: updated return value (VSL) */
		return SeListCompile(vars)
			? SeCompile_GOOD : SeCompile_FAIL;
	default :
		ErPLog( "BUG: SeDefCompile: Unknown definition node (%s)\n",
			SeCvtToStr( deftokp->type ) );
		}
	/* 11-04-29 ch3: updated return value (VSL) */
	return SeCompile_FAIL;
	}

/*
	SeSysDef *SeDoTokSysDef( SeToken *tokenp, NmPool *argnames )

	Converts an SeToken node into an SeSysDef node.  Subexpressions are
	assumed to have already been converted.  argnames points to a pool
	of parameter names if a function definition is being compiled and is
	NULL otherwise.

	RETURN:	pointer to converted node, if successful

		NULL, otherwise; the tokens are left intact when this occurs
 */
STATIC SeSysDef *
#if STD_C
SeDoTokSysDef( SeToken *tokenp, NmPool *argnames )
#else
SeDoTokSysDef( tokenp, argnames )
register SeToken *tokenp;
NmPool *argnames;
#endif
	{	register SeSysDef *sysdefp; /* pointer to allocated node */
	assert(tokenp != NULL);
	assert(tokenp->text != NULL);	/* might be "", though */
#if SeDEBUG == 3
	ErPLog( "SeDoTokSysDef: tokenp->text=%s type=%s\n",
		tokenp->text, SeCvtToStr( tokenp->type ) );
#endif
#if SeDEBUG == 2
#if STD_C
	ErPLog( "SeDoTokSysDef(%p,%p)\n", (pointer)tokenp, (pointer)argnames );
#else
	ErPLog( "SeDoTokSysDef(0x%lx,0x%lx)\n", (long)tokenp, (long)argnames );
#endif
#endif
	sysdefp = (SeSysDef  *)DmXalloc(SeSysDef);
	sysdefp->type = tokenp->type;
	assert(sysdefp->type != SeNT_COMPNAME);	/* initially tagged as system */
	switch( sysdefp->type )
		{
	case SeNT_CQUALIFIER :
		{	register int index;	/* SeQualifiers pool index */
			long save_erindex = ErIndex;
		assert(tokenp->text[0] != 0);
		if( (index = NmIndex( tokenp->text, &SeQualifiers, mTrue ))
			== -1 )
			return NULL;
		assert(ErIndex == save_erindex);
		assert(index >= 0);
		sysdefp->c.index = index;
		sysdefp->core.text = DmStrDup(tokenp->text );
		assert( sysdefp->core.text != NULL );
		break;
		}
	case SeNT_QUALSYS : /* qualified system node */
		{	register int index;	/* SeSystems pool index */
			long save_erindex = ErIndex;
		assert(tokenp->text[0] != 0);
		/* Before adding system to name pool, check to make sure it is
		   not a list. */
		if( (index = NmIndex( tokenp->text, &SeLists, mFalse )) >= 0 )
			/* We have a qualified list. */
			sysdefp->type = SeNT_LISTNAME;
		else
			{
			ErSet( save_erindex );
			/* Add to system name pool. */
			/* 14-08-25 ch3: make sure system is added right (VSL) */
			if( (index = SeSysInsert(tokenp->text))
				== -1 )
				return NULL;
			}
		assert(ErIndex == save_erindex);
		assert(index >= 0);
		sysdefp->c.index = index;
		sysdefp->core.text = DmStrDup(tokenp->text );
		assert( sysdefp->core.text != NULL );
		break;
		}
	case SeNT_QUALIST : /* qualified list name */
	case SeNT_LISTNAME : /* list name */
		{	register int index;	/* SeLists pool index */
			long save_erindex = ErIndex;
		assert(tokenp->text[0] != 0);
		if( (index = NmIndex( tokenp->text, &SeLists, mFalse )) == -1 )
			{
			ErPLog( "BUG: SeDoTokSysDef: %s \"%s\" not in n. p.\n",
				SeCvtToStr( sysdefp->type ), tokenp->text );
			return NULL;
			}
		assert(ErIndex == save_erindex);
		assert(index >= 0);
		sysdefp->c.index = index;
		sysdefp->core.text = DmStrDup(tokenp->text );
		assert( sysdefp->core.text != NULL );
		break;
		}
	case SeNT_QUALCOMP : /* qualified component node */
	case SeNT_SYSNAME : /* component|system leaf node */
		{	register int index;	/* RtComponents pool index */
			long save_erindex = ErIndex;
		assert(tokenp->text[0] != 0);
		if( (index = NmIndex( tokenp->text, &RtComponents, mFalse ))
			>= 0 )
			sysdefp->type = SeNT_COMPNAME;	/* it's a component */
		else
			{ /* not a component, but could be a list */
			assert(index == -1);
			ErSet( save_erindex );	/* not an error (yet) */
			if( (index = NmIndex( tokenp->text, &SeLists, mFalse ))
				>= 0 )
				/* It's a list. */
				sysdefp->type = SeNT_LISTNAME;
			else
				{ /* not a component => assume it's a system */
				assert(index == -1);
				ErSet( save_erindex );	/* not an error (yet) */
				if( (index = SeSysInsert( tokenp->text )) < 0 )
					{	/* now THIS is an error */
					assert(index == -1);
					ErPLog(
		"SeDoTokSysDef: couldn't add \"%s\" to systems list:\n\t%s\n",
					sysdefp->core.text );
					sysdefp->type = SeNT_UNSET;	/* safety net */
					DmFree((genptr_t)sysdefp->core.text );
					DmFree((genptr_t)sysdefp );
					assert(ErIsSet());
					return NULL;
					}
				}
			}
		assert(ErIndex == save_erindex);
		assert(index >= 0);
assert(sysdefp->type != SeNT_COMPNAME || index < NmSize( &RtComponents ));
assert(sysdefp->type != SeNT_SYSNAME || index < NmSize( &SeSystems ));
		sysdefp->c.index = index;      /* for RtComponents|SeSystems */
		sysdefp->core.text = DmStrDup(tokenp->text );
		assert( sysdefp->core.text != NULL );
		break;
		}
	case SeNT_PARAM : /* function parameter in body of definition */
		{	register int index;	/* name pool index */
		assert(tokenp->text[0] != 0);
		assert(argnames != NULL);
		if( (index = NmIndex( tokenp->text, argnames, mFalse ))
			== -1 )
			{
			ErPLog( "SeDoTokSysSef: %s \"%s\" not in name pool!\n",
				"BUG: function parameter",
				tokenp->text );
			DmFree((genptr_t)sysdefp );
			assert(ErIsSet());
			return NULL;
			}
		assert(index >= 0);
		assert(index < NmCount( argnames ));
		sysdefp->p.index = index; /* positional parameter index */
		sysdefp->core.text = DmStrDup(tokenp->text );
		assert( sysdefp->core.text != NULL );
		break;
		}
	case SeNT_CONSTANT : /* constant leaf node */
		assert(tokenp->text[0] != 0);
		sysdefp->n.value = atof( tokenp->text );
		sysdefp->core.text = DmStrDup(tokenp->text );
		assert( sysdefp->core.text != NULL );
		break;
	default : /* operator node */
		sysdefp->o.lhsp = tokenp->lhsp;
		sysdefp->o.rhsp = tokenp->rhsp;
		sysdefp->core.text = DmStrDup(tokenp->text );
		assert( sysdefp->core.text != NULL );
		break;
		}
	SeTokFree( tokenp );
#if SeDEBUG == 3
	ErPLog( "SeDoTokSysDef: returning sysdefp=0x%x text=0x%x:%s type=%s\n",
		sysdefp, sysdefp->core.text, sysdefp->core.text,
		SeCvtToStr(sysdefp->type) );
#endif
	return sysdefp;
	}

/*
	SeIsFoldable( SeSysDef *expp )

	Determine whether or not an expression (at the top level, a function
	definition) is guaranteed to reduce to a constant when evaluated in a
	context where the active function-call arguments are all constants.

	When in doubt, it errs in the safe direction ("not foldable").

	Rules:
		resursively examine expression nodes:
			follow function calls into arguments
			follow system invocations into definitions, if any

		constant nodes => okay
		function parameter nodes => okay
		unary or binary operator nodes with foldable operands => okay

		any node a component => non-foldable
		any node a not-yet-defined system => non-foldable
		any node a function call to a function whose definition is
			flagged as non-foldable => non-foldable

	This algorithm relies on function calls being only to already defined
	functions; however, forward references to *systems* are allowed.

	Note that built-in random number generators are flagged as non-foldable.

	This function is for internal Se package use only.

	RETURN:	mTrue if no problem with constant folding

		mFalse if constant folding not safe (not an error condition)
 */
STATIC int	SeFoldLevel = 0;	/* nesting depth of SeIsFoldable() */
STATIC MuvesBool
#if STD_C
SeIsFoldable( register SeSysDef *expp )
#else
SeIsFoldable( expp )
	register SeSysDef	*expp;
#endif
	{
	register MuvesBool	retval = mFalse;	/* return value (be pessimistic) */

	assert(expp != NULL);
#if SeDEBUG == 2
	ErPLog( "SeIsFoldable(%d)\n", expp->type );
#endif
	if( SeFoldLevel >= 100 )	/* avoid (probable) recursion */
		{
#if SeDEBUG
		ErPLog( "SeIsFoldable: recursion safety limit (100) hit\n" );
#endif
		return	mFalse;		/* harmless if we're wrong */
		}
	else
		++SeFoldLevel;
	switch( expp->type )
		{
	case SeNT_SYSNAME :
		if( expp->c.index < NmSize( &SeSystems ) )
			/* Recurse on this system's definition, if any. */
			{
#if SeDEBUG == 2
			ErPLog( "\tSYSNAME:%s\n",
				NmName( expp->c.index, &SeSystems ) );
#endif
			if( SeDataSystem != NULL )
				{	SeSyDat *sdp =
						SeDataSystem[expp->c.index];
				if( sdp != NULL )
					retval = SeIsFoldable( sdp->sysdef );
				/* else not yet defined;
					play safe and return mFalse */
				}
			else if( SeDebugging ) 	/* "Can't happen." */
				ErPLog( "SeIsFoldable: BUG: NULL SeDataSystem\n");
			}
		else if( SeDebugging )  /*  expp->c.index >= NmSize( &SeSystems ) */
			ErPLog(
		"SeIsFoldable: BUG: system index (%d) not in name pool.\n",
				expp->c.index
				);
		break;
	case SeNT_COMPNAME :
		if( SeDebugging )
			{
			if( expp->c.index >= NmCount( &SeComponents ) )
				ErPLog(
		"SeIsFoldable: BUG: component index (%d) not in name pool.\n",
				expp->c.index
				);
			}
		break;	/* component FRF is a variable; return mFalse */
	case SeNT_FNCALL :
#if SeDEBUG == 2
		ErPLog( "\tFNCALL\n" );
#endif
		assert(expp->f.index >= 0);
		assert(expp->f.index < NmCount(&SeFunctions));
		assert(SeFnDfn != NULL);
		assert(SeFnDfn[expp->f.index] != NULL);
		if( ! SeFnDfn[expp->f.index]->foldable ) /* Test definition. */
			break;	/* definition is not foldable; return mFalse */
		{	SeArgExp *np;
		/* Test each argument. */
		assert(expp->f.argexps != NULL);
		assert(! DqIsEmpty( expp->f.argexps ));
		DqEACH( expp->f.argexps, np, SeArgExp )
			if( ! SeIsFoldable( np->expp ) )
				goto foldret;
		}
		retval = mTrue;	/* definition and argument exprs all foldable */
		break;
	case SeNT_PARAM :	/* Function parameter: has argument index. */
#if SeDEBUG == 2
		ErPLog( "\tPARAMETER#%d\n", expp->p.index );
#endif
		retval = mTrue;
		break;
	case SeNT_CONSTANT :
#if SeDEBUG == 2
		ErPLog( "\tCONSTANT:%g\n", expp->n.value );
#endif
		retval = mTrue;
		break;
	case SeNT_RUNIF :
#if SeDEBUG == 2
		ErPLog( "\tRANDOM-UNIFORM\n" );
#endif
		retval = mFalse;	/* no need to inspect operands */
		break;
	case SeNT_RNORM :
#if SeDEBUG == 2
		ErPLog( "\tRANDOM-NORMAL\n" );
#endif
		retval = mFalse;	/* no need to inspect operands */
		break;
	case SeNT_MOFN :
#if SeDEBUG == 2
		ErPLog( "\tM-OF-N\n" );
#endif
		retval = mFalse;	/* no need to inspect operands */
		break;
	case SeNT_PKD :
#if SeDEBUG == 2
		ErPLog( "\tPKD\n" );
#endif
		retval = mFalse; /* no need to inspect operands */
		break;
	/* 02-07-27 ch3: added support for ORCA node type */
	case SeNT_ORCA :
#if SeDEBUG == 2
		ErPLog( "\tORCA\n" );
#endif
		retval = mFalse; /* no need to inspect operands */
		break;
	case SeNT_EVAL :
#if SeDEBUG == 2
		ErPLog( "\tEVAL\n" );
#endif
		retval = mFalse;	/* no need to inspect operands */
		break;
	default :
#if SeDEBUG == 2
		ErPLog( "\tOPERATOR\n" );
#endif
		if( SeIS_UNARY_OP( expp->type ) )
			retval = SeIsFoldable( expp->o.rhsp );
		else if( SeIS_BINARY_OP( expp->type ) )	/* safety check */
			retval = SeIsFoldable( expp->o.lhsp )
			      && SeIsFoldable( expp->o.rhsp );
		else if( SeDebugging )
			ErPLog( "SeIsFoldable: BUG: illegal type %d\n",
				expp->type );
		break;
		}

    foldret:
	--SeFoldLevel;
	return	retval;
	}

/*
	MuvesBool SeFnCompile( SeParseVars *vars, MuvesBool optimize )

	Compile the function definition from the parser token stack
	(SeStackp) with the parameter list in the specified name pool.
	SeStackp is assumed to contain a function definition
	(func_name(param(s))=expr) represented as a stack of input
	tokens (the "(param(s))" part is in the name pool rather than
	on the token stack).  If the optimize argument is 'true'
	SeFnCompile() calls the expression optimizer for all compiled
	system definitions.  SeFnCompile() uses SeFnInsert() to add the
	definition to the SeFunctions name pool; then it sets up the
	SeFnDfn array.  Then it compiles the function by calling
	SeStkCompile() and SeTok2SysDef() and links the resulting
	expression into the SeFnDfn array, freeing up the entire parser
	token stack in the process.

	RETURN: mTrue for success

		mFalse and set an error index upon failure
 */
STATIC MuvesBool
#if STD_C
SeFnCompile( SeParseVars *vars, MuvesBool optimize )
#else
SeFnCompile( argnames, optimize )
NmPool *argnames;
MuvesBool optimize;
#endif
	{	register SeToken *tokenp;  /* -> func_name or "=" token */
		register int index;	   /* SeFunctions name-pool index */
		register DqNode *cmpstack; /* -> compiled expression */

	assert(vars->SeStackp != NULL);

	/* Pop function-name token off stack. */
	tokenp = DqTPop( vars->SeStackp, SeToken );
	assert(tokenp != NULL);
	assert(tokenp->type == SeNT_FUNCNAME);
	assert(tokenp->text != NULL);
	assert(tokenp->text[0] != 0);
	/* Insert function named by tokenp->text into the SeFunctions name pool
	   (extend the SeFnDfn array, if necessary, to accommodate it). */
	if( (index = SeFnInsert( tokenp->text )) < 0 )
		{
		assert(index == -1);
		goto noadd;
		}
	assert(index < SeFnDLen);
	/* Release storage for function-name token. */
	SeTokFree( tokenp );

	/* Allocate SeFnDat node for this function. */
	assert(SeFnDfn != NULL);
	if( SeFnDfn[index] != NULL )
		{
		ErPLog( "Function \"%s\" is multiply defined\n",
			NmName( index, &SeFunctions ) );
		ErSet( SeDUPFNDEF );	/* duplicate function definition */
		goto nocomp;
		}
	SeFnDfn[index] = (SeFnDat  *)DmXalloc(SeFnDat);

	/* Pop assignment token off stack and free its storage. */
	tokenp = DqTPop( vars->SeStackp, SeToken );
	assert(tokenp != NULL);
	assert(tokenp->type == SeNT_ASSIGNMENT);
	assert(tokenp->text != NULL);
	assert(StrEq(tokenp->text, SeTtbl[SeNT_ASSIGNMENT].ts));
	SeTokFree( tokenp );

	SeFnDfn[index]->funcdefp = NULL;	/* in case SeStkCompile dies */

	/* Compile expression for this function and link it into the SeFnDfn
		array. */
	if( (cmpstack = SeStkCompile( vars, vars->SeStackp, &vars->argnames )) == NULL
	 || (SeFnDfn[index]->funcdefp = SeTok2SysDef( vars, cmpstack )) == NULL )
		goto nocomp;

	/* Optimize the expression tree if desired. */
	/*  added by Jeff Hanes, 20 Mar 95  */
	if( optimize )
		{
		SeFnDfn[index]->foldable = mFalse;	/* foil recursion */
		SeOptimize( &SeFnDfn[index]->funcdefp );
		/* 06-21-00 ch3  added check for error flag because new */
		/*               multiple occurrence routine may set it */
		if (ErIsSet())
			return mFalse;
		SeFnDfn[index]->foldable = SeIsFoldable(
						SeFnDfn[index]->funcdefp );
		assert(SeFoldLevel == 0);
		}
	return	mTrue;

	/* Error handling: */
noadd:
	ErPLog( "Couldn't add \"%s\" to function list\n", tokenp->text );
	SeTokFree( tokenp );
	goto flstak;
nocomp:
	assert(NmName( index, &SeFunctions ) != NULL);
	ErPLog( "Error while compiling function definition \"%s\"\n",
		NmName( index, &SeFunctions ) );
flstak:
	SeFlushStack(vars);

	if( SeDebugging )
		ErPLog( "SeFnCompile: %s\n", ErString() );

	assert(ErIsSet());
	return	mFalse;			/* report failure */
	
	}

STATIC MuvesBool
#if STD_C
Se2ArgFuncInsert( const char *name, SeNodeCategory type )
#else
Se2ArgFuncInsert( name, type )
const char *name;
SeNodeCategory type;
#endif
	{	int index;
		register SeSysDef *fp;	/* -> root of definition expression */
	/* Insert named function into the SeFunctions name pool
	   (extend the SeFnDfn array to accommodate it). */
	if( (index = SeFnInsert( name )) < 0 )
		{
		assert(index == -1);
		goto ouch;
		}

	/* Allocate SeFnDat node for this function. */
	assert(SeFnDfn != NULL);
	assert(SeFnDfn[index] == NULL);
	SeFnDfn[index] = (SeFnDat  *)DmXalloc(SeFnDat);

	/* Construct expression tree for this function. */
	SeFnDfn[index]->funcdefp = fp = (SeSysDef  *)DmMalloc(sizeof(SeSysDef ));
	fp->o.lhsp = (SeSysDef  *)DmXalloc(SeSysDef);
	fp->o.rhsp = (SeSysDef  *)DmXalloc(SeSysDef);

	fp->type = type;
	fp->o.lhsp->type = SeNT_PARAM;
	fp->o.lhsp->p.index = 0;
	fp->o.rhsp->type = SeNT_PARAM;
	fp->o.rhsp->p.index = 1;
	fp->core.text = DmStrDup(name );
	assert( fp->core.text != NULL );
	fp->o.lhsp->core.text = DmStrDup("ARG1" );
	assert( fp->o.lhsp->core.text != NULL );
	fp->o.rhsp->core.text = DmStrDup("ARG2" );
	assert( fp->o.rhsp->core.text != NULL );

	SeFnDfn[index]->foldable = SeIsFoldable( fp );
	assert(!SeFnDfn[index]->foldable); /* function requires evaluation */
	return mTrue;

	/* Error handling: */
oof1:
	DmFree((genptr_t)SeFnDfn[index]->funcdefp->o.lhsp );
oof2:
	DmFree((genptr_t)SeFnDfn[index]->funcdefp );
	--index;
oof3:
	assert(index >= 0);
	DmFree((genptr_t)SeFnDfn[index]->funcdefp->o.rhsp );
oof4:
	DmFree((genptr_t)SeFnDfn[index]->funcdefp->o.lhsp );
oof5:
	DmFree((genptr_t)SeFnDfn[index]->funcdefp );

ouch:
	ErPLog( "Error while installing function \"%s\".\n", name );
	assert(ErIsSet());

	if( SeDebugging )
		ErPLog( "SeFuncInsert: %s\n", ErString() );

	ErClear();		/* find out later if function is used */
	return mFalse;
	}

/*
	void SeBuiltIn( void )

	Install built-in function definitions and constants.
	Built-in definitions are expected to have been hand-optimized.

	BUILT-IN FUNCTIONS CURRENTLY PROVIDED:

	_random_uniform(min,max)	provides a random number greater
					than or equal to min and less
					than max, distributed uniformly
					over the range of possible
					values.

	_random_normal(mu,sigma)	provides a random number
					distributed as a Gaussian with
					mean mu and standard deviation
					sigma.
 */
void
#if STD_C
SeBuiltIn( void )
#else
SeBuiltIn()
#endif
	{	register int index;	/* a recycled name-pool index */
		register SeSysDef *fp;	/* -> root of definition expression */
		register SeTypeID tid;	/* enumerated data type */

	/* Insert data type enumeration constants. */
	for( tid = (SeTypeID)0; tid < SeTypeSentinel; tid++ )
		{	char buf[SeBUFSIZE];
			SeSyDat *sydp;
		buf[0] = '_'; /* prepend underscore */
		(void) strcpy( buf+1, SeStrType( tid ) );
		if( (index = SeSysInsert( buf )) < 0 )
			{
			assert(index == -1);
			goto ouch;
			}
		assert( SeDataSystem != NULL );
		assert( SeDataSystem[index] == NULL );
		sydp = SeDataSystem[index] = (SeSyDat  *)DmXalloc(SeSyDat);
		/* Fill in the header info for the system.  Since we don't
		   know the type of the expression being evaluated, can't
		   mark state as valid.  We could guess at the type, but it
		   seems pointless. */
		sydp->state = SeINVALID;
		sydp->save.value = SeTypeUnset; /* safety net */
		sydp->save.type = SeTypeUnset;  /* ditto */
		fp = sydp->sysdef = (SeSysDef  *)DmXalloc(SeSysDef);
		fp->type = SeNT_CONSTANT;
		fp->core.text = DmStrDup(buf );
		assert( fp->core.text != NULL );
		fp->n.index = index;
		fp->n.value = tid;
		}
	/* Fabricate nodes for built-in functions.  Actual implementation
	   will be associated with node type at evaluation time. */
	(void) Se2ArgFuncInsert( "_eval", SeNT_EVAL );
	(void) Se2ArgFuncInsert( "_random_uniform", SeNT_RUNIF );
	(void) Se2ArgFuncInsert( "_random_normal", SeNT_RNORM );
	(void) Se2ArgFuncInsert( "_MofN", SeNT_MOFN );
	(void) Se2ArgFuncInsert( "_Pkd", SeNT_PKD );
	/* 02-07-27 ch3: added support for ORCA node type */
	(void) Se2ArgFuncInsert( "_orca", SeNT_ORCA );
#if SeDEBUG
	SePrtKnownSystems( "Built-in systems" );
#endif

	return;

ouch:
	ErPLog( "Error while installing built-ins\n" );
	assert(ErIsSet());

	if( SeDebugging )
		ErPLog( "SeBuiltIn: %s\n", ErString() );

	ErClear();		/* find out later if built-in is used */
	}

/*
	int SeFnInsert( const char *name )

	This function inserts the specified function definition into the
	SeFunctions name pool and extends the SeFnDfn array if necessary
	to accommodate it; however, SeFnInsert() doesn't insert any
	information into the array.

	RETURN:	SeFunctions name pool index, if successful

		-1 and set the error index appropriately if not
 */
STATIC int
#if STD_C
SeFnInsert( const char *name )
#else
SeFnInsert( name )
const char *name;
#endif
	{	register int index; /* SeFunctions name-pool index for name */
		register int olen = SeFnDLen;	/* original SeFnDfn len. */
	assert(name != NULL);
	assert(name[0] != 0);
#if SeDEBUG == 2
	ErPLog( "SeFnInsert(%s)\n", name );
#endif
	if( (index = NmIndex( name, &SeFunctions, mTrue )) == -1 )
		{
		assert(ErIsSet());	/* not enough memory */
		return	-1;	/* report failure */
		}
	assert(SeFnDfn != NULL);
	assert(olen > 0);
	/* If SeFnDfn array is too small, increase its length. */
	if( index >= olen )		/* then we also know that index != -1 */
		{	register int i;	/* indexes SeFnDfn[.] */
			register SeFnDat **new;	/* result of realloc */
		assert(index == olen);
		new = (SeFnDat *  *)DmRealloc(SeFnDfn, (olen * 2)*sizeof(SeFnDat * ));
		SeFnDLen = olen * 2;
		SeFnDfn = new;	/* data may have moved */
		/* Initialize additional invalid pointers to NULL. */
		for( i = olen; i < SeFnDLen; i++ )
			SeFnDfn[i] = NULL;
		}
	assert(index >= 0 || ErIsSet());
	return index;			/* -1 if NmIndex() failed */
	}

/**
	MuvesBool SeStCompile( FILE *fp, const char *statename )

	SeStCompile() parses and compiles the named state vector,
	maintaining an internal representation of the expression for
	later quick evaluation.  It must be passed the stream pointer
	returned by a previous call to SeStOpen().  State_vector
	is a string naming a state vector to be found in this file.

	RETURN: mTrue if successful

		mFalse and set an error index if not
**/
MuvesBool
#if STD_C
SeStCompile( FILE *fp, const char *statename )
#else
SeStCompile( fp, statename )
FILE *fp;
const char *statename;
#endif
	{	register MuvesBool retstatus;
	assert(statename != NULL);
	assert(*statename != 0);
#if SeDEBUG
#if STD_C
	ErPLog( "SeStCompile(%p,%s)\n", (pointer) fp, statename );
#else
	ErPLog( "SeStCompile(0x%lx,%s)\n", (long) fp, statename );
#endif
#endif
	SeParseVars *vars = (SeParseVars *)DmCalloc(1, sizeof(SeParseVars));
	vars->fp = fp;

	/* Initialize token stack. */
	assert(vars->SeStackp == NULL);
	if( (vars->SeStackp = DqOpen()) == NULL )
		return mFalse;

	/* Ensure that file pointer is at beginning. */
	Se1stLine( vars );

	/* Parse and compile the state vector. */
	if( (retstatus = SeStGetDef( vars, statename )) )
		{	register SeSysDef **defs;
			register int index;
			register int di;
		/* Run through all names in the definition and make sure
		   all are in either the SeSystems or SeComponents
			name pool. */
		index = NmIndex( statename, &SeStates, mFalse );
		assert(index != -1);
		assert(index < NmCount( &SeStates ));
		assert(SeStDef[index] != NULL);
		assert(SeStDef[index]->defs != NULL);
		defs = SeStDef[index]->defs;
		assert(defs[SeStDef[index]->length] == NULL);
		for( di = SeStDef[index]->length - 1; di >= 0; di-- )
			if( defs[di] == NULL )
				ErPLog( "%s: %dth %s \"%s\" undefined.\n",
					"BUG: SeStCompile", di,
					"element of vector", statename );
		if( ! SeListExpand( SeStDef[index] ) )
			{
			assert(ErIsSet());
			DmFree(vars);
			return mFalse;
			}
		}
	if( ! retstatus && ! DqIsEmpty( vars->SeStackp ) )
		SeFlushStack(vars);
	assert(DqIsEmpty( vars->SeStackp ));	/* all nodes should be free */
	DqClose( vars->SeStackp );
	vars->SeStackp = NULL;	/* invalidate queue pointer */
	if( ! retstatus )
		{
		ErPLog( "%s (%s) in states file:\n",
			"Error while compiling state vector definition",
			statename );
		assert(ErIsSet());
		DmFree(vars);
		return mFalse;
		}
	assert(!ErIsSet());
	DmFree(vars);
	return retstatus;
	}


/*
	int SeStInsert( const char *name )

	This function inserts the specified state vector into the
	SeStates name pool and extends the SeStDef array if necessary
	to accommodate it; however, SeStInsert() doesn't insert any
	information into the array.

	RETURN:	SeStates name pool index, if successful

		-1 and set the error index appropriately if not
 */
int
#if STD_C
SeStInsert( const char *name )
#else
SeStInsert( name )
const char *name;
#endif
	{	register int index;	/* SeStates name-pool index for name */
		register int olen = SeStDLen;	/* original SeStDef len. */
	assert(name != NULL);
	assert(name[0] != 0);
#if SeDEBUG
	ErPLog( "SeStInsert(%s)\n", name );
#endif
	if( (index = NmIndex( name, &SeStates, mTrue )) == -1 )
		{
		assert(ErIsSet());	/* not enough memory */
		return	-1;	/* report failure */
		}
	assert(olen > 0);
	/* If SeStDef array is too small, increase its length. */
	if( index >= olen )		/* then we also know that index != -1 */
		{	register int i;	/* indexes SeStDef[.] */
			register SeStDat **new;	/* result of realloc */
		new = (SeStDat *  *)DmRealloc(SeStDef, (olen * 2)*sizeof(SeStDat * ));
		SeStDLen = olen * 2;
		SeStDef = new;	/* data may have moved */
		/* Initialize additional invalid pointers to NULL. */
		for( i = olen; i < SeStDLen; i++ )
			SeStDef[i] = NULL;
		}
	assert(index >= 0 || ErIsSet());
	return index;			/* -1 if NmIndex() failed */
	}

/*
	int SeListInsert( const char *name )

	This function inserts the specified list into the SeLists name pool
	and extends the SeListDfn array if necessary to accommodate it;
	however, SeListInsert() doesn't insert any information into the array.

	RETURN:	SeLists name pool index, if successful

		-1 and set the error index appropriately if not
 */
STATIC int
#if STD_C
SeListInsert( const char *name )
#else
SeListInsert( name )
const char *name;
#endif
	{	register int index;	/* SeLists name-pool index for name */
		register int olen = SeLiDLen;	/* original SeListDfn len. */
	assert(name != NULL);
	assert(name[0] != 0);
#if SeDEBUG
	ErPLog( "SeListInsert(%s)\n", name );
#endif
	if( (index = NmIndex( name, &SeLists, mTrue )) == -1 )
		{
		assert(ErIsSet());	/* not enough memory */
		return	-1;	/* report failure */
		}
	assert(olen > 0);
	/* If SeListDfn array is too small, increase its length. */
	if( index >= olen )		/* then we also know that index != -1 */
		{	register int i;	/* indexes SeListDfn[.] */
			register SeLiDat **new;	/* result of realloc */
		new = (SeLiDat *  *)DmRealloc(SeListDfn, (olen*2)*sizeof(SeLiDat * ));
		SeLiDLen = olen * 2;
		SeListDfn = new;	/* data may have moved */
		/* Initialize additional invalid pointers to NULL. */
		for( i = olen; i < SeLiDLen; i++ )
			SeListDfn[i] = NULL;
		}
	assert(index >= 0 || ErIsSet());
	return index;			/* -1 if NmIndex() failed */
	}

/*
	void SeSysDelete( const char *name )

	This function deletes the specified system from the SeSystems name pool
	and the SeDataSystem array and frees the associated system definition
	if it is non-NULL. WARNING, this function does not shrink the size of
	the SeSystems name pool, or the SeDataSystem array, but unused memory
	will be reclaimed should SeSysInsert be used subsequently.

 */
void
#if STD_C
SeSysDelete( const char *name )
#else
SeSysDelete( name )
const char *name;
#endif
	{	register int index;	/* SeSystems name-pool index for name */
	assert(name != NULL);
	assert(name[0] != 0);
#if SeDEBUG
	ErPLog( "SeSysDelete(%s)\n", name );
	SePrtKnownSystems( "Systems before delete" );
#endif
	index = NmIndex( name, &SeSystems, mFalse );
	assert(index != -1);

	NmDeleteName( name, &SeSystems );

        register int olen;	/* number of valid systems */
	assert(NmSize( &SeSystems ) > 0);

	/* Free entrie in SeDataSystem[]. */
	if( SeDataSystem[index] != NULL )
		{
		assert( SeDataSystem[index]->sysdef != NULL );
		SeExpFree( SeDataSystem[index]->sysdef );
		DmFree((genptr_t)SeDataSystem[index] );
		/* 11-04-21 ch3: reset since not filling in gap (VSL) */
		SeDataSystem[index] = NULL;
		}

#if 0  /* 11-04-21 ch3: cannot fill in gap, will mess up all system nodes
	*               with index into SeDataSystem[] */
	/* Scroll entries past index down one to fill in gap. */
	for( ; index < olen; index++ )
		SeDataSystem[index] = SeDataSystem[index+1];
#endif
#if SeDEBUG
	SePrtKnownSystems( "Systems after delete" );
#endif
	}

/** 
	int SeSysInsert( const char *name )

	This function inserts the specified system into the SeSystems name pool
	and extends the SeDataSystem array if necessary to accommodate it;
	however, SeSysInsert() doesn't insert any information into the array.

	RETURN:	SeSystems name pool index, if successful

		-1 and set the error index appropriately if not
**/
int
#if STD_C
SeSysInsert( const char *name )
#else
SeSysInsert( name )
const char *name;
#endif
	{	register int index;	/* SeSystems name-pool index for name */
		register int olen = SeSyDLen;	/* original SeDataSystem len. */
	assert(name != NULL);
	assert(name[0] != 0);
#if SeDEBUG
	ErPLog( "SeSysInsert(%s)\n", name );
#endif
	if( (index = NmIndex( name, &SeSystems, mTrue )) == -1 )
		{
		assert(ErIsSet());	/* not enough memory */
		return	-1;	/* report failure */
		}
	assert(olen > 0);
	/* If SeDataSystem array is too small, increase its length. */
	if( index >= olen )		/* then we also know that index != -1 */
		{	register int i;	/* indexes SeDataSystem[.] */
			register SeSyDat **new;	/* result of realloc */
		new = (SeSyDat *  *)DmRealloc(SeDataSystem, (olen * 2)*sizeof(SeSyDat * ));
		SeSyDLen = olen * 2;
		SeDataSystem = new;	/* data may have moved */
		/* Initialize additional invalid pointers to NULL. */
		for( i = olen; i < SeSyDLen; i++ )
			SeDataSystem[i] = NULL;
		}
	assert(index >= 0 || ErIsSet());
	return index;			/* -1 if NmIndex() failed */
	}

/*
	void SeTokFree( SeToken *tokenp )

	Free storage for token.
 */
STATIC void
#if STD_C
SeTokFree( SeToken *tokenp )
#else
SeTokFree( tokenp )
SeToken *tokenp;
#endif
	{
	assert(tokenp != NULL);
	assert(tokenp->text != NULL);
	/* Release storage for text of token. */
	DmFree((genptr_t)tokenp->text );
#ifdef DEBUG
	tokenp->type = SeNT_UNSET;	/* safety net */
	tokenp->text = NULL;
	tokenp->lhsp = tokenp->rhsp = NULL;
	tokenp->link.left = tokenp->link.right = NULL;
#endif
	DmFree((genptr_t)tokenp );
	}

/*
	SeSysDef *SeTok2SysDef( SeParseVars *vars, DqNode *stackp )

	This function is called after all but one member of the SeToken
	stack has been compiled into a tree of SeSysDef nodes.  This means
	that this last SeToken node is the root of the compiled expression
	tree.  SeTok2SysDef() converts this last stack member into an
	SeSysDef node to complete the compilation of the input token stack
	into an expression tree.

	This function is for internal Se package use only.

	RETURN:	a pointer to the compiled expression tree if successful

		NULL if SeDoTokSysDef fails; the tokens are left intact when
		this occurs
 */
SeSysDef *
#if STD_C
SeTok2SysDef( SeParseVars *vars, DqNode *stackp )
#else
SeTok2SysDef( stackp )
DqNode	*stackp;
#endif
	{	register SeToken *tokenp;	/* -> last token from stack */
		SeSysDef *sysdefp;
	assert(stackp != NULL);
	assert(!DqIsEmpty( stackp ));
	tokenp = DqTPop( stackp, SeToken );
	assert(DqIsEmpty( stackp ));
	assert(tokenp != NULL);
	if( (sysdefp = SeDoTokSysDef( tokenp, &vars->argnames )) == NULL )
		{
		assert( ErIsSet() );
		return sysdefp; /* fatal error */
		}
	else
	if( ErIsSet() )
		{ /* Lower-level error not propagated, this is a programming
		     error, so force either a dump or an error.  Problem is,
		     the error may not be the first encountered since ErIndex
		     will get overwritten if there are multiple errors in
		     the expression. */
		assert( ! ErIsSet() );
		if (vars->errmsg != NULL)
			{
			sprintf(vars->errmsg, "BUG: %s", ErString());
			}
		sysdefp = NULL;
		}
	return sysdefp;
	}

/*
	DqNode *SeStkCompile( SeParseVars *vars, DqNode *stackp, NmPool *argnames )

	Compiles the token (sub)stack into a one-member stack which is the
	root of an expression tree.  argnames will point to a name pool of
	parameters if a function definition is being compiled and will be NULL
	otherwise.

	This function is for internal Se package use only.

	RETURN: a pointer to the one-member stack result (stackp) if successful

		NULL on failure; the stack needs to be flushed when this occurs
 */
DqNode *
#if STD_C
SeStkCompile( SeParseVars *vars, DqNode *stackp, NmPool *argnames )
#else
SeStkCompile( stackp, argnames )
register DqNode	*stackp;
NmPool *argnames;
#endif
	{	register SeToken *tokenp;
	assert(stackp != NULL);
#if SeDEBUG == 2
	SeDbgStack( "SeStkCompile: function calls", stackp, (NmPool *) NULL );
#endif

	/* Process all function calls first. */
	for( tokenp = DqFirst( stackp, SeToken ); &tokenp->link != stackp; )
		{	DqNode *prevtokp;
			int index;
			register int parenct; /* () nesting level */
			register SeToken *lfparp, *rtparp;
			register SeToken *functokp;
			SeToken *exptokp;
			SeToken *nextp;		/* -> successor of rtparp */
			register SeSysDef *fncallp;
		if( tokenp->type != SeNT_FNCALL )
			{
			tokenp = DqFirst( &tokenp->link, SeToken );
			continue;
			}
		/* We have a function call. */

		/* Get index to function definition node. */
		if( (index = NmIndex( tokenp->text, &SeFunctions, mFalse ))
			== -1 )
			{ /* Function not defined. */
			ErPLog( "Undefined function: %s\n", tokenp->text );
			ErSet( SeFN_UNDEF );
			goto report_err;
			}
		/* Allocate an expression token on which to hang the
			compiled function call for a while. */
		functokp = (SeToken  *)DmXalloc(SeToken);
		functokp->type = SeNT_EXPR;
		functokp->lhsp = NULL;
		functokp->text = DmStrDup("" );
		/* Allocate a fncallnode to hold the function call arguments
		   and function definition ptr. */
		fncallp = (SeSysDef  *)DmXalloc(SeSysDef);
		functokp->rhsp = fncallp;
		fncallp->type = tokenp->type;
		fncallp->core.text = DmStrDup(tokenp->text );
		assert( fncallp->core.text != NULL );
		fncallp->f.index = index;
		if( (fncallp->f.argexps = DqOpen()) == NULL )
			goto freedef_err;

		/* Detach function call node and free storage. */
		lfparp = DqTNext( stackp, &tokenp->link, SeToken );
		if( tokenp == DqFirst( stackp, SeToken ) )
			prevtokp = stackp;
		else
			prevtokp = DqPred( stackp, &tokenp->link );
		tokenp = DqTDetach( stackp, &tokenp->link, SeToken );
		assert(tokenp != NULL);
		assert(tokenp->type == SeNT_FNCALL);
		SeTokFree( tokenp );

		/* Snip out and compile successive expressions until we
		   find a matching right parenthesis (ends arg list).
		   Queue each compiled expression into list and hang it on
		   the fncallnode. */
		for(	rtparp = exptokp =
				DqTNext( stackp, &lfparp->link, SeToken ),
			parenct = 1; /* left parenthesis processed already */
			(nextp = DqTNext( stackp, &rtparp->link, SeToken )) != NULL;
			rtparp = nextp )
			{
#ifdef DEBUG
			if (nextp == rtparp)
				ErPLog( "SeStkCompile: %s\n",
					"malformed function call" );
#endif
			assert(nextp != rtparp);
			assert(parenct >= 0);
			if( rtparp->type == SeNT_LF_PAREN )
				parenct++;
			else
			if( rtparp->type == SeNT_RT_PAREN )
				parenct--;
			/* If at end of expression, compile and store. */
			if(	(rtparp->type == SeNT_RT_PAREN && parenct == 0)
			    ||	(rtparp->type == SeNT_LIST && parenct == 1) )
				{	register DqNode *argtokp;
					DqNode *cmpexpp;
					SeArgExp *argexpp;
					SeToken *detp = NULL;
				if( (argtokp = DqOpen()) == NULL )
					goto freeargs_err;
				argtokp->right = &exptokp->link;
				argtokp->left = rtparp->link.left;
				argtokp->right->left = argtokp->left->right =
					argtokp;
				exptokp = DqTNext( stackp, &rtparp->link,
						SeToken );
				/* Snip out the argument list. */
				(prevtokp->right = rtparp->link.right)->left =
					prevtokp;
				argexpp = (SeArgExp  *)DmXalloc(SeArgExp);
				/* Compile argument expression. */
				if( (cmpexpp = SeStkCompile(vars, argtokp, argnames))
					== NULL )
					goto freeargexp_err;
				assert(cmpexpp == argtokp);
				assert(cmpexpp->right == cmpexpp->left);
					/* one node */
				/* Pluck SeToken node from Dq list. */
				detp = DqTPop( cmpexpp, SeToken );
				assert(DqIsEmpty( cmpexpp ));
				DqClose( cmpexpp ); /* => DqClose( argtokp ) */
#ifdef DEBUG
				argtokp = cmpexpp = NULL; /* safety net */
#endif
				/* Convert SeToken to SeSysSef node and
				   store. */
				if( (argexpp->expp =
					SeDoTokSysDef( detp, argnames ))
					== NULL )
					goto reattach_err;
				/* Link into compiled argument list. */
				DqAppend( fncallp->f.argexps, &argexpp->link );
				if( rtparp->type == SeNT_RT_PAREN )
					break; /* all arguments processed */
				if( rtparp->type == SeNT_LIST )
					SeTokFree( rtparp );
				continue;
reattach_err:
				/* Reattach the detached tokens so they can
				   be freed. */
				DqR_Insert( &detp->link, prevtokp );
freeargexp_err:
				DmFree((genptr_t)argexpp );
				if( detp != NULL ) /* argtokp already freed */
					goto freeargs_err;
freesub_err:
				while( (detp = DqTPop( argtokp, SeToken ))
					!= NULL )
					SeTokFree( detp );
				DqClose( argtokp );
				goto freeargs_err;
				}
			assert(parenct >= 0);
			}
		/* Move current pointer to after the argument list, for
			next iteration. */
		assert(rtparp->type != SeNT_LIST);	/* has been freed */
		tokenp = DqFirst( &rtparp->link, SeToken );
		
		/* Free left-paren and right-paren token nodes. */
		SeTokFree( lfparp );
		SeTokFree( rtparp );

		/* Link subexpr. into token chain in place of function
			call. */
		DqR_Insert( &functokp->link, prevtokp );
		continue;
		/* Error handling: */
freeargs_err:
		{	SeArgExp *np;
		while( (np = DqTPop( fncallp->f.argexps, SeArgExp )) != NULL )
			{
			SeExpFree( np->expp );
#ifdef DEBUG
			np->expp = NULL; /* safety net */
			np->link.left = np->link.right = NULL;
#endif
			DmFree((genptr_t)np );
			}
		DqClose( fncallp->f.argexps );
		}
freedef_err:
#ifdef DEBUG
		fncallp->type = SeNT_UNSET;	/* safety net */
		fncallp->f.argexps = NULL;
		fncallp->f.index = -1;
#endif
		DmFree((genptr_t)fncallp );
freetxt_err:
		DmFree((genptr_t)functokp->text );
freetok_err:
#ifdef DEBUG
		functokp->type = SeNT_UNSET;	/* safety net */
		functokp->rhsp = NULL;
#endif
		DmFree((genptr_t)functokp );
report_err:
#ifdef DEBUG
		ErPLog( "SeStkCompile: %s\n", ErString() );
#endif
		assert(ErIsSet());
		return	NULL;	/* report failure */
		}

#if SeDEBUG == 2
	SeDbgStack( "SeStkCompile: parentheses", stackp, (NmPool *) NULL );
#endif

	/* Process all parenthesized sub-expressions next. */
	for( tokenp = DqFirst( stackp, SeToken ); &tokenp->link != stackp; )
		{
		if( tokenp->type != SeNT_LF_PAREN )
			{
			tokenp = DqFirst( &tokenp->link, SeToken );
			continue;
			}
		/* else we have a parenthesized expression */
		{	register SeToken *lfparp=tokenp;/* -> ( token */
			register SeToken *rtparp;	/* -> ) token */
			SeToken *subtokp, *detp;
			register int parenct;	/* () nesting level */
			DqNode	*subexpp,	/* subexpr. tokens */
				*cmpexpp,	/* compiled subexpr. */
				*prevtokp = lfparp->link.left;
						/* ('s predecessor */
		/* Find matching right parenthesis (ends subexpr). */
		for(	rtparp = DqTNext( stackp, &lfparp->link, SeToken ),
			parenct = 0;
		      	!(parenct == 0 && rtparp->type == SeNT_RT_PAREN);
			rtparp = DqTNext( stackp, &rtparp->link, SeToken )
			)
			{
			assert(rtparp != DqFirst( stackp, SeToken ));
			/* (Real syntax error was diagnosed earlier.) */
			assert(parenct >= 0);
			if( rtparp->type == SeNT_LF_PAREN )
				parenct++;
			else
			if( rtparp->type == SeNT_RT_PAREN )
				parenct--;
			assert(parenct >= 0);
			}
		/* Move current pointer to after the parenthesized
		   expression, for next iteration. */
		tokenp = DqFirst( &rtparp->link, SeToken );
		/* Detach subexpression from token stack, replacing it
		   with the compiled subexpression. */
		if( (subexpp = DqOpen()) == NULL )
			goto report_err;
		/* Transfer subexpr. token chain to subexpp queue. */
		subexpp->right = lfparp->link.right;
		subexpp->left = rtparp->link.left;
		subexpp->right->left = subexpp->left->right = subexpp;
		/* Snip out the parentheses (conceptually now empty). */
		(prevtokp->right = rtparp->link.right)->left = prevtokp;
		/* Free left-paren and right-paren token nodes. */
		SeTokFree( lfparp );
		SeTokFree( rtparp );
		/* Recursively compile the subexpression. */
		if( (cmpexpp = SeStkCompile( vars, subexpp, argnames ))
			== NULL )
			goto report_err;	/* stack eventually flushed */
		assert(cmpexpp == subexpp);
		assert(cmpexpp->right == cmpexpp->left); /* one node */
		/* Allocate an expression token on which to hang the
		   compiled subexpression for a while. */
		subtokp = (SeToken  *)DmXalloc(SeToken);
		subtokp->type = SeNT_EXPR;
		subtokp->lhsp = NULL;
		subtokp->text = DmStrDup("" );
		/* Reattach compiled subexpression to EXPR token. */
		detp = DqTPop( cmpexpp, SeToken );
		assert(DqIsEmpty( cmpexpp ));
		DqClose( cmpexpp );
		if( (subtokp->rhsp = SeDoTokSysDef( detp, argnames ))
			== NULL )
			goto doterr;
		/* Link subexpr. into token chain in place of (...) */
		DqR_Insert( &subtokp->link, prevtokp );
		continue;	/* process more instances of (...) */

		/* Error handling: */
doterr:
		/* Reattach the detached tokens so they can be freed. */
		DqR_Insert( &detp->link, prevtokp );
		assert(subtokp->text != NULL);
		assert(subtokp->text[0] == 0);
		DmFree((genptr_t)subtokp->text );
strerr:
#ifdef DEBUG
		subtokp->type = SeNT_UNSET;	/* safety net */
		subtokp->rhsp = NULL;
#endif
		DmFree((genptr_t)subtokp );
		goto report_err;
		} /* else block */
		} /* for */
	/* At this point, we have eradicated all parentheses and function
	   calls by recursively evaluating their contents as subexpressions.
	   The rest of the operators are processed in order of precedence;
	   therefore, all operators bind with their next-door neighbors. */
	/* Process qualified components. */
#if SeDEBUG == 2
	SeDbgStack("SeStkCompile: qualified components",stackp,(NmPool *)NULL );
#endif
	DqEACH( stackp, tokenp, SeToken )
	/* note: for VSL, QUALCOMP node type will not be seen (11-04-29 ch3) */
	if( tokenp->type == SeNT_QUALCOMP )
#ifdef COMPILE_FOR_VSL
		/* for VSL, create a QUALOP node */
		/* with lhsp set to COMPNAME node with base index */
		/* and rhsp set to CQUALIFIER node */
		/* qualified component name will be added to SeComponents */
		/* VSL will create qualified componenet name as needed */
		{	static SeToken *lfsqrp, *cqualp, *rtsqrp;
			char qualname[SeBUFSIZE]; /* build qualified name */
		/* Promote SeNT_LF_SQUARE to SeNT_QUALOP node. */
		lfsqrp = DqTNext( stackp, &tokenp->link, SeToken );
		assert(lfsqrp != DqFirst( stackp, SeToken ));
		assert(lfsqrp->type == SeNT_LF_SQUARE);
		lfsqrp->type = SeNT_QUALOP;
		cqualp = DqTNext( stackp, &lfsqrp->link, SeToken );
		assert(cqualp != DqFirst( stackp, SeToken ));
		assert(cqualp->type == SeNT_CQUALIFIER);
		rtsqrp = DqTNext( stackp, &cqualp->link, SeToken );
		assert(rtsqrp != DqFirst( stackp, SeToken ));
		assert(rtsqrp->type == SeNT_RT_SQUARE);
		/* Detach SeNT_RT_SQUARE node. */
		rtsqrp = DqTDetach( stackp, &rtsqrp->link, SeToken );
		assert(rtsqrp != NULL);
		assert(rtsqrp->type == SeNT_RT_SQUARE);
		SeTokFree( rtsqrp );
		tokenp = DqTDetach( stackp, &tokenp->link, SeToken );
		/* process node to COMPNAME, set index to base comp index */
		if( (lfsqrp->lhsp = SeDoTokSysDef( tokenp, argnames )) == NULL )
			{ /* Free detached token, then free rest of stack. */
			SeTokFree( tokenp );
			goto flushstack;
			}
		cqualp = DqTDetach( stackp, &cqualp->link, SeToken );
		/* process CQUALIFIER node, adds to SeQualifiers name pool */
		if( (lfsqrp->rhsp = SeDoTokSysDef( cqualp, argnames )) == NULL )
			{ /* Free detached token, then free rest of stack. */
			SeTokFree( cqualp );
			goto flushstack;
			}
		/* create qualified component name */
		sprintf(qualname, "%s[%s]", tokenp->text, cqualp->text);
		/* add to SeComponents name ppol (don't care about its index) */
		if ((NmIndex(qualname, &SeComponents, mTrue)) == -1)
			goto report_err;
		/* should not be necessary to add to SeQualp[] for VSL */
		/* finally set top node to QUALOP node */
		tokenp = lfsqrp;
		}
#else  // MUVES
		/* for MUVES, create an EXPR node with no lhsp and */
		/* rhsp set to COMPNAME node with qualified component index */
		{	SeToken *cqualtokp;
			SeToken *comptokp;
			SeToken *exptokp;
			char qualname[SeBUFSIZE]; /* build qualified name */
			int index, count;
		comptokp = tokenp;
		/* Allocate an expression token on which to hang the
		  compiled qualified component for a while. */
		exptokp = (SeToken  *)DmXalloc(SeToken);
		exptokp->type = SeNT_EXPR;
		exptokp->lhsp = NULL;
		/* Store component name for a little while. */
		exptokp->text = DmStrDup(comptokp->text );
		/* Replace qualified component token with expression token
		   in stack. */
		DqR_Insert( &exptokp->link, &comptokp->link );
		tokenp = exptokp;	/* tokenp must stay valid in loop */
		comptokp = DqTDetach( stackp, &comptokp->link, SeToken );
		/* Detach left bracket node and free storage. */
		cqualtokp = DqTNext( stackp, &exptokp->link, SeToken );
		assert(cqualtokp != DqFirst( stackp, SeToken ));
		cqualtokp = DqTDetach( stackp, &cqualtokp->link, SeToken );
		assert(cqualtokp != NULL);
		assert(cqualtokp->type == SeNT_LF_SQUARE);
		SeTokFree( cqualtokp );
		/* Detach qualifier node. */
		cqualtokp = DqTNext( stackp, &exptokp->link, SeToken );
		assert(cqualtokp != DqFirst( stackp, SeToken ));
		cqualtokp = DqTDetach( stackp, &cqualtokp->link, SeToken );
		assert(cqualtokp != NULL);
		assert(cqualtokp->type == SeNT_CQUALIFIER);
		/* Build qualified component name. */
		(void) sprintf( qualname, "%s[%s]",
				exptokp->text, cqualtokp->text );
		/* Free qualifier node. */
		SeTokFree( cqualtokp );
		/* Convert qualified component node to SeSysDef node. */
		if( (exptokp->rhsp = SeDoTokSysDef( comptokp, argnames ))
			== NULL )
			goto qfreetxt_err;
		index = exptokp->rhsp->c.index; /* save component index */
		assert(exptokp->rhsp->type == SeNT_COMPNAME);
			/* would have generated syntax error */
		/* Add qualified component name to name pool. */
		count = NmCount( &SeComponents );
		if( (exptokp->rhsp->c.index =
			NmIndex(qualname, &SeComponents, mTrue))
			== -1 )
			goto qfreetxt_err;

		/* copy qualname to core text name */
		DmFree((genptr_t)exptokp->rhsp->core.text );
		exptokp->rhsp->core.text = DmStrDup(qualname);

		assert(exptokp->rhsp->c.index >= NmCount( &RtComponents ));
		/* If the name pool grew, must add qualifier to list. */
		if( count < NmCount( &SeComponents ) )
			{	SeQalNode *newp;
			/* Initialize Dq list if necessary. */
			if(	SeQualp[index] == NULL /* not initialized */
			    &&	(SeQualp[index] = DqOpen()) == NULL )
				goto qfreetxt_err;
			newp = (SeQalNode  *)DmXalloc(SeQalNode);
			newp->index = exptokp->rhsp->c.index;
			DqPush( SeQualp[index], &newp->link );
#if SeDEBUG == 2
			ErPLog( "SeStkCompile: %s:%d newp=0x%x index=%d\n",
				NmName( index, &SeComponents ), index, newp,
				newp->index );
#endif
			}
		/* Detach right bracket node and free storage. */
		cqualtokp = DqTNext( stackp, &exptokp->link, SeToken );
		assert(cqualtokp != DqFirst( stackp, SeToken ));
		cqualtokp = DqTDetach( stackp, &cqualtokp->link, SeToken );
		assert(cqualtokp != NULL);
		assert(cqualtokp->type == SeNT_RT_SQUARE);
		SeTokFree( cqualtokp );
		continue;
qfreeqal_err:
		{	SeQalNode *np;
		while( (np = DqTPop( SeQualp[index], SeQalNode )) != NULL )
			{
#ifdef DEBUG
			np->index = -1; /* safety net */
			np->link.left = np->link.right = NULL;
#endif
			DmFree((genptr_t)np );
			}
		DqClose( SeQualp[index] );
		SeQualp[index] = NULL; /* safety net */
		}
qfreetxt_err:
		DmFree((genptr_t)exptokp->text );
qfreetok_err:
#ifdef DEBUG
		exptokp->type = SeNT_UNSET;	/* safety net */
		exptokp->rhsp = NULL;
#endif
		DmFree((genptr_t)exptokp );
		goto report_err;
		}
#endif  // MUVES
	else
	if( tokenp->type == SeNT_QUALSYS || tokenp->type == SeNT_QUALIST )
		/* For qualified systems/lists, we must defer processing of
		   the qualifier, so we turn it into a binary operator node.
		   Here we eliminate the SeNT_RT_SQUARE node, and
		   promote the SeNT_LF_SQUARE node to a SeNT_QUALOP node. */
		{	static SeToken *lfsqrp, *cqualp, *rtsqrp;
		/* Promote SeNT_LF_SQUARE to SeNT_QUALOP node. */
		lfsqrp = DqTNext( stackp, &tokenp->link, SeToken );
		assert(lfsqrp != DqFirst( stackp, SeToken ));
		assert(lfsqrp->type == SeNT_LF_SQUARE);
		lfsqrp->type = SeNT_QUALOP;
		cqualp = DqTNext( stackp, &lfsqrp->link, SeToken );
		assert(cqualp != DqFirst( stackp, SeToken ));
		assert(cqualp->type == SeNT_CQUALIFIER);
		rtsqrp = DqTNext( stackp, &cqualp->link, SeToken );
		assert(rtsqrp != DqFirst( stackp, SeToken ));
		assert(rtsqrp->type == SeNT_RT_SQUARE);
		/* Detach SeNT_RT_SQUARE node. */
		rtsqrp = DqTDetach( stackp, &rtsqrp->link, SeToken );
		assert(rtsqrp != NULL);
		assert(rtsqrp->type == SeNT_RT_SQUARE);
		SeTokFree( rtsqrp );
		tokenp = DqTDetach( stackp, &tokenp->link, SeToken );
		if( (lfsqrp->lhsp = SeDoTokSysDef( tokenp, argnames )) == NULL )
			{ /* Free detached token, then free rest of stack. */
			SeTokFree( tokenp );
			goto flushstack;
			}
		cqualp = DqTDetach( stackp, &cqualp->link, SeToken );
		if( (lfsqrp->rhsp = SeDoTokSysDef( cqualp, argnames )) == NULL )
			{ /* Free detached token, then free rest of stack. */
			SeTokFree( cqualp );
			goto flushstack;
			}
		tokenp = lfsqrp;
		}
	/* Process unary operators, right-to-left precedence. */
	SeUnOpCombine(	"SeStkCompile: unary op",
			tokenp->type == SeNT_NOT
		     ||	tokenp->type == SeNT_ANOT
		     ||	tokenp->type == SeNT_ABS
		     ||	tokenp->type == SeNT_BOOL
		     );
	/* Process all binary operators, left-to-right precedence. */
	SeBinOpCombine( "SeStkCompile: LIST", tokenp->type == SeNT_LIST );
	SeBinOpCombine( "SeStkCompile: AND", tokenp->type == SeNT_AND );
	SeBinOpCombine( "SeStkCompile: XOR", tokenp->type == SeNT_XOR );
	SeBinOpCombine( "SeStkCompile: OR", tokenp->type == SeNT_OR );
	SeBinOpCombine( "SeStkCompile: MIN or MAX",
		tokenp->type == SeNT_MIN || tokenp->type == SeNT_MAX );
	SeBinOpCombine( "SeStkCompile: PROD or QUOT",
		tokenp->type == SeNT_PROD || tokenp->type == SeNT_QUOT );
	SeBinOpCombine( "SeStkCompile: SUM or DIFF",
		tokenp->type == SeNT_SUM || tokenp->type == SeNT_DIFF );
	SeBinOpCombine( "SeStkCompile: LT or GT",
		tokenp->type == SeNT_LT || tokenp->type == SeNT_GT );
	SeBinOpCombine( "SeStkCompile: LTEQ or GTEQ",
		tokenp->type == SeNT_LTEQ || tokenp->type == SeNT_GTEQ );

#if SeDEBUG == 2
	SeDbgStack( "SeStkCompile:leaving", stackp, (NmPool *) NULL );
#endif
	return stackp;			/* report success */
flushstack:
	SeFlushStack(vars);
	return NULL;
	}

/*
	MuvesBool SeListCompile( SeParseVars *vars )

	Compile a list from the parser token stack (SeStackp).  SeStackp
	is assumed to contain a list (list_name=member[,member]+) represented
	as a stack of input tokens.  SeListCompile() adds the list name to
	the SeLists name pool and adds the list to the SeListDfn array,
	indexed by name pool index.  It also deletes the list name from the
	SeSystems name pool and removes the corresponding entry in the
	SeDataSystem array.  The entire parser token stack is freed
	in the process.

	RETURN: mTrue for success

		mFalse and set an error index upon failure
 */
STATIC MuvesBool
#if STD_C
SeListCompile( SeParseVars *vars )
#else
SeListCompile()
#endif
	{	register SeToken *tokenp;
		register int index;
		register int parenct = 0;
		DqNode *memstackp = NULL; /* For compiling members. */
		char *expr_name= NULL;

	assert(vars->SeStackp != NULL);
#if SeDEBUG == 3
	SeDbgStack( "SeListCompile", vars->SeStackp, (NmPool *) NULL );
#endif

	/* Pop list-name token off stack. */
	tokenp = DqTPop( vars->SeStackp, SeToken );
	assert(tokenp != NULL);
	assert(tokenp->type == SeNT_LISTNAME);
	assert(tokenp->text != NULL);
	assert(tokenp->text[0] != 0);

	/* First, if list name is registered as a system, fix it.  This
	   is necessary when SeStOpen() is called previously. */
	if( (index = NmIndex( tokenp->text, &SeSystems, mFalse )) != -1 )
		{	SeSyDat *sydp;
		if( SeDataSystem[index] != NULL )
			{
			ErPLog( " *** List name \"%s\" redefined.\n",
				tokenp->text );
			goto noadd;
			}
		else
		sydp = SeDataSystem[index] = (SeSyDat  *)DmXalloc(SeSyDat);
		/* Fill in the header info for the system.  Since it is a list
		   name, this is just a place holder. */
		sydp->state = SeINVALID;
		sydp->save.value = SeTypeUnset; /* safety net */
		sydp->save.type = SeTypeUnset;  /* ditto */
		sydp->sysdef = (SeSysDef  *)DmXalloc(SeSysDef);
		sydp->sysdef->type = SeNT_LISTNAME;
		sydp->sysdef->core.text = DmStrDup(tokenp->text );
		assert( sydp->sysdef->core.text != NULL );
		}
	else
		ErClear(); /* not an error */

	/* Insert list named by tokenp->text into the SeLists name pool
	   (extend the SeListDfn array, if necessary, to accommodate it). */
	if( (index = SeListInsert( tokenp->text )) < 0 )
		{
		assert(index == -1);
		goto noadd;
		}
	assert(index < SeLiDLen);
	/* Allocate SeLiDat node for this system. */
	if( SeListDfn[index] != NULL )
		{
		ErPLog( "List \"%s\" is multiply defined\n", tokenp->text );
		SeTokFree( tokenp );
		ErSet( SeDUPLIST );
		goto nocomp;
		}
	/* Release storage for list-name token. */
	SeTokFree( tokenp );

	/* Pop assignment token off stack and free its storage. */
	tokenp = DqTPop( vars->SeStackp, SeToken );
	assert(tokenp != NULL);
	assert(tokenp->type == SeNT_ASSIGNMENT);
	assert(tokenp->text != NULL);
	assert(StrEq(tokenp->text, SeTtbl[SeNT_ASSIGNMENT].ts));
	SeTokFree( tokenp );
	tokenp = NULL;

	/* Initialize SeListDfn[index] if not already. */
	if(	SeListDfn[index] == NULL
	    &&	(SeListDfn[index] = (SeLiDat *) DqOpen()) == NULL )
		goto noadd;

	/* Compile list. Push each member on a stack, compile it, and
	   append it to the list definition. */
	if( (memstackp = DqOpen()) == NULL )
		goto noadd;
	parenct = 0;
	do
		{	SeSysDef *sysdefp;
			register SeLiMember *mp;

		if ( tokenp != NULL && ((tokenp->type == SeNT_LIST) && 
					(parenct == 0))
			)
			{
			SeTokFree( tokenp );
			tokenp = NULL;
			}
		tokenp = DqTPop( vars->SeStackp, SeToken );
#if SeDEBUG == 3
		ErPLog( "SeListCompile: tokenp is 0x%x:%s:\n",
			tokenp, tokenp == NULL ? "empty" : tokenp->text );
#endif
		if( tokenp == NULL || ((tokenp->type == SeNT_LIST) && 
					(parenct == 0)))
			{	SeToken *memtokp;
			/* Compile member token and append to list. */
			assert( ! DqIsEmpty( memstackp ) );
			if( SeStkCompile( vars, memstackp, (NmPool *)NULL ) == NULL )
				goto badmember;
			memtokp = DqTPop( memstackp, SeToken );
#if SeDEBUG == 3
			ErPLog( "SeListCompile: memtokp is 0x%x:%s:\n",
				memtokp, memtokp->text );
#endif
			assert( memtokp != NULL );
			assert( DqIsEmpty( memstackp ) );
			if( (sysdefp = SeDoTokSysDef( memtokp, &vars->argnames ))
				== NULL )
				goto nocomp;
			mp = (SeLiMember  *)DmXalloc(SeLiMember);
#if SeDEBUG == 3
			ErPLog( "SeListCompile: member is 0x%x:%s:\n",
				sysdefp, SeSysTextRep( sysdefp ) );
#endif

			switch(sysdefp->type)
				{
			case SeNT_LISTNAME :
			case SeNT_QUALIST :
			case SeNT_SYSNAME :
			case SeNT_QUALSYS :
				DmFree((genptr_t)expr_name );
				expr_name = NULL;
				break;
			default:
				DmFree((genptr_t)sysdefp->core.text);
				sysdefp->core.text = expr_name;
				expr_name = NULL;
				}

			SeOptimize (&sysdefp);
			mp->member = *sysdefp; /* struct copy */

			DmFree((genptr_t)sysdefp );
			DqAppend( SeListDfn[index], &mp->link );
#if SeDEBUG == 3
			{	SeLiMember *lmp;
			ErPLog( "SeListCompile: appending member %s:\n",
				SeSysTextRep( &mp->member ) );
			DqEACH( SeListDfn[index], lmp, SeLiMember )
				ErPLog( "mp=0x%x member=%s\n",
					lmp, SeSysTextRep( &lmp->member ) );
			}
#endif
			}
		else
			{
				struct bu_vls vls;

			if( expr_name == NULL )
				expr_name = DmStrDup( tokenp->text);
			else
				{
				bu_vls_init(&vls);
				bu_vls_strcat (&vls, expr_name);
				bu_vls_strcat(&vls, tokenp->text);
				DmFree((genptr_t)expr_name );
				expr_name = DmStrDup(bu_vls_addr(&vls));
				bu_vls_free(&vls);
				}
			switch ( tokenp->type)
				{
			case SeNT_LF_PAREN:
				parenct++;
				break;
			case SeNT_RT_PAREN:
				parenct--;
				break;
				}
			DqAppend( memstackp, &tokenp->link );
			continue;
			}
		}
	while( tokenp != NULL );

	if (expr_name != NULL)
		DmFree((genptr_t)expr_name );


#if SeDEBUG == 3
	{	SeLiMember *lmp;
	ErPLog( "SeListCompile: list members:\n" );
	DqEACH( SeListDfn[index], lmp, SeLiMember )
		ErPLog( "mp=0x%x member=%s\n",
			lmp, SeSysTextRep( &lmp->member ) );
	}
#endif

	DqClose( memstackp);

	return	mTrue;

	/* Error handling: */
badmember:
	ErPLog( "*** %s: expected \"%s\"(%s) got \"%s\"(%s).\n",
		"Error compiling list members",
		SeTtbl[SeNT_LIST].ts, SeCvtToStr( SeNT_LIST ),
		tokenp->text, SeCvtToStr( tokenp->type ) );
	SeTokFree( tokenp );
	goto flstak;

noadd:
	ErPLog( "Couldn't add \"%s\" to systems list\n", tokenp->text );
	SeTokFree( tokenp );
	goto flstak;
nocomp:
	assert(NmName( index, &SeLists ) != NULL);
	ErPLog( "Error while compiling list \"%s\"\n",
		NmName( index, &SeLists ) );
flstak:
	SeFlushStack(vars);
#ifdef DEBUG
	ErPLog( "SeListCompile: %s\n", ErString() );
#endif
	assert(ErIsSet());
	return	mFalse;			/* report failure */
	}


/*
	MuvesBool SeSysCompile( SeParseVars *vars, MuvesBool optimize )

	Compile the system from the parser token stack (SeStackp).  SeStackp
	is assumed to contain a system definition (sys_name=expr) represented
	as a stack of input tokens.  SeSysCompile() uses SeSysInsert() to add
	the system to the SeSystems name pool; then it sets up the SeDataSys-
	tem array.  Then it compiles the system by calling SeStkCompile() and
	SeTok2SysDef() and links the resulting expression into the SeDataSys-
	tem array, freeing up the entire parser token stack in the process.
	If optimize is mTrue, call the optimization functions, otherwise leave
	the function definition as it exists in the input file.

	RETURN: positive index of system compiled
		SeCompile_FAIL
 */
/* 11-04-29 ch3: changed return value to index of system compiled (VSL) */
STATIC MuvesBool
#if STD_C
SeSysCompile( SeParseVars *vars, MuvesBool optimize )
#else
SeSysCompile( optimize )
MuvesBool optimize;
#endif
	{	register SeToken *tokenp;	/* -> sys_name or "=" token */
		register int index;		/* SeSystems name-pool index */
		register DqNode *cmpstack;	/* -> compiled expression */
		register SeSyDat *sydp;
	assert(vars->SeStackp != NULL);
#if SeDEBUG == 2
	SeDbgStack( "SeSysCompile", vars->SeStackp, (NmPool *) NULL );
#endif

	/* Pop system-name token off stack. */
	tokenp = DqTPop( vars->SeStackp, SeToken );
	assert(tokenp != NULL);
	assert(tokenp->type == SeNT_SYSNAME);
	assert(tokenp->text != NULL);
	assert(tokenp->text[0] != 0);

	/* Insert system named by tokenp->text into the SeSystems name pool
	   (extend the SeDataSystem array, if necessary, to accommodate it). */
	if( (index = SeSysInsert( tokenp->text )) < 0 )
		{
		assert(index == -1);
		goto noadd;
		}
	assert(index < SeSyDLen);

	/* Allocate SeSyDat node for this system. */
	/* 11-04-21 ch3: only check for defined system in file mode (VSL) */
	if( !vars->interactive && SeDataSystem[index] != NULL )
		{
		ErPLog( "System \"%s\" is multiply defined\n", tokenp->text );
		SeTokFree( tokenp );
		ErSet( SeDUPSYSDEF );	/* duplicate system definition */
		goto nocomp;
		}

	/* Release storage for system-name token. */
	SeTokFree( tokenp );

	/* Pop assignment token off stack and free its storage. */
	tokenp = DqTPop( vars->SeStackp, SeToken );
	assert(tokenp != NULL);
	assert(tokenp->type == SeNT_ASSIGNMENT);
	assert(tokenp->text != NULL);
	assert(StrEq(tokenp->text, SeTtbl[SeNT_ASSIGNMENT].ts));
	SeTokFree( tokenp );

	/* Compile expression for this system and link it into the
	   SeDataSystem	array. */
	/* 11-05-23 ch3: just get sysdef before allocating SeSyDat (VSL) */
	SeSysDef *sysdef = NULL;	/* in case SeStkCompile dies */
	if( (cmpstack = SeStkCompile( vars, vars->SeStackp, (NmPool *) NULL )) == NULL
	 || (sysdef = SeTok2SysDef( vars, cmpstack )) == NULL )
		goto nocomp;

	/* 11-05-23 ch3: check for recursion in proposed expression (VSL) */
	int found;
	if (vars->interactive && (found = SeFindSysExpr(sysdef, index)) != -1)
	{
		/* system was found in expression, there is recursion, reject */
		SeExpFree(sysdef);
		ErSet(SeSYSRECURSIVE);
		sprintf(vars->errmsg, "Child %s is already an ancestor of %s!",
			NmName(found, &SeSystems), NmName(index, &SeSystems));
		return SeCompile_FAIL;
	}

	/* 11-05-23 ch3: sysdef is valid, SeSyDat can be allocated (VSL) */
	sydp = (SeSyDat  *)DmXalloc(SeSyDat);
	sydp->state = SeINVALID; /* initialize system node */
	sydp->sysdef = sysdef;
#ifdef DEBUG
	sydp->save.value = -1.0;	/* safety net */
	sydp->save.type = SeTypeUnset; /* safety net */
#endif

	/* 11-04-21 ch3: now that sysdef compiled, delete any existing (VSL) */
	if (SeDataSystem[index] != NULL)
	{
		SeExpFree(SeDataSystem[index]->sysdef);
	}
	/* 11-04-21 ch3: and assign new sysdef into array (VSL) */
	SeDataSystem[index] = sydp;

	/* Optimize the expression tree if desired. */
	/*  added by Jeff Hanes, 20 Mar 95  */
	if( optimize )
		{
		SeOptimize( &SeDataSystem[index]->sysdef );
		/* 06-21-00 ch3  added check for error flag because new */
		/*               multiple occurrence routine may set it */
		/* 11-04-29 ch3: changed return value (VSL) */
		if (ErIsSet())
			return SeCompile_FAIL;
		}
	/* 11-04-29 ch3: changed return value (VSL) */
	return	index;

	/* Error handling: */
noadd:
	ErPLog( "Couldn't add \"%s\" to systems list\n", tokenp->text );
	SeTokFree( tokenp );
	goto flstak;
nocomp:
	assert(NmName( index, &SeSystems ) != NULL);
	ErPLog( "Error while compiling system \"%s\"\n",
		NmName( index, &SeSystems ) );
flstak:
	SeFlushStack(vars);
#if DEBUG
	ErPLog( "SeSysCompile: %s\n", ErString() );
#endif
	assert(ErIsSet());
	/* 11-04-29 ch3: changed return value (VSL) */
	return	SeCompile_FAIL;			/* report failure */
	}
