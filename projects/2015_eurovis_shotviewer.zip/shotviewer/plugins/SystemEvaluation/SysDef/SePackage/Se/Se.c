/*
	Se.c -- MUVES "Se" (system evaluator) package

	created:	88/01/12	G S Moss
	edited:         01/04/17        C Hunt III
			removed static from SeCritSz, SeRegisterQualComp()
	edited:		01/12/07	C Hunt III
			added case for SeNT_TMPEXPR to SeExpFree()
	edited:		02/07/24	C Hunt III
			corrected comparison operators in SeGetPks() and
			SeGetPkds() - this corrects a bug that cause too much
			memory to be allocated depending on the size of the list
			in the _Pkd function
	edited:		02/07/27        C Hunt III
			added support for ORCA node type to SeExpCopy(),
			SeExpFree(), SeCrtExpression(), SeAddListMember(),
			SePrtExpression(), SeTxtExpression(), SeGetQualName(),
			and SeStoreSysComps()
			implemented new _orca function in SeEvlExpression()
			added new function SeCheckExprAndGetComp() (SCR446)
	edited:		02/10/15	C Hunt III
			moved the number of kills check for the _Pkd function in
			SeEvlExpression() - this corrects a bug that lead to
			unpredictable results with the number of kills form of
			the _Pkd function
	edited:		03/09/11	C Hunt III
			added SeNT_QUALCOMP node type to SeExpCopy(),
			discovered this problem during testing of AJEM SCR414
			(multiple occurrence expression substitution bug)
	edited:		05/04/18	C Hunt III
			modified debugging message related to calling
			SeOptimize(), which calls SeFindMultOcc(),
			changes made related to SCR579
	edited:		05/06/20	C Hunt III
			added error flag check after call to SeOptimize() so
			that if the error flag has been set inside
			SeFindMultOcc(), the Se parser will abort (AJEM SCR579)
	edited:		06/02/20	C Hunt III
			Correct pkiterate code to use same component values for
			all systems of a state vector, previous component values
			were randomly drawn for each system definition by adding
			new function SeIterateVector();
			optimized reading of SingleStream environment variable
			where it is read once and its value stored instead of
			being read, i.e. calling ApGetEnv() for each used;
			changed unecessary DmCalloc() calls to DmMalloc()
			since memory is initialized after it was allocated;
			optimated SeIterate() function;
			removed unecessary intialization loops after allocation
			by 4 DmCalloc() calls in SeSysOpen() (SCR747)
	edited:		08/07/22	C Hunt
			added SeSyDStart variable to contain the start of the
			user sysdefs (from the sysdef file), initialized this
			variable in SeSysOpen() after the built-in systems and
			environment variable systems are added (SCR813)
	edited:		09/11/16	C Hunt
			added a limit check for the number of elements in the
			list argument of the _Pkd function of 30, greater than
			this results in an overflow in the calculation for the
			number of calculations (2^number of elements) that need
			to be performed, which causes the calculation routine to
			malfunction - an error is thrown for this error situation
			the equation for calculating the number of calculations
			was replaced with a better one using the '<<' operator
			(SCR1300)
	edited:		12/10/22	C Hunt
			corrected compiler warnings (VSL)
*/
#ifndef lint
static char RCSid[] = "$Id: Se.c,v 1.94 2010/06/23 19:54:51 geoffs Exp $";
#endif

#ifndef DEBUG
#define NDEBUG
#endif

#include <assert.h>
#include <math.h>
#include <setjmp.h>
#include <signal.h>
#include <stdio.h>
#include <string.h>
#ifdef __STDC__
#include <stdlib.h>			/* for abort() */
#include <time.h>			/* 05-08-25 ch3: SCR579 */
#else
extern void abort();
#endif

#include <std.h>

#include <Ap.h>
#include <Cp.h>  /* 02-07-27 ch3: added for CpORCA_PERSONNEL */
#include <Dq.h>
#include <Er.h>
#include <Io.h>
#include <stdio.h>
#include <common.h>   /* BRL-CAD 7.2.4+ no longer use config.h (SCR670) */
#include <bu.h>
#include <Dm.h>
#include <Nm.h>
#include <Rn.h>
#include <Rt.h>
#include <Se.h>

#include "SeDefs.h"

#ifndef SIG_ERR
#if STD_C
#define	SIG_ERR	((void (*)( int ))-1)
#else
#define	SIG_ERR	((void (*)())-1)
#endif
#endif

#ifndef STATIC
#define STATIC	static
#endif


#ifndef SeDEBUG
#define SeDEBUG	0
#endif

extern int SeDebugging;
#define ErDebugging SeDebugging

/* Global pointer to "iscritical" array, see SeStIsCritical(). */
char *SeIsCritical = NULL;
/* 01-04-17 ch3: removed static from SeCritSz for SeTcl.c */
int SeCritSz = 0;	/* current size of array */

DqNode **SeSysComps = NULL;	/* linked lists containing sorted RtComponent
				   ids for each system in SeSystems name pool. */

DqNode **SeStateComps = NULL;	/* linked lists containing RtComponent ids for
				   all elements of each state vector analyzed. */

STATIC FILE *SeOutp;

/* 06-02-20 ch3: added flag indicating if "SingleStream" was read (SCR747) */
MuvesBool single_stream = mFalse;

/* Variables to store the needed number of iterations */
int iterations=-1;  /* 06-02-20 ch3: changed from long */
long chebyIterations=-1;

/* Stores the maximum number of iterations for pkchebyshev */
long maxIterations=-1;

/* If mTrue, allows conversion from lof & frf to type killed.  Used so that pkiterate and pk chebyshev model pk */
MuvesBool iterating=mFalse;

/* Flags so that LOF & FRF to pk errors only print once */
MuvesBool printedLOFError=mFalse;
MuvesBool printedFRFError=mFalse;

/* 06-02-20 ch3: removed unecessary global envp1 and envp2 (SCR747) */
/* Variables for holding chebyshev values */
double interval=.01;
double confidence=.8;

/* Since RtComponents name pool may be out of sync during DdDepend's
   reinitialization of the various packages, keep a private copy of the
   number of components in the name pool, set/reset by SeSysOpen/SeSysClose. */
int SeNComps = 0;

/*
	NmPool SeSystems

	SeSysOpen() reads all system definitions from the designated
	"sysdef" file and returns a pointer to a name pool of systems
	encountered while parsing the file; this name pool is also
	accessible as the global variable SeSystems.

	NmPool SeComponents

	SeSysOpen() makes a copy of the RtComponents name pool and
	adds any qualified components to the end as they are encountered
	while parsing the "sysdef" file.

	NmPool SeFunctions

	SeFnCompile() adds each function to this name pool as its definition
	is compiled.

	NmPool SeStates

	SeCompile() parses and compiles state vector definitions from the
	"states" file and builds a name pool of state vectors; this name
	pool is accessible as the global variable SeStates.

	NmPool SeQualifiers

	SeStkCompile() adds each system qualifier to this name pool.

	NmPool SeLists

	SeListCompile() builds this name pool to store names of lists.
 */
NmPool SeSystems;	/* target systems from sysdef exprs */
NmPool SeComponents; 	/* RtComponents name pool plus qualified components */
NmPool SeFunctions;	/* function definitions */
NmPool SeStates;	/* state vector definitions */
NmPool SeQualifiers;	/* system qualifiers */
NmPool SeLists;		/* lists for aliasing in state vector definitions */

/* dynamically-allocated array of pointers to Dq lists of SeQalNode structs,
   indexed by SeComponents name pool indices. */
DqNode **SeQualp = NULL;	/* parallels SeComponents and points to
				   lists of qualified instances. */

/* dynamically-allocated array of SeTypeKilled values (stuffed into shorts),
   indexed by SeComponents name pool indices. */
short *SeKilled = NULL;

/* dynamically-allocated array of pointers to SeSyDat structs,
   indexed by SeSystems name pool indices: */
SeSyDat **SeDataSystem = NULL;
int SeSyDLen = SeSyD_LEN;	/* allocated length of SeDataSystem array */
/* 08-07-22 ch3: added start of user sysdefs variable (SCR813) */
int SeSyDStart;			/* start index of user sysdefs */

/* dynamically-allocated array of pointers to SeFnDat structs,
   indexed by SeFunctions name pool indices: */
SeFnDat **SeFnDfn = NULL;
int SeFnDLen = SeFnD_LEN;	/* allocated length of SeFnDfn array */
/* 12-04-02 ch3: added start of user functions variable (VSL) */
int SeFnDStart;			/* start index of user functions */

/* dynamically-allocated array of pointers to SeLiDat structs,
   indexed by SeLists name pool indices: */
SeLiDat **SeListDfn = NULL;
int SeLiDLen = SeLiD_LEN;	/* allocated length of SeListDfn array */


/* dynamically-allocated array of pointers to SeStDat structs,
	indexed by SeStates name pool indices: */
SeStDat **SeStDef = NULL;
int SeStDLen = SeStD_LEN;	/* allocated length of SeStDef array */

/* 11-05-13 ch3: added application pointer for VSL (VSL) */
void *SeAppPtr = NULL;

/* functions local to this module: */
/* 06-30-00 ch3  moved prototypes for SeGetQualName() to SeDefs.h */
#if STD_C
STATIC MuvesBool SeCrtSystem( int sys_index, char **iscritp, const char *qualifier );
STATIC MuvesBool SeCrtExpression( const SeSysDef *sysp, char **ip, const char *qp );
/* 01-04-17 ch3: removed STATIC and moved SeRegisterQualComp() to Se.h */
STATIC int SeRegisterQualSys( const SeSysDef *sysdefp, const char *qualifier );
STATIC double SeEvlComponent( int compid, const SeValue vals[], SeTypeID typ );
STATIC void SePrtTypeConvErr( int compid, SeTypeID from, SeTypeID to );
STATIC void SeStStomp( void );
STATIC void SeStompDat( void );
STATIC double SeIterate( long iterations, SeSysDef *sysdefp, const SeValue *valp, const double *argp, const char *qualifier );
#else
STATIC MuvesBool SeCrtSystem();
STATIC MuvesBool SeCrtExpression();
/* 01-04-17 ch3: removed STATIC and moved SeRegisterQualComp() to Se.h */
STATIC int SeRegisterQualSys();
STATIC double SeEvlComponent();
STATIC void SePrtTypeConvErr();
STATIC void SeStStomp();
STATIC void SeStompDat();
STATIC double SeIterate();
#endif
/* 06-02-20 ch3: added prototype for new function (SCR747) */
static MuvesBool SeIterateVector PARAMS((const char *statename, SeStDat *defp,
	const SeValue *valp));

#if SeDEBUG == 3
#if STD_C
STATIC void SePrtStVector( SeStDat *defp, const char *label );
#else
STATIC void SePrtStVector();
#endif
#endif

#ifdef DEBUG
#if STD_C
STATIC void SePrtNamePool( NmPool *poolp, const char *poolnm );
#else
STATIC void SePrtNamePool();
#endif
#endif
/*
	MuvesBool SeCrtSystem( int sys_index, char **iscritp, const char *qualifier )

	Walk the expression tree for the system with the given SeSystems index
	and set flags in the iscritp array for each component encountered.  The
	iscritp array must point to enough storage and its indices correspond
	to the component indices in the SeComponents name pool.

	SeCrtSystem() first locates the compiled expression for the named system
	in the SeDataSystem array, then calls SeCrtExpression() to walk the data
	structure which represents the compiled system.

	RETURN:	mTrue for success

		mFalse and set an error index if sysname is not in the SeSystems
		name pool, SeDataSystem is uninitialized, the named system
		is not compiled, the system definition is self-referencing,
		or as a side effect of SeCrtExpression() failure
 */
STATIC MuvesBool
#if STD_C
SeCrtSystem( int sys_index, char **iscritp, const char *qualifier )
#else
SeCrtSystem( sys_index, iscritp, qualifier )
int sys_index;
char **iscritp;
const char *qualifier;
#endif
	{	register SeSyDat *sdp;
		register int retcode;
	assert(sys_index >= 0);
	assert(sys_index < NmSize( &SeSystems ));
	assert(*iscritp != NULL);
#if SeDEBUG == 4
#if STD_C
	ErPLog( "SeCrtSystem([%s],%p)\n", NmName( sys_index, &SeSystems ),
		(pointer) *iscritp );
#else
	ErPLog( "SeCrtSystem([%s],0x%lx)\n", NmName( sys_index, &SeSystems ),
		(long) *iscritp );
#endif
#endif
	if( SeDataSystem == NULL )
		{	/* No systems compiled yet. */
			/* BUG: SeCntxCompile called before SeSysOpen. */
		ErSet( SeSTCMPNONSEQ );

		if( SeDebugging )	/* programmer's error, not user's */
			ErPLog( "SeCrtSystem: %s\n", ErString() );

		assert( SeDataSystem != NULL );
		return mFalse;
		}
	assert( SeDataSystem[sys_index] != NULL );
	sdp = SeDataSystem[sys_index];

	if( sdp->state == SeEVALUATING )
		{	/* Recursive definition of system. */
		/* The user better hear about this one. */
		ErPLog( "Recursive definition of system or list \"%s\".\n",
			NmName( sys_index, &SeSystems ) );
		ErPLog( "Recursion permitted with list definitions, but %s.\n",
			"lists must be defined before they are referenced" );
		ErSet( SeSYSRECURSIVE );
		return	mFalse;
		}
	sdp->state = SeEVALUATING;
	retcode = SeCrtExpression( sdp->sysdef, iscritp, qualifier );
	sdp->state = SeINVALID;
	return	retcode;
	}

/*
	SeSysDef *SeExpCopy( const SeSysDef *expp )

	Make copy of expression subtree pointed to by expp.

	This function is for internal Se package use only.
 */
SeSysDef *
#if STD_C
SeExpCopy( const SeSysDef *expp )
#else
SeExpCopy( expp )
const SeSysDef *expp;
#endif
	{	SeSysDef *newp;
	assert(expp != NULL);
#if SeDEBUG == 4
#if STD_C
	ErPLog( "SeExpCopy(%p) %s\n",
		(pointer) expp, SeCvtToStr( expp->type ) );
#else
	ErPLog( "SeExpCopy(0x%lx) %s\n",
		(long) expp, SeCvtToStr( expp->type ) );
#endif
#endif
	/* Allocate this node. */
	newp = (SeSysDef  *)DmXalloc(SeSysDef);
	*newp = *expp;
	newp->core.text = DmStrDup(expp->core.text );

	if( SeIS_UNARY_OP( expp->type ) )
		{
		if( expp->o.rhsp != NULL )
			newp->o.rhsp = SeExpCopy( expp->o.rhsp );
		assert( newp->o.lhsp == NULL );
		}
	else
	if( SeIS_BINARY_OP( expp->type ) )
		{
		if( expp->o.lhsp != NULL )
			newp->o.lhsp = SeExpCopy( expp->o.lhsp );
		if( expp->o.rhsp != NULL )
			newp->o.rhsp = SeExpCopy( expp->o.rhsp );
		}
	else
	switch( expp->type )
		{
	case SeNT_QUALSYS :
	case SeNT_QUALIST :
	case SeNT_SYSNAME :
	case SeNT_LISTNAME :
	case SeNT_CQUALIFIER :
	case SeNT_COMPNAME :
	case SeNT_QUALCOMP :  /* 03-09-11 ch3: added */
	case SeNT_CONSTANT :
		break; /* nothing to do */
	case SeNT_FNCALL :
		if( expp->f.argexps != NULL )
			{	SeArgExp *op;
			if( (newp->f.argexps = DqOpen()) == NULL )
				return NULL;
			assert(! DqIsEmpty( expp->f.argexps ));
			DqEACH( expp->f.argexps, op, SeArgExp )
				{	SeArgExp *np;
				np = (SeArgExp *)DmXalloc(SeArgExp);
				np->expp = SeExpCopy( op->expp );
				DqAppend( newp->f.argexps, &np->link );
				}
			}
		break;
	case SeNT_EXPR :
	/* 06-30-00 ch3  added case for new multiple occurrence operator */
	case SeNT_MULTOCC :
		if( expp->o.rhsp != NULL )
			newp->o.rhsp = SeExpCopy( expp->o.rhsp );
		assert(newp->o.lhsp == NULL);
		break;
	case SeNT_RUNIF :		/* just like a binary op */
	case SeNT_RNORM :
	case SeNT_MOFN :
	case SeNT_PKD :
	/* 02-07-27 ch3: added support for ORCA node type */
	case SeNT_ORCA :
	case SeNT_EVAL :
		if( expp->o.lhsp != NULL )
			newp->o.lhsp = SeExpCopy( expp->o.lhsp );
		if( expp->o.rhsp != NULL )
			newp->o.rhsp = SeExpCopy( expp->o.rhsp );
		break;
	default :
		if( SeDebugging )
			{
			ErPLog( "SeExpCopy: BUG: illegal type %s\n",
				SeCvtToStr( expp->type ) );
			assert(expp->type == SeNT_CONSTANT);	/* force core dump */
			}
		break;
		}
	return newp;
	}

/*
	void SeExpFree( SeSysDef *expp )

	Free up expression subtree pointed to by expp.

	This function is for internal Se package use only.
 */
void
#if STD_C
SeExpFree( SeSysDef *expp )
#else
SeExpFree( expp )
SeSysDef *expp;
#endif
	{
	assert(expp != NULL);
#if SeDEBUG == 4
#if STD_C
	ErPLog( "SeExpFree(%p) %s\n",
		(pointer) expp, SeCvtToStr( expp->type ) );
#else
	ErPLog( "SeExpFree(0x%lx) %s\n",
		(long) expp, SeCvtToStr( expp->type ) );
#endif
#endif
	if( SeIS_UNARY_OP( expp->type ) )
		{
		if( expp->o.rhsp != NULL )
			SeExpFree( expp->o.rhsp );
		/* else expression optimizer needs our assistance; be nice. */

		if( SeDebugging )
			expp->o.rhsp = NULL;	/* safety net */
		}
	else
	if( SeIS_BINARY_OP( expp->type ) )
		{
		if( expp->o.lhsp != NULL )
			SeExpFree( expp->o.lhsp );
		/* else expression optimizer needs our assistance; be nice. */
		if( expp->o.rhsp != NULL )
			SeExpFree( expp->o.rhsp );
		/* else expression optimizer needs our assistance; be nice. */
		if( SeDebugging )
			{
			expp->o.lhsp = NULL;	/* safety net */
			expp->o.rhsp = NULL;
			}
		}
	else
	switch( expp->type )
		{
	case SeNT_QUALIST :
	case SeNT_LISTNAME :
#if SeDEBUG == 4
		{	const char *name;
		if( NmCount( &SeLists ) == 0 )
			/* NmClear() may have been called from previous
			   SeSysClose(), so this is not an error. */
			ErPLog( "\tNT_LISTNAME:(unavailable)\n" );
		else
		if( (name = NmName( expp->c.index, &SeLists )) == NULL )
			ErPLog( "BUG:\tNT_LISTNAME:(***** undefined)\n" );
		else
			ErPLog( "\tNT_LISTNAME:%s\n", name );
		}
#endif
		if( SeDebugging )
			expp->c.index = -1;	/* safety net */
		break;
	case SeNT_QUALSYS :
	case SeNT_SYSNAME :
#if SeDEBUG == 4
		{	const char *name;
		if( NmSize( &SeSystems ) == 0 )
			/* NmClear() may have been called from previous
				SeSysClose(), so this is not an error. */
			ErPLog( "\tNT_SYSNAME:(unavailable)\n" );
		else
		if( (name = NmName( expp->c.index, &SeSystems )) == NULL )
			ErPLog( "BUG:\tNT_SYSNAME:(***** undefined)\n" );
		else
			ErPLog( "\tNT_SYSNAME:%s\n", name );
		}
#endif

		if( SeDebugging )
			expp->c.index = -1;	/* safety net */
		break;
	case SeNT_FNCALL :
		if( expp->f.argexps != NULL )
			{	SeArgExp *np;
			assert(! DqIsEmpty( expp->f.argexps ));
			while( (np = DqTPop( expp->f.argexps, SeArgExp ))
				!= NULL )
				{
				SeExpFree( np->expp );
				DmFree((genptr_t)np );
				}
			DqClose( expp->f.argexps );
			}
		if( SeDebugging )
			{
			expp->f.index = -1; /* safety net */
			expp->f.argexps = NULL;
			}
		break;
	case SeNT_CQUALIFIER :
#if SeDEBUG == 4
		{	const char *name;
		if( expp->c.index >= NmCount( &SeQualifiers )
		 || (name = NmName( expp->c.index, &SeQualifiers )) == NULL )
			ErPLog( "BUG:\t%s:(***** undefined)\n",
				SeCvtToStr(expp->type) );
		else
			ErPLog( "\t%s:%s\n", SeCvtToStr(expp->type), name );
		}
#endif
		if( SeDebugging )
			expp->c.index = -1;	/* safety net */
		break;
	case SeNT_COMPNAME :
#if SeDEBUG == 4
		{	const char *name;
		if( expp->c.index >= NmCount( &SeComponents )
		 || (name = NmName( expp->c.index, &SeComponents )) == NULL )
			ErPLog( "BUG:\t%s:(***** undefined)\n",
				SeCvtToStr(expp->type) );
		else
			ErPLog( "\t%s:%s\n", SeCvtToStr(expp->type), name );
		}
#endif
		if( SeDebugging )
			expp->c.index = -1;	/* safety net */
		break;
	case SeNT_PARAM :
#if SeDEBUG == 4
		ErPLog( "\tNT_PARAM:%d\n", expp->p.index );
#endif
		if( SeDebugging )
			expp->p.index = -1;	/* safety net */
		break;
	case SeNT_CONSTANT :
#if SeDEBUG == 4
		ErPLog( "\tNT_CONSTANT:%g\n", expp->n.value );
#endif
		if( SeDebugging )
			expp->n.value = -1.0;	/* safety net */
		break;
	case SeNT_EXPR :
	/* 06-30-00 ch3  added case for multiple occurrence operator */
	case SeNT_MULTOCC :
		assert(expp->o.lhsp == NULL);
		if( expp->o.rhsp != NULL )
			SeExpFree( expp->o.rhsp );
		/* else expression optimizer needs our assistance; be nice. */
		if( SeDebugging )
			expp->o.rhsp = NULL;	/* safety net */
		break;
	/* 01-12-07 ch3:  added case for temporary expression node */
	case SeNT_TMPEXPR :
		/* nothing to do here */
		break;
	case SeNT_RUNIF :		/* just like a binary op */
	case SeNT_RNORM :
	case SeNT_PKD :
	/* 02-07-27 ch3: added support for ORCA node type */
	case SeNT_ORCA :
	case SeNT_MOFN :
		if( expp->o.lhsp != NULL )
			SeExpFree( expp->o.lhsp );
		/* else expression optimizer needs our assistance; be nice. */
		if( expp->o.rhsp != NULL )
			SeExpFree( expp->o.rhsp );
		/* else expression optimizer needs our assistance; be nice. */
		if( SeDebugging )
			{
			expp->o.lhsp = NULL;	/* safety net */
			expp->o.rhsp = NULL;
			}
		break;
	case SeNT_EVAL :
		if( expp->o.lhsp != NULL )
			SeExpFree( expp->o.lhsp );
		/* else expression optimizer needs our assistance; be nice. */
		if( expp->o.rhsp != NULL )
			SeExpFree( expp->o.rhsp );
		/* else expression optimizer needs our assistance; be nice. */
		if( SeDebugging )
			{
			expp->o.lhsp = NULL;	/* safety net */
			expp->o.rhsp = NULL;
			}
		break;
	default :
		if( SeDebugging )
			{
			ErPLog( "SeExpFree: BUG: illegal type %s\n",
				SeCvtToStr( expp->type ) );
			assert(expp->type == SeNT_CONSTANT);	/* force core dump */
			}
		break;
		}
	if( expp->core.text != NULL )
		DmFree((genptr_t)expp->core.text );
	/* 01-12-07 ch3:  added check for temp expression which has no text */
	else if( expp->type != SeNT_TMPEXPR )
		ErPLog( "SeExpFree: %s node has no text assigned.\n",
			SeCvtToStr( expp->type ) );
	expp->core.text = NULL;
	expp->type = -1;	/* safety net */
	DmFree((genptr_t)expp );
	return;
	}

/**
	const DqNode *SeGetQualList( int comp_index )

	SeGetQualList() looks for qualified instances of a component
	for the specified RtComponents/SeComponents name pool index.
	If instances exist, a Dq list of SeQalNode structs containing
	SeComponent name pool indices are returned.

	typedef struct
		{
		DqNode link;
		int index;   // name pool index to qualified component
		}
	SeQalNode;

	SeGetQualList() returns null if no qualified entries are
	found for the specified component or returns null and sets
	the error index if an error occurs.
**/
const DqNode *
#if STD_C
SeGetQualList( int comp_index )
#else
SeGetQualList( comp_index )
int comp_index;
#endif
	{
#if SeDEBUG == 4
	ErPLog( "SeGetQualList(%d)\n", comp_index );
#endif
	assert( comp_index < NmCount( &RtComponents ));
	if( SeQualp == NULL )
		{
		ErSet( SeQALNONSEQ );
		if( SeDebugging )
			ErPLog( "SeGetQualList: %s\n", ErString() );
		return  NULL;
		}
	return SeQualp[comp_index];
	}

/*
	MuvesBool SeCrtExpression( const SeSysDef *sysdefp, char **iscritp,
				const char *qualifier )

	This routine is called by SeCrtSystem() and recursively to traverse
	the expression tree pointed to by sysdefp and set flags in the
	iscritp array for each component encountered.  The iscritp array
	must point to enough storage and its indices must correspond to
	the component indices in the SeComponents name pool.  If 'qualifier'
	is non-NULL it specifies a qualifier to apply at any component leaf
	nodes that are not already qualified.

	RETURN:	mTrue for success

		mFalse and set an error index in the event of an error in
		traversing the expression
 */
STATIC MuvesBool
#if STD_C
SeCrtExpression( const SeSysDef *sysdefp, char **iscritp, const char *qualifier )
#else
SeCrtExpression( sysdefp, iscritp, qualifier )
const SeSysDef *sysdefp;
char **iscritp;
const char *qualifier;
#endif
	{	time_t time1, time2;  /* 05-08-25 ch3: SCR579 */
	assert(sysdefp != NULL);
	assert(*iscritp != NULL);
#if SeDEBUG == 7
	ErPLog( "SeCrtExpression(%s)\n", SeCvtToStr( sysdefp->type ) );
#endif
	switch( sysdefp->type )
		{
	case SeNT_LISTNAME :
		{
		if( sysdefp->c.index >= NmCount( &SeLists ) )
			{	/* not a list */
		if( SeDebugging )
			ErPLog( "%s list index (%d) not in name pool.\n",
				"SeCrtExpression: BUG:",
				sysdefp->c.index);

			ErSet( SeSTCORRUPT );
			break;
			}
		else	/* Loop all members of list and recurse on each. */
			{	SeLiMember *mp;
#if SeDEBUG == 7
			ErPLog( "\tLISTNAME:%s\n",
				NmName( sysdefp->c.index, &SeLists ) );
#endif
			DqEACH( SeListDfn[sysdefp->c.index], mp, SeLiMember )
				{
				if( ! SeCrtExpression( &mp->member, iscritp,
						     qualifier ) )
					return mFalse;
				}
			return mTrue;
			}
		}
	case SeNT_SYSNAME :
	case SeNT_QUALSYS :
		{
		if( sysdefp->c.index >= NmSize( &SeSystems ) )
			{	/* not a system */

			if( SeDebugging )
				{
				ErPLog(
				"%s system (%s) index (%d) not in name pool.\n",
				"SeCrtExpression: BUG:",
				sysdefp->core.text, sysdefp->c.index);
#ifdef DEBUG
				SePrtNamePool( &SeSystems, "Systems" );
				SePrtNamePool( &SeLists, "Lists" );
				SePrtNamePool( &SeComponents, "Components" );
#endif
				}

			ErSet( SeSTCORRUPT );
			break;
			}
		else	/* Recurse on this system's system definition. */
			{
#if SeDEBUG == 7
			ErPLog( "\tSYSNAME:%s\n",
				NmName( sysdefp->c.index, &SeSystems ) );
#endif
			if ( ( sysdefp->type == SeNT_QUALSYS ) ||
				( qualifier != NULL ) )
				{
				int newindex;
				SeSyDat *sydp;

				if ( (newindex = SeRegisterQualSys( sysdefp, qualifier )) < 0 )
					{
					ErPLog( "Error registering qualified system\n");
					}

				if( SeDataSystem[newindex] == NULL )
					{
					SeDataSystem[newindex] =
						(SeSyDat  *)DmXalloc(SeSyDat);
					sydp = SeDataSystem[newindex];
					sydp->state = SeINVALID; /* initialize system node */
					sydp->sysdef = SeExpCopy( SeDataSystem[sysdefp->c.index]->sysdef );
					if( SeDebugging )
						{
						sydp->save.value = -1.0;	/* safety net */
						sydp->save.type = SeTypeUnset; /* safety net */
						}
					}
				}
			return SeCrtSystem( sysdefp->c.index, iscritp,
					    qualifier );
			}
		}
	case SeNT_COMPNAME :
		{	int ci = sysdefp->c.index;
			const char *compname, *qualname;
		compname = NmName( ci, &SeComponents );
		assert( compname != NULL );
#if SeDEBUG == 7
		ErPLog( "\tCOMPNAME:%s\n",
				NmName( sysdefp->c.index, &SeComponents ) );
#endif
		if( qualifier != NULL  && ci < NmCount( &RtComponents ) )
			{
			/* Supplied qualifier overrides, build qualified
			   component name. */

			if( SeDebugging == 2 )
				ErPLog( "%s '%s' applied to component '%s'.\n",
				"SeCrtExpression: qualifier", qualifier,
				compname );

			qualname = SeGetQualName( compname, qualifier );
			if( ! SeRegisterQualComp( qualname, ci ) )
				break;
			if( (ci = NmIndex( qualname, &SeComponents, mFalse ))
				== -1 )
				{
				ErPLog( "BUG: %s: '%s' not in n.p.\n",
					"SeCrtExpression", qualname );
				assert( ci >= 0 );
				break;
				}
			/* tag qualified component as critical */
			(*iscritp)[ci] = mTrue;
			return	mTrue;
			}
		else if( qualifier != NULL  && ci < NmCount( &SeComponents ) )
			{
			if( SeDebugging )
				{
				/* XXXX - warn about qualifying a qualifier */
				ErPLog( "SeCrtExpression: WARNING: ");
				ErLog( "Ignoring qualifier on an already\n");
				ErLog( "\t\tqualified component. Trying to qualify %s with [%s].\n",
					NmName( ci, &SeComponents ), qualifier);
				}
			}
		if( ci >= NmCount( &SeComponents ) )
			{	/* not a valid component */
			if( SeDebugging )
				ErPLog(	"%s: component index (%d) not in name pool.\n",
				"SeCrtExpression: BUG", ci );

			ErSet( SeSTCORRUPT );
			break;
			}
		else	/* Set critical flag for this component. */
			{
			(*iscritp)[ci] = mTrue;
			return	mTrue;
			}
		}
	case SeNT_QUALOP :
#if SeDEBUG == 7
		ErPLog( "SeCrtExpression: NT_QUALOP: %s\n",
			SeCvtToStr( sysdefp->o.lhsp->type ) );
#endif
		{	char *qualname;

		qualname = sysdefp->o.rhsp->core.text;
		if (qualifier != NULL)
			{
			ErPLog( "SeCrtExpression: WARNING: ");
			ErLog("qualifier %s ignored for %s\n",
				qualifier, sysdefp->o.lhsp->core.text );
			}

		return SeCrtExpression( sysdefp->o.lhsp, iscritp,
				qualname);
		}
			
	case SeNT_CONSTANT :
#if SeDEBUG == 7
		ErPLog( "\tCONSTANT:%g\n", sysdefp->n.value );
#endif
		/* nothing to do */
		return	mTrue;
	case SeNT_PARAM :
#if SeDEBUG == 7
		ErPLog( "\tFUNCTION PARAMETER:%d\n", sysdefp->p.index );
#endif
		/* nothing to do */
		return	mTrue;
	case SeNT_FNCALL :
		{	SeArgExp *np;
#if SeDEBUG == 7
		ErPLog( "\tFUNCTION CALL:%s\n",
			NmName( sysdefp->f.index, &SeFunctions ) );
#endif
		assert(sysdefp->f.argexps != NULL);
		assert(! DqIsEmpty( sysdefp->f.argexps ));
		/* Recurse on each argument expression. */
		DqEACH( sysdefp->f.argexps, np, SeArgExp )
			if( ! SeCrtExpression( np->expp, iscritp, qualifier ) )
				return mFalse;
		/* Recurse on function definition expression. */
		assert(sysdefp->f.index >= 0);
		assert(sysdefp->f.index < NmCount(&SeFunctions));
		assert(SeFnDfn != NULL);
		assert(SeFnDfn[sysdefp->f.index] != NULL);
		assert(SeFnDfn[sysdefp->f.index]->funcdefp != NULL);
		return SeCrtExpression( SeFnDfn[sysdefp->f.index]->funcdefp,
					iscritp, qualifier );
		}
	case SeNT_EXPR :
	/* 06-30-00 ch3  added case for multiple occurrence operator */
	case SeNT_MULTOCC :
		assert( sysdefp->o.lhsp == NULL );
		/* 05-08-25 ch3: added time reporting debug output */
		time(&time1);
		if (SeCrtExpression( sysdefp->o.rhsp, iscritp, qualifier ))
		{
			if ( SeDebugging & SEDBG_STSMSGS )
			{
				int secs;

				time(&time2);
				secs = (int)difftime(time2, time1);
				if (secs > 0)
				{
					ErPLog("SeCrtExpression: Time to "
						"evaluate MultOcc expression "
						"= %d secs\n", secs);
				}
			}
			return mTrue;
		}
		return mFalse;
	case SeNT_NOT :
	case SeNT_ABS :
	case SeNT_BOOL :
		/* Recurse on the right-hand side. */
#if SeDEBUG == 7
		ErPLog( "\tUNARY OP\n" );
#endif
		return	SeCrtExpression( sysdefp->o.rhsp, iscritp, qualifier );
	case SeNT_LIST :
	case SeNT_PROD :
	case SeNT_QUOT :
	/* 06-30-00 ch3  added case for AND */
	case SeNT_AND :
	case SeNT_OR :
	case SeNT_MIN :
	case SeNT_MAX :
	case SeNT_XOR :
	case SeNT_SUM :
	case SeNT_DIFF :
	case SeNT_LT :
	case SeNT_GT :
	case SeNT_LTEQ :
	case SeNT_GTEQ :
	case SeNT_RUNIF :
	case SeNT_RNORM :
	case SeNT_MOFN :
	case SeNT_PKD :
	/* 02-07-27 ch3: added support for ORCA node type */
	case SeNT_ORCA :
	case SeNT_EVAL :
		/* Recurse on both the left-hand and right-hand sides. */
		return SeCrtExpression( sysdefp->o.lhsp, iscritp, qualifier )
		    && SeCrtExpression( sysdefp->o.rhsp, iscritp, qualifier );
	default :
		ErPLog( "SeCrtExpression: Illegal operator type: \"%s\"\n",
			SeCvtToStr(sysdefp->type) );
		(void)ErLog( "\taround the expression: \"%s %s %s\"\n", 
			(sysdefp->o.lhsp->core.text == NULL ? "(null)" : sysdefp->o.lhsp->core.text),
			(sysdefp->core.text == NULL ? "(null)" : sysdefp->core.text),
			(sysdefp->o.rhsp->core.text == NULL ? "(null)" : sysdefp->o.rhsp->core.text ));
		ErSet( SeSTCORRUPT );
		break;
		}
	return	mFalse;	/* value returned on error */
	}

/*
	double SeEvlComponent( int compid, const SeValue values[],
				SeTypeID type )

	This routine takes the value and type in values[compid] and returns
	a converted value of the specified type.  If a conversion can not be
	performed, an error is printed and -1.0 is returned.
 */
STATIC double
#if STD_C
SeEvlComponent( int compid, const SeValue values[], SeTypeID type )
#else
SeEvlComponent( compid, values, type )
int compid;
const SeValue values[];
SeTypeID type;
#endif
	{	const SeValue *valp;
	assert( values != NULL );
	assert( compid < NmCount(&SeComponents) );
	assert( type > SeTypeUnset );
	assert( type < SeTypeSentinel );

	valp = &values[compid];
	assert( valp != NULL );
#if SeDEBUG == 4
	ErPLog( "SeEvlComponent: type=%s convert from component=%s type=%s\n",
		SeStrType( type ), NmName( compid, &SeComponents ),
		SeStrType( valp->type ) );
#endif
	if( valp->type == SeTypeUnset )
		{ /* Component not damaged, output appropriate default. */
#if SeDEBUG
		ErPLog( "SeEvlComponent: component not damaged\n" );
#endif
		switch( type )
			{
		case SeTypeFRF :	/* fully functional */
			return 1.0;
		case SeTypeHit :	/* not hit */
			return 0.0;
		case SeTypeKilled :	/* not killed */
			return 0.0;
		case SeTypeNotKilled :	/* not killed */
			return 1.0;
		case SeTypeLOF :	/* no loss of function */
			return 0.0;
		case SeTypePK :		/* zero probability of kill */
			return 0.0;
		case SeTypePS :		/* total probability of survival */
			return 1.0;
		case SeTypePKIterate:   /* Iterative estimation of pk
						using environmental
						variable Se_Iterate*/
			return 0.0;
		case SeTypePKChebyshev: /* Iterative estimation of pk
						using Se_Confidence and
						an Se_Interval */
			return 0.0;
		case SeTypeScalar :	/* zero value */
			return 0.0;
			}
		assert(type == SeTypePK); /* force abort */
		}

	if( valp->type == type )
		return (double) valp->value;	/* no conversion necessary */

	/* Must convert to specified type. */
	switch( type )
		{
	case SeTypeFRF :
		switch( valp->type )
			{
		case SeTypeLOF : /* convert LOF to FRF */
#if SeDEBUG
			ErPLog("SeEvlComponent: LOF=%g converted to FRF=%g\n",
				(double) valp->value,
				1.0 - (double) valp->value );
#endif
			return 1.0 - (double) valp->value;
			}
		break;
	case SeTypeKilled :
		switch( valp->type )
			{
		  /* Special conversion of FRF to type killed for iterative types.  
			It is opened by setting the flag 'iterating' to mTrue.    */
		case SeTypeFRF :
			if(!iterating)
				break;
			if(!printedFRFError)
				{
				  /* warns of conversion to pk because it is more intuitive than killed*/
				ErPLog( "WARNING: Converting from type FRF to type PK");
				printedFRFError=mTrue;
				}

			/* Need to save flags so that the random draw only
			   occurs once per component per initial shot. */
			if( SeKilled == NULL )
				{	register int i;
				SeKilled =
				     (short *)DmMalloc( NmCount( &SeComponents ) * sizeof(short));

				for( i = NmCount( &SeComponents ); --i >= 0; )
					SeKilled[i] = -1;
				}
			if( SeKilled[compid] == -1 )
				{
				if (single_stream)
					{
					SeKilled[compid] = RnUnif(RnSINGLE_STREAM)>
							valp->value ? 0 : 1;
					}
				else
					{
					SeKilled[compid] = RnUnif(SeSTREAM)>
							valp->value ? 0 : 1;
					}
				}
			return 1-(double) SeKilled[compid];

		  /* Special conversion of LOF to type killed for iterative types.  
			It is opened by setting the flag 'iterating' to mTrue.    */
			
		case SeTypeLOF :
			if(!iterating)
				break;
			if(!printedLOFError)
				{
				  /* warns of conversion to pk because it is more intuitive than killed*/
				ErPLog( "WARNING: Converting from type LOF to type PK\n");
				printedLOFError=mTrue;
				}

                case SeTypePKIterate : /* convert PKIterate to KILLED flag*/
                case SeTypePKChebyshev : /* convert PKChebyshev to KILLED flag */
		case SeTypePK : /* convert PK to KILLED flag */
			/* Need to save flags so that the random draw only
			   occurs once per component per initial shot. */
			if( SeKilled == NULL )
				{	register int i;
				SeKilled =
				     (short *)DmMalloc(NmCount(&SeComponents) * sizeof(short));
				for( i = NmCount( &SeComponents ); --i >= 0; )
					SeKilled[i] = -1;
				}
			if( SeKilled[compid] == -1 )
				{
				if (single_stream)
					{
					SeKilled[compid]
						= RnUnif(RnSINGLE_STREAM)
						<= valp->value;
					}
				else
					{
					SeKilled[compid]
						= RnUnif(SeSTREAM)
						<= valp->value;
					}
				}
#if SeDEBUG
			ErPLog( "%s: %s PK=%g converted to KILLED=%s\n",
				"SeEvlComponent",
				NmName( compid, &SeComponents ),
				(double) valp->value,
				SeKilled[compid] ? "true" : "false" );
				
#endif
			return (double) SeKilled[compid];
		case SeTypePS : /* convert PS to KILLED flag */
			/* Need to save flags so that the random draw only
			   occurs once per component per initial shot. */
			if( SeKilled == NULL )
				{	register int i;
				SeKilled =
				     (short *)DmMalloc(NmCount(&SeComponents) * sizeof(short));
				for( i = NmCount( &SeComponents ); --i >= 0; )
					SeKilled[i] = -1;
				}
			if( SeKilled[compid] == -1 )
				{
				if (single_stream)
					{
					SeKilled[compid] = RnUnif(RnSINGLE_STREAM)>
							valp->value ? 1 : 0;
					}
				else
					{
					SeKilled[compid] = RnUnif(SeSTREAM)>
							valp->value ? 1 : 0;
					}
				}
#if SeDEBUG
			ErPLog( "%s: %s PS=%g converted to KILLED=%s\n",
				"SeEvlComponent",
				NmName( compid, &SeComponents ),
				(double) valp->value,
				SeKilled[compid] ? "true" : "false" );
				
#endif
			return (double) SeKilled[compid];
		case SeTypeHit :
			return (double) valp->value;
			}
		break;
	case SeTypeNotKilled :
		switch( valp->type )
			{
                case SeTypePKIterate : /* convert PKIterate to NOT-KILLED flag */
                case SeTypePKChebyshev : /* convert PKChebyshev to NOT-KILLED flag */
		case SeTypePK : /* convert PK to NOT-KILLED flag */
			/* Need to save flags so that the random draw only
			   occurs once per component per initial shot. */
			/* Values are stored in the SeKilled[] array as 
			   killed values, but are converted to non-killed
			   values when returned. */
			if( SeKilled == NULL )
				{	register int i;
				SeKilled =
				     (short *)DmMalloc(NmCount(&SeComponents) * sizeof(short ));
				for( i = NmCount( &SeComponents ); --i >= 0; )
					SeKilled[i] = -1;
				}
			if( SeKilled[compid] == -1 )
				{
				if (single_stream)
					{
					SeKilled[compid] = RnUnif(RnSINGLE_STREAM)>
							valp->value ? 0 : 1;
					}
				else
					{
					SeKilled[compid] = RnUnif(SeSTREAM)>
							valp->value ? 0 : 1;
					}
				}
#if SeDEBUG
			ErPLog( "%s: %s PK=%g converted to KILLED=%s\n",
				"SeEvlComponent",
				NmName( compid, &SeComponents ),
				(double) valp->value,
				SeKilled[compid] ? "true" : "false" );
				
#endif
			return (double) (1.0 - SeKilled[compid]);

		case SeTypePS : /* convert PS to NOT-KILLED flag */
			/* Need to save flags so that the random draw only
			   occurs once per component per initial shot. */
			/* Values are stored in the SeKilled[] array as 
			   killed values, but are converted to non-killed
			   values when returned. */
			if( SeKilled == NULL )
				{	register int i;
				SeKilled =
				     (short *)DmMalloc(NmCount(&SeComponents) * sizeof(short));
				for( i = NmCount( &SeComponents ); --i >= 0; )
					SeKilled[i] = -1;
				}
			if( SeKilled[compid] == -1 )
				{
				if (single_stream)
					{
					SeKilled[compid] = RnUnif(RnSINGLE_STREAM)>
							valp->value ? 1 : 0;
					}
				else
					{
					SeKilled[compid] = RnUnif(SeSTREAM)>
							valp->value ? 1 : 0;
					}
				}
#if SeDEBUG
			ErPLog( "%s: %s PS=%g converted to KILLED=%s\n",
				"SeEvlComponent",
				NmName( compid, &SeComponents ),
				(double) valp->value,
				SeKilled[compid] ? "true" : "false" );
				
#endif
			return (double) (1.0 - SeKilled[compid]);
			}
		break;
	case SeTypeLOF :
		switch( (int) valp->type )
			{
		case SeTypeFRF : /* convert FRF to LOF */
#if SeDEBUG
			ErPLog("%s: %s FRF=%g converted to LOF=%g\n",
				"SeEvlComponent",
				NmName( compid, &SeComponents ),
				(double) valp->value,
				1.0 - (double) valp->value );
#endif
			return 1.0 - (double) valp->value;
		case SeTypePK :
			return (double) valp->value;
			}
		break;
	case SeTypePKIterate :
	case SeTypePKChebyshev :
	case SeTypePK :
		switch( (int) valp->type )
			{
		case SeTypePS : /* convert PS to PK */
#if SeDEBUG
			ErPLog("%s: %s PS=%g converted to PK=%g\n",
				"SeEvlComponent",
				NmName( compid, &SeComponents ),
				(double) valp->value,
				1.0 - (double) valp->value );
#endif
			return 1.0 - (double) valp->value;
		case SeTypeHit :
		case SeTypeKilled :
		case SeTypeLOF :
			return (double) valp->value;
			}
		break;
	case SeTypePS :
		switch( (int) valp->type )
			{
                case SeTypePKChebyshev : /* convert PKChebyshev to PS */ 
#if SeDEBUG  
		ErPLog("%s: %s PKChebyshev=%g converted to PS=%g\n", 
			"SeEvlComponent", 
			NmName( compid, &SeComponents), 
			 (double) valp->value, 
			 1.0 - (double) valp->value ); 
#endif
                        return 1.0 - (double) valp->value;
                case SeTypePKIterate : /* convert PKIterate to PS */
#if SeDEBUG
                       ErPLog("%s: %s PKIterate=%g converted to PS=%g\n",
                               "SeEvlComponent",
                               NmName( compid, &SeComponents ),
                               (double) valp->value,
                               1.0 - (double) valp->value );
#endif
                      return 1.0 - (double) valp->value;

		case SeTypePK : /* convert PK to PS */
#if SeDEBUG
			ErPLog("%s: %s PK=%g converted to PS=%g\n",
				"SeEvlComponent",
				NmName( compid, &SeComponents ),
				(double) valp->value,
				1.0 - (double) valp->value );
#endif
			return 1.0 - (double) valp->value;
			}
		break;
	case SeTypeHit :
		switch( (int) valp->type )
			{
		case SeTypePKIterate :
		case SeTypePKChebyshev :
		case SeTypePK :
		case SeTypeKilled :
			return (double) valp->value;
			}
		/* if we add probability of hit, this needs to change */
		break;
	case SeTypeScalar :
		/* Convert all SeTypes to scalar(return a double of the value) */
		switch( (int) valp->type )
			{
			case SeTypePK : 
			case SeTypePS :
			case SeTypeKilled :
			case SeTypeNotKilled :
			case SeTypeHit :
			case SeTypeLOF :
			case SeTypeFRF : 
				return (double) valp->value;
			}
		break;
		}
	/* Can't do conversion, report it. */
	SePrtTypeConvErr( compid, valp->type, type );
	ErSet( SeTYPEMISMATCH );
	return -1.0;
	}

/*
	int SeMofN(DqNode *list, double cutoff, const SeValue *valp,
		SeTypeID type, const char *qual) - returns the number of
		elements from list who evaluate greater than the cutoff.
*/
int
#if STD_C
SeMofN( SeLiDat *list, double cutoff, const SeValue *valp,
		 SeTypeID type, const char *qual )
#else
SeMofN( list, cutoff, valp, type, qual )
SeLiDat *list;
double cutoff;
const SeValue *valp;
SeTypeID type;
const char *qual;
#endif
	{
	int cnt=0;
	SeLiMember *mp;

	DqEACH( list, mp, SeLiMember )
		{
		switch( mp->member.type)
			{
		case SeNT_LISTNAME:
			cnt = cnt + 
			    SeMofN( SeListDfn[mp->member.c.index], cutoff,
					valp, type, qual);
			break;
                case SeNT_QUALOP:
                        assert( mp->member.o.lhsp != NULL );
                        switch (mp->member.o.lhsp->type)
                                {
                        case SeNT_LISTNAME:
				if( qual == NULL )
					{
					qual = NmName( mp->member.o.rhsp->c.index,
						    &SeQualifiers );
					assert( qual != NULL );
					}
				cnt = cnt + 
			    		SeMofN( SeListDfn[mp->member.o.lhsp->c.index],
						cutoff, valp, type, qual);
				break;
			default:
				if (SeEvlExpression( &mp->member, valp, NULL,
					type, qual ) > cutoff)
					cnt++;
				}
			break;
		default:
			if (SeEvlExpression( &mp->member, valp, NULL,
				type, qual ) > cutoff)
				cnt++;
			}
		}
	return cnt;
	}
/*
	int SeGetPks(double **pkarr, int *pksize, int pkstart, DqNode *list,
		const SeValue *valp, SeTypeID type, const char *qual) - returns
		the number of elements in the list (exanding any lists found),
		also allocates and fills an array with the list element values
		and returns its allocated size.
*/
int
#if STD_C
SeGetPks( double **pkarr, int *pksize, int pkstart, SeLiDat *list,
	const SeValue *valp, SeTypeID type, const char *qual )
#else
SeGetPks( pkarr, pksize, pkstart, list, valp, type, qual )
double **pkarr;		/* pointer to Pk array pointer */
int *pksize;		/* pointer to Pk size variable */
int pkstart;		/* index to start filling in Pk array */
SeLiDat *list;
double cutoff;
const SeValue *valp;
SeTypeID type;
const char *qual;
#endif
	{
	int cnt=0;
	int subcnt;
	SeLiMember *mp;

	DqEACH( list, mp, SeLiMember )
		{
		switch( mp->member.type)
			{
		case SeNT_LISTNAME:
			subcnt = SeGetPks( pkarr, pksize, pkstart + cnt,
				SeListDfn[mp->member.c.index], valp, type,
				qual);
			if (subcnt < 0)
				return -1;
			cnt += subcnt;
			continue;  /* to next list element */
                case SeNT_QUALOP:
                        assert( mp->member.o.lhsp != NULL );
                        if (mp->member.o.lhsp->type == SeNT_LISTNAME)
				{
				if( qual == NULL )
					{
					qual = NmName( mp->member.o.rhsp->c.index,
						    &SeQualifiers );
					assert( qual != NULL );
					}
				subcnt = SeGetPks( pkarr, pksize, pkstart + cnt,
					SeListDfn[mp->member.o.lhsp->c.index],
					valp, type, qual);
				if (subcnt < 0)
					return -1;
				cnt += subcnt;
				continue;  /* to next list element */
				}
			break;
			}

		/* otherwise, evaluate list element and store into array */
		/* 02-07-24 ch3: corrected comparison operator from '<=' */
		if (pkstart + cnt >= *pksize)
			{
			if (*pksize == 0)
				*pksize = 16;
			else
				*pksize *= 2;
			*pkarr = (double *)DmRealloc(*pkarr, (*pksize)*sizeof(double));
			if (*pkarr == NULL)
				return -1;
			}
		(*pkarr)[pkstart + cnt++] = SeEvlExpression( &mp->member,
			valp, NULL, type, qual );
		}
	return cnt;
	}

/*
	int SeGetPkds(double **pkarr, int *pksize, DqNode *list,
		const SeValue *valp, SeTypeID type, const char *qual) - returns
		the number of elements in the list (any lists found cause an
		error), also allocates and fills an array with the list element
		values and returns its allocated size.
*/
int
#if STD_C
SeGetPkds( double **pkarr, int *pksize, SeLiDat *list,
	const SeValue *valp, SeTypeID type, const char *qual )
#else
SeGetPkds( pkarr, pksize, list, valp, type, qual )
double **pkarr;		/* pointer to Pk array pointer */
int *pksize;		/* pointer to Pk size variable */
SeLiDat *list;
double cutoff;
const SeValue *valp;
SeTypeID type;
const char *qual;
#endif
	{
	int cnt=0;
	SeLiMember *mp;

	DqEACH( list, mp, SeLiMember )
		{
		switch( mp->member.type)
			{
		case SeNT_LISTNAME:
			return -1;  /* embedded lists not allowed */
                case SeNT_QUALOP:
                        assert( mp->member.o.lhsp != NULL );
                        if (mp->member.o.lhsp->type == SeNT_LISTNAME)
				return -1;  /* embedded lists not allowed */
			break;
			}

		/* otherwise, evaluate list element and store into array */
		/* 02-07-24 ch3: corrected comparison operator from '<=' */
		if (cnt >= *pksize)
			{
			if (*pksize == 0)
				*pksize = 16;
			else
				*pksize *= 2;
			*pkarr = (double *)DmRealloc(*pkarr, (*pksize)*sizeof(double));
			if (*pkarr == NULL)
				return -1;
			}
		(*pkarr)[cnt++] = SeEvlExpression( &mp->member, valp, NULL,
			type, qual );
		}
	return cnt;
	}

/*
	int SeGetPks(double **pkarr, int *pksize, int pkstart, DqNode *list,
		const SeValue *valp, SeTypeID type, const char *qual) - returns
		the number of elements in the list (exanding any lists found),
		also allocates and fills an array with the list element values
		and returns its allocated size.
*/
/* 02-07-27 ch3: added new function to support new _orca function */
MuvesBool
#if STD_C
SeCheckExprAndGetComp( SeSysDef *sysdefp, SeSysDef **evaldefpp,
	const char **orca_personnel, const char **qualifier )
#else
SeCheckExprAndGetComp( sysdefp, evaldefpp, orca_personnel, qualifier )
SeSysDef *sysdefp;	/* pointer to system definition to check */
SeSysDef **evaldefpp;	/* pointer to evaluation definition pointer to return */
const char **orca_personnel;	/* pointer to orca personnel name found */
const char **qualifier;	/* pointer to qualifier name found */
#endif
	{
	char *qual;	/* pointer to a qualifier name */
	SeLiMember *mp;	/* list member pointer */
	const char *name;	/* component name */
	int comp;	/* component index */

	switch( sysdefp->type )
		{
	case SeNT_QUALOP:  /* possible qualified list */
		assert( sysdefp->o.lhsp != NULL );
		if( sysdefp->o.lhsp->type != SeNT_QUALIST )
			{
			ErPLog( "Invalid item found in _orca arguments %s.\n",
				sysdefp->o.lhsp->c.text );
			ErSet( SeSTCORRUPT );
			return mFalse;
			}
		if( *qualifier == NULL )
			{
			*qualifier = NmName( sysdefp->o.rhsp->c.index,
				&SeQualifiers );
			assert( *qualifier != NULL );
			}
		else
			{
			/* make sure qualifier matches what we found so far */
			name = NmName( sysdefp->o.rhsp->c.index,
				&SeQualifiers );
			assert( name != NULL );
			if( !StrEq( name, *qualifier ) )
				{
				ErPLog( "Different qualifier '%s' found on "
					"list in _orca arguments: %s.\n",
					name, *qualifier );
				ErSet( SeSTCORRUPT );
				return mFalse;
				}
			}
		sysdefp = sysdefp->o.lhsp;
		/* fall-thru to process list */
	case SeNT_LISTNAME:  /* list */
		DqEACH( SeListDfn[sysdefp->c.index], mp, SeLiMember )
			{
			if( !SeCheckExprAndGetComp( &mp->member, evaldefpp,
					orca_personnel, qualifier ) )
				{
				ErSet( SeSTCORRUPT );
				return mFalse;  /* error already reported */
				}
			}
		return mTrue;

	case SeNT_EXPR:  /* possible qualifier component */
		/* must be a qualifier component */
		if( sysdefp->o.lhsp != NULL
				|| sysdefp->o.rhsp->type != SeNT_COMPNAME )
			{
			ErPLog( "Expressions not allowed in _orca "
				"arguments.\n" );
			ErSet( SeSTCORRUPT );
			return mFalse;
			}
		if( (name = SePrsQualName( sysdefp->o.rhsp->c.index ))
				== NULL)
			{
			ErPLog( "Expected component qualifier no found in "
				"_orca arguments.\n" );
			ErSet( SeSTCORRUPT );
			return mFalse;
			}
		if( *qualifier == NULL )
			{
			/* first qualified component found, save qualifier
			 * and set evauluation system definition pointer */
			*qualifier = name;
			*evaldefpp = sysdefp->o.rhsp;
			}
		else
		/* make sure qualifier matches what we found so far */
		if( !StrEq( name, *qualifier ) )
			{
			ErPLog( "Different qualifier '%s' found on component "
				"in _orca arguments: %s.\n", name, *qualifier );
			ErSet( SeSTCORRUPT );
			return mFalse;
			}

		if( (name = SePrsBaseName( sysdefp->o.rhsp->c.index )) == NULL)
			{
			ErPLog( "Error getting base component in _orca "
				"arguments.\n" );
			ErSet( SeSTCORRUPT );
			return mFalse;
			}
		comp = NmIndex( name, &RtComponents, mFalse );
		break;

	case SeNT_COMPNAME:  /* non-qualified component */
		comp = sysdefp->c.index;
		break;

	default:
		ErPLog( "Error: expecting component or list elements in _orca"
			" arguments.\n");
		ErSet( SeSTCORRUPT );
		return mFalse;
		}
		
	/* check for orca personnel component property */
	if( (name = CpGetStrProp( comp, CpORCA_PERSONNEL )) == NULL )
		{
		ErPLog( "Error: component '%s' does not have '%s' property in "
			"_orca arguments.\n", NmName( comp, &RtComponents ),
			CpORCA_PERSONNEL );
		ErSet( SeSTCORRUPT );
		return mFalse;
		}

	if( *orca_personnel == NULL )
		{
		/* first component found, save orca_personnel name */
		*orca_personnel = name;
		}
	else
	/* make sure orca personnel name matches what we found so far */
	if( !StrEq( name, *orca_personnel ) )
		{
		ErPLog( "Different %s '%s' found on component '%s' in _orca "
			"arguments: %s.\n", CpORCA_PERSONNEL, name,
			NmName( comp, &RtComponents ), *orca_personnel );
		ErSet( SeSTCORRUPT );
		return mFalse;
		}
	
	/* if first component found, set evaluation system definition pointer */
	/* (will be reset later if a qualifier component is found) */
	/* (if first component was qualifier, then already set above) */
	if( *evaldefpp == NULL )
		{
		*evaldefpp = sysdefp;
		}

	return mTrue;
	}

/*
	double SeEvlExpression( SeSysDef *sysdefp, const SeValue *valp,
				const double *argp, SeTypeID type,
				const char *qualifier )

	This routine does the recursive expression evaluation for SeStEval()
	and SeSysEval().  sysdefp points to the root of the expression or
	subexpression being evaluated.  valp points to an array of SeValue
	structs containing typed values for all critical components.  Argp
	is a pointer to an array of argument values if a function call is
	being evaluated and NULL otherwise.  type is the expected type of the
	component values at the leaf nodes of the expression (see SeTypeID
	enumeration for a list of types).  If qualifier is non-NULL, it is
	a qualifier to be applied to any components down in leaf nodes that
	are not alread qualified.

	This function is for internal Se package use only.

	RETURN: value for component converted to specified type

		garbage and set an error index if a problem is detected

	XXX -- The recursive evaluation scheme requires at least one function
	call per primitive operation (e.g. +).  This is horrifically expensive
	for many implementations, and should probably be replaced by a scheme
	wherein the optimized expression tree is converted to "code" for a fast
	interpreter.
 */
double
#if STD_C
SeEvlExpression( SeSysDef *sysdefp, const SeValue *valp, const double *argp,
		 SeTypeID type, const char *qualifier )
#else
SeEvlExpression( sysdefp, valp, argp, type, qualifier )
SeSysDef *sysdefp;
const SeValue *valp;	/* array of typed component values */
const double *argp;
SeTypeID type;		/* expected type for component values */
const char *qualifier;
#endif
	{	double lvalue, rvalue;
	ApT_EnvVar *envp;  /* 06-02-20 ch3: used this instead of global */
	assert(sysdefp != NULL);
#if SeDEBUG == 4
	ErPLog( "SeEvlExpression: %s text=%s type=%s qualifier=%s\n",
		SeCvtToStr( sysdefp->type ), sysdefp->core.text,
		SeStrType( type ),
		qualifier == NULL ? "(null)" : qualifier );
#endif
	assert(valp != NULL);

         /*
               Checks to see if the type desired is an iterative
               type (or any other future type which requires top
               down consideration).  If a type is discovered, its
               environmental variables are found and tested.

                                                       */
        switch( type )
                {
                  /* Converts pkchebyshev to appropriate number of iterations of killed */
                case SeTypePKChebyshev :
                          /* Exit avoids multiple reads */
                        if(chebyIterations!=-1)
                                return SeIterate(chebyIterations,sysdefp,valp,argp,qualifier);
                        envp=ApGetEnvVar("Se_Confidence");
                        if(envp==NULL||envp->val<=0||envp->val>=1)
                                {
                                  /* Error messages if Se_Confidence not
                                        properly set */
                                if( envp==NULL ) 
                                   ErPLog("Se package: pkchebyshev: Note: Environmental variable \"Se_Confidence\" not defined, doing default .80 confidence\n");
                                else if( envp->val<=0 )
                                   ErPLog("Se package: pkchebyshev: WARNING: Value of %f for \"Se_Confidence\" is invalid (must be >0), doing default .80 confidence\n",envp->val);
                                else if( envp->val>=0 )
                                   ErPLog("Se package: pkchebyshev: WARNING: Value of %f for \"Se_Confidence\" is invalid (must be <1), doing default .80 confidence\n",envp->val);
                                if( SeDebugging )
                                   ErPLog("\"Se_Confidence\" not defined properly, doing .80 confidence");
                                }
                        else 
                                {
                                confidence=envp->val;
                                }
                        envp=ApGetEnvVar("Se_Interval");
                        if(envp==NULL||envp->val<=0||envp->val>=1)
                                {
                                  /* Error messages if Se_Interval not
                                       properly set */
                                if( envp==NULL )
                                   ErPLog("Se package: pkchebyshev: Note: Environmental variable \"Se_Interval\" not defined, doing default .01 interval\n");
                                else if( envp->val<=0 )
                                   ErPLog("Se package: pkchebyshev: WARNING: Value of %f for \"Se_Interval\" is invalid (must be >0), doing default .01 interval\n",envp->val);
                                else if( envp->val>=1 )
                                  ErPLog("Se package: pkchebyshev: WARNING: Value of %f for \"Se_Interval\" is invalid (must be <1), doing default .01 interval\n",envp->val);
                                if( SeDebugging )
                                   ErPLog("\"Interval\" not defined properly, doing default .01 interval");
                                } 
                       else
                                {
                                interval=envp->val; 
                                }

                         /* Calculates iterations needed for given
                                Confidence and interval */

                        chebyIterations=(int)(((double)1/(4*(1-confidence)*(interval)*(interval))));

			  /* Checks if maxIterations has been set */
			if(maxIterations==-1)
			{
				  /* Gets the environmental variable */
	                        envp=ApGetEnvVar("Se_Max_Iterations");
                        	if(envp==NULL||envp->val<=0)
                                	{
                                	  /* Error messages if Se_Max_Iterations not
                                	        properly set */
					if( (envp != NULL) && (envp->val<=0) )
                                	   ErPLog("Se package: pkchebyshev: WARNING: Value of %g for \"Se_Max_Iterations\" is invalid (must be >0), setting to default 50,000\n",envp->val);
                                	if( SeDebugging )
                                	   ErPLog("\"Se_Max_Iterations\" not defined properly, setting to 50,000");
					  /* Default value for max_Iterations */
					maxIterations=50000;
                                	}
                        	else 
                                	{
                                	maxIterations=(long)envp->val;
                                	}
				
			}
			if(maxIterations<chebyIterations)
			{
				  /* Warning if maxIterations is exceeded */ 
                                ErPLog("pkchebyshev: WARNING: A confidence of %f and interval of size %f requires %d iterations, but this exceeds the value of \"Se_Max_Iterations\" (%d).  If you wish to compute to this confidence, please set the environmental variable \"Se_Max_Iterations\" to be greater than %d\n ",
					confidence,
					interval,
					chebyIterations,
					maxIterations,
					chebyIterations);
				chebyIterations=maxIterations;
			}
                        return SeIterate(chebyIterations,sysdefp,valp,argp,qualifier);
 
                  /* Converts pkiterate to appropriate number of iterations of killed */
                case SeTypePKIterate :
                          /* Exit avoids multiple reads */
                        if(iterations!=-1)
                                return SeIterate(iterations,sysdefp,valp,argp,qualifier);
                        envp=ApGetEnvVar("Se_Iterations");
                        if(envp==NULL||envp->val<=0)
                        {
                                  /* Error messages if Se_Iterate not
                                        properly set */
 
                                if( envp==NULL )
                                   ErPLog("Se package: pkiterate: Environmental variable \"Se_Iterations\" not defined, doing default 12500 iterations\n");
                                else if( envp->val<=0 )
                                   ErPLog("Se package: pkiterate: Value of %d for \"Se_Iterations\" is invalid (must be >0), doing default 12500 iterations\n",(long)envp->val);
                                iterations=12500;
                                return SeIterate(12500,sysdefp,valp,argp,qualifier);
                        }

                          /* Sets iterations and calls iterate function */
                        iterations=(int)(envp->val);
                        return SeIterate(iterations,sysdefp,valp,argp,qualifier);
 
                } 

	switch( sysdefp->type )
		{
	case SeNT_SYSNAME :
	case SeNT_QUALSYS :
		{
		if( sysdefp->c.index >= NmSize( &SeSystems ) )
			{	/* not a system */
			if( SeDebugging )
			   ErPLog("%s: system index (%d) not in name pool.\n",
			 	  "SeEvlExpression: BUG",
				  sysdefp->c.index);

			ErSet( SeSTCORRUPT );
			break;
			}
		else	/* Recurse on this system's definition. */
			{
			register int index;
			const char *qualname;

			if ( qualifier != NULL )
				{
				qualname = SeGetQualName( sysdefp->core.text, qualifier );
				if ( (index = NmIndex( qualname, &SeSystems, mFalse )) < 0 )
					{
					ErPLog( "unregistered qualified system\n");
					break;
					}
				}
			else
				{
				index = sysdefp->c.index;
				}
#if SeDEBUG == 4
			ErPLog( "\tSYSNAME:%s\n",
				NmName( index, &SeSystems ) );
#endif
			return	SeSysEval( index, valp, argp, type,
					   qualifier );
			}
		}
	case SeNT_COMPNAME :
		/* Return value for this component, converted
		   to the specified type if necessary. */
		{	int ci = sysdefp->c.index;
			const char *compname, *qualname;
		compname = NmName( ci, &SeComponents );
		assert( compname != NULL );
		/* 11-05-05 ch3: Note: for VSL, the following if will always
		 *               be false since the RtComponents name pool is
		 *               essentially empty (VSL) */
		if( qualifier != NULL  && ci < NmCount( &RtComponents ) )
			{ /* Supplied qualifier overrides, build qualified
			     component name. */
#if SeDEBUG
			ErPLog( "%s '%s' applied to component '%s'.\n",
				"SeEvlExpression: qualifier", qualifier,
				compname );
#endif
			qualname = SeGetQualName( compname, qualifier );
			if( ! SeRegisterQualComp( qualname, ci ) )
				break;
			if( (ci = NmIndex( qualname, &SeComponents, mFalse ))
				== -1 )
				{
				ErPLog( "BUG: %s: '%s' not in n.p.\n",
					"SeEvlExpression", qualname );
				assert( ci >= 0 );
				break;
				}
			}
		else
		if( ci >= NmCount( &SeComponents ) )
			{	/* not a valid component */
			if( SeDebugging )
		         ErPLog( "%s: component index (%d) not in name pool.\n",
				"SeEvlExpression: BUG", sysdefp->c.index );

			ErSet( SeSTCORRUPT );
			break;
			}
#if SeDEBUG == 4
		ErPLog( "\tCOMPNAME:%s\n", NmName( ci, &SeComponents ) );
#endif
		return SeEvlComponent( ci, valp, type );
		}
	/* 11-04-29 ch3: added case for QUALCOMP node type (VSL) */
	case SeNT_QUALCOMP :
		/* note: for MUVES, this node type will not be in expression */
		/* for now, just evaluate component and ignore qualifier */
		{	int ci = sysdefp->c.index;
		if( ci >= NmCount( &SeComponents ) )
			{	/* not a valid component */
			if( SeDebugging )
		         ErPLog( "%s: component index (%d) not in name pool.\n",
				"SeEvlExpression: BUG", sysdefp->c.index );

			ErSet( SeSTCORRUPT );
			break;
			}
#if SeDEBUG == 4
		ErPLog( "\tQUALCOMP:%s\n", NmName( ci, &SeComponents ) );
#endif
		return SeEvlComponent( ci, valp, type );
		}
	case SeNT_FNCALL :
		{	const char *funcname;
			double *argv; /* -> to evaluated argument expressions */
			SeArgExp *np;
			register int argct = 0;
#if SeDEBUG == 4
			register int i;
			static int level = 0;
#endif
		assert(sysdefp->f.argexps != NULL);
		assert(! DqIsEmpty( sysdefp->f.argexps ));
		funcname = NmName( sysdefp->f.index, &SeFunctions );
		assert( funcname != NULL );
#if SeDEBUG == 4
		ErPLog( "\tFUNCTION CALL:%s\n", funcname );
#endif
		/* Get count of arguments. */
		DqEACH( sysdefp->f.argexps, np, SeArgExp )
			argct++;

		if( StrEq( funcname, "_eval" ) )
			{ /* Really an operator, not a function call.
			     _eval( type, expr ) changes the expected type
			     of its 2nd arg to the first arg. */
			if( argct != 2 )
				{
				ErPLog( "Error: _eval operator %s.\n",
					"requires two arguments" );
				ErSet( SeSTCORRUPT );
				break;
				}
			np = DqFirst( sysdefp->f.argexps, SeArgExp );
			assert( np != NULL );
			/* Change type to numeric value from first arg. */
			type = (SeTypeID)SeEvlExpression( np->expp, valp,
					argp, type, qualifier );
			np = DqTNext( sysdefp->f.argexps, &np->link, SeArgExp);
			assert( np != NULL ); 
			/* Evaluate expression with new type. */
			return SeEvlExpression( np->expp, valp, argp, type,
						qualifier );
	 		}
		else if( StrEq( funcname, "_MofN" ) )
			{	int	list_index = -1;
				int	cnt=0;
				double	cutoff;
				SeLiDat	*list;
				const char	*qual;

			if ( (argct != 1) && ( argct != 2 ))
				{
				ErPLog( "Error: _MofN function %s.\n",
					"requires one or two arguments" );
				ErSet( SeSTCORRUPT );
				break;
				}
			np = DqFirst( sysdefp->f.argexps, SeArgExp );
			assert( np != NULL );
			if ( np->expp->type == SeNT_LISTNAME)
				{
				qual = NULL;
				list_index = np->expp->c.index;
				list =  SeListDfn[list_index];
				}
			else if ( np->expp->type == SeNT_QUALOP )
				{
				assert( np->expp->o.lhsp != NULL );
				if ( np->expp->o.lhsp->type == SeNT_LISTNAME)
					{
					if( qualifier == NULL )
						{
						qual = NmName( np->expp->o.rhsp->c.index,
							    &SeQualifiers );
						assert( qual != NULL );
						}
					else
						{
						qual = qualifier;
						}
					list_index = np->expp->o.lhsp->c.index;
					list =  SeListDfn[list_index];
					}
				else
					goto bad_arg;
				}
			else
				{
bad_arg:  ErPLog( "Error: _MofN: expecting list element as first argument(%s).\n",
					np->expp->core.text);
				ErSet( SeSTCORRUPT );
				break;
				}


			if ( argct == 2)
				{
				np = DqTNext( sysdefp->f.argexps, &np->link, SeArgExp);
				assert( np != NULL );
				cutoff = SeEvlExpression( np->expp, valp, argp, type,
					 qualifier );
				}
			else
				{
				cutoff = 0.0;
				}
			if ( (cnt = SeMofN( list, cutoff, valp, type, qual ))
					< 0 )
				{
				ErPLog("Error expanding list %s.\n",np->expp->c.text);
				return 0.0;
				}

			/* Evaluate expression with new type. */
			return (double) cnt;
	 		}
		else if( StrEq( funcname, "_Pkd" ) )
			{	int	list_index = -1;
				int	cnt=0;
				SeLiDat	*list;
				const char	*qual;
				int	nkills = -1;
				double	*pkarr;
				int	pksize;
				int	pkdcnt = 0;
				double	*pkdarr;
				int	pkdsize;
				int	ncalcs;
				int	i;
				double	pkfinal;

			if ( argct != 2 )
				{
				ErPLog( "Error: _Pkd function %s.\n",
					"requires two arguments" );
				ErSet( SeSTCORRUPT );
				break;
				}
			np = DqFirst( sysdefp->f.argexps, SeArgExp );
			assert( np != NULL );
			if ( np->expp->type == SeNT_LISTNAME)
				{
				qual = NULL;
				list_index = np->expp->c.index;
				list =  SeListDfn[list_index];
				}
			else if ( np->expp->type == SeNT_QUALOP )
				{
				assert( np->expp->o.lhsp != NULL );
				if ( np->expp->o.lhsp->type == SeNT_LISTNAME)
					{
					if( qualifier == NULL )
						{
						qual = NmName( np->expp->o.rhsp->c.index,
							    &SeQualifiers );
						assert( qual != NULL );
						}
					else
						{
						qual = qualifier;
						}
					list_index = np->expp->o.lhsp->c.index;
					list =  SeListDfn[list_index];
					}
				else
					goto bad_arg2;
				}
			else
				{
bad_arg2:			ErPLog( "Error: _Pkd: expecting list element as first argument.\n");
				ErSet( SeSTCORRUPT );
				break;
				}

			pkarr = NULL;
			pksize = 0;
			cnt = SeGetPks( &pkarr, &pksize, 0, list, valp, type,
				qual );
			if (cnt < 0)
				{
				ErPLog("Error expanding list %s.\n",
					np->expp->c.text);
				return 0.0;
				}
			/* 09-11-16 ch3: added limit check (SCR1300) */
			if (cnt > 30)
			{
				ErPLog("List has more than 30 elements (%d), "
					"_Pkd cannot be performed.\n", cnt);
				ErSet(SePKDOVERFLOW);
				return 0.0;
			}
			/* 09-11-16 ch3: replaced equation (SCR1300) */
			ncalcs = 1 << cnt;  /* i.e. 2 ^ cnt */

			np = DqTNext( sysdefp->f.argexps, &np->link, SeArgExp);
			assert( np != NULL );
			if ( np->expp->type == SeNT_LISTNAME)
				{
				qual = NULL;
				list_index = np->expp->c.index;
				list =  SeListDfn[list_index];
				}
			else if ( np->expp->type == SeNT_QUALOP )
				{
				assert( np->expp->o.lhsp != NULL );
				if ( np->expp->o.lhsp->type == SeNT_LISTNAME)
					{
					if( qualifier == NULL )
						{
						qual = NmName( np->expp->o.rhsp->c.index,
							    &SeQualifiers );
						assert( qual != NULL );
						}
					else
						{
						qual = qualifier;
						}
					list_index = np->expp->o.lhsp->c.index;
					list =  SeListDfn[list_index];
					}
				else
					{
					nkills = SeEvlExpression( np->expp,
						valp, argp, type, qual );
					}
				}
			else
				{
				nkills = SeEvlExpression( np->expp, valp, argp,
					type, qual );
				}

			if (nkills == -1)
				{
				pkdarr = NULL;
				pkdsize = 0;
				pkdcnt = SeGetPkds( &pkdarr, &pkdsize, list,
					valp, type, qual );
				if (pkdcnt < 0)
					{
					ErPLog("Error expanding list %s.\n",
						np->expp->c.text);
					return 0.0;
					}
				if (pkdcnt != cnt && pkdcnt != ncalcs )
					{
					ErPLog( "Error: _Pkd: pkd list does not have the proper number of elements.\n");
					ErSet( SeSTCORRUPT );
					break;
					}
				}

			/* calculate the final result */
			pkfinal = 0.0;
			for (i = 0; i < ncalcs; i++)
				{
				int	c;
				double	pkd;

				/* calculate Pk for this element */
				/* and count number of kills in this element */
				double	pkelem = 1.0;
				int	bit = 1;
				int	killcount = 0;
				for (c = 0; c < cnt; c++)
					{
					if (i & bit)
						{
						killcount++;
						pkelem *= pkarr[c];
						}
					else
						{
						pkelem *= (1 - pkarr[c]);
						}
					bit <<= 1;
					}

				/* get pkd value for this element */
				/* 02-10-15 ch3: moved number of kills check */
				if (nkills >= 0)
					/* number of kills form */
					pkd = killcount < nkills ? 0.0 : 1.0;
				else if (pkdcnt == ncalcs)
					/* long hand form */
					pkd = pkdarr[i];
				else
					/* short hard form */
					if (killcount == 0)
						pkd = 0.0;
					else
						pkd = pkdarr[killcount - 1];
				/* add Pk for element to final Pk */
				pkfinal += pkelem * pkd;
				}

			DmFree((genptr_t)pkarr);
			if (nkills == -1)
				DmFree((genptr_t)pkdarr);
			return pkfinal;
	 		}
		/* 02-07-27 ch3: added support for new _orca function */
		else if( StrEq( funcname, "_orca" ) )
			{	const char	*orca_personnel;
				const char	*qual;
				SeSysDef	*evaldefp;

			orca_personnel = NULL;
			qual = qualifier;
			evaldefp = NULL;

			DqEACH( sysdefp->f.argexps, np, SeArgExp )
				{
				if( !SeCheckExprAndGetComp( np->expp, &evaldefp,
						&orca_personnel, &qual ) )
					{
					/* 14-12-01 ch3: need to return, not break (AppCore) */
					return -1.0;  /* error already reported */
					}
				}

			return SeEvlExpression( evaldefp, valp, argp, type,
				qual );
	 		}
#if SeDEBUG == 4
		for( i = 0; i < level; i++ )
			ErLog( "\t" );
		ErLog( "FNCALL: %d args\n", argct );
#endif
		/* Allocate space to hold values for evaluated arguments. */
		argv = (double *)DmCalloc(argct, sizeof(double ));

		/* Evaluate each argument. */
		argct = 0;
		DqEACH( sysdefp->f.argexps, np, SeArgExp )
			{
#if SeDEBUG == 4
			level++;
#endif
			argv[argct++] =	SeEvlExpression( np->expp, valp, argp,
							 type, qualifier );
#if SeDEBUG == 4
			level--;
			for( i = 0; i < level; i++ )
				ErLog( "\t" );
			ErLog( "argct %d value %g\n", argct, argv[argct-1] );
#endif
			}
		/* Evaluate function definition expression WRT argv. */
		assert(sysdefp->f.index >= 0);
		assert(sysdefp->f.index < NmCount(&SeFunctions));
		assert(SeFnDfn != NULL);
		assert(SeFnDfn[sysdefp->f.index] != NULL);
		assert(SeFnDfn[sysdefp->f.index]->funcdefp != NULL);
#if SeDEBUG == 4
		level++;
#endif
		lvalue = SeEvlExpression( SeFnDfn[sysdefp->f.index]->funcdefp,
					valp, argv, type, qualifier );
#if SeDEBUG == 4
		level--;
#endif
		/* Free up resources. */
		DmFree((genptr_t)argv );
#if SeDEBUG == 4
		for( i = 0; i < level; i++ )
			ErLog( "\t" );
		ErLog( "FNCALL: returning %g\n", lvalue );
#endif
		return lvalue;
		}
	case SeNT_QUALOP :
		{	
			char *qualname;

		qualname = sysdefp->o.rhsp->core.text;
		if( ( SeDebugging == 2 ) && (qualifier != NULL) )
			{
			ErPLog( "SeEvlExpression: WARNING: ");
			ErLog("qualifier %s ignored for %s\n",
				qualifier, sysdefp->o.lhsp->core.text );
			}

		return SeEvlExpression( sysdefp->o.lhsp, valp, argp, 
				type, qualname);
		}
	case SeNT_EXPR :
		/* Return the right-hand side. */
#if SeDEBUG == 4
		ErPLog( "\tNT_EXPR\n" );
#endif
		assert( sysdefp->o.rhsp != NULL );
		if( sysdefp->o.rhsp->type == SeNT_COMPNAME )
			/* Must be a qualified component. */
			return SeEvlComponent( sysdefp->o.rhsp->c.index, valp,
					       type );
		return SeEvlExpression( sysdefp->o.rhsp, valp, argp, type,
					qualifier );
	case SeNT_PARAM : /* Function parameter: has index into argp. */
		assert(argp != NULL);
		return argp[sysdefp->p.index];
	case SeNT_CONSTANT :
#if SeDEBUG == 4
		ErPLog( "\tCONSTANT:%g\n", sysdefp->n.value );
#endif
		/* Just return the numeric constant. */
		return	sysdefp->n.value;
	case SeNT_NOT :
#if SeDEBUG == 4
		ErPLog( "\tNT_NOT\n" );
#endif
		/* Return the logical complement of the right-hand side. */
		return 1.0 - SeEvlExpression( sysdefp->o.rhsp, valp, argp,
					      type, qualifier );
	case SeNT_ABS :
		/* Return the absolute value of the right-hand side. */
#if SeDEBUG == 4
		ErPLog( "\tNT_ABS\n" );
#endif
		rvalue = SeEvlExpression( sysdefp->o.rhsp, valp, argp, type,
					  qualifier );
		return	Abs( rvalue );
	case SeNT_BOOL :
		/* Return 1.0 if the right-hand side is > 0.0,
			and 0.0 otherwise. */
#if SeDEBUG == 4
		ErPLog( "\tNT_BOOL\n" );
#endif
		rvalue = SeEvlExpression( sysdefp->o.rhsp, valp, argp, type,
					  qualifier );
		return	rvalue > 0.0 ? 1.0 : 0.0;
	/* 06-30-00 ch3  added case for AND since it's not optimized now */
	case SeNT_AND :
	case SeNT_PROD :
#if SeDEBUG == 4
		ErPLog( "\tNT_PROD\n" );
#endif
		/* Return the product of the left-hand and right-hand sides. */
		if( (lvalue =
			SeEvlExpression( sysdefp->o.lhsp, valp, argp, type,
					 qualifier )) == 0.0 )
			return	0.0;	/* saves time */
		return lvalue * SeEvlExpression( sysdefp->o.rhsp, valp, argp,
						 type, qualifier );
	case SeNT_OR :	/* assumes statistical independence */
		/* Return the complement of the conjunction of the complements
		   of left-hand and right-hand sides (De Morgan's law).  In
		   case of small values for both sides, return the difference
		   of the sum and product of the left-hand and right-hand
		   sides to guard against floating-point inaccuracies. */
#if SeDEBUG == 4
		ErPLog( "\tNT_OR\n" );
#endif
		if ( (lvalue = SeEvlExpression( sysdefp->o.lhsp, valp, argp,
						type, qualifier ))
			== 1.0
		  || (rvalue = SeEvlExpression( sysdefp->o.rhsp, valp, argp,
						type, qualifier ))
			== 1.0
		   )
			return	1.0;	/* saves time */
		if ( lvalue == 0.0 )
			return	rvalue;	/* saves a small amount of time */
		if ( rvalue == 0.0 )
			return	lvalue;	/* saves a small amount of time */
		if ( Abs( lvalue ) < 0.5 && Abs( rvalue ) < 0.5 )
			return	lvalue + rvalue - lvalue*rvalue;
		else
			return	1.0 - (1.0 - lvalue)*(1.0 - rvalue);
	case SeNT_MIN :
		/* Return the minimum of left-hand and right-hand sides. */
#if SeDEBUG == 4
		ErPLog( "\tNT_MIN\n" );
#endif
		lvalue = SeEvlExpression( sysdefp->o.lhsp, valp, argp, type,
					  qualifier );
		rvalue = SeEvlExpression( sysdefp->o.rhsp, valp, argp, type,
					  qualifier );
		return	lvalue < rvalue ? lvalue : rvalue;
	case SeNT_MAX :
		/* Return the maximum of the left-hand and right-hand sides. */
#if SeDEBUG == 4
		ErPLog( "\tNT_MAX\n" );
#endif
		lvalue = SeEvlExpression( sysdefp->o.lhsp, valp, argp, type,
					  qualifier );
		rvalue = SeEvlExpression( sysdefp->o.rhsp, valp, argp, type,
					  qualifier );
		return	lvalue > rvalue ? lvalue : rvalue;
	case SeNT_XOR :	/* assumes statistical independence */
		{	register double lrprod;
		/* Return the probability of either-L-or-R-but-not-both,
		   where the L and R probabilities are given as the left-hand
		   and right-hand operands.  In case of a large value for
		   either operand, a rearranged expression is used, to guard
		   against floating-point inaccuracies. */
#if SeDEBUG == 4
		ErPLog( "\tNT_XOR\n" );
#endif
		lvalue = SeEvlExpression( sysdefp->o.lhsp, valp, argp, type,
					  qualifier );
		rvalue = SeEvlExpression( sysdefp->o.rhsp, valp, argp, type,
					  qualifier );
		if ( lvalue == 0.0 )
			return	rvalue;	/* saves a small amount of time */
		if ( lvalue == 1.0 )
			return	1.0 - rvalue;	/* saves small amount of time */
		if ( rvalue == 0.0 )
			return	lvalue;	/* saves a small amount of time */
		if ( rvalue == 1.0 )
			return	1.0 - lvalue;	/* saves small amount of time */
		if( Abs( lvalue ) < 0.5 && Abs( rvalue ) < 0.5 )
			{
			lrprod = lvalue * rvalue;
			return	(lvalue + rvalue - lrprod) * (1.0 - lrprod);
			}
		else	{
			lvalue = 1.0 - lvalue;
			rvalue = 1.0 - rvalue;
			lrprod = lvalue * rvalue;
			return	(lvalue + rvalue - lrprod) * (lrprod - 1.0);
			}
		}
	case SeNT_LIST :
		/* Return list of expressions. */
#if SeDEBUG == 4
		ErPLog( "\tNT_LIST\n" );
#endif
	ErPLog( "BUG: SeEvlExpression: can't eval a %s expression.\n",
			SeCvtToStr( sysdefp->type ) );
		break;
	case SeNT_SUM :
		/* Return sum of the left-hand and right-hand sides. */
#if SeDEBUG == 4
		ErPLog( "\tNT_SUM\n" );
#endif
		return	SeEvlExpression( sysdefp->o.lhsp, valp, argp, type,
					  qualifier ) +
			SeEvlExpression( sysdefp->o.rhsp, valp, argp, type,
					  qualifier );
	case SeNT_DIFF :
		/* Return difference of the left-hand and right-hand sides. */
#if SeDEBUG == 4
		ErPLog( "\tNT_DIFF\n" );
#endif
		return	SeEvlExpression( sysdefp->o.lhsp, valp, argp, type,
					  qualifier ) -
			SeEvlExpression( sysdefp->o.rhsp, valp, argp, type,
					  qualifier );
	case SeNT_QUOT :
#if SeDEBUG == 4
		ErPLog( "\tNT_QUOT\n" );
#endif
		/* Return the quotient of the left-hand and right-hand sides. */
		if( (rvalue = SeEvlExpression( sysdefp->o.rhsp, valp, argp,
					       type, qualifier )) == 0.0 )
			{
			ErSet( SeDIVBYZERO );
			break;
			}
		return SeEvlExpression( sysdefp->o.lhsp, valp, argp, type,
					qualifier ) / rvalue;
	case SeNT_LT :
		/* Return 1 if the left-hand side is less than that of the
		   right-hand side, otherwise 0. */
#if SeDEBUG == 4
		ErPLog( "\tNT_LT\n" );
#endif
		lvalue = SeEvlExpression( sysdefp->o.lhsp, valp, argp, type,
					  qualifier );
		rvalue = SeEvlExpression( sysdefp->o.rhsp, valp, argp, type,
					  qualifier );
		return	(double) (lvalue < rvalue);
	case SeNT_GT :
		/* Return 1 if the left-hand side is greater than that of the
		   right-hand side, otherwise 0. */
#if SeDEBUG == 4
		ErPLog( "\tNT_GT\n" );
#endif
		lvalue = SeEvlExpression( sysdefp->o.lhsp, valp, argp, type,
					  qualifier );
		rvalue = SeEvlExpression( sysdefp->o.rhsp, valp, argp, type,
					  qualifier );
		return	(double) (lvalue > rvalue);
	case SeNT_LTEQ :
		/* Return 1 if the left-hand side is less than or equal to
		   that of the right-hand side, otherwise 0. */
#if SeDEBUG == 4
		ErPLog( "\tNT_LTEQ\n" );
#endif
		lvalue = SeEvlExpression( sysdefp->o.lhsp, valp, argp, type,
					  qualifier );
		rvalue = SeEvlExpression( sysdefp->o.rhsp, valp, argp, type,
					  qualifier );
		return	(double) (lvalue <= rvalue);
	case SeNT_GTEQ :
		/* Return 1 if the left-hand side is greater than or equal
		   to that of the right-hand side, otherwise 0. */
#if SeDEBUG == 4
		ErPLog( "\tNT_GTEQ\n" );
#endif
		lvalue = SeEvlExpression( sysdefp->o.lhsp, valp, argp, type,
					  qualifier );
		rvalue = SeEvlExpression( sysdefp->o.rhsp, valp, argp, type,
					  qualifier );
		return	(double) (lvalue >= rvalue);
	case SeNT_RUNIF :
		/* Return random number uniformly distributed in given range. */
#if SeDEBUG == 4
		ErPLog( "\tNT_RUNIF\n" );
#endif
		if ( (lvalue = SeEvlExpression( sysdefp->o.lhsp, valp, argp,
						type, qualifier ))
		  >= (rvalue = SeEvlExpression( sysdefp->o.rhsp, valp, argp,
						type, qualifier )) )
			{		/* usage check (would actually work) */
			ErSet( SeRANGE );
			break;
			}
			{
			if (single_stream)
				{
				return RnFlt( RnSINGLE_STREAM, lvalue, rvalue );
				}
			else
				{
				return RnFlt( SeSTREAM, lvalue, rvalue );
				}
			}
	case SeNT_RNORM :
		/* Return random number normally distributed with given mean
			and standard deviation. */
#if SeDEBUG == 4
		ErPLog( "\tNT_RNORM\n" );
#endif
		lvalue = SeEvlExpression( sysdefp->o.lhsp, valp, argp, type,
					  qualifier );
		if( (rvalue = SeEvlExpression( sysdefp->o.rhsp, valp, argp,
					       type, qualifier )) < 0.0 )
			{
			ErSet( SeSTDDEV );
			break;
			}
			{
			if (single_stream)
				{
				return RnNorm( RnSINGLE_STREAM, lvalue, rvalue );
				}
			else
				{
				return RnNorm( SeSTREAM, lvalue, rvalue );
				}
			}
	/* 06-30-00 ch3  added support to handle multiple occurrence */
	case SeNT_MULTOCC :
		/* Return the right-hand side. */
		/* Multiple occurrence assumes the expression is for PK */
#if SeDEBUG == 4
		ErPLog( "\tNT_MULTOCC\n" );
#endif
		assert( sysdefp->o.rhsp != NULL );
		lvalue = SeEvlExpression( sysdefp->o.rhsp, valp, argp, type,
			qualifier );
		switch (type)
			{
		case SeTypeNotKilled:
		case SeTypePS:
		case SeTypeFRF:
			return 1.0 - lvalue;
		default:
			return lvalue;
			}

	default :
		ErPLog( "SeEvlExpression: Illegal operator type \"%s\"\n",
				SeCvtToStr( sysdefp->type ) );

		ErSet( SeSTCORRUPT );
		break;
		}
	assert(ErIsSet());
	return -1.0;	/* valued returned on error */
	}

/*
	SeSysDef **SeAddListMember( SeStDat *defp, SeSysDef *elemdefp,
				    SeLiMember *mp, int index )

	Add member of list to state vector specified by 'defp'.  The list
	name node or qualified list name node being expanded is specified
	as 'elemdefp'.  The list member ptr 'mp' and SeLists n.p. index
	are also provided by the calling routine.

	Returns the address of the new member if successful, and NULL
	otherwise.
 */

/*ARGSUSED*/ 
STATIC SeSysDef **
#if STD_C
SeAddListMember( SeStDat *defp, SeSysDef *elemdefp, SeLiMember *mp, int index )
#else
SeAddListMember( defp, elemdefp, mp, index )
SeStDat *defp;
SeSysDef *elemdefp;
SeLiMember *mp;
int index;
#endif
	{	register const SeSysDef *memberp;
		SeSysDef **markp = NULL;
#if SeDEBUG == 3
	SePrtStVector( defp, "SeAddListMember: entered" );
	ErPLog( "SeAddListMember: list=%s: member=%s element type=%s\n",
		NmName( index, &SeLists ),
		SeSysTextRep( &mp->member ),
		SeCvtToStr( elemdefp->type ) );
#endif
	/* If list is qualified, need to insert SeNT_QUALOP node above
	   referenced member expression tree. */
	switch( elemdefp->type )
		{
	case SeNT_QUALOP :
		{	static SeSysDef opnode;
		opnode = *elemdefp; /* struct copy */
		opnode.o.lhsp = &mp->member;

#if SeDEBUG == 3
		ErPLog( "SeAddListMember: opnode.o.lhs type=%s\n",
			SeCvtToStr( opnode.o.lhsp->type ) );
#endif
		switch( opnode.o.lhsp->type )
			{
		case SeNT_COMPNAME :
			{	char *qualname;
			/* We have a qualified component, make sure
			   it is registered in the SeComponents n.p. */
			qualname = SeSysTextRep( &opnode );
			/* 05-02-08 jh: need to check if a qualified
                           component is inside a qualified
                           list. (SCR544) */
			{
			  char *q = qualname; int n = 0;
			  while (*q) if (*q++ == '[') ++n;
			  if (n > 1) {
			    ErPLog("Qualified component appears inside a "
				   "qualified list: %s\n", qualname);
			    ErSet(SeQUALQUAL);
			    DmFree((genptr_t)qualname);
			    return NULL;
			  }
			}
			if( ! SeRegisterQualComp( qualname,
						  opnode.o.lhsp->c.index ) )
				{
				assert( markp == NULL );
				goto finish;
				}
			DmFree((genptr_t)qualname );
			break;
			}
		case SeNT_LISTNAME :
			{ /* We have a qualified list. */
				int li = mp->member.c.index;
				SeLiMember *lmp;
#if SeDEBUG == 3
			ErPLog( "SeAddListMember: element is %s\n",
				SeSysTextRep( elemdefp ) );
#endif
			/* Recurse on each member of sublist. */
			DqEACH( SeListDfn[li], lmp, SeLiMember )
				{
#if SeDEBUG == 3
				ErPLog( "%s on member=%s of list=%s\n",
					"SeAddListMember: recursing",
					SeSysTextRep( &lmp->member ),
					NmName( li, &SeLists ) );
#endif
				if( (markp = SeAddListMember( defp, elemdefp,
						lmp, li )) == NULL )
					goto finish;
				}
			goto finish;
			}
		case SeNT_EXPR :
			if( mp->member.o.rhsp->type == SeNT_COMPNAME )
				{ /* We have a qualifier applied to a qualified
				     component.  The inner-most qualifier takes
				     precidence, so register it. */
					const char *basename;
					char *qualname;
					int ci;
					SeSysDef *compdefp = mp->member.o.rhsp;
				basename = SePrsBaseName( compdefp->c.index );
				assert( basename != NULL );
				ci = NmIndex( basename, &SeComponents, mFalse );
				assert( ci != -1 ); 
				qualname = SeSysTextRep( mp->member.o.rhsp );
				if( ! SeRegisterQualComp( qualname, ci ) )
					{
					assert( markp == NULL );
					goto finish;
					}
				DmFree((genptr_t)qualname );
				break;
				}
		/*FALLTHRU*/
		/* in-line expression, let fall thru and treat as simple member */
		case SeNT_NOT :
		case SeNT_ANOT :
		case SeNT_ABS :
		case SeNT_BOOL :
		case SeNT_AND :
		case SeNT_XOR :
		case SeNT_OR :
		case SeNT_MIN :
		case SeNT_MAX :
		case SeNT_SUM :
		case SeNT_DIFF :
		case SeNT_PROD :
		case SeNT_QUOT :
		case SeNT_LT :
		case SeNT_GT :
		case SeNT_RUNIF :
		case SeNT_RNORM :
		case SeNT_MOFN :
		case SeNT_PKD :
		/* 02-07-27 ch3: added support for ORCA node type */
		case SeNT_ORCA :
		case SeNT_EVAL :
		case SeNT_SYSNAME :
		case SeNT_QUALOP:
		/* 06-30-00 ch3  added case for new multiple occurrence op */
		case SeNT_MULTOCC :
			break;

			/* else can't handle it so fall thru */
		default :
			if( SeDebugging ) 
				{
				ErPLog("%s QUALOP: ignoring \"%s\"(%s)\n",
					"SeAddListMember:",
					opnode.o.lhsp->core.text,
					SeCvtToStr( opnode.o.lhsp->type ) );
				}
			else
  				ErPLog("%s QUALOP: ignoring (%s)\n",
			 		"SeAddListMember:",
					SeCvtToStr( opnode.o.lhsp->type ) );

				break;
			}
		memberp = &opnode;
		break;
		}
	default :
		memberp = &mp->member;
		}

	/* If member is itself a list, need to recurse. */
	switch( memberp->type )
		{
	case SeNT_QUALIST :
	case SeNT_LISTNAME :
		{ /* We have a list. */
			int li = memberp->c.index;
			SeLiMember *lmp;
		/* Recurse on each member of sublist. */
		DqEACH( SeListDfn[li], lmp, SeLiMember )
			{
#if SeDEBUG == 3
			ErPLog( "%s on member=%s of list=%s\n",
				"SeAddListMember: recursing",
				SeSysTextRep( &lmp->member ),
				NmName( li, &SeLists ) );
#endif
			if( (markp = SeAddListMember( defp, &lmp->member,
						      lmp, li )) == NULL )
				goto finish;
#if SeDEBUG == 3
			SePrtStVector(defp,"SeAddListMember: after recursing" );
#endif
			}
		goto finish;
		}
	default:
		break;
		}

	/* Simple member, add it to list. */
	markp = SeStAddMember( defp, memberp );
finish:
#if SeDEBUG == 3
	SePrtStVector( defp, "SeAddListMember: returning" );
#endif
	return markp;
	}

#if SeDEBUG == 3

STATIC void
#if STD_C
SePrtStVector( SeStDat *defp, const char *label )
#else
SePrtStVector( defp, label )
SeStDat *defp;
const char *label;
#endif
	{	SeSysDef **defs;
	assert( defp != NULL );
	ErPLog( "%s: ", label );
	if( defp->defs != NULL )
		for( defs = defp->defs; *defs != NULL; defs++ )
			ErLog( "%s, ", SeSysTextRep( *defs ) );
	ErLog( "\n" );
	}
#endif

/* this function will register a new qualified component if */
/* the base component already exists, and will return the index */
/* of the qualifier component, otherwise returns -1 for an error */

/* 01-04-17 ch3: this function was added for SeTcl.c */
MuvesBool
#if STD_C
SeRegisterNewQualComp( const char *qualname )
#else
SeRegisterNewQualComp( qualname )
const char *qualname;
int ci;
#endif
        {
		int ci;
		const char *basename;
                char buffer[SeBUFSIZE];

		/* first we need get the base component */
                strncpy( buffer, qualname, SeBUFSIZE );
                assert(strlen(buffer) < SeBUFSIZE);

                if( (basename = strtok( buffer, SeTK_LF_SQUARE )) == NULL
                           || strtok( (char *) NULL, SeTK_RT_SQUARE ) == NULL )
			{
			/* this should not happen because */
			/* qualname should contain a qualifier */
			return -1;
			}
		
		/* check if the base component name exists */
		if( (ci = NmIndex( basename, &RtComponents, mFalse ) ) < 0 )
			{
			/* basename does not exist */
			return -1;
			}
		
		/* now we can register the qualifier component */
		if( !SeRegisterQualComp( qualname, ci ) )
			{
			/* could not register component */
			return -1;
			}

		/* get the index of the newly added qualifier component */
		if( (ci = NmIndex( qualname, &SeComponents, mFalse )) == -1 )
			{
			/* this shouldn't have happened */
			return -1;
			}
				
		/* make it critical so s2ReadDesFile will load it for CATS */
		SeIsCritical[ci] = mTrue;

		return ci;  /* return qualified component's index */
	}

MuvesBool  /* 01-04-17 ch3: removed STATIC for SeTcl.c */
#if STD_C
SeRegisterQualComp( const char *qualname, int ci )
#else
SeRegisterQualComp( qualname, ci )
const char *qualname;
int ci;
#endif
	{	int qi, ncomps;

	if( SeDebugging ) 
	      ErPLog( "SeRegisterQualComp: qualname=%s ci=%d\n", qualname, ci );

	assert( ci < NmCount( &RtComponents ) );
	ncomps = NmCount( &SeComponents );
	if( (qi = NmIndex( qualname, &SeComponents, mTrue )) == -1 )
		return mFalse; /* error set */
	/* Add qualified component to SeQualp[] if not already in there. */
	if( ncomps < NmCount( &SeComponents ) )
		{	SeQalNode *newp;
		if( SeDebugging == 2 ) 
			ErPLog( "%s: Adding \"%s\" to %s n. p.\n",
				"SeRegisterQualComp", qualname,
				"SeComponents" );

		/* May need to grow the iscritical array. */
		/* XXX - still relies on globals SeCritSz and SeIsCritical*/
		if( (SeCritSz > 0) && (ncomps+1 > SeCritSz) )
			{	register int nc;
			SeIsCritical =
				(char *)DmRealloc(SeIsCritical,(SeCritSz*2)*sizeof(char));
			SeCritSz *= 2;
			for( nc = ncomps; nc < SeCritSz; nc++ )
				SeIsCritical[nc] = mFalse;
			}

		/* Initialize Dq list if necessary. */
		if( SeQualp[ci] == NULL && (SeQualp[ci] = DqOpen()) == NULL )
			return mFalse;
		newp = (SeQalNode *)DmXalloc(SeQalNode);
		newp->index = qi;
		DqPush( SeQualp[ci], &newp->link );
		}
	return mTrue;
	}

STATIC int
#if STD_C
SeRegisterQualSys( const SeSysDef *sysdefp, const char *qualifier )
#else
SeRegisterQualSys( sysdefp, qualifier )
const SeSysDef *sysdefp;
const char *qualifier;
#endif
	{
	register int qualindex;
	const char *qualname = SeGetQualName(sysdefp->core.text, qualifier);

	if ((qualindex = NmIndex( qualname, &SeSystems, mFalse )) == -1 )
		{
		ErClear(); /* ok clear error */
		return SeSysInsert( qualname );
		}
	return qualindex; /* already indexed */

	}


STATIC SeSysDef **
#if STD_C
SeStExpandMember( SeStDat *defp, SeSysDef **defs )
#else
SeStExpandMember( defp, defs )
SeStDat *defp;
SeSysDef **defs;
#endif
	{	const char *listname;
		int index;
		int newlen;
		int marker;
		register SeLiMember *mp;
		SeSysDef *elemdefp;
		SeSysDef **newdefsp, **olddefsp;
		register SeSysDef **ndp, **odp, **markp;
	assert( defp->values == NULL );
#if SeDEBUG == 3
	ErPLog( "SeStExpandMember: defs=0x%x\n", defs );
	SePrtStVector( defp, "SeStExpandMember: before expansion" );
#endif

	/* Get name of list from state vector element. */
	elemdefp = *defs;
	switch( elemdefp->type )
		{
	case SeNT_QUALOP :
		assert( elemdefp->o.lhsp != NULL );
		index = elemdefp->o.lhsp->c.index;
		break;
	case SeNT_QUALIST :
	case SeNT_LISTNAME :
		index = elemdefp->c.index;
		break;
	default :
		ErPLog( "BUG: SeStExpandMember: type '%s' not handled.\n",
			SeCvtToStr( elemdefp->type ) );
		assert( elemdefp->type == SeNT_LISTNAME );
		return NULL;
		}
	listname = NmName( index, &SeLists );
	assert( listname != NULL );
#if SeDEBUG == 3
	ErPLog( "SeStExpandMember: expanding list \"%s\"\n", listname );
#endif
	if( NmIndex( listname, &SeSystems, mFalse ) != -1 )
		{
#if SeDEBUG
		ErPLog( "SeStExpandMember: deleting '%s' from SeSystems.\n",
			listname );
#endif
		SeSysDelete( listname );
		}
	else
		ErClear();

	assert( ! DqIsEmpty( SeListDfn[index] ) );

	/* Allocate an array of names to hold everything up to the member
	   being expanded. */
	newlen = defs - defp->defs;
	if( newlen > 0  )
		{
		newdefsp = (SeSysDef **)DmCalloc(newlen+1, sizeof(SeSysDef *));
		for(	odp = defp->defs, ndp = newdefsp;
			odp != defs && *odp != NULL;
			odp++, ndp++ )
			*ndp = *odp; /* copy definition to new array */
		*ndp = NULL;	/* NULL terminate array */
		marker = newlen;
		}
	else
		{
		newdefsp = NULL;
		odp = defs;
		marker=0;
		}
	assert( odp == defs );

	/* lets clear out text names from expanding element name on down */
	{
		char **strp;
	for ( strp = defp->text + newlen; *strp != NULL; strp++)
		{
		DmFree((genptr_t)*strp );
		*strp = NULL;
		}
	}


	/* Keep ptr to old name array, but install new one. */
	olddefsp = defp->defs;
	defp->defs = newdefsp;
	defp->length = newlen;


#if SeDEBUG == 3
	DqEACH( SeListDfn[index], mp, SeLiMember )
		ErPLog( "SeStExpandMember: mp=0x%x member=%s\n",
			mp, SeSysTextRep( &mp->member ) );
#endif

	/* Expand list and append to new array. */
	DqEACH( SeListDfn[index], mp, SeLiMember )
		{	int li;
#if SeDEBUG == 3
		ErPLog( "SeStExpandMember: before calling SeAddListMember: mp=0x%x member=%s\n", mp, SeSysTextRep( &mp->member ) );
		SePrtStVector( defp, "SeStExpandMember: before calling SeAddListMember" );
#endif
		/* If this member is a system, check to see if it was promoted to
		   a list after it was included in this list; 
		   if so, adjust its type and index. */
		if(   mp->member.type == SeNT_SYSNAME 
		   && (li = NmIndex( mp->member.core.text, &SeLists, mFalse )) >= 0 )
			{
			/* It's a list */
			mp->member.type = SeNT_LISTNAME;
			mp->member.c.index = li;
			}
		else
			ErClear();

		markp = SeAddListMember( defp, elemdefp, mp, index );
		/* 05-02-09 jh: must check return value (SCR544) */
		if (markp == NULL)
		  return mFalse;
#if SeDEBUG == 3
		SePrtStVector( defp, "SeStExpandMember: after calling SeAddListMember" );
#endif
		marker = markp - defp->defs + 1;
		}

	/* free expanded node */
	if (*odp != NULL)
		SeExpFree( *odp );

	/* Copy remainder of old array to end of new array. */
	for( odp++; *odp != NULL; odp++ )
		{
		if( SeStAddMember( defp, *odp ) == NULL )
			return NULL;
		SeExpFree( *odp );
		}

	/* Free up old list. */
	DmFree((genptr_t)olddefsp );
	
	assert( defp->defs != NULL );
#if SeDEBUG == 3
	SePrtStVector( defp, "SeStExpandMember: after expansion" );
	ErPLog( "SeStExpandMember: returning 0x%x\n",
		defp->defs + marker );
#endif
	return defp->defs + marker; /* return ptr to member following new entries */
	}

/*

	MuvesBool SeListExpand( SeStDat *defp )

	Check state vector for list references, and expand if needed.
 */
MuvesBool
#if STD_C
SeListExpand( SeStDat *defp )
#else
SeListExpand( defp )
SeStDat *defp;
#endif
	{	SeSysDef **defs;
	assert(defp != NULL);
	assert(defp->defs != NULL);
	assert(defp->length > 0);
	assert(defp->type > SeTypeUnset && defp->type < SeTypeSentinel);

#if SeDEBUG == 3
	SePrtStVector( defp, "SeListExpand: before expansion" );
#endif
	
	/* Expand any list references in state vector. */
	for( defs = defp->defs; *defs != NULL;  )
		{	SeSysDef *sysdefp = *defs;
#if SeDEBUG == 3
		ErPLog( "SeListExpand: Current member %s\n",
			SeSysTextRep(*defs) );
#endif
		switch( sysdefp->type )
			{
		case SeNT_QUALOP :
			assert( sysdefp->o.lhsp != NULL );
			if(	sysdefp->o.lhsp->type != SeNT_LISTNAME
			     &&	sysdefp->o.lhsp->type != SeNT_QUALIST )
				{
				defs++;
				continue;
				}
			assert( sysdefp->o.lhsp->c.index );
			goto do_list;
		case SeNT_LISTNAME :
		case SeNT_QUALIST :
			assert( sysdefp->c.index );
do_list :
#if SeDEBUG == 3
			ErPLog( "Expanding member %s\n", SeSysTextRep(*defs) );
#endif
			if( (defs = SeStExpandMember( defp, defs )) == NULL )
				return mFalse;
			break;
		default :
			defs++;
			}
		}
#if SeDEBUG == 3
	SePrtStVector( defp, "SeListExpand: after expansion" );
#endif
	return mTrue;
	}

/*

	MuvesBool SeExpandLists( void )

	Check all state vectors for list references, and expand if needed.
 */
MuvesBool
#if STD_C
SeExpandLists( void )
#else
SeExpandLists()
#endif
	{	register int i;
	if( NmCount( &SeLists ) == 0 )
		return mTrue; /* no lists */

	for( i = NmCount( &SeStates ); --i >= 0; )
		if( ! SeListExpand( SeStDef[i] ) )
			return mFalse;
	return mTrue;
	}

/*
	Stuff for trapping FPE exceptions during expression evaluation.
 */

#if STD_C
STATIC void (*SeOldFpe)( int ) = SIG_ERR;	/* old SIGFPE catcher */
#else
STATIC void (*SeOldFpe)() = SIG_ERR;	/* old SIGFPE catcher */
#endif

STATIC MuvesBool SeFpeMine = mFalse;		/* "Se is evaluating" flag */
STATIC jmp_buf SeJmpBuf;

#if 0  /* this function is not used */
STATIC void
#if STD_C
SeFpeTrap( int sig )
#else
SeFpeTrap( sig )
int sig;
#endif
	{
	assert(sig == SIGFPE);
	assert(SeOldFpe != SIG_ERR);	/* else SeFpeTrap was set up wrong */

#if SeDEBUG
/* XXX	(void)write( 2, "XXX SeFpeTrap\n", 14 ); */
/* XXX	ErPLog( "XXX SeFpeTrap(%d)\n", sig );	XXX */
#endif
	if ( SeFpeMine )
		{
		(void)signal( sig, SeFpeTrap );	/* reset for next time */
		longjmp( SeJmpBuf, sig );
		}
	else if ( SeOldFpe != SIG_IGN && SeOldFpe != SIG_DFL )
		(*SeOldFpe)( sig );	/* route to previous handler */
	else if ( SeOldFpe == SIG_DFL )
		{
		/* There really is no good way to recover from this; we
		   must not merely ignore the exception, because in some
		   implementations the faulting instruction is restarted. */

		ErPLog( "*** Floating-point exception detected ***\n" );
		ErPLog( "*** Analysis terminated; submit a bug report ***\n" );

		if( SeDebugging ) 
			exit( EXIT_FAILURE );	/* best I could think of */
		else
			abort();	/* hope the function traceback helps */
		}
    }
#endif

/*
	void SePrtNamePool( NmPool *poolp, const char *poolnm )

	Prints all name pool entries to the standard error output.
 */
#ifdef DEBUG
STATIC void
#if STD_C
SePrtNamePool( NmPool *poolp, const char *poolnm )
#else
SePrtNamePool( poolp, poolnm )
NmPool *poolp;
const char *poolnm;
#endif
	{	register int id, nitems = NmCount( poolp );
	ErPLog( "%s:\n", poolnm );
	for( id = 0; id < nitems; id++ )
		ErPLog( "\t% 4d:%s\n",
			id, NmName( id, poolp ) );
	}

#endif
#ifdef DEBUG
/*
	void SePrtKnownSystems( const char *heading )

	Prints all system names to the standard error output.
 */
void
#if STD_C
SePrtKnownSystems( const char *heading )
#else
SePrtKnownSystems( heading )
const char *heading;
#endif
	{	register int sys, nsys = NmSize( &SeSystems );
	ErPLog( "%s\n", heading );
	for( sys = 0; sys < nsys; sys++ )
		if(	SeDataSystem[sys] != NULL
		    &&	SeDataSystem[sys]->sysdef->type != SeNT_LISTNAME )
			ErPLog( "% 4d:%s:%s:%s\n",
				sys, NmName( sys, &SeSystems ),
				SeDataSystem[sys]->sysdef->core.text,
				SeCvtToStr( SeDataSystem[sys]->sysdef->type ) );
	}
#endif

/*
	void SeSysCompList( SeSysDef *sysdefp, int level )

	Creates a list of components in a system expression subtree
 */
/*ARGSUSED*/
void
#if STD_C
SeSysCompList( SeSysDef *sysdefp, SeCompInfoList *list, int level )
#else
SeSysCompList( sysdefp, list, level )
SeSysDef *sysdefp;
SeCompInfoList *list;
int level;
#endif
	{	register int col;	/* column counter for indentation */

	if( sysdefp == NULL )
		{
		ErPLog( "BUG: null (sub)expression pointer.\n" );
		(void) ErLog( "NULL\n" );
		}
	else
	switch( sysdefp->type )
		{
	case SeNT_QUALSYS :
	case SeNT_SYSNAME :
		{	register const char *name;
		if( (name = NmName( sysdefp->c.index, &SeSystems )) == NULL )
			ErPLog( "BUG: bad system (%s) index (%d).\n",
				sysdefp->core.text, sysdefp->c.index );
		else
			{
			if( SeDataSystem[sysdefp->c.index] != NULL )
				SeSysCompList( SeDataSystem[sysdefp->c.index]->sysdef,
					       list, level+1 );
			}
		break;
		}
	case SeNT_QUALIST:
	case SeNT_LISTNAME:
		{	register const char *name;
		SeLiMember *mp;
		if( (name = NmName( sysdefp->c.index, &SeLists )) == NULL )
			ErPLog( "BUG: bad system (%s) index (%d).\n",
				sysdefp->core.text, sysdefp->c.index );
		else
			{
			DqEACH( SeListDfn[sysdefp->c.index], mp, SeLiMember )
				SeSysCompList( &mp->member, list, level+1 );
			}
		break;
		}
	case SeNT_QUALCOMP :
	case SeNT_COMPNAME :
		{	register const char *name;
		int id, index;
		if( (name = NmName( sysdefp->c.index, &SeComponents )) == NULL )
			ErPLog( "BUG: bad component index (%d).\n",
				sysdefp->c.index );
		else
			{
			if (strchr(name, '[') != NULL)
				{
				name = SePrsBaseName(sysdefp->c.index);
				id = NmIndex(name, &SeComponents, mFalse);
				}
			else
				id = sysdefp->c.index;
			index = NmIndex(name, &list->names, mTrue);
			if (list->len <= index)
				{
				list->len = list->len == 0 ? 32 : list->len * 2;
				list->id = (int *)DmRealloc(list->id, 
							sizeof(int) * list->len);
				}
			list->id[index] = id;
			}
		break;
		}
	case SeNT_CONSTANT :
		break;
	case SeNT_FNCALL :
		{	register const char *name;
		if( (name = NmName( sysdefp->f.index, &SeFunctions )) == NULL )
			ErPLog( "BUG: bad function definition index (%d).\n",
				sysdefp->f.index );
		else
			{	SeArgExp *np;
			DqEACH( sysdefp->f.argexps, np, SeArgExp )
				{
				SeSysCompList( np->expp, list, level+1 );
				}
			}
		break;
		}
	case SeNT_PARAM :
		break;
	case SeNT_MULTOCC :
		/* FALL THRU */
	case SeNT_EXPR :
		SeSysCompList( sysdefp->o.rhsp, list, level+1 );
		break;
	case SeNT_NOT :
	case SeNT_ANOT :
	case SeNT_ABS :
	case SeNT_BOOL :
		SeSysCompList( sysdefp->o.rhsp, list, level+1 );
		break;
	case SeNT_LIST :
	case SeNT_AND :
	case SeNT_XOR :
	case SeNT_OR :
	case SeNT_MIN :
	case SeNT_MAX :
	case SeNT_SUM :
	case SeNT_DIFF :
	case SeNT_PROD :
	case SeNT_QUOT :
	case SeNT_LT :
	case SeNT_GT :
	case SeNT_QUALOP :
	case SeNT_RUNIF :
	case SeNT_RNORM :
	case SeNT_MOFN :
	case SeNT_PKD :
	case SeNT_ORCA :
	case SeNT_EVAL :
		SeSysCompList( sysdefp->o.lhsp, list, level+1 );
		SeSysCompList( sysdefp->o.rhsp, list, level+1 );
		break;
	case SeNT_UNSET:
		ErPLog( "BUG: node type unset.\n" );
		(void) ErLog( "Node type unset\n" );
		break;
	default :
		ErPLog( "BUG: SeSysCompList: illegal node type (%s).\n",
			SeCvtToStr(sysdefp->type) );
		(void) ErLog( "Unknown node type %s\n",
				SeCvtToStr(sysdefp->type) );
		break;
		}
	}

#ifdef DEBUG
/*
	void SePrtExpression( SeSysDef *sysdefp, int level )

	Prints a system expression subtree to the standard error.
 */
/*ARGSUSED*/
void
#if STD_C
SePrtExpression( SeSysDef *sysdefp, int level )
#else
SePrtExpression( sysdefp, level )
SeSysDef *sysdefp;
int level;
#endif
	{	register int col;	/* column counter for indentation */
#if 0
	for( col = 0; col < level; col++ )
		ErLog( " " );
#endif
	if( sysdefp == NULL )
		{
		ErPLog( "BUG: null (sub)expression pointer.\n" );
		(void) ErLog( "NULL\n" );
		}
	else
	switch( sysdefp->type )
		{
	case SeNT_QUALSYS :
	case SeNT_SYSNAME :
		{	register const char *name;
		if( (name = NmName( sysdefp->c.index, &SeSystems )) == NULL )
			ErPLog( "BUG: bad system (%s) index (%d).\n",
				sysdefp->core.text, sysdefp->c.index );
		else
			{
			if( ! StrEq( sysdefp->core.text, name ) )
				ErPLog( "*** SePrtExpression: %s: %s != %s\n",
					SeCvtToStr( sysdefp->type ),
					sysdefp->core.text, name );
			(void) ErLog( "[% 4d:%s:%s]\n",
				      sysdefp->c.index, name,
				      sysdefp->core.text );
			if( SeDataSystem[sysdefp->c.index] == NULL )
				ErPLog( "SePrtExpression: system %s undefined.\n",
					name );
			else
			SePrtExpression( SeDataSystem[sysdefp->c.index]->sysdef,
				         level+1 );
			}
		break;
		}
	case SeNT_QUALCOMP :
	case SeNT_COMPNAME :
		{	register const char *name;
		if( (name = NmName( sysdefp->c.index, &SeComponents )) == NULL )
			ErPLog( "BUG: bad component index (%d).\n",
				sysdefp->c.index );
		else
			{
			if( ! StrEq( sysdefp->core.text, name ) )
				ErPLog( "*** SePrtExpression: %s: %s != %s\n",
					SeCvtToStr( sysdefp->type ),
					sysdefp->core.text, name );
			(void) ErLog( "<% 4d:%s:%s>\n",
				      sysdefp->c.index, name,
				      sysdefp->core.text );
			}
		break;
		}
	case SeNT_CONSTANT :
		(void) ErLog( "{%f:%s}\n",
			      sysdefp->n.value, sysdefp->core.text );
		break;
	case SeNT_FNCALL :
		{	register const char *name;
		if( (name = NmName( sysdefp->f.index, &SeFunctions )) == NULL )
			ErPLog( "BUG: bad function definition index (%d).\n",
				sysdefp->f.index );
		else
			{	SeArgExp *np;
			(void) ErLog( "%s(\n", name );
			DqEACH( sysdefp->f.argexps, np, SeArgExp )
				{
				if(np != DqFirst(sysdefp->f.argexps, SeArgExp))
					{
					for( col = 0; col < level; col++ )
						(void) ErLog( " " );
					(void) ErLog( ",\n" );
					}
				SePrtExpression( np->expp, level+1 );
				}
			for( col = 0; col < level; col++ )
				(void) ErLog( " " );
			(void) ErLog( ")\n" );
			}
		break;
		}
	case SeNT_PARAM :
		(void) ErLog( "$%d\n", sysdefp->p.index );
		break;
	/* 06-30-00 ch3  added case to handle new multiple occurrence op */
	case SeNT_MULTOCC :
		(void) ErLog( "MultOcc" );
		/* FALL THRU */
	case SeNT_EXPR :
		(void) ErLog( "%s\n", SeTtbl[SeNT_LF_PAREN].ts );
		SePrtExpression( sysdefp->o.rhsp, level+1 );
		for( col = 0; col < level; col++ )
			(void) ErLog( " " );
		(void) ErLog( "%s\n", SeTtbl[SeNT_RT_PAREN].ts );
		break;
	case SeNT_NOT :
	case SeNT_ANOT :
	case SeNT_ABS :
	case SeNT_BOOL :
		(void) ErLog( "%s\n", SeSysTextRep( sysdefp ) );
		SePrtExpression( sysdefp->o.rhsp, level+1 );
		break;
	case SeNT_LIST :
	case SeNT_AND :
	case SeNT_XOR :
	case SeNT_OR :
	case SeNT_MIN :
	case SeNT_MAX :
	case SeNT_SUM :
	case SeNT_DIFF :
	case SeNT_PROD :
	case SeNT_QUOT :
	case SeNT_LT :
	case SeNT_GT :
	case SeNT_QUALOP :
	case SeNT_RUNIF :
	case SeNT_RNORM :
	case SeNT_MOFN :
	case SeNT_PKD :
	/* 02-07-27 ch3: added support for ORCA node type */
	case SeNT_ORCA :
	case SeNT_EVAL :
		SePrtExpression( sysdefp->o.lhsp, level+1 );
		(void) ErLog( "%s ", SeSysTextRep( sysdefp ) );
		SePrtExpression( sysdefp->o.rhsp, level+1 );
		break;
	case SeNT_UNSET:
		ErPLog( "BUG: node type unset.\n" );
		(void) ErLog( "Node type unset\n" );
		break;
	default :
		ErPLog( "BUG: illegal node type (%s).\n",
			SeCvtToStr(sysdefp->type) );
		(void) ErLog( "Unknown node type %s\n",
				SeCvtToStr(sysdefp->type) );
		break;
		}
	}
#endif
/*
	void SeTxtExpression( SeSysDef *sysdefp, int level )

	Prints a system expression subtree to the standard error.
 */
/*ARGSUSED*/
char *
#if STD_C
SeTxtExpression( SeSysDef *sysdefp, int level )
#else
SeTxtExpression( sysdefp, level )
SeSysDef *sysdefp;
int level;
#endif
	{
		char *rt_txt=NULL;
		char buffer[SeBUFSIZE];
#ifdef USE_MMSTRAPPEND
		char *lt_txt=NULL;
#else
		struct bu_vls lt_txt;

		bu_vls_init(&lt_txt);
#endif

	if( sysdefp == NULL )
		return NULL;

	switch( sysdefp->type )
		{
	case SeNT_QUALSYS :
	case SeNT_SYSNAME :
		{	register const char *name;
		if( (name = NmName( sysdefp->c.index, &SeSystems )) == NULL )
			ErPLog( "BUG: bad system (%s) index (%d).\n",
				sysdefp->core.text, sysdefp->c.index );
		else
			{
			if( ! StrEq( sysdefp->core.text, name ) )
				ErPLog( "*** SeTxtExpression: %s: %s != %s\n",
					SeCvtToStr( sysdefp->type ),
					sysdefp->core.text, name );
			}
		return DmStrDup(name );
		}
	case SeNT_QUALIST:
	case SeNT_LISTNAME:
		{	register const char *name;
		if( (name = NmName( sysdefp->c.index, &SeLists )) == NULL )
			ErPLog( "BUG: bad system (%s) index (%d).\n",
				sysdefp->core.text, sysdefp->c.index );
		else
			{
			if( ! StrEq( sysdefp->core.text, name ) )
				ErPLog( "*** SeTxtExpression: %s: %s != %s\n",
					SeCvtToStr( sysdefp->type ),
					sysdefp->core.text, name );
			}
		return DmStrDup(name );
		}
	case SeNT_QUALCOMP :
	case SeNT_COMPNAME :
		{	register const char *name;
		if( (name = NmName( sysdefp->c.index, &SeComponents )) == NULL )
			ErPLog( "BUG: bad component index (%d).\n",
				sysdefp->c.index );
		else
			{
			if( ! StrEq( sysdefp->core.text, name ) )
				ErPLog( "*** SeTxtExpression: %s: %s != %s\n",
					SeCvtToStr( sysdefp->type ),
					sysdefp->core.text, name );
			}
		return DmStrDup(name );
		}
	case SeNT_CONSTANT :
		return DmStrDup(sysdefp->core.text );

	case SeNT_FNCALL :
		{	register const char *name;
				 struct bu_vls func_txt;
				 char *arg_txt=NULL;
				 char *ret_val;

		bu_vls_init(&func_txt);
		if( (name = NmName( sysdefp->f.index, &SeFunctions )) == NULL )
			ErPLog( "BUG: bad function definition index (%d).\n",
				sysdefp->f.index );
		else
			{	SeArgExp *np;
			bu_vls_strcat(&func_txt, name);
			bu_vls_strcat(&func_txt, "(");
			DqEACH( sysdefp->f.argexps, np, SeArgExp )
				{
				if(np != DqFirst(sysdefp->f.argexps, SeArgExp))
					{
					bu_vls_strcat(&func_txt, ",");
					}
				arg_txt = SeTxtExpression( np->expp, level+1 );
				bu_vls_strcat(&func_txt, arg_txt);
				DmFree((genptr_t)arg_txt);
				}
			bu_vls_strcat(&func_txt, ")");
			}

		ret_val = DmStrDup(bu_vls_addr(&func_txt));
		bu_vls_free(&func_txt);
		return ret_val;
		}
	case SeNT_PARAM :
		sprintf( buffer, "$%d", sysdefp->p.index );
		return DmStrDup(buffer );
	/* 06-30-00 ch3  added case to handle new multiple occurrence op */
	case SeNT_MULTOCC :
		bu_vls_strcat(&lt_txt, "MultOcc");
		/* FALL THRU */
	case SeNT_EXPR :
		{	char *ret_val;

		bu_vls_strcat(&lt_txt, SeTtbl[SeNT_LF_PAREN].ts);
		rt_txt = SeTxtExpression( sysdefp->o.rhsp, level+1 );
		bu_vls_strcat(&lt_txt, rt_txt);
		DmFree((genptr_t)rt_txt);
		bu_vls_strcat(&lt_txt, SeTtbl[SeNT_RT_PAREN].ts);

		ret_val = DmStrDup(bu_vls_addr(&lt_txt));
		bu_vls_free(&lt_txt);
		return ret_val;
		}

	case SeNT_NOT :
	case SeNT_ANOT :
	case SeNT_ABS :
	case SeNT_BOOL :
		{	char *ret_val;

		bu_vls_strcat(&lt_txt, SeSysTextRep(sysdefp));
		rt_txt = SeTxtExpression(sysdefp->o.rhsp, level+1);
		bu_vls_strcat(&lt_txt, rt_txt);
		DmFree((genptr_t)rt_txt);

		ret_val = DmStrDup(bu_vls_addr(&lt_txt));
		bu_vls_free(&lt_txt);
		return ret_val;
		}
	case SeNT_LIST :
	case SeNT_AND :
	case SeNT_XOR :
	case SeNT_OR :
	case SeNT_MIN :
	case SeNT_MAX :
	case SeNT_SUM :
	case SeNT_DIFF :
	case SeNT_PROD :
	case SeNT_QUOT :
	case SeNT_LT :
	case SeNT_GT :
	case SeNT_RUNIF :
	case SeNT_RNORM :
	case SeNT_MOFN :
	case SeNT_PKD :
	/* 02-07-27 ch3: added support for ORCA node type */
	case SeNT_ORCA :
	case SeNT_EVAL :
		{	char *ret_val;

		bu_vls_strcpy(&lt_txt, SeTxtExpression(sysdefp->o.lhsp, level+1));
		bu_vls_strcat(&lt_txt, SeSysTextRep(sysdefp));
		rt_txt = SeTxtExpression(sysdefp->o.rhsp, level+1);
		bu_vls_strcat(&lt_txt, rt_txt);
		DmFree((genptr_t)rt_txt);

		ret_val = DmStrDup(bu_vls_addr(&lt_txt));
		bu_vls_free(&lt_txt);
		return ret_val;
		}
	case SeNT_QUALOP :
		{	char *base;
			char *qual;
		base = SeTxtExpression( sysdefp->o.lhsp, level+1 );
		qual = SeTxtExpression( sysdefp->o.rhsp, level+1 );
		if ( sysdefp->o.lhsp->type == SeNT_COMPNAME )
			{
			sprintf( buffer, "%s%s", base, qual);
			}
		else
			{
			sprintf( buffer, "\"%s\"%s", base, qual);
			}
		DmFree((genptr_t)base );
		DmFree((genptr_t)qual );
		return DmStrDup(buffer );
		}
	case SeNT_CQUALIFIER:
		sprintf( buffer, "[%s]", sysdefp->core.text );
		return DmStrDup(buffer );
	case SeNT_UNSET:
		ErPLog( "BUG: node type unset.\n" );
		(void) ErLog( "Node type unset\n" );
		break;
	default :
		ErPLog( "BUG: illegal node type (%s).\n",
			SeCvtToStr(sysdefp->type) );
		(void) ErLog( "Unknown node type %s\n",
				SeCvtToStr(sysdefp->type) );
		break;
		}
	return NULL;
	}

STATIC void
#if STD_C
SePrtTypeConvErr( int compid, SeTypeID from, SeTypeID to )
#else
SePrtTypeConvErr( compid, from, to )
int compid;
SeTypeID from, to;
#endif
	{
	ErPLog( "Error in state vector file or system definition file.\n" );
	ErPLog( "%s \"%s\" from type \"%s\" to \"%s\".\n",
		"Can't convert value of component",
		NmName( compid, &SeComponents ),
		SeStrType( from ), SeStrType( to ) );
	}

/**
	void SeStClose( FILE *fp )

	Once the user has completed his calls to SeStCompile(), he
	should call SeStClose() to shut down the states file.  If more
	than one states file is to be accessed, this routine must be
	called before the second call to SeStOpen().
**/
void
#if STD_C
SeStClose( FILE *fp )
#else
SeStClose( fp )
FILE *fp;
#endif
	{
#if defined(VDEBUG) || SeDEBUG == 4
#if STD_C
	ErPLog( "SeStClose(%p)\n", (pointer) fp );
#else
	ErPLog( "SeStClose(0x%lx)\n", (long) fp );
#endif
#endif
	assert(fp != NULL);
	(void) fclose( fp );
	}

/**
	MuvesBool SeStFree( void )

        Once the user has completed his calls to SeStEval(), he should
        call SeSysClose() and SeStFree() to free up storage.  Also, if
        he hasn't already, the user should call SeStClose() to close
        the states file.  If more than one states file is to be accessed,
        SeStFree() must be called before a second call to SeStOpen().
        This routine returns mFalse if SeStOpen() has not previously
        been called.  SeStFree() need not be called if SeStCompile()
        has been not been used at least once, although it doesn't hurt.

        Frees up storage associated with compiled state vector definitions.

        RETURN: mTrue if successful

                mFalse and set an error index if SeStDef, the pointer
                to the whole mess, is NULL or the SeStates name pool
		is empty
**/
MuvesBool
#if STD_C
SeStFree( void )
#else
SeStFree()
#endif
	{
#if defined(VDEBUG) || SeDEBUG == 4
	ErPLog( "SeStFree()\n" );
#endif
	/* 06-02-20 ch3: reset values from environment variables (SCR747) */
	single_stream = mFalse;
	iterations = -1;

	if( SeStDef == NULL )
		{
		ErSet( SeSTFRENONSEQ );
		if( SeDebugging )
			ErPLog( "SeStFree: %s\n", ErString() );

		return  mFalse;
		}
	SeStStomp();
	NmClear( &SeStates );  /* free up state vector name pool storage */
	return mTrue;
	}

/*
	void SeStompDat( void )

	SeStompDat() deallocates storage for the SeDataSystem, SeFnDfn
	and SeQualp arrays and resets their allocation sizes to the minimum.
	Also frees the SeSysComps[] and SeStateComps[] arrays of
	component id queues.
 */
STATIC void
#if STD_C
SeStompDat( void )
#else
SeStompDat()
#endif
	{	register int i;	/* indexes SeDataSystem[]/SeFnDfn[] */
		register int nsys = NmSize( &SeSystems );
		register int nstates = NmCount( &SeStates );
#if SeDEBUG == 4
	ErPLog( "SeStompDat()\n" );
#endif
	assert(SeDataSystem != NULL);
	assert(SeFnDfn != NULL);
	assert(SeQualp != NULL);
	assert(SeNComps != 0);

	/* Free up SeKilled[] array. */
	if( SeKilled != NULL )
		{
		DmFree((genptr_t)SeKilled );
		SeKilled = NULL;
		}

	/* Free up SeDataSystem[] entries. */
	assert(SeSyDLen >= nsys);
	
#ifdef DEBUG
	for( i = SeSyDLen; --i >= 0; )
#else
	for( i = nsys; --i >= 0; )
#endif

	if( SeDataSystem[i] != NULL )
		{
		assert(i < nsys);
#if SeDEBUG == 2
		ErPLog( "SeStompDat: freeing system \"%s\" index %d\n",
			NmName( i, &SeSystems ), i );
#endif
		if( SeDataSystem[i]->sysdef != NULL )
			SeExpFree( SeDataSystem[i]->sysdef );
		if( SeDebugging )
			{
			SeDataSystem[i]->state = -1;	/* safety net */
			SeDataSystem[i]->save.value = -1.0;
			SeDataSystem[i]->save.type = SeTypeUnset;
			SeDataSystem[i]->sysdef = NULL;
			}
		DmFree((genptr_t)SeDataSystem[i] );
		if( SeDebugging )
			SeDataSystem[i] = NULL;		/* safety net */

		}
	DmFree((genptr_t)SeDataSystem );
	SeDataSystem = NULL;
	SeSyDLen = SeSyD_LEN;

	/* Free up SeListDfn[] entries. */
	assert(SeLiDLen >= NmCount( &SeLists ));

#ifdef DEBUG
	for( i = SeLiDLen; --i >= 0; )
#else
	for( i = NmCount( &SeLists ); --i >= 0; )
#endif

		if( SeListDfn[i] != NULL )
		{	SeLiMember *mp;
		assert(i < NmCount( &SeLists ));
#if SeDEBUG == 2
		ErPLog( "SeStompDat: freeing list \"%s\" index %d\n",
			NmName( i, &SeLists ), i );
#endif
		while( (mp = DqTPop(SeListDfn[i], SeLiMember)) != NULL )
			{	SeSysDef *sysdefp;
			sysdefp = (SeSysDef *)DmXalloc(SeSysDef);
			*sysdefp = mp->member;
			SeExpFree( sysdefp );
			DmFree((genptr_t)mp );
			}
		DqClose( SeListDfn[i] );
		if( SeDebugging )
			SeListDfn[i] = NULL;		/* safety net */

		}
	DmFree((genptr_t)SeListDfn );
	SeListDfn = NULL;
	SeLiDLen = SeLiD_LEN;

	/* Free up SeFnDfn[] entries. */
	assert(SeFnDLen >= NmCount( &SeFunctions ));
#ifdef DEBUG
	for( i = SeFnDLen; --i >= 0; )
#else
	for( i = NmCount( &SeFunctions ); --i >= 0; )
#endif
		if( SeFnDfn[i] != NULL )
			{
			assert(i < NmCount( &SeFunctions ));
#if SeDEBUG == 2
			ErPLog( "SeStompDat: %s \"%s\" index %d\n",
				"freeing function definition",
				NmName( i, &SeFunctions ), i );
#endif
			if( SeFnDfn[i]->funcdefp != NULL )
				SeExpFree( SeFnDfn[i]->funcdefp );
#ifdef DEBUG
			SeFnDfn[i]->funcdefp = NULL;
#endif
			DmFree((genptr_t)SeFnDfn[i] );
#ifdef DEBUG
			SeFnDfn[i] = NULL;		/* safety net */
#endif
			}
	DmFree((genptr_t)SeFnDfn );
	SeFnDfn = NULL;
	SeFnDLen = SeFnD_LEN;

	/* Free up SeQualp[] entries. */
	/* 01-04-17 ch3: moved code to SeStompSeQualp() and added call to it */
	SeStompSeQualp();

	/* Free up SeSysComps[] entries. */
	if( SeSysComps != NULL )
	    {
	    for( i = nsys; --i >= 0; )
		if( SeSysComps[i] != NULL )
			{	register SeQalNode *np;
#if SeDEBUG == 2
			ErPLog( "SeStompDat: %s \"%s\" index %d\n",
				"freeing system components list",
				NmName( i, &SeSystems ), i );
#endif
			while( (np = DqTPop( SeSysComps[i], SeQalNode )) != NULL )
				{
#if SeDEBUG == 2
				ErPLog( "%s 0x%x: index=%d lft=0x%x rgt=0x%x\n",
					"SeStompDat: freeing node",
					np, np->index,
					np->link.left, np->link.right );
#endif
#ifdef DEBUG
				np->index = -1;		/* safety net */
				np->link.left = np->link.right = NULL;
#endif
				DmFree((genptr_t)np );
				}
			DqClose( SeSysComps[i] );
#ifdef DEBUG
			SeSysComps[i] = NULL;		/* safety net */
#endif
			}
	    DmFree((genptr_t)SeSysComps );
	    SeSysComps = NULL;
	    }

	/* Free up SeStateComps[] entries. */
	if( SeStateComps != NULL )
	    {
	    for( i = nstates; --i >= 0; )
		if( SeStateComps[i] != NULL )
			{	register SeQalNode *np;
#if SeDEBUG == 2
			ErPLog( "SeStompDat: %s \"%s\" index %d\n",
				"freeing state components list",
				NmName( i, &SeSystems ), i );
#endif
			while( (np = DqTPop( SeStateComps[i], SeQalNode )) != NULL )
				{
#if SeDEBUG == 2
				ErPLog( "%s 0x%x: index=%d lft=0x%x rgt=0x%x\n",
					"SeStompDat: freeing node",
					np, np->index,
					np->link.left, np->link.right );
#endif
#ifdef DEBUG
				np->index = -1;		/* safety net */
				np->link.left = np->link.right = NULL;
#endif
				DmFree((genptr_t)np );
				}
			DqClose( SeStateComps[i] );
#ifdef DEBUG
			SeStateComps[i] = NULL;		/* safety net */
#endif
			}
	    DmFree((genptr_t)SeStateComps );
	    SeStateComps = NULL;
	    }
	}

/*
	void SeStompSeQualp( void )

	SeStompSeQualp() deallocates storage for the SeQualp arrays
	and resets its allocation sizes to the minimum.
	
	01-04-17 ch3: created this function from parts of SeStompDat() so
		      that only SeQualp[] can be de-allocated from SeTcl.c
 */
void
#if STD_C
SeStompSeQualp( void )
#else
SeStompSeQualp()
#endif
	{	register int i;	/* indexes SeQualp[] */

	for( i = SeNComps; --i >= 0; )
		if( SeQualp[i] != NULL )
			{	register SeQalNode *np;
#if SeDEBUG == 2
			ErPLog( "SeStompDat: %s \"%s\" index %d\n",
				"freeing qualified component list",
				NmName( i, &SeComponents ), i );
#endif
			while( (np = DqTPop( SeQualp[i], SeQalNode )) != NULL )
				{
#if SeDEBUG == 2
				ErPLog( "%s 0x%x: index=%d lft=0x%x rgt=0x%x\n",
					"SeStompDat: freeing node",
					np, np->index,
					np->link.left, np->link.right );
#endif
#ifdef DEBUG
				np->index = -1;		/* safety net */
				np->link.left = np->link.right = NULL;
#endif
				DmFree((genptr_t)np );
				}
			DqClose( SeQualp[i] );
#ifdef DEBUG
			SeQualp[i] = NULL;		/* safety net */
#endif
			}
	DmFree((genptr_t)SeQualp );
	SeQualp = NULL;
	}

/**
	FILE *SeStOpen( const char *states_file )

	SeStOpen() opens and initializes the parser for the designated
	"states" file.  A stream pointer is returned, or a null pointer
	if an error is detected.
**/
FILE *
#if STD_C
SeStOpen( const char *states_file )
#else
SeStOpen( states_file )
const char *states_file;
#endif
	{	FILE *fp;
/*	assert(states_file != NULL);
	assert(*states_file != 0);
*/
	if( states_file == NULL )
		states_file = "/dev/null";	/* special hack */
#if defined(VDEBUG) || SeDEBUG
	ErPLog( "SeStOpen(%s)\n", states_file );
#endif
	if( (fp = IoOpenFile( "r", SeSTNOFILE, states_file, (char *) NULL ))
		== NULL )
		{
		ErPLog( "Couldn't open states file \"%s\":\n\t%s\n",
			states_file, ErString() );
		return NULL;
		}
	/* 11-05-05 ch3: removed Se1stLine(), done by SeStCompile() (VSL) */

	/* Guard against calling twice without cleaning up. */
	if( NmCount( &SeStates ) > 0 )
		{
		assert(SeStDef != NULL);
		SeStStomp();	/* free up old SeStDef[] entries */
		NmClear( &SeStates );	/* free up name pool storage */
		ErSet( SeSTOPENONSEQ );
		goto report_err;
		}
	/* If SeStOpen() was called previously, but not SeStCompile() or
	   SeStFree(), SeStDef should be ready to go, otherwise we need to
	   allocate storage and initialize it. */
	if( SeStDef == NULL )
		{	register int i;
		/* Allocate storage for array of state vector definitions. */
		assert(SeStDLen == SeStD_LEN);
			/* always reset when deallocated */
		SeStDef = (SeStDat * *)DmCalloc(SeStDLen, sizeof(SeStDat * ));
		/* Initialize invalid pointers (all pointers, at this point)
			to NULL. */
		for( i = SeStDLen; --i >= 0; )
			SeStDef[i] = NULL;
		}
	return fp;
report_err:
	(void) fclose( fp );
	ErPLog( "%s \"%s\":\n\t%s\n",
		"Error while processing state vector definition file",
		states_file, ErString() );
	assert(ErIsSet());
	return	NULL;		/* failure */
	}

/**
	double *SeStEval( const char *statename, const SeValue *valp,
			SeTypeID *typep, int *lengthp )

	SeStEval() will return an array of doubles representing the
	evaluated metrics as defined for the named state vector.  The
	variable type of the vector (see SeTypeID enumeration for a
	list of types) and the length of the vector will be
	implicitly returned in typep and lengthp respectively, which
	must point to valid storage locations provided by the caller.
	The pointer returned by SeStEval() is valid until the next call
	to either SeSysReset() or SeStFree().

	A call to SeStEval() must be preceded by a call to SeStCompile()
	for the named state vector; SeStCompile() in turn has prereq-
	uisites.

	SeStEval() sets the error index and returns NULL if an error
	is detected.
**/
double *
#if STD_C
SeStEval( const char *statename, const SeValue *valp, SeTypeID *typep,
	  int *lengthp )
#else
SeStEval( statename, valp, typep, lengthp )
const char *statename;
const SeValue *valp;
SeTypeID *typep;
int *lengthp;
#endif
	{	int index;
		register SeStDat *defp;
		register double *vp;
		register SeSysDef **defs;
	assert(statename != NULL);
	assert(statename[0] != '\0');
#if SeDEBUG
	ErPLog( "SeStEval(%s)\n", statename );
#endif
	assert(valp != NULL);
	assert(typep != NULL);
	assert(lengthp != NULL );
	assert(NmCount(&SeStates) > 0);

	if( ErIsSet() )
		{
		ErPrint();		
		return NULL;
		}

	if( (index = NmIndex( statename, &SeStates, mFalse )) == -1 )
		{
#ifdef DEBUG
		ErPLog( "BUG: SeStEval(%s): undefined state vector.\n",
			statename );
#endif
		ErSet( SeSTUNDEF );
		return NULL;
		}
	defp = SeStDef[index];
	assert(defp != NULL);
	assert(defp->defs != NULL);
	assert(defp->length > 0);
	assert(defp->type > SeTypeUnset && defp->type < SeTypeSentinel);

	if( ! SeExpandLists() )
		{
		assert(ErIsSet());
		return NULL;
		}
	*typep = defp->type;	  /* return type of state vector */
	*lengthp = defp->length;  /* return length */

	if( defp->values != NULL ) /* State vector already evaluated. */
		{
		assert(!ErIsSet());
		return defp->values;
		}

	/* 06-02-20 ch3: allocate space to hold results of evaluation (SCR747)*/
	defp->values = (double *)DmMalloc(defp->length * sizeof(double ));

	if (defp->type == SeTypePKIterate)
	{
		if (!SeIterateVector(statename, defp, valp))
		{
			return NULL;
		}
	}
	else
	{
	vp = defp->values;
	for( defs = defp->defs; *defs != NULL; defs++  )
		{
		*vp = SeEvlExpression( *defs, valp, (const double *)NULL,
					defp->type, (const char *) NULL );
		if( ErIsSet() )
			{
			ErPLog( "Error in state vector (%s).\n",
					statename );
			ErPLog( "%s (%s).\n",
				"Error evaluating system",
				SeCvtToStr((*defs)->type));
			return NULL;
			}
		vp++;
		assert(defs - defp->defs < defp->length);
		}
	}

	assert(!ErIsSet());
	return defp->values;
	}

/* 06-02-20 ch3: added new function to evaluate entire state vector with same
 *               set of randomly drawn component kill values (SCR747) */
static MuvesBool
SeIterateVector PARAMS((const char *statename, SeStDat *defp,
	const SeValue *valp))
{
	ApT_EnvVar *envp;		/* environment variable */
	short *SaveKilled;		/* save SeKilled array pointer */
	int *SaveState = NULL;		/* save system states array */
	SeValue *SaveValue = NULL;	/* save system values array */
	int nsys;			/* number of systems */
	double *vp;			/* vector array pointer */
	SeSysDef **defs;		/* systen definition pointer */
	int iter;			/* iteration loop index variable */
	int i;				/* loop index variable */
 	int ncomps;			/* number of components */
	int j;				/* loop index variable */
	int *nkills;			/* number of kills counter */

	/* evaluate all systems, checking which ones evaluate to zero */
	i = 0;
	for (defs = defp->defs, vp = defp->values; *defs != NULL; defs++, vp++)
	{
		assert(defs - defp->defs < defp->length);
		if ((*vp = SeEvlExpression(*defs, valp, NULL, SeTypePK, NULL))
			== 0)
		{
			i++;
		}
	}
	if (i == defp->length)
	{
		/* all states are zero, nothing to iterate */
		return mTrue;
	}

	if (iterations == -1)
	{
		envp = ApGetEnvVar("Se_Iterations");
		if (envp == NULL || envp->val <= 0)
		{
			 /* Error messages if Se_Iterate not properly set */

			if (envp == NULL)
			{
				ErPLog("Se package: pkiterate: Environmental "
					"variable 'Se_Iterations' not "
					"defined, doing default 12500 "
					"iterations\n");
			}
			else if (envp->val <= 0)
			{
				ErPLog("Se package: pkiterate: Value of %d "
					"for 'Se_Iterations' is invalid "
					"(must be >0), doing default 12500 "
					"iterations\n",(long)envp->val);
			}
			iterations = 12500;
		}
		else
		{
			iterations = (int)envp->val;
		}
	}

	nsys = NmSize(&SeSystems);

	SaveKilled = SeKilled;
	if (SeDataSystem != NULL)
	{
		/* save SeDataSystem info */
		SaveValue = (SeValue *)DmMalloc(nsys * sizeof(SeValue));
		SaveState = (int *)DmMalloc(nsys * sizeof(int));
		for (i = nsys; --i >= 0;)
		{
			if (SeDataSystem[i] != NULL)
			{
				/* Saving data */
				SaveState[i] = SeDataSystem[i]->state;
				SaveValue[i].type = SeDataSystem[i]->save.type;
				SaveValue[i].value
					= SeDataSystem[i]->save.value;
			}
		}
	}

 	/* iterate system definitions */         
 	ncomps = NmCount(&SeComponents);
	nkills = (int *)DmCalloc(defp->length, sizeof(int));
	iterating = mTrue;
	SeKilled = NULL;  /* reset to force reallocation */
	for (iter = iterations; --iter >= 0;)
	{
		/* resets system data for this iteration */
		for (i = nsys; --i >= 0;)
		{
			if (SeDataSystem[i] != NULL)
			{
				SeDataSystem[i]->state = SeINVALID;	
			}
		}

		for (defs = defp->defs, i = 0; *defs != NULL; defs++, i++)
		{
			/* evaluate system if not zero */
			if (defp->values[i] != 0)
			{
				/* evaluate expression as killed, tally if 1 */
				if ((SeEvlExpression(*defs, valp, NULL,
					SeTypeKilled, NULL)) == 1)
				{
					nkills[i]++;
				}
				if (ErIsSet())
				{
					ErPLog("Error in state vector (%s).\n",
						statename);
					ErPLog("%s (%s).\n",
						"Error evaluating system",
						SeCvtToStr((*defs)->type));
					return mFalse;
				}
			}
		} 
 		/* reset the SeKilled array */
		if (SeKilled != NULL)
		{
			for (j = ncomps; --j >= 0;)
			{
				SeKilled[j] = -1;
			}
		}
	}
	/* calculate pks based on number of kills and iterations */
	for (defs = defp->defs, i = 0; *defs != NULL; defs++, i++)
	{
		if (defp->values[i] != 0)
		{
			defp->values[i] = (double)nkills[i]
				/ (double)iterations;
		}
	}
	iterating = mFalse;
	if (SeKilled != NULL)
	{
		DmFree((genptr_t)SeKilled);
	}
	DmFree((genptr_t)nkills);

	/* restore SeDataSystem to original values */
	if (SeDataSystem != NULL)
	{	
		for (i = nsys; --i >= 0;)
		{
			if (SeDataSystem[i] != NULL)
			{
				SeDataSystem[i]->state = SaveState[i];
				SeDataSystem[i]->save.type = SaveValue[i].type;
				SeDataSystem[i]->save.value
					= SaveValue[i].value;
			}
		}
		DmFree((genptr_t)SaveState);
		DmFree((genptr_t)SaveValue);
	}
	/* reset SeKilled to old values */
	SeKilled = SaveKilled;
	return mTrue;
}


 /*
 	double SeIterate( long iterations, SeSysDef *sysdefp, const SeValue *valp,
 			    const double *argp, const char *qualifier )
 
 	This routine calls SeEvlExpression on the parameters n times,
 	where n is the long integer specified in the arguements,
 	with type Killed and calculates the pk as a percentage of those
 	results.

  */
  

/* 06-02-20 ch3: optimized this function (SCR747) */
double
#if STD_C 
SeIterate(long iterations, SeSysDef *sysdefp, const SeValue *valp,
	const double *argp, const char *qualifier)
#else
SeIterate(sysdefp, valp, argp, qualifier)
long iterations;
SeSysDef *sysdefp;
const SeValue *valp;	/* array of typed component values*/
const double *argp;
const char *qualifier;
#endif
{
	int nsystems;		/* number of systems */
	short *save_killed;	/* save SeKilled information */
	SeValue *save_value = NULL;  /* save SeDataSystem state information */
	int *save_state = NULL;	/* save SeDataSystem value information */
	int i;			/* loop index variable */
	int j;			/* loop index variable */
 	int nkills;		/* counts number of "kills" */
 	int ncomps;		/* number of components */
 
 /*This code may start a check for multiple occurances
 	short *occur;
 	occur = (short *)DmCalloc(ncomps, sizeof(short));
 	if (!SeMultOccTest(sysdefp, occur, qualifier, 0, mFalse))
 	{ printf("NO MULT OCC");
 		return SeEvlExpression(sysdefp, valp, argp, SeTypePK,
			qualifier);
 	}
  */
 	/* if pk is 0 it is not ncessary to iterate */
 	if (SeEvlExpression(sysdefp, valp, argp, SeTypePK, qualifier) == 0)
	{
 		return 0.0;
	}
 
	/* save SeDataSystem info */
 	nsystems = NmSize(&SeSystems);
	if (SeDataSystem != NULL)
 	{
 		save_value = (SeValue *)DmMalloc(nsystems * sizeof(SeValue));
 		save_state = (int *)DmMalloc(nsystems * sizeof(int));
 		for (j = nsystems; --j >= 0;)
 		{
 			if (SeDataSystem[j] != NULL)
			{
 				/* save data */
 				save_state[j] = SeDataSystem[j]->state;
 				save_value[j].value
					= SeDataSystem[j]->save.value;
 				save_value[j].type = SeDataSystem[j]->save.type;
 			}
 		}
 	}

 	/* iterate system definitions */         
 	save_killed = SeKilled;
	SeKilled = NULL;
	iterating = mTrue;  
 	nkills = 0;
 	ncomps = NmCount(&SeComponents);
 	for (i = iterations; --i >= 0;)
 	{
 		/* reset system data to allow new run */
 		for (j = nsystems; --j >= 0;)
 		{
 			if (SeDataSystem[j] != NULL)
			{
 				SeDataSystem[j]->state = SeINVALID;	
			}
		}

 		/* evaluate system expression as killed and tally it if 1 */
		if ((SeEvlExpression(sysdefp, valp, argp, SeTypeKilled,
			qualifier)) == 1)
		{
 			nkills++;
		}

 		/* reset the SeKilled array */
		if (SeKilled != NULL)
		{
			for (j = ncomps; --j >= 0;)
			{
				SeKilled[j] = -1;
			}
		}
	}
 	iterating = mFalse;
 	
 	/* restore SeDataSystem to original values */
	if (SeDataSystem != NULL)
 	{	
 		for (j = nsystems; --j >= 0;)
 		{
 			if (SeDataSystem[j] != NULL)
 			{
  				SeDataSystem[j]->save.value
					= save_value[j].value;
 				SeDataSystem[j]->save.type = save_value[j].type;
 				SeDataSystem[j]->state = save_state[j];
 			}
 		}
		DmFree((genptr_t)save_state);
 		DmFree((genptr_t)save_value);
 	}

	if (SeKilled != NULL)
	{
		DmFree((genptr_t)SeKilled);
	}
 	/* reset SeKilled to old values */
 	SeKilled = save_killed;
 
 	return (double)nkills / (double)iterations;
}




/**
	MuvesBool SeSysCritical( const char *sysname, char **iscriticalp )

	SeSysCritical() checks whether components are referenced
	either directly or indirectly by the named system.  Any
	referenced component is, by definition, considered critical.
	Iscriticalp must point to an array whose indices correspond to
	target components in the SeComponents name pool; the elements
	of this array will be set to mTrue if the corresponding component
	is referenced and otherwise will be left untouched.  Thus,
	initialization of the iscriticalp array is the responsibility of
	the calling routine. 

	A call to SeSysCritical() must be preceded by a call to SeSysOpen().

	RETURN: mTrue if successful

		mFalse with an error message if not
**/
MuvesBool
#if STD_C
SeSysCritical( const char *sysname, char **iscriticalp )
#else
SeSysCritical( sysname, iscriticalp )
const char *sysname;
char **iscriticalp;
#endif
	{	int index;
	assert(sysname != NULL);
	assert(sysname[0] != '\0');
#if SeDEBUG
	ErPLog( "SeSysCritical(%s,)\n", sysname );
#endif
	assert(iscriticalp != NULL);
	assert(NmSize(&SeSystems) > 0);
	/* Find the compiled definition of the system and call
	   SeCrtExpression. */
	if( (index = NmIndex( sysname, &SeSystems, mFalse )) != -1 )
		{	SeSysDef *sysdefp;
		assert(SeDataSystem != NULL);
		assert(SeDataSystem[index] != NULL);
		sysdefp = SeDataSystem[index]->sysdef;
		assert(sysdefp != NULL);
		if( ! SeCrtExpression( sysdefp, iscriticalp, (const char *)NULL ) )
			{
			assert(ErIsSet());
			return mFalse;
			}
		}
	else	/* Not a system */
		{
		ErPLog( "BUG: SeSysCritical: \"%s\" %st.\n",
			*sysname, "not a system" );
		return mFalse;
		}
	assert(index != -1);
	return mTrue;
	}

#ifndef COMPILE_FOR_VSL
/**
	char *SeIsCritical

	Global pointer to "iscritical" array built by SeStIsCritical().

	char *SeStIsCritical( void )

	SeStIsCritical() allocates an array to be indexed by SeComponents
	name pool index where each entry is a flag indicating whether the
	corresponding component or qualified component is "critical".
	Components or qualified components that are referenced directly or
	indirectly by the named state vector are considered critical.  It
	is the caller's responsibility to free the array.

	A call to SeStIsCritical() must be preceded by calls to SeStCompile()
	which in turn has prerequisites.

	RETURN: a pointer to a dynamically allocated array of length
	NmCount( &SeComponents ) if successful, otherwise return NULL
	and set an error index.
**/
char * 
#if STD_C
SeStIsCritical( void )
#else
SeStIsCritical()
#endif
	{	register int comp;
		register const ApStSpec *stspec;
		ApT_EnvVar *envp;

	if( SeCritSz > 0 )
		ErPLog( "BUG: %s: called twice without calling SeStFree\n",
			"SeStIsCritical" );

	/* Allocate initial size of array. */
	SeCritSz = NmCount( &SeComponents );
	assert( SeCritSz > 0 );
	SeIsCritical = (char *)DmCalloc(SeCritSz, sizeof(char ));

	/* Initialize all values. */
#if 0  /* DmCalloc() already initialized array */
	for( comp = SeCritSz; --comp >= 0; )
		SeIsCritical[comp] = mFalse;
#endif

	/* Loop through states and build/set SeIsCritical[] array. */
	for(	stspec = ApVector(ApRESET);
		stspec != NULL;
		stspec = ApVector(ApNEXT))
		{	int index;
			int olen;
			char *statename = stspec->name;
			register SeStDat *defp;
			register SeSysDef **defs;
		assert(statename != NULL);
		assert(statename[0] != '\0');
#if SeDEBUG
		ErPLog( "SeStIsCritical(%s)\n", statename );
#endif
		if( (index = NmIndex( statename, &SeStates, mFalse )) == -1 )
			{
#ifdef DEBUG
			ErPLog( "BUG: %s(%s): undefined state vector.\n",
				"SeStIsCritical", statename );
#endif
			ErSet( SeSTUNDEF );
			goto error_is_set;
			}
		defp = SeStDef[index];
		assert(defp != NULL);
		assert(defp->defs != NULL);
		assert(defp->length > 0);
		assert(defp->type > SeTypeUnset && defp->type < SeTypeSentinel);

		olen = defp->length;
		if( ! SeListExpand( defp ) )
			goto error_is_set;

		if( SeDebugging )
		   if( olen < defp->length )
			ErPLog( "%s \"%s\" grew due to list expansion.\n",
				"SeStIsCritical: vector", statename );

		for( defs = defp->defs; *defs != NULL; defs++ )
			{
#if SeDEBUG == 7
			ErPLog( "SeStIsCritical: printing expression %s\n",
				(*defs)->core.text );
			SePrtExpression( *defs, 0 );
#endif
			if( ! SeCrtExpression( *defs, &SeIsCritical, (const char *)NULL ) )
				goto error_is_set;
			assert(defs - defp->defs < defp->length);
			}
		}
	if( SeCritSz > NmCount( &SeComponents ) )
		{ /* SeIsCritical larger than necessary, so shrink wrap it. */
		SeCritSz = NmCount( &SeComponents );
		SeIsCritical = (char  *)DmRealloc(SeIsCritical, (SeCritSz)*sizeof(char ));
		}

	if ( (envp=ApGetEnvVar("RegionList")) != NULL) 
	  {
	    ErPLog ("RegionList switch is longer supported.\n");
	    /*
	     * SeGetSysList() will not work with the new Rt package.
	     *
	     * if( ! SeGetSysList())
	     *		goto error_is_set;
	     */
	  }
	return SeIsCritical;

error_is_set :
	assert( ErIsSet() );
	DmFree((genptr_t)SeIsCritical );
	return NULL;
	}
#endif

/*
	
	MuvesBool SeStBuildTextReps( SeStDat *defp )

	Allocate and fill in array of strings describing state vecter elements.
	Typically these will be names of systems, components, or qualified
	systems or components, but may also be expressions.
*/
STATIC MuvesBool
#if STD_C
SeStBuildTextReps( SeStDat *defp )
#else
SeStBuildTextReps( defp )
SeStDat *defp;
#endif
	{	SeSysDef **defs;
		char **textp;
	assert( defp->text == NULL );
	defp->text = (char **)DmCalloc(defp->length+1, sizeof(char *));
	for(	defs = defp->defs, textp = defp->text;
		*defs != NULL;
		defs++, textp++ )
		*textp = SeSysTextRep( *defs );
	*textp = NULL;
	return mTrue;
	}

/**
	const char **SeStQuery( const char *statename, SeTypeID *typep,
				int *lengthp)

	SeStQuery() returns a null-terminated array of pointers to the
	member names for the named state vector.  Also, the variable
	type of the vector (see SeTypeID enumeration) and the length of
	the vector will be implicitly returned in typep and lengthp
	respectively, which must point to valid storage locations
	provided by the caller.

	A call to SeStQuery() must be preceded by a call to SeStCompile()
	for the named state vector; SeStCompile() in turn has prerequisites.

	SeStQuery() sets the error index and returns NULL if an error is
	detected.
**/
const char **
#if STD_C
SeStQuery( const char *statename, SeTypeID *typep, int *lengthp )
#else
SeStQuery( statename, typep, lengthp )
const char *statename;
SeTypeID *typep;
int *lengthp;
#endif
	{	int index;
		register SeStDat *defp;
	assert(statename != NULL);
	assert(statename[0] != '\0');
	assert(typep != NULL);
	assert(lengthp != NULL);
#if SeDEBUG
	ErPLog( "SeStQuery(%s)\n", statename );
#endif
	assert(NmCount(&SeStates) > 0);
	if( (index = NmIndex( statename, &SeStates, mFalse )) == -1 )
		{
		if( SeDebugging )
			ErPLog( "BUG: SeStQuery(%s): undefined state vector.\n",
			statename );

		ErSet( SeSTUNDEF );
		return NULL;
		}
	defp = SeStDef[index];
	assert(defp != NULL);
	assert(defp->defs != NULL);
	assert(defp->length > 0);
	assert(defp->type > SeTypeUnset && defp->type < SeTypeSentinel);
	if( defp->defs == NULL )
		{ /* State vector not compiled yet. */
		ErSet( SeSTQRYNONSEQ );

		if( SeDebugging )	/* programmer's error, not user's */
			ErPLog( "SeStQuery: %s\n", ErString() );
		}
	if( defp->text == NULL )
		if( ! SeStBuildTextReps( defp ) )
			return NULL;

	*typep = defp->type;
	*lengthp = defp->length;
	return (const char **) defp->text;
	}

/**
	const char *SeStrType( SeTypeID type )

	Return string representation for one of the supported evaluated
	component/system damage types (see SeTypeID enumeration for a
	list of supported types).  SeStrType() is guaranteed to return a
	valid string; "BOGUS" is returned if an unknown type is specified
	and "unset" is returned if the value is initialized, but not set.
**/
const char *
#if STD_C
SeStrType( SeTypeID type )
#else
SeStrType( type )
SeTypeID type;
#endif
	{
	switch( type )
		{
	case SeTypeFRF :
		return "frf";
	case SeTypeHit :
		return "hit";
	case SeTypeKilled :
		return "killed";
	case SeTypeNotKilled :
		return "notkilled";
	case SeTypeLOF :
		return "lof";
	case SeTypePKChebyshev:
		return "pkchebyshev";
	case SeTypePKIterate:
		return "pkiterate";
	case SeTypePK :
		return "pk";
	case SeTypePS :
		return "ps";
	case SeTypeScalar :
		return "scalar";
	case SeTypeUnset :
		return "unset";
	default :
		if( SeDebugging )
			{
			ErPLog( "SeStrType: invalid type %d\n", type );
			assert( type == SeTypeUnset );
			}
		return "BOGUS";
		}
	/*NOTREACHED*/
	}

/*
	void SeStStomp( void )

	SeStStomp() deallocates storage for the SeStDef and SeIsCritical arrays
	and resets their allocation sizes to the minimum.
 */
STATIC void
#if STD_C
SeStStomp( void )
#else
SeStStomp()
#endif
	{	register int i;	/* indexes SeStDef[] */
#if SeDEBUG
	ErPLog( "SeStStomp()\n" );
#endif
	assert(SeStDef != NULL);
	if( *SeStDef == NULL || NmCount( &SeStates ) == 0 )
		return;

	/* Free up SeStDef[] entries. */
	assert(SeStDLen >= NmCount( &SeStates ));
	for( i = NmCount( &SeStates ); --i >= 0; )
		{ /* If definition failed to compile, pointer will be NULL. */
		if( SeStDef[i] == NULL )
			continue; /* nothing to do */
		assert(i < NmCount( &SeStates ));
#if SeDEBUG == 2
		ErPLog( "SeStStomp: %s \"%s\" index %d\n",
			"freeing state vector",
			NmName( i, &SeStates ), i );
#endif
		assert(SeStDef[i]->text != NULL);
		if( SeStDef[i]->text != NULL )
			{	register char **textp;
			for( textp = SeStDef[i]->text; *textp != NULL; textp++ )
				DmFree((genptr_t)*textp );
			DmFree((genptr_t)SeStDef[i]->text );
			}
		assert(SeStDef[i]->defs != NULL);
		if( SeStDef[i]->defs != NULL )
			{	register SeSysDef **defp;
			for( defp = SeStDef[i]->defs; *defp != NULL; defp++ )
				SeExpFree( *defp );
			DmFree((genptr_t)SeStDef[i]->defs );
			}

		if( SeStDef[i]->values != NULL )
			DmFree((genptr_t)SeStDef[i]->values);
		if( SeDebugging )
			{
			SeStDef[i]->type = SeTypeUnset;	/* safety net */
			SeStDef[i]->length = 0;
			SeStDef[i]->text = NULL;
			SeStDef[i]->values = NULL;
			SeStDef[i]->defs = NULL;
			}
		DmFree((genptr_t)SeStDef[i] );

		if( SeDebugging )
			SeStDef[i] = NULL;		/* safety net */
		}
	DmFree((genptr_t)SeStDef );
	SeStDef = NULL;
	SeStDLen = SeStD_LEN;

	if( SeCritSz > 0 )
		{
		DmFree((genptr_t)SeIsCritical );
		SeIsCritical = NULL;
		SeCritSz = 0;
		}
	assert( SeIsCritical == NULL );
	}

/**
	double SeSysEval( int sys_index, const SeValue *valp,
			  const double *argp, SeTypeID type,
			  const char *qualifer )

	SeSysEval() returns the value of the expression associated with
	the given index into the SeSystems systems name pool; this value
	typically represents system fractional remaining functionality,
	loss of function, or probability of system kill.  The address of
	an array of SeValue structs must also be furnished; these are
	taken as the component values.  Damage at the component level is
	expressed as a typed value using the SeValue structure.  Regardless
	of type, the value is stored as a float.

	typedef struct
		{
		float value;	// component damage value of specified type
		SeTypeID type;	// enumerated type of value
		}
	SeValue;

	The valp array indices correspond to indices into the SeComponents
	name pool.  A pointer to an array of argument values (argp) must be
	furnished if a function call is being evaluated; otherwise, argp
	can be a null pointer.

	The data types are enumerated as follows:

	typedef enum
		{			// Recognized types:
		SeTypeUnset = -1,
		SeTypeFRF,		// frf
		SeTypeLOF,		// lof
		SeTypeHit,		// hit
		SeTypeKilled,		// killed
		SeTypeNotKilled,	// not killed
		SeTypeScalar,		// scalar
		SeTypePK,		// pk
		SeTypePS,		// ps
		SeTypePKIterate         // pk evaluated iteratively with integer
		SeTypePKChebyshev       // pk evaluated iteratively within confidence bounds
		SeTypeSentinel
		}
	SeTypeID;

	If qualifier is non-NULL, it is applied to any components (at the
	leaf nodes of the expression) that are not already qualified.

	SeSysOpen() must have been called before this function in order
	to read the system and function definitions from the "sysdef"
	file.  In addition, SeGetQualList() must have been used by the
	builder of the valp array to determine the proper indices for
	qualified components.  Typically, SeSysEval() will not be used
	directly by other packages, but will be called by SeStEval().

	SeSysEval() returns -1.0 if an error is detected; note that this
	is a possible valid value, so ErIsSet() is necessary to verify
	that an error has occurred.
**/
double
#if STD_C
SeSysEval( int sys_index, const SeValue *valp, const double *argp,
	   SeTypeID type, const char *qualifier )
#else
SeSysEval( sys_index, valp, argp, type, qualifier )
int sys_index;
const SeValue *valp;
const double *argp;
SeTypeID type;
const char *qualifier;
#endif
	{	register SeSyDat *sdp;

	assert(valp != NULL);

	/* The reason the following aren't "assert"s is that we trust
	   other packages less than we trust the Se implementation. */
	if( sys_index < 0 || sys_index >= NmSize( &SeSystems ) )
		{	/* sys_index not in SeSystems name pool. */
		if( SeDebugging )
			ErPLog( "%s USAGE BUG: System # %d not in name pool.\n",
				"SeSysEval:", sys_index );

		ErSet( SeSTNOSYS );
		return	-1.0;
		}
#if defined(VDEBUG) || SeDEBUG
#if STD_C
	ErPLog( "SeSysEval([%s],%p,%p,%s,%s)\n",
		NmName( sys_index, &SeSystems ),
		(pointer) valp, (pointer) argp, SeStrType( type ),
		qualifier == NULL ? "(null)" : qualifier );
#else
	ErPLog( "SeSysEval([%s],0x%lx,0x%lx,%s,%s)\n",
		NmName( sys_index, &SeSystems ),
		(long) valp, (long) argp, SeStrType( type ),
		qualifier == NULL ? "(null)" : qualifier );
#endif
#endif
	if( SeDataSystem == NULL )
		{	/* No systems compiled yet. */
		ErSet( SeSYSEVLNONSEQ );

		if( SeDebugging )	/* programmer's error, not user's */
			ErPLog( "SeSysEval: %s\n", ErString() );
		return	-1.0;
		}
	if( (sdp = SeDataSystem[sys_index]) == NULL )
		{	/* Named system not compiled. */
		ErSet( SeSTCORRUPT );

		if( SeDebugging )	/* programmer's error, not user's */
			{
			ErPLog( "SeSysEval: No definition for system '%s'\n",
			NmName( sys_index, &SeSystems ) );
			}
		return	-1.0;
		}
	if( sdp->state == SeEVALUATING )
		{	/* Recursive definition of system. */
		/* The user better hear about this one. */
		ErPLog( "Recursive definition of system or list \"%s\".\n",
			NmName( sys_index, &SeSystems ) );
		ErPLog( "Recursion permitted with list definitions, but %s.\n",
			"lists must be defined before they are referenced" );
		ErSet( SeSYSRECURSIVE );
		return	-1.0;
		}
#ifdef COMPILE_FOR_VSL
/* 11-12-13 ch3: added locked system state (VSL) */
	if (sdp->state == SeLOCKED)
		{
		return (double) sdp->save.value;
		}
#endif
	if( sdp->state != SeVALID || sdp->save.type != type )
		{
		sdp->state = SeEVALUATING;
		double value = SeEvlExpression( sdp->sysdef, valp, argp,
						type, qualifier );
#ifdef COMPILE_FOR_VSL
		if (ErIsSet()) {
		    sdp->state = SeINVALID;
		    return -1;
		}
#endif
		sdp->save.value = value;
		sdp->save.type = type;
#ifdef COMPILE_FOR_VSL
		/* 11-05-12 ch3: register system evaluation (VSL) */
		extern void SeWrapperRegisterSystemValue(int index, void *ptr,
			SeTypeID type, double value);
		if (SeAppPtr != NULL)
			{
			SeWrapperRegisterSystemValue(sys_index, SeAppPtr,
				sdp->save.type, sdp->save.value);
			}
#endif
		}
	sdp->state = SeVALID;	/* even if SeEvlExpression() reports error */
	return (double) sdp->save.value;
	}

/**
	MuvesBool SeSysClose( void )

	Once the user has completed his calls to SeStEval(), he should
	call SeSysClose() (and SeStClose()) to free up storage.  If more
	than one "sysdef" file is to be accessed, SeSysClose() must be
	called before a second call to SeSysOpen().  This routine
	returns mFalse if SeSysOpen() has not previously been called.

	Frees storage of system definitions (SeDataSystem) and the
	system name pool (SeSystems).

	RETURN:	mTrue for success mFalse and set error index if SeSystems name pool is empty,
	corrupted or uninitialized, or if SeDataSystem has not been
	allocated

	Once the user has completed his calls to SeStEval(), he should
        call SeSysClose() and SeStFree() to free up storage.   Also, if
        he hasn't already, the user should call SeStClose() to close
        the "states" file.  If more than one "sysdef" or "states" file
        is to be accessed, the appropriate close/free routine must be
        called before a second call to the corresponding open routine.

        This routine returns mFalse if the appropriate open routine has
        not previously been called; e.g., SeSysOpen() must precede
        SeSysClose().  SeStFree() need not be called if SeStCompile()
        has been not been used at least once, although it doesn't hurt.
**/
MuvesBool
#if STD_C
SeSysClose( void )
#else
SeSysClose()
#endif
	{
#if defined(VDEBUG) || SeDEBUG
	ErPLog( "SeSysClose()\n" );
#endif
	/* Allocation of SeDataSystem indicates that SeSysOpen()
	   was successfully called first, and conversely. */
	assert(SeDataSystem!=NULL);
	if( SeDataSystem == NULL )
		{
		ErSet( SeSYSCLONONSEQ );

		if( SeDebugging )	/* programmer's error, not user's */
			ErPLog( "SeSysClose: %s\n", ErString() );
		return	mFalse;
		}
	assert(NmSize( &SeSystems ) >= 0);
	/* Free up SeDataSystem, SeQualp, SeListDfn and SeFnDfn storage: */
	SeStompDat();

	SeNComps = 0; /* reset saved length of RtComponents name pool */
	NmClear( &SeSystems );	  /* free up system name pool storage */
	NmClear( &SeComponents ); /* free up component name pool storage */
	NmClear( &SeFunctions );  /* free up function name pool storage */
	NmClear( &SeQualifiers ); /* free up system qualifiers n. p. storage */
	NmClear( &SeLists );	  /* free up list name pool storage */
	return mTrue;
	}


/*
	initializes and allocates sysdef variables
	loads library sysdef file
	loads env vars as constants
	opens user sysdef file if specified (no action if NULL)

	assumes RtComponents loaded with component names
*/
SeParseVars *
SeSysInit(const char *libstr, MuvesBool interactive_mode, void *ptr)
{
	ApT_EnvVar *envp;	/* environment variable ptr */
	char *filnam;		/* pointer to sysdef file name */
	MuvesBool success;	/* parse and compile success status */

	/* allocation parse variable structure */
	SeParseVars *vars = (SeParseVars *)DmCalloc(1, sizeof(SeParseVars));

	/* initialize token stack and argument list name pool */
	vars->SeStackp = DqOpen();
	NmInit(&vars->argnames);

	/* set flag if single stream environment variable is present */
	single_stream = ApGetEnvVar("SingleStream") != NULL;

	/* Guard against calling twice without cleaning up. */
	if (SeDataSystem != NULL || SeFnDfn != NULL || SeQualp != NULL)
	{
		SeStompDat();	/* free up old SeDataSystem[] entries */
		ErSet(SeSYSOPENONSEQ);
		vars->error = SeFail2;
		return vars;
	}
	if (NmSize(&SeSystems) > 0)
	{
		NmClear(&SeSystems);	/* free up name pool storage */
		ErSet(SeSYSOPENONSEQ);
		vars->error = SeFail2;
		return vars;
	}
	if (NmCount(&SeComponents) > 0)
	{
		NmClear(&SeComponents); /* free up name pool storage */
		ErSet(SeSYSOPENONSEQ);
		vars->error = SeFail2;
		return vars;
	}
	if (NmCount(&SeQualifiers) > 0)
	{
		NmClear(&SeQualifiers); /* free up name pool storage */
		ErSet(SeSYSOPENONSEQ);
		vars->error = SeFail2;
		return vars;
	}
	if (NmCount(&SeLists) > 0)
	{
		NmClear(&SeLists);	/* free up name pool storage */
		ErSet(SeSYSOPENONSEQ);
		vars->error = SeFail2;
		return vars;
	}

	/* allocate storage for array of list definitions */
	assert(SeLiDLen == SeLiD_LEN);	/* always reset when deallocated */
	SeListDfn = (SeLiDat **)DmCalloc(SeLiDLen, sizeof(SeLiDat *));

	/* allocate storage for array of system definitions */
	assert(SeSyDLen == SeSyD_LEN);	/* always reset when deallocated */
	SeDataSystem = (SeSyDat **)DmCalloc(SeSyDLen, sizeof(SeSyDat *));

	/* allocate storage for array of function definitions */
	assert(SeFnDLen == SeFnD_LEN);	/* always reset when deallocated */
	SeFnDfn = (SeFnDat **)DmCalloc(SeFnDLen, sizeof(SeFnDat *));

	/* only initialize and copy components for non-interactive mode (VSL) */
	/* (this is delayed for VSL for components to be loaded separately) */
	if (!interactive_mode && !SeInitComps(vars))
	{
		return vars;
	}

	/* parse and compile systems or function definitions into
	 * expression trees */
	vars->SeResName = mTrue;  /* MUVES must define only reserved names */

	/* install built-in functions */
	SeBuiltIn();

	/* read library sysdef file */
	if (!SeTesting)
	{
		/* 11-05-04 ch3: corrected sysdef path with libstr arg (VSL) */
		if (libstr == NULL)
		{
			libstr = "/lib/";
			int len = strlen(IoMUVES()) + strlen(libstr)
				+ strlen(SeSTDDEF) + 1;
			filnam = DmMalloc(len);
			strcat(strcpy(filnam, IoMUVES()), libstr);
		}
		else
		{
			int len = strlen(libstr) + strlen(SeSTDDEF) + 1;
			filnam = DmMalloc(len);
			strcpy(filnam, libstr);
		}
		strcat(filnam, SeSTDDEF);
	}
	else  /* special testing mode for SeTest */
	{
		int len = strlen(SeSTDDEF) + 1;
		filnam = DmMalloc(len);
		strcpy(filnam, SeSTDDEF);
	}

	success = SeSysReadFile(vars, filnam);
	/* non fatal if error returned */
	if (vars->error == SeFail3)
	{
		/* not fatal if error opening file */
		vars->error = SeNoFail;
	}
	else  /* release file pointer and close queue used for token stack */
	{
		assert(DqIsEmpty(SeStackp));	/* all nodes should be free */

		if (!success)
		{
			assert(ErIsSet());
			ErPLog("%s library definition file \"%s\":\n\t%s\n",
				"Error while processing", SeSTDDEF, ErString());
			/* not fatal */
			ErClear();
		}
	}
	DmFree(filnam);

	/* Insert environment variables into compiled expression tree. */
	for (envp = ApEnvVars(ApRESET); envp != NULL; envp = ApEnvVars(ApNEXT))
	{
		int si;

		/* insert variable into the SeSystems name pool (extend the
		 * SeDataSystem array, if necessary, to accommodate it) */
		if ((si = SeSysInsert(envp->name)) < 0)
		{
			assert(si == -1);
			vars->error = SeFail2;
			return vars;
		}
		assert(si < SeSyDLen);

		/* allocate SeSysDef node for this system */
		if (SeDataSystem[si] != NULL)
		{
			ErPLog("Environment variable \"%s\" is multiply defined"
				"\n", envp->name);
			vars->error = SeFail2;
			return vars;
		}
		SeDataSystem[si] = (SeSyDat *)DmXalloc(SeSyDat);

		SeDataSystem[si]->state = SeINVALID;
		SeDataSystem[si]->sysdef = (SeSysDef *)DmXalloc(SeSysDef);
		SeDataSystem[si]->sysdef->type = SeNT_CONSTANT;
		SeDataSystem[si]->sysdef->core.text = DmStrDup(envp->name);
		SeDataSystem[si]->sysdef->n.index = si;
		SeDataSystem[si]->sysdef->n.value = envp->val;
	}
#if SeDEBUG
	SePrtKnownSystems( "Environment Variables included" );
#endif

	vars->SeResName = mFalse; /* users must define only nonreserved names */

	/* 08-07-22 ch3: save start index of user sysdefs (SCR813) */
	/* 11-04-14 ch3: moved to before open file (VSL) */
	SeSyDStart = NmCount(&SeSystems);

	/* 12-04-02 ch3: save start index of user functions (VSL) */
	SeFnDStart = NmCount(&SeFunctions);

	/* 11-04-21 ch3: set allow sysdef duplicates (VSL) */
	vars->interactive = interactive_mode;

	/* 11-04-26 ch3: allocate error message buffer if selected (VSL) */
	if (interactive_mode)
	{
		vars->errmsg = DmMalloc(SeBUFSIZE);
	}

	/* 11-05-13 ch3: store in global pointer for SeSysEval() (VSL) */
	SeAppPtr = vars->appPtr = ptr;
	return vars;
}


// function to copy RtComponents to SeComponents name pool
MuvesBool SeInitComps(SeParseVars *vars)
{
	/* copy all critical components to SeComponents name pool */
	assert(NmCount(&RtComponents) > 0);
	if (!vars->find_comps)
	{
		if (NmCount(&RtComponents) <= 0)
		{
			ErPLog("No components found in RtComponents name pool.\n");
			vars->error = SeFail2;
			return mFalse;
		}
		/* for VSL, SeComponents only contain qualified components */
		if (!NmDup(&RtComponents, &SeComponents))
		{
			ErPLog("Couldn't copy RtComponents name pool to "
				"SeComponents.\n");
			vars->error = SeFail2;
			return mFalse;
		}
		/* allocate storage for array of qualified component lists */
		assert(NmCount(&RtComponents) == NmCount(&SeComponents));
	}

	/* save count of components for Se use only */
	/* RtComponents may be out of sync at cleanup time */
	SeNComps = NmCount(&RtComponents);
	SeQualp = (DqNode **)DmCalloc(SeNComps, sizeof(DqNode *));
	return mTrue;
}


/*
	initializes and allocates sysdef variables
	loads library sysdef file
	loads env vars as constants
	opens user sysdef file if specified (no action if NULL)

	assumes RtComponents loaded with component names
*/

/* 11-04-27 ch3: implemented new function (VSL) */
void
SeSysTerm(SeParseVars *vars)
{
	if (vars->SeStackp != NULL)
	{
		DqClose(vars->SeStackp);
		vars->SeStackp = NULL;
	}
	if (vars->errmsg != NULL)
	{
		DmFree(vars->errmsg);
		vars->errmsg = NULL;
	}
	SeSysClose();  /* 11-05-04 ch3: cleanup other variables (VSL) */
	DmFree(vars);
}


/*
   	opens file
	reads sysdefs from file until end

	returns bs_good is successful, bs_ugly if error
*/
MuvesBool
SeSysReadFile(SeParseVars *vars, const char *sysdef_file)
{
	MuvesBool success;

	if ((vars->fp = IoOpenFile("r", SeSYSNOFILE, sysdef_file,
		(char *)NULL)) == NULL)
	{
		const char *open_error = "Couldn't open system definition file "
			"\"%s\":\n\t%s\n";
		if (vars->errmsg != NULL)
		{
			sprintf(vars->errmsg, open_error, sysdef_file,
				ErString());
		}
		else
		{
			ErPLog(open_error, sysdef_file, ErString());
		}
		vars->error = SeFail3;
		return mFalse;
	}
	Se1stLine(vars);	/* initialize for parser diagnostics */

	/* continues until no more sysdefs or an error occurs */
	success = SeSysAdd(vars, NULL);
#if SeDEBUG == 2
		SePrtKnownSystems( "Incremental User Systems" );
#endif
	fclose(vars->fp);
	vars->fp = NULL;

	return success;
}


/*
   	parses and if no error, compiles one system

	assumes SeSysInit() has been called first

	returns bs_good if successfully parsed and compiled
		bs_bad if end of file reached (file mode only)
		bs_ugly if an error occurred
*/
MuvesBool
SeSysAdd(SeParseVars *vars, const char *sysdef_str)
{
	bs_type success;
	
	if (sysdef_str == NULL)
	{
		if (vars->fp == NULL)
		{
			return bs_ugly;
		}
		if (vars->allow_comps)
		{
			/* look for #COMP: at begin of file */
			vars->find_comps = mTrue;
		}
		/* look for #TABLE: in file */
		vars->allow_table = mTrue;
		if (vars->etable != NULL)
		{
			vars->etable[0] = '\0';  /* clear table file name */
		}
	}
	else  // one line system add from VSL
	{
		if (vars->fp != NULL)
		{
			return bs_ugly;
		}
		vars->str = (char *)sysdef_str;
		vars->len = strlen(sysdef_str);
		Se1stLine(vars);	/* initialize for parser diagnostics */
	}

	while ((success = SeDefGet(vars)) == bs_good)
	{
		int index;

		if ((index = SeDefCompile(vars, SeOptimizeNoSystem)) >= 0)
		{
#ifdef COMPILE_FOR_VSL
			if (!vars->SeResName)
			{
				extern void SeWrapperRegisterSystem(int index,
					void *ptr);
				SeWrapperRegisterSystem(index, vars->appPtr);
			}
#endif
		}
		if (index == SeCompile_FAIL)
		{
			success = bs_ugly;  /* failure */
			break;
		}
#if SeDEBUG == 2
		else
		{
			SePrtKnownSystems( "Incremental User Systems" );
		}
#endif
		NmClear(&vars->argnames);
	}
	NmClear(&vars->argnames);

#ifdef COMPILE_FOR_VSL
	if (success != bs_ugly)  /* no error? */
	{
		if (vars->allow_comps)
		{
			int i;
			/* need to register all components */
			for (i = 0; i < NmSize(&RtComponents); i++)
			{
				const char *name = NmName(i, &RtComponents);
				extern void SeWrapperRegisterComponent(
					int compindex, void *ptr);
				SeWrapperRegisterComponent(NmIndex(name,
					&RtComponents, mFalse), vars->appPtr);
			}
			vars->allow_comps = mFalse;
		}
	}
#endif
	return success != bs_ugly;
}


// find if specified system is contained in a system (11-05-23 ch3: VSL)
// returns index of system where found or -1 if not found
int SeFindSys(int index, int sysindex)
{
	if (SeDataSystem[index] != NULL
		&& SeFindSysExpr(SeDataSystem[index]->sysdef, sysindex) != -1)
	{
		return index;  // return system where it was found
	}
	// specified system is not defined or was not found
	return -1;
}


// find if specified system is used in an expression (11-05-23 ch3: VSL)
int SeFindSysExpr(SeSysDef *sysdefp, int sysindex)
{
	SeArgExp *np;
	int index;

	switch (sysdefp->type)
	{
	case SeNT_QUALSYS:
	case SeNT_SYSNAME:
		if (sysindex == sysdefp->c.index)
		{
			// found the system
			return sysindex;
		}
		// check if specified system is used in the system
		return SeFindSys(sysdefp->c.index, sysindex);

	case SeNT_FNCALL:
		DqEACH(sysdefp->f.argexps, np, SeArgExp)
		{
			index = SeFindSysExpr(np->expp, sysindex);
			if (index != -1)
			{
				// found specified system in an argument
				return index;
			}
		}
		return -1;

	case SeNT_MULTOCC:
	    // FALL THRU
	case SeNT_EXPR:
	case SeNT_NOT:
	case SeNT_ANOT:
	case SeNT_ABS:
	case SeNT_BOOL:
		return SeFindSysExpr(sysdefp->o.rhsp, sysindex);

	case SeNT_LIST:
	case SeNT_AND:
	case SeNT_XOR:
	case SeNT_OR:
	case SeNT_MIN:
	case SeNT_MAX:
	case SeNT_SUM:
	case SeNT_DIFF:
	case SeNT_PROD:
	case SeNT_QUOT:
	case SeNT_LT:
	case SeNT_GT:
	case SeNT_LTEQ:
	case SeNT_GTEQ:
	case SeNT_RUNIF:
	case SeNT_RNORM:
	case SeNT_MOFN:
	case SeNT_PKD:
	case SeNT_ORCA:
	case SeNT_EVAL:
	case SeNT_QUALOP:
		index = SeFindSysExpr(sysdefp->o.lhsp, sysindex);
		if (index != -1)
		{
			return index;
		}
		return SeFindSysExpr(sysdefp->o.rhsp, sysindex);

	case SeNT_QUALIST:
	case SeNT_LISTNAME:
	case SeNT_QUALCOMP:
	case SeNT_COMPNAME:
	case SeNT_CONSTANT:
	case SeNT_PARAM:
	case SeNT_CQUALIFIER:
	case SeNT_UNSET:
	default:
		return -1;  // non-system leaf node, system not found
	}
}

/* Run through all systems in SeSystems name pool and make sure all
   are defined. */
MuvesBool
SeSysCheck(void)
{		
	int i;
	int nsysdefs = 0;
	const char *name;

	for (i = 0; i < NmSize(&SeSystems); i++)
	{
		if ((name = NmName(i, &SeSystems)) != NULL)
		{
			if (SeDataSystem[i] == NULL)
			{
				nsysdefs++;
				ErPLog("*** undefined identifier (%s) "
					"referenced in system definition file."
					"\n", name);
				ErPLog("\"%s\" must be either a system defined "
					"in the sysdef file,\n", name);
				ErLog("\t or a valid component name in the "
					"region map file.\n");
				ErSet(SeUNDEFIDENT);
			}
		}
	}
	return nsysdefs == 0;
}


/**
	NmPool *SeSysOpen( const char *sysdef_file, MuvesBool optimize )

	NmPool SeSystems
	NmPool SeComponents

	SeSysOpen() reads all system definitions from the designated
	"sysdef" file and returns a pointer to a name pool of systems
	encountered while parsing the file; this name pool is also
	accessible as the global variable SeSystems.  SeSysOpen() also
	builds a globally accessible name pool of components called
	SeComponents which is a copy of the RtComponents name pool,
	but has any "qualified" components, encountered in the "sysdef"
	file, tacked onto the end.  A qualified component is one that
	exists in the "sysdef" file with a qualifier attached as
	described in the package docs for this file's syntax.  The
	entire qualified name will be stored in the name pool.  If the
	boolean argument "optimize" is set to mTrue, it will attempt to
	optimize the system expressions read from the file, otherwise
	it will leave them as defined in the file.

	The convenience routine SeGetQualList() can be used to get a
	Dq list of SeComponents name pool indices for qualified
	components associated with a component index from the
	RtComponents name pool.

	Before reading the specified "sysdef" file, SeSysOpen() reads a
	library file, $MUVES/lib/sysdef, that contains useful standard
	function definitions, if it exists.  Those functions can be used
	in definitions within the "sysdef" file.  There are also some
	functions built into the Se package that are always available
	for use in expressions.  All MUVES-supplied function names begin
	with an underscore; such names must not be used for analyst-
	defined functions or systems.

	If a null pointer is supplied as the filename argument,
	/dev/null is used instead, but the library file is still read.
	If SeSysOpen() encounters an error, it returns a null pointer.

	BUILT-IN FUNCTIONS CURRENTLY PROVIDED:

	_random_uniform(min,max)	provides a random number greater
					than or equal to min and less
					than max, distributed uniformly
					over the range of possible
					values.

	_random_normal(mu,sigma)	provides a random number
					distributed as a Gaussian with
					mean mu and standard deviation
					sigma.
**/
MuvesBool	SeTesting = mFalse;	/* special hack for local stddef when testing */

NmPool *
#if STD_C
SeSysOpen( const char *sysdef_file, MuvesBool optimize )
#else
SeSysOpen( sysdef_file, optimize )
const char *sysdef_file;
MuvesBool optimize;
#endif
	{	ApT_EnvVar *envp;	/* environment variable ptr */
		FILE *fp;	/* sysdef file stream */
		MuvesBool success;
		/* 06-30-00 ch3  added variables for delayed optimization */
		int sys;        /* system loop index variable */
		int nsys;       /* number of systems variable */
	if( sysdef_file == NULL )
		sysdef_file = "/dev/null";	/* special hack */

	assert(*sysdef_file != 0);
#if defined(VDEBUG) || SeDEBUG
	ErPLog( "SeSysOpen(%s)\n", sysdef_file );
#endif

	/*==============*/
	/*  INITIALIZE  */
	/*==============*/

	/* initializes and allocates sysdef variables */
	/* loads library sysdef file */
	/* loads env vars as constants */
	/* opens user sysdef file */
	SeParseVars *vars = SeSysInit(NULL, mFalse, NULL);
	if (vars->error == SeFail2)
	{
		goto fail_2;
	}

	/*=====================*/
	/*  READ USER SYSDEFS  */
	/*=====================*/

	success = SeSysReadFile(vars, sysdef_file);
	if (vars->error == SeFail3)
	{
		goto fail_3;
	}


	/*====================*/
	/*  OPTIMIZE SYSDEFS  */
	/*====================*/

	/* 06-30-00 ch3  added code to now optimize all systems BEGIN */
	if (success && optimize)
		{
		/* 05-05-18 ch3: changed debugging flag from SEDBG_NULLSYS */
		if ( SeDebugging & SEDBG_STSMSGS )
			ErPLog("SeSysOpen: begin optimize\n");
		nsys = NmSize( &SeSystems );
		for ( sys = 0; sys < nsys; sys++ )
			{
			/* 05-05-18 ch3: added debugging message */
			if ( SeDebugging & SEDBG_STSMSGS )
				ErPLog("SeSysOpen: Optimizing system '%s'\n",
					NmName(sys, &SeSystems));
			if ( SeDataSystem[sys] != NULL )
			{
				SeOptimize( &SeDataSystem[sys]->sysdef );
				/* 05-06-20 ch3: added error flag check */
				if (ErIsSet())
				{
					ErPLog("SeSysOpen: optimize failed\n");
					success = mFalse;
					break;
				}
			}
			else if ( SeDebugging & SEDBG_NULLSYS )
				ErPLog("SeSysOpen: System[%d]=NULL\n", sys);
			}
		}
	/* 06-30-00 ch3  added code to now optimize all systems END */

#if SeDEBUG
	SePrtKnownSystems( "All Systems" );
#endif

	/*============*/
	/*  CLEAN-UP  */
	/*============*/

	/* Release file pointer and close queue used for token stack. */
	assert(DqIsEmpty( SeStackp ));	/* all nodes should be free */
	DqClose(vars->SeStackp);
	vars->SeStackp = NULL;	/* invalidate queue pointer */

	if (!success)
		{	register long saveErIndex = ErIndex;
		assert(ErIsSet());
		/* No go, so free up storage. */
		if( ! SeSysClose() )
			{
			assert(ErIsSet());
			ErPLog( "Internal \"Se\" package BUG: %s\n",
				ErString() );
			}
		/* SeSysClose() called SeStompDat() and NmClear(). */
		assert(NmSize( &SeSystems ) == 0);
		assert(SeDataSystem == NULL);
		ErSet( saveErIndex );	/* report parsing/compilation error */
		goto fail_1;
		}

	success = SeSysCheck();

	DmFree(vars);  /* no longer need the parse variables */

	if (!SeExpandLists())
	{
		goto fail_3;
	}

	if (!success)
	{
		return NULL;
	}
	else
	{
		return &SeSystems;	/* success */
	}

	/* Error returns: */

fail_2:	assert(DqIsEmpty(vars->SeStackp));
	DqClose(vars->SeStackp);
	vars->SeStackp = NULL;	/* invalidate queue pointer */
fail_1:	/* (void) fclose( fp ); ** SCR 1093 */
fail_3:	ErPLog( "Error while processing system definition file \"%s\":\n\t%s\n",
		sysdef_file, ErString() );
	assert(ErIsSet());
	DmFree(vars);
	return	NULL;		/* failure */
}

/**
	void SeSysReset( void )

	SeSysReset() clears the values internally associated with the
	systems corresponding to the SeSystems name pool.  Also, any
	values associated with the state vectors in the SeStates name
	pool are freed.  This must be done after systems have been
	evaluated with either SeSysEval() or SeStEval() and one of these
	routines is to be called again with different component values.

	Invalidates all values in compiled-system array (SeDataSystem).
	This forces re-evaluation of the "sysdef" expressions the next time
	a system's value is referenced.  Frees all "values" arrays for
	evaluated state vectors in the compiled state vector array
	(SeStDef).  This forces re-evaluation of a state vector the next
	time SeStEval() is called for that vector.

	This routine must be called whenever one or more systems or
	state vectors that have previously been evaluated are to be
	evaluated with new component values.
**/
void
#if STD_C
SeSysReset( void )
#else
SeSysReset()
#endif
	{	register int i;
#if defined(VDEBUG) || SeDEBUG
	ErPLog( "SeSysReset()\n" );
#endif
	for( i = NmSize( &SeSystems ); --i >= 0; )
		{
#ifdef COMPILE_FOR_VSL
		    if (SeDataSystem[i] == NULL ) {
			continue;
		    }
#else
		assert( SeDataSystem[i] != NULL );
#endif
		SeDataSystem[i]->state = SeINVALID;

#ifndef COMPILE_FOR_VSL
		if( SeDebugging )
#endif
			{
			SeDataSystem[i]->save.value = -1.0;
			SeDataSystem[i]->save.type = SeTypeUnset;
			/* 11-12-05 ch3: not necessary to register value change,
		  	 *               SeSysReset() no longer called by
			 *               SeWrapper (it now re-evaluates systems)
			 */
			}
		}
	if( SeStDef == NULL )
		return; /* SeStOpen() not yet called. */

	/* Free storage for invalid results. */
	assert(SeStDLen >= NmCount( &SeStates ));
	for( i = NmCount( &SeStates ); --i >= 0; )
		{
		assert(SeStDef[i] != NULL);
		assert(i < NmCount( &SeStates ));
#if SeDEBUG == 2
		ErPLog( "SeSysReset: %s \"%s\": index %d\n",
			"invalidating results for state vector",
			NmName( i, &SeStates ), i );
#endif
		if( SeStDef[i]->text == NULL )
			ErPLog( "SeSysReset: WARNING: NULL text field\n" );
		assert(SeStDef[i]->defs != NULL);
		if( SeStDef[i]->values != NULL )
			{
			DmFree((genptr_t)SeStDef[i]->values);
			SeStDef[i]->values = NULL;
			}
		}
	/* Invalidate cached component kill values. */
	if( SeKilled != NULL )
		for( i = NmCount( &SeComponents ); --i >= 0; )
			SeKilled[i] = -1;
	}

const char *
#if STD_C
SeGetQualName( const char *compname, const char *qualifier )
#else
SeGetQualName( compname, qualifier )
const char *compname;
const char *qualifier;
#endif
	{	static char buffer[SeBUFSIZE];
	(void) sprintf( buffer, "%s[%s]", compname, qualifier );
	return buffer;
	}

char *
#if STD_C
SeSysTextRep( const SeSysDef *sysdefp )
#else
SeSysTextRep( sysdefp )
const SeSysDef *sysdefp;
#endif
	{	const char *text = NULL;
		char *qualname;
		char *bptr;
		char buffer[SeBUFSIZE];

	switch( sysdefp->type )
		{
	case SeNT_CQUALIFIER :
		text = NmName( sysdefp->c.index, &SeQualifiers );
		break;
	case SeNT_QUALOP :
		text = SeSysTextRep( sysdefp->o.lhsp );
		qualname = SeSysTextRep( sysdefp->o.rhsp );
		(void) sprintf( buffer, "%s[%s]", text, qualname );
		DmFree((genptr_t)(char *) text );
		DmFree((genptr_t)qualname );
		text = buffer;
		break;
	case SeNT_QUALSYS :
	case SeNT_SYSNAME :
		text = NmName( sysdefp->c.index, &SeSystems );
		break;
	case SeNT_CONSTANT :
		if( sysdefp->n.index >= 0 )
			text = NmName( sysdefp->n.index, &SeSystems );
		else
			{
			(void) sprintf( buffer, "%f", sysdefp->n.value );
			text = buffer;
			}
		break;
	case SeNT_QUALIST :
	case SeNT_LISTNAME :
		text = NmName( sysdefp->c.index, &SeLists );
		break;
	case SeNT_QUALCOMP :
	case SeNT_COMPNAME :
		text = NmName( sysdefp->c.index, &SeComponents );
		break;
	case SeNT_EXPR :
	/* 06-30-00 ch3  added case for new multiple occurrence operator */
	case SeNT_MULTOCC :
		return SeSysTextRep( sysdefp->o.rhsp );
	case SeNT_FUNCNAME :
	case SeNT_FNCALL :
		text = NmName( sysdefp->f.index, &SeFunctions );
		(void) sprintf( buffer, "%s(", text );
		if( sysdefp->f.argexps != NULL )
			{	SeArgExp *np;
			assert(! DqIsEmpty( sysdefp->f.argexps ));
			DqEACH( sysdefp->f.argexps, np, SeArgExp )
				{	char *exptext;
				exptext = SeSysTextRep( np->expp );
				bptr = buffer + strlen(buffer);
				(void) sprintf( bptr, " %s,", exptext );
				DmFree((genptr_t)exptext );
				}
			}
		bptr = buffer + strlen(buffer) - 1;
		(void) sprintf( bptr, " )" );
		text = buffer;
		break;
	case SeNT_RUNIF :
	case SeNT_RNORM :
	case SeNT_MOFN :
	case SeNT_PKD :
	/* 02-07-27 ch3: added support for ORCA node type */
	case SeNT_ORCA :
	case SeNT_EVAL :
		break;
	case SeNT_LIST :
	case SeNT_AND :
	case SeNT_XOR :
	case SeNT_OR :
	case SeNT_MIN :
	case SeNT_MAX :
	case SeNT_SUM :
	case SeNT_DIFF :
	case SeNT_PROD :
	case SeNT_QUOT :
	case SeNT_LT :
	case SeNT_GT :
	case SeNT_NOT :
	case SeNT_ANOT :
	case SeNT_ABS :
	case SeNT_BOOL :
		text = SeTtbl[sysdefp->type].ts;
		break;
	default :
		ErPLog( "SeSysTextRep: '%s' not supported.\n",
			SeCvtToStr( sysdefp->type ) );
		assert( sysdefp->type == SeNT_QUALSYS );
		return NULL;
		}
	return DmStrDup(text );
	}


/*
	SeCompInsert() inserts a new SeQalNode (containing a component id index)
	into a queue of component ids.  The new node is inserted sorted in
	ascending component id order.  Duplicate component id nodes will
	not be inserted.
*/
void
#if STD_C
SeCompInsert( DqNode *regq, SeQalNode *newp )
#else
SeCompInsert( regq, newp )
DqNode *regq;
SeQalNode *newp;
#endif
	{	SeQalNode *p;

	if( DqIsEmpty( regq ) )
		{
		DqPush( regq, &newp->link );
		return;
		}
	else	
		DqEACH( regq, p, SeQalNode )
		{
		if( newp->index == p->index )
			{ /* already have this component */
			DmFree((genptr_t)newp );
			return;
			}
		else if( newp->index < p->index )
			{
			DqL_Insert( &newp->link, &p->link );
			return;
			}
		else	/* keep going */
			;
		}

	DqAppend( regq, &newp->link );
	}


/*
	SeStoreSysComps() finds all of the components referenced by the
	specified system index and creates a linked list of component id nodes
	for that system (inserted in order to eliminate duplicates).  
	The SeSysComps array (indexed by SeSystems index)
	points to each system's queue of component id nodes.
*/
MuvesBool
#if STD_C
SeStoreSysComps( SeSysDef *sysdefp, int sys )
#else
SeStoreSysComps( sysdefp, sys )
SeSysDef *sysdefp;
int sys;
#endif
	{
	if( sysdefp == NULL )
		{
		ErPLog( "BUG: null (sub)expression pointer.\n" );
		return mFalse;
		}
	else
	switch( sysdefp->type )
		{
	case SeNT_SYSNAME :
	case SeNT_QUALSYS :
		{	register const char *name;
		if( (name = NmName( sysdefp->c.index, &SeSystems )) == NULL )
			{
			ErPLog( "BUG: bad system index (%d).\n",
				sysdefp->c.index );
			return mFalse;
			}
		else
		if( SeDataSystem[sysdefp->c.index] != NULL )
			if( ! SeStoreSysComps( SeDataSystem[sysdefp->c.index]->sysdef, 
					sys ))
				return mFalse;
		break;
		}
	case SeNT_LISTNAME :
	case SeNT_QUALIST :
		{	SeLiMember *lmp;
		/* Recurse on each member of sublist. */
		DqEACH( SeListDfn[sysdefp->c.index], lmp, SeLiMember )
			if (! SeStoreSysComps(&lmp->member, sys))
				return mFalse;
		break;
		}
	case SeNT_QUALCOMP :
	case SeNT_COMPNAME :
		{	SeQalNode *newp;
			const char *qname = NULL;
			const char *name = NmName( sysdefp->c.index, &SeComponents );
			register int comp;

		if((qname=SePrsQualName(sysdefp->c.index)) == NULL)
			ErClear();
		if(qname != NULL && (name=SePrsBaseName(sysdefp->c.index)) == NULL)
			return mFalse;

		if( (comp = NmIndex( name, &SeComponents, mFalse )) == -1 )
			{
			ErPLog( "BUG: Couldn't find component \"%s\" in %s.\n",
					name, "SeComponents Name Pool" );
			return mFalse;
			}

		newp = (SeQalNode *)DmXalloc(SeQalNode);
		newp->index = comp;
		SeCompInsert( SeSysComps[sys], newp );
		break;
		}
	case SeNT_FNCALL :
		{	register const char *name;
		if( (name = NmName( sysdefp->f.index, &SeFunctions )) == NULL )
			{
			ErPLog( "BUG: bad function definition index (%d).\n",
				sysdefp->f.index );
			return mFalse;
			}
		else
			{	SeArgExp *np;
			DqEACH( sysdefp->f.argexps, np, SeArgExp )
				if( ! SeStoreSysComps( np->expp, sys ))
					return mFalse;
			}
		break;
		}
	case SeNT_CONSTANT :
	case SeNT_PARAM :
	case SeNT_CQUALIFIER :
	case SeNT_QUALOP :
		break;
	case SeNT_EXPR :
	/* 06-30-00 ch3  added case for new multiple occurrence operator */
	case SeNT_MULTOCC :
	case SeNT_NOT :
	case SeNT_ANOT :
	case SeNT_ABS :
	case SeNT_BOOL :
		if( ! SeStoreSysComps( sysdefp->o.rhsp, sys ) )
			return mFalse;
		break;
	case SeNT_LIST :
	case SeNT_AND :
	case SeNT_XOR :
	case SeNT_OR :
	case SeNT_MIN :
	case SeNT_MAX :
	case SeNT_SUM :
	case SeNT_DIFF :
	case SeNT_PROD :
	case SeNT_QUOT :
	case SeNT_LT :
	case SeNT_GT :
	case SeNT_RUNIF :
	case SeNT_RNORM :
	case SeNT_MOFN:
	case SeNT_PKD :
	/* 02-07-27 ch3: added support for ORCA node type */
	case SeNT_ORCA :
	case SeNT_EVAL :
		if( ! SeStoreSysComps( sysdefp->o.lhsp, sys ) )
			return mFalse;
		if( ! SeStoreSysComps( sysdefp->o.rhsp, sys ) )
			return mFalse;
		break;
	case SeNT_UNSET:
		ErPLog( "BUG: node type unset.\n" );
		break;
	default :
		ErPLog( "BUG: illegal node type (%s).\n",
			SeCvtToStr(sysdefp->type) );
		break;
		}
	return mTrue;
	}


/*
	SeStoreStateComps() finds all of the components referenced by the
	specified state vector and creates a linked list of component id nodes
	for that state (inserted in order to eliminate duplicates).  
	The SeStateComps array (indexed by SeStates index)
	points to each state's queue of component id nodes.
*/
MuvesBool
#if STD_C
SeStoreStateComps( char *statename )
#else
SeStoreStateComps( statename )
char *statename;
#endif
	{	const char **elems;
		int si;
		int i;
		int len;
		SeTypeID type;
		const char *name;
		int namelen;
		char *elemname = NULL;

	if( (elems = SeStQuery( statename, &type, &len )) == NULL )
		return mFalse;
		
	if( (si = NmIndex( statename, &SeStates, mFalse )) == -1 )
		{
		ErPLog("BUG: state name \"%s\" not found in Name Pool.\n",
				statename);
		return mFalse;
		}
	if( ( SeStateComps[si] = DqOpen()) == NULL )
		return mFalse;

	for( i = 0; i < len; ++i )
		{	register int sys;	/* index in SeSystems */
			register int comp;	/* index in RtComponents */

		/* XXX I'm not sure why, but sometimes component names
		   have parentheses or quotes around them.  The Se pkg is
	           putting them, but they don't seem necessary, and they
		   interfere with this process.  We need to look at getting
		   rid of them. */

		/* Remove any extraneous '(' and ')' from
		   element name. */
		name = elems[i];
		namelen = strlen(name);
		elemname = (char*)DmCalloc(namelen+1, sizeof(char));
		if( name[0] == SeCH_LF_PAREN )
			{
			(void)sprintf( elemname, "%s", name+1 );
			elemname[namelen-2] = '\0';
			}
		/* Remove any extraneous "" around component name. */
		else
		if( name[0] == SeCH_DBL_QUOTE )
			{	const char *s;
				char *t;
			s = name;
			t = elemname;
			while( *s != '\0' )
				if( *s != '\"' )
					*t++ = *s++;
				else
					s++;
			*t= '\0';
			}
		else
			{
			(void)sprintf( elemname, "%s", name );
			elemname[namelen] = '\0';
			}


		/* Clear Erindex before calling NmIndex(). */
		if( ErIsSet() )
			{
			ErPrint();
			return mFalse;
			}
		if( (sys = NmIndex( elemname, &SeSystems, mFalse )) >= 0 )
			/* this is a system */
			{	SeQalNode *p;
			if( SeSysComps[sys] == NULL )
				/* SeSysComps[] should be filled in. */
				return mFalse; 
			DqEACH( SeSysComps[sys], p, SeQalNode )
				{	SeQalNode *newp;
				newp = (SeQalNode  *)DmXalloc(SeQalNode);
				*newp = *p;
				SeCompInsert( SeStateComps[si], newp );
				}
			}
		else	/* must be a component */
			{	const char *qname = NULL;
				SeQalNode *newp;

			ErClear();	/* Clear ErIndex if set by NmIndex() */

			if( (comp = NmIndex( elemname, &SeComponents, mFalse )) < 0 )
				return mFalse;

			if((qname=SePrsQualName(comp)) == NULL)
				ErClear();
			if(qname != NULL)
				{
				if( (name=SePrsBaseName(comp)) == NULL)
					return mFalse;

				comp = NmIndex( name, &RtComponents, mFalse );
				}

			newp = (SeQalNode *)DmXalloc(SeQalNode);
			newp->index = comp;
			SeCompInsert( SeStateComps[si], newp );
			}
		DmFree((genptr_t)elemname);
		elemname = NULL;
		}
	return mTrue;
	}

void SePkgInit() 
{
  static int done = 0;
  if (!done) {
    done = 1;
    ApPkgInit();
    DqPkgInit();
    ErPkgInit();
    IoPkgInit();
    NmPkgInit();
#ifndef COMPILE_FOR_VSL
    RtPkgInit();
#endif
	
    NmInit (&SeSystems);
    NmInit (&SeComponents);
    NmInit (&SeFunctions);
    NmInit (&SeStates);
    NmInit (&SeQualifiers);
    NmInit (&SeLists);
    
#   ifdef DEBUG
    ErPLog("Se package initialized.\n");
#   endif
  }
}
