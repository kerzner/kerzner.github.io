/*
	Fa -- MUVES File Access package -- Functions for initializing
		the package.

	created:	92/07/01	G S Moss
	edited:		12/10/22	C Hunt
			corrected compiler warnings (VSL)
 */

#ifndef lint
static char RCSid[] = "$Id: Fa.c,v 1.39 2010/06/23 19:54:46 geoffs Exp $";
#endif

#ifdef __STDC__
#include <stdlib.h>
#endif

#ifndef DEBUG
#define NDEBUG
#endif
#ifndef STATIC
#define STATIC	static
#endif

#include <assert.h>

#include <sys/param.h>
#include <sys/types.h>

#include <stdio.h>
#include <unistd.h>
#include <dirent.h>
#include <pwd.h>
#include <time.h>

#include "Fa.h"
#include <Dq.h>
#include <Io.h>
#include <stdio.h>
#include <common.h>   /* BRL-CAD 7.2.4+ no longer use config.h (SCR670) */
#include <Dm.h>
#include <bu.h>

/* bizarrely, this include wasn't here before, even though genptr_t needs
   it... */
#include <Rt.h>

extern int FaDebugging;
#define ErDebugging FaDebugging

#if ! STD_C
extern char *getenv();
#endif

#define FaUMASK	0007	/* world permissions off */

FaInfo FaGlobals =	/* package globals neatly */
	{
	-1,	/* rgid */
	-1,	/* ruid */
	0,	/* rumask */
#if defined(MUVES_USER_ENABLE)
	-1,	/* egid */
	-1,	/* euid */
	0,	/* eumask */
#endif
	-1,	/* ngroups */
	NULL,	/* rgidlist */
	"",	/* user */
	NULL,	/* path */
	NULL,	/* homedir */
	NULL,	/* workdir */
	NULL,	/* rootdir */
	NULL,	/* analdir */
	NULL,	/* tempdir */
	NULL,	/* catalog */
	{ 0 }	/* defaults */
	};

/* Register official input file specifications here:
   NB ordering must mirror FaInputFileType enumeration in Fa.h.
   Also, do not use plural names, singular is better for generality of use.

   Usage:
	for( i = 0; i < FaITypeSentinel; i++ )
		{
		dirname = FaInputFiles[i].dirname;
		longname = FaInputFiles[i].longname;
		}
	ccmap_directory_name = FaInputFiles[FaITypeComponentCategoryMap].dirname;
	ccmap_long_name = FaInputFiles[FaITypeComponentCategoryMap].longname;
 */
FaFileSpec FaInputFiles[FaITypeSentinel] =
	{
	{	FaDIRCLASSIF,	"classification markings file" },
	{	FaDIRCATMAP,	"component category map" },
	{	FaDIRCMPROP,	"component property" },
	{	FaDIRDAMSEL,	"damage evaluation selection" },
	{	FaDIRECURVE,	"evaluation module curve" },
	{	FaDIRENV,	"environment variable" },
	{	FaDIRMATPROP,	"material property" },
	{	FaDIRPARAMS,	"parameters" },
	{	FaDIREUSRAY,	"reusable ray" },
	{	FaDIRBCURVE,	"blast curve files" },
	{	FaDIRFCURVE,	"indirect fire module curve" },
	{	FaDIRICURVE,	"interaction module curve" },
	{	FaDIRPACK,	"armor packages" },
	{	FaDIRIFMSEL,	"indirect fire module selection" },
	{	FaDIRSTATES,	"state vector" },
	{	FaDIRSYSEXP,	"system definition" },
	{	FaDIRTARGET,	"target" },
	{	FaDIRTHREAT,	"threat" },
	{	FaDIRVIEW,	"view specification" },
	{	FaDIRVIF,	"view information file" }
	};

FaFileSpec FaOutputFiles[FaOTypeSentinel] =
	{
	{	FaDIRSIV,	"siv output files" },
	{	FaDIRCXC,	"cellxcell output files" },
	{	FaDIRPFILES,	"pressure files" }
	};

#ifdef COMPILE_FOR_VSL
void FaFreTrie( FaTriNode **triepp ) {abort();}
void FaErPrt( const char *format, ... ) { abort(); }
void FaSafNCopy( char *s1, const char *s2, unsigned n ) {abort();}
const char *FaDirCat( const char *s1, const char *s2 ) {abort();}

#endif


/**
        FaInfo *FaInit( const char *cwd )

        Initialize the Fa package.  FaInit() fills in the FaGlobals structure
        and returns a pointer to it.  In case of an error, FaInit() prints
        an appropriate diagnostic and returns NULL.  If an application wishes
        to establish a current working directory, it must pass FaInit() the
        absolute path name to that directory, otherwise "cwd" must be NULL.
	If the environment variable "MUVES_ANALYSIS_DIR" is set, that is 
	used as	the path to the analysis(project) directory to be used. 
	Otherwise, the default analysis directory is used 
	($MUVES/data/analysis).
**/

FaInfo *
#if STD_C
FaInit( const char *cwd )
#else
FaInit( cwd )
const char *cwd;
#endif
	{	char buffer[FaBUFLEN];
		register FaDefaults *defaultp;
		struct passwd *pw;
		char *projdir;

	if( FaGlobals.rgid != -1 )
		{
		FaErPrt( "BUG: FaInit() called twice, call FaFree() first.\n" );
		return (FaInfo *) NULL;
		}
	FaGlobals.rgid = getgid();		/* get real GID */
	FaGlobals.ruid = getuid();		/* get real UID */
#if defined(MUVES_USER_ENABLE)
	FaGlobals.egid = getegid();		/* get effective GID */
	FaGlobals.euid = geteuid();		/* get effective UID */
#endif
	FaGlobals.rumask = umask( FaUMASK );	/* save user's UMASK */
#if defined(MUVES_USER_ENABLE)
	FaGlobals.eumask = umask( FaUMASK );	/* verify effective UMASK */
#endif

	/* Get user's password entry. */
	if( (pw = getpwuid( FaGlobals.ruid )) == NULL )
		{
		FaErPrt( "Could not get user's password entry.\n" );
		return (FaInfo *) NULL;
		}
	FaSafCopy( FaGlobals.user, pw->pw_name );

	if( FaDebugging && pw->pw_gid != FaGlobals.rgid )
		FaErPrt( "*** FaInit: WARNING: user using assumed GID (%d)!\n",
			 FaGlobals.rgid );

	/* Get multiple groups for user. */
	FaGlobals.rgidlist = NULL;
	if( (FaGlobals.ngroups = getgroups( 0, (gid_t *) NULL )) == -1 )
		FaErPrt( "Can't determine supplementary groups because: %s\n",
			IoStrPerror() );
	else
	if( FaGlobals.ngroups > 0 )
		{
		FaGlobals.rgidlist = (gid_t *)DmCalloc(FaGlobals.ngroups, sizeof(gid_t ));
		int id = getgroups( FaGlobals.ngroups, FaGlobals.rgidlist );
		}

	/* Get user's path setting. */
	if( (FaGlobals.path = getenv( "PATH" )) == NULL )
		{
		FaErPrt( "$PATH not set in environment.\n" );
		return (FaInfo *) NULL;
		}
	/* Get user's home. */
	if( (FaGlobals.homedir = getenv( "HOME" )) == NULL )
		{
		FaErPrt( "$HOME not set in environment.\n" );
		return (FaInfo *) NULL;
		}
	/* Set the current working directory if specified. */
	if( cwd != NULL)
		FaGlobals.workdir = DmStrDup(cwd );
	/* Get the root of the MUVES file hierarchy. */
	FaGlobals.rootdir = DmStrDup(IoMUVES() );

	/* Get root to analysis directory to use. */
	if( ( projdir = getenv( "MUVES_ANALYSIS_DIR" )) == NULL )
		{
		FaSafCopy( buffer, FaDirCat( FaGlobals.rootdir, FaDIRDATA ) );
		FaSafCopy( buffer, FaDirCat( buffer, FaDIRPROJEC ) );
		FaGlobals.analdir = DmStrDup( buffer );
		}
	else
		FaGlobals.analdir = DmStrDup( projdir );

	/* Get path for $MUVES/tmp. */
	FaSafCopy( buffer, FaDirCat( FaGlobals.rootdir, FaDIRTMP ) );
	FaGlobals.tempdir = DmStrDup(buffer );

	/* Setup defaults for UI behavior. FaFILXCELBROWRC will override. */
	defaultp = &FaGlobals.defaults;
	defaultp->bincells = FaDFL_BINCELLOCS;
	defaultp->cellszfromrc = mFalse;
	defaultp->cellsz.wid = FaDFL_HCELSZ;
	defaultp->cellsz.hgt = FaDFL_VCELSZ;
	defaultp->celldispsz.h = FaDFL_WIDTH;
	defaultp->celldispsz.v = FaDFL_HEIGHT;
	defaultp->cellspacing.h = FaDFL_HSPACE;
	defaultp->cellspacing.v = FaDFL_VSPACE;
	defaultp->display = NULL;
	defaultp->browser = FaDFL_BROWSER;
	defaultp->interpcolors = FaDFL_BLEND;
	defaultp->monitoranalysis = FaDFL_VERBOSE;
	defaultp->monochrome = FaDFL_MONOCHROME;
	defaultp->nbins = FaDFL_NUMBINS;
	defaultp->minbinval = FaDFL_MINBIN;
	defaultp->maxbinval = FaDFL_MAXBIN;
	defaultp->showcolorkey = FaDFL_KEYCOLOR;
	defaultp->showborder = FaDFL_SHOWBORDER;
	defaultp->showgrid = FaDFL_AXES;
	defaultp->shownumeric = FaDFL_SHOWNUMERIC;
	defaultp->usefill = FaDFL_USEFILL;
	defaultp->userect = FaDFL_USERECT;
	defaultp->usesize = FaDFL_USESIZE;

	if( FaDebugging )
		{
		FaErPrt( "User's login name = \"%s\"\n", FaGlobals.user );
		FaErPrt( "Real GID = %d\n", FaGlobals.rgid );
		FaErPrt( "Real UID = %d\n", FaGlobals.ruid );
		FaErPrt( "User's UMASK = %03o\n", FaGlobals.rumask );
#if defined(MUVES_USER_ENABLE)
		FaErPrt( "Effective GID = %d\n", FaGlobals.egid );
		FaErPrt( "Effective UID = %d\n", FaGlobals.euid );
		FaErPrt( "Effective UMASK = %03o\n", FaGlobals.eumask );
#endif
		{
			register int grp;
			FaErPrt( "The user is in %d groups:\n",
				 FaGlobals.ngroups );
			for( grp = 0; grp < FaGlobals.ngroups; grp++ )
				FaErPrt( "\t\t%d\n",
					 (int) FaGlobals.rgidlist[grp] );
		}
		FaErPrt( "User's search path is \"%s\"\n", FaGlobals.path );
		FaErPrt( "User's home directory is \"%s\"\n",
			 FaGlobals.homedir );
		FaErPrt( "User's current working directory is \"%s\"\n",
			 FaGlobals.workdir == NULL ? "(null)" :
			 FaGlobals.workdir );
		FaErPrt( "MUVES installed under \"%s\"\n", FaGlobals.rootdir );
		FaErPrt( "MUVES projects live in \"%s\"\n",
			 FaGlobals.analdir );
		FaErPrt( "MUVES scratch directory is \"%s\"\n",
			 FaGlobals.tempdir );
		}
	return &FaGlobals;
	}
/**
        void FaFree( void )

        Close down the Fa package.  FaFree() frees and invalidates all
        storage allocated by FaInit().
**/
void
#if STD_C
FaFree( void )
#else
FaFree()
#endif
	{
	if( FaGlobals.rgid == -1 )
		{
		FaErPrt( "BUG: FaFree() called before FaInit().\n" );
		return;
		}
	FaGlobals.rgid = -1;
	FaGlobals.ruid = -1;
#if defined(MUVES_USER_ENABLE)
	FaGlobals.egid = -1;
	FaGlobals.euid = -1;
#endif
	FaGlobals.rumask = 0;
#if defined(MUVES_USER_ENABLE)
	FaGlobals.eumask = 0;
#endif
	FaGlobals.user[0] = '\0';
	FaGlobals.path = NULL;		/* points to static storage */
	FaGlobals.homedir = NULL;	/* points to static storage */
	if( FaGlobals.workdir != NULL )
		DmFree((genptr_t)FaGlobals.workdir );
	DmFree((genptr_t)FaGlobals.rootdir );
	DmFree((genptr_t)FaGlobals.analdir );
	DmFree((genptr_t)FaGlobals.tempdir );
	FaGlobals.rootdir = NULL;
	FaGlobals.analdir = NULL;
	FaGlobals.tempdir = NULL;
	if( FaGlobals.catalog != NULL )
		FaFreTrie( &FaGlobals.catalog );
	assert( FaGlobals.catalog == NULL );
	if( FaGlobals.ngroups > 0 )
		{
		assert( FaGlobals.rgidlist != NULL );
		DmFree((genptr_t)FaGlobals.rgidlist );
		FaGlobals.ngroups = -1;
		FaGlobals.rgidlist = NULL;
		}
	assert( FaGlobals.rgidlist == NULL );
	}


void FaPkgInit()
{
    static int done = 1;
    if (!done) {
	done = 1;
	DqPkgInit();
	FaPkgInit();
	IoPkgInit();
	
	
	#ifdef DEBUG
	ErPLog ("Fa package initialized.\n");
	#endif
    }
}
