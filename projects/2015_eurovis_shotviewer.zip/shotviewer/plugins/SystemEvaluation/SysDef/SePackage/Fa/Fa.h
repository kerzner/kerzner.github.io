/*
	created:	92/07/01	G S Moss
	edited:		03/06/02	K Bowman
			added prototypes for FaBeReal() and FaBeEffective()
			because they are used by other files (corrected for
			SCR380)

	RCSid:  	$Id: Fa.h,v 1.51 2010/06/23 19:54:46 geoffs Exp $
*/
/**
	<Fa.h> -- MUVES "Fa" (File access) package I/F definitions

	The Fa package provides uniform controlled access to the MUVES data
	file hierarchy.  Naming conventions for all standard MUVES data files
	and configuration files are defined by this package.
**/
#ifndef Fa_H_INCLUDED
#define Fa_H_INCLUDED

#include <std.h>
#include <stdio.h>

#ifdef __linux__
#include <sys/param.h>
#include <sys/types.h>
#include <string.h>
#include <unistd.h>
#include <pwd.h>
#include <time.h>
#endif

#include <sys/stat.h>

#if STD_C
#include <stdarg.h>
#else
#include <varargs.h>
#endif
#include <dirent.h>

#include <Dq.h>


#ifndef L_cuserid
#define L_cuserid 9
#endif /* L_cuserid */

#define FaStrNULL (char *)NULL

/**
	Enumerate all input file types, serves as index to FaInputFiles[].

	typedef enum
		{
		FaITypeInvalid = -1,		// must be first
		FaITypeClassification,
		FaITypeComponentCategoryMap,
		FaITypeComponentProperty,
		FaITypeDamageEvaluationSelection,
		FaITypeEvaluationModuleCurve,
		FaITypeEnvironmentVariable,
		FaITypeMaterialProperty,
		FaITypeParameters,
		FaITypeReusableRay,
		FaITypeBlastCurve,
		FaITypeIndirectFireModuleCurve,
		FaITypeInteractionModuleCurve,
		FaITypeArmorPackage,
		FaITypeIndirectFireModuleSelection,
		FaITypeStateVector,
		FaITypeSystemDefinition,
		FaITypeTarget,
		FaITypeThreat,
		FaITypeViewSpecification,
		FaITypeViewInformation,
		FaITypeSentinel			// must be last
		}
	FaInputFileType;

	Associate FaDIRINPUTS subdirectory names, user-oriented names,
	and enumerated types.

	typedef struct
		{
		const char *dirname;
		const char *longname;
		}
	FaFileSpec FaInputFiles[FaITypeSentinel] =
		{
		{	FaDIRCLASSIF,	"classification markings" },
		{	FaDIRCATMAP,	"component category map" },
		{	FaDIRCMPROP,	"component property" },
		{	FaDIRDAMSEL,	"damage evaluation selection" },
		{	FaDIRECURVE,	"evaluation module curve" },
		{	FaDIRENV,	"environment variable" },
		{	FaDIRMATPROP,	"material property" },
		{	FaDIRPARAMS,	"parameters" },
		{	FaDIREUSRAY,	"reusable ray" },
		{	FaDIRBCURVE,	"blast curve" },
		{	FaDIRFCURVE,	"indirect fire module curve" },
		{	FaDIRICURVE,	"interaction module curve" },
		{	FaDIRPACK,	"armor packages" },
		{	FaDIRIFMSEL,	"indirect fire module selection" },
		{	FaDIRSTATES,	"state vector" },
		{	FaDIRSYSEXP,	"system definition" },
		{	FaDIRTARGET,	"target" },
		{	FaDIRTHREAT,	"threat" },
		{	FaDIRVIEW,	"view specification" }
		{	FaDIRVIF,	"view information files" }
		};

	Usage:
		for( i = 0; i < FaITypeSentinel; i++ )
			{
			dirname = FaInputFiles[i].dirname;
			longname = FaInputFiles[i].longname;
			}
		ccmap_dirname = FaInputFiles[FaITypeComponentCategoryMap].dirname;
		ccmap_longname = FaInputFiles[FaITypeComponentCategoryMap].longname;
**/
typedef struct {
    const char *dirname;
    const char *longname;
}
FaFileSpec;

typedef enum {
    FaITypeInvalid = -1,		/* must be first */
    FaITypeClassification,
    FaITypeComponentCategoryMap,
    FaITypeComponentProperty,
    FaITypeDamageEvaluationSelection,
    FaITypeEvaluationModuleCurve,
    FaITypeEnvironmentVariable,
    FaITypeMaterialProperty,
    FaITypeParameters,
    FaITypeReusableRay,
    FaITypeBlastCurve,
    FaITypeIndirectFireModuleCurve,
    FaITypeInteractionModuleCurve,
    FaITypeArmorPackage,
    FaITypeIndirectFireModuleSelection,
    FaITypeStateVector,
    FaITypeSystemDefinition,
    FaITypeTarget,
    FaITypeThreat,
    FaITypeViewSpecification,
    FaITypeViewInformation,
    FaITypeSentinel			/* must be last */
}
FaInputFileType;

extern FaFileSpec FaInputFiles[FaITypeSentinel];


/**
	Enumerate all output file types, serves as index to FaOutputFiles[].

	typedef enum
		{
		FaOTypeInvalid = -1,		// must be first
		FaOTypeSiv,
		FaOTypeSentinel			// must be last
		}
	FaOutputFileType;

	Associate FaDIRRESULTS subdirectory names, user-oriented names,
	and enumerated types.

	typedef struct
		{
		const char *dirname;
		const char *longname;
		}
	FaFileSpec FaOutputFiles[FaOTypeSentinel] =
		{
		{	FaDIRSIV,	"siv output files" },
		};

	Usage:
		for( i = 0; i < FaOTypeSentinel; i++ )
			{
			dirname = FaOutputFiles[i].dirname;
			longname = FaOutputFiles[i].longname;
			}
		iua_dirname = FaOutputFiles[FaOTypeIndividualUnitActionFile].dirname;
		iua_longname = FaOutputFiles[FaOTypeIndividualUnitActionFile].longname;
**/
typedef enum {
    FaOTypeInvalid = -1,		/* must be first */
    FaOTypeSiv,
    FaOTypeCxc,
    FaOTypePresFiles,
    FaOTypeSentinel			/* must be last */
}
FaOutputFileType;

extern FaFileSpec FaOutputFiles[FaOTypeSentinel];

/* Subdirectories under MUVES directory. */
#define FaDIRLIB	"lib"		/* MUVES lib directory */
#define FaDIRMETHOD	"lib/methods"	/* defined approx. methods */
#define FaDIRTMP	"tmp"		/* for temporary files */
#define FaDIRDATA	"data"		/* MUVES data directory */
#define FaDIRBIN	"bin"		/* stand-alone executables */

/* Subdirectories under FaDIRPROJEC/<project> directory. */
#define FaDIRSESSION	"sessions"	/* scripted MUVES runs */
#define FaDIRRESULTS	"results"	/* outputs */
#define FaDIRINPUTS	"inputs"	/* inputs */
#define FaDIRDUMPSTER	".dumpster"	/* "cut" files/directories */

/* Subdirectories of the FaDIRINPUTS directory. */
#define FaDIRAPATCH  "patch"	/* XXX -- not used */
#define FaDIRCLASSIF "classif"	/* classification marking files */
#define FaDIRCATMAP  "ccmap"	/* component category maps */
#define FaDIRCMPROP  "prop"	/* component property files */
#define FaDIRDAMSEL  "des"	/* damage evaluation selection files */
#define FaDIRECURVE  "ecurve"	/* evaluation module interpolation tables */
#define FaDIRENV     "environ"	/* environment variables */
#define FaDIRMATPROP "matprop"	/* material property files */
#define FaDIRPARAMS  "params"	/* parameter files */
#define FaDIREUSRAY  "ray"	/* reusable ray files */
#define FaDIRBCURVE  "bcurve"	/* blast curve files */
#define FaDIRFCURVE  "fcurve"	/* indirect-fire module (IFM) data tables */
#define FaDIRICURVE  "icurve"	/* interaction module interpolation tables */
#define FaDIRPACK    "pack"	/* armor package files */
#define FaDIRIFMSEL  "ifmsel"	/* IFM selection files */
#define FaDIRSTATES  "states"	/* state vector files */
#define FaDIRSYSEXP  "sysdef"	/* system definition expression files */
#define FaDIRTARGET  "target"	/* target data bases */
#define FaDIRTHREAT  "threat"	/* threat data bases */
#define FaDIRVIEW    "view"	/* view specifications */
#define FaDIRVIF     "vif"	/* view information files */

/* Subdirectories and files of the FaDIRRESULTS directory. */
#define FaDIRSIV     "Siv"	/* siv output files */
#define FaDIRCXC     "Cxc"	/* cellxcell output files */
#define FaDIRPFILES  "PressureFiles"	/* ABEL pressure data files */
#define FaTCLERROR   "._frtclerrors"  /* Tcl error output file */

/* Files under FaDIRTARGET/<target> directory. */
#define FaFILGEOM "geometry"	/* contains pointer to MGED file */
#define FaFILCOMP "comp"	/* maps component names to region ID */
#define FaFILHOST "host"	/* ray tracing host selection file */

/* Files under FaDIRLIB directory. */
#define FaFILCONFIG	"site.conf" /* specifies site-specific stuff */

/* Files under FaDIRMETHOD/<method> directory. */
#define FaFILMETHODS	"roster"  /* available methods */
#define FaFILMODKEYS	"modkeys" /* available modkey descriptions */

/* Files under FaDIRTHREAT/<threat> directory. */
#define FaFILRANGE	"range"

/* Files under FaDIRPROJEC/<project> directory. */
#define FaFILACCESSLIST	".access"	/* access list */

/* Files in FaDIRSESSION. */
#define FaFILVERSION	".version"	/* last version number */

/* Startup files in user's home directory. */
#define FaFILMUVESRC	".muvesrc"
#define FaFILXCELBROWRC	".xcellbrowserrc"

/* Subdirectories under UiDIRDATA directory. */
#define FaDIRPROJEC	"analysis"	/* project working directories */

/* Legal commands for access list file. */
#define FaA_LIST	"list"
#define FaA_OWNER	"owner"
#define FaA_READ	"read"
#define FaA_WRITE	"write"

/* Modal flags for file/directory name sorter (FaBldSortedList). */
#define FaF_NONE	0	/* no sorting */
#define FaF_AUTOMATIC	1	/* sort alphabetically, then by modtime */
#define FaF_MODTIME	2	/* sort by mod time */
#define FaF_ALPHABET	3	/* sort alphabetically */

/* Recognized file types for trie tree. */
#define FaFT_BOGUS	0
#define FaFT_PROJECT	1
#define FaFT_SESSIONS	2
#define FaFT_RESULTS	3
#define FaFT_INPUTS	4
#define FaFT_FRESULTS	5
#define FaFT_IRESULTS	6
#define FaFT_LOGFIL	7
#define FaFT_SESFIL	8
#define FaFT_ACCESS	9
#define FaFT_LOCK	10
#define FaFT_VERSION	11
#define FaFT_DCLASS	12
#define FaFT_DSTATES	20
#define FaFT_DCATMAP	21
#define FaFT_DCMPROP	22
#define FaFT_DDAMSEL	23
#define FaFT_DECURVE	24
#define FaFT_DFCURVE	25
#define FaFT_DICURVE	26
#define FaFT_DPACK	27
#define FaFT_DIFMSEL	28
#define FaFT_DREURAY	29
#define FaFT_DSYSDEF	30
#define FaFT_DTARGETS	31	/* FaDIRTARGETS */
#define FaFT_DTHREATS	32
#define FaFT_DVIEW	33
#define FaFT_DPATCH	34	/* (XXX) may go away */
#define FaFT_DENVIRON	35
#define FaFT_DMATPROP	36
#define FaFT_DPARAMS	37
#define FaFT_DVIF	38
#define FaFT_CLASS	39
#define FaFT_STATES	40
#define FaFT_CATMAP	41
#define FaFT_CMPROP	42
#define FaFT_DAMSEL	43
#define FaFT_ECURVE	44
#define FaFT_FCURVE	45
#define FaFT_ICURVE	46
#define FaFT_PACK	47
#define FaFT_IFMSEL	48
#define FaFT_REURAY	49
#define FaFT_SYSDEF	50
#define FaFT_TARGET	51	/* FaDIRTARGETS/<target> */
#define FaFT_THREAT	52
#define FaFT_VIEW	53
#define FaFT_PATCH	54	/* (XXX) may go away */
#define FaFT_TARFIL	55	/* FaDIRTARGETS/<target>/<file> */
#define FaFT_THRFIL	56
#define FaFT_DUMPDIR	57	/* dumpster directory */
#define FaFT_DUMPENTRY	58	/* dumpster entry */
#define FaFT_ENVIRON	59
#define FaFT_MATPROP	60
#define FaFT_PARAMS	61
#define FaFT_COMPRESS	62
#define FaFT_USRFRES	63	/* final results in non-MUVES directory */
#define FaFT_VIF	64
#define FaFT_DBCURVE	65
#define FaFT_BCURVE	66

#define FaFT_DSIV	67
#define FaFT_DCXC	68
#define FaFT_DPFILES	69
#define FaFT_CXC	70
#define FaFT_AVG	71
#define FaFT_IUA	72
#define FaFT_SUM	73
#define FaFT_TCL_ER	74

#define FaTG_TITLE    "title"	/* tag for title of session */

/* Legal keywords for FaFILCONFIG. */
#define FaK_ARCHIVEHOST		"archivehost"
#define FaK_DBSERVERHOST	"dbserverhost"

/* Names for bits in permission mode flag argument to access(2), etc. */
#define FaM_EXIST	0x0
#define FaM_EXEC	0x1
#define FaM_WRITE	0x2
#define FaM_READ	0x4
#define FaM_OWN		0x8	/* not used by access(2) */

/* Modal flags for denoting type of results file. */
#define FaR_INTRES	1	/* display intermediate results files */
#define FaR_FINRES	2	/* display final results files */
#define FaR_LOGRES	3

/* Formal names for RC file key words. */
#define FaRCBinCelLocs		"BinCellLocations"
#define FaRCBindKeyToFunc	"BindKeyToFunction"
#define FaRCCelSize		"TargetSpaceCellSize"
#define FaRCDispCelSize		"CellDisplaySize"
#define FaRCInterpColors	"InterpolateColors"
#define FaRCMenuItemsVis	"MenuItemsVisible"
#define FaRCMonitorAnalLog	"MonitorAnalysisLog"
#define FaRCMonochromeDisp	"MonochromeDisplay"
#define FaRCNumBins		"NumberOfBins"
#define FaRCMinBin		"MinimumBinValue"
#define FaRCMaxBin		"MaximumBinValue"
#define FaRCShoCelBorder	"ShowCellBorders"
#define FaRCShoColorKey		"ShowColorKey"
#define FaRCShoGrPlAxes		"ShowGridPlaneAxes"
#define FaRCShoNumericValue	"ShowNumericValue"
#define FaRCSpcBetCels		"SpaceBetweenCells"
#define FaRCTextLinesSaved	"TextLinesSaved"
#define FaRCUseFilledCells	"UseFilledCells"
#define FaRCUseRectangles	"UseRectangles"
#define FaRCUseSizeOfCell	"UseSizeOfCell"
#define FaRCXDisplay		"XWindowsDisplay"
#define FaRCWebBrowserCmd	"WebBrowserCommand"

/* Default values for variables that control user interface behavior.
   These defaults may be changed by directives in the user's RC file. */
#define FaDFL_VERBOSE	  mTrue
/* Defaults for FaP_XCELLBROWSER options. */
#define FaDFL_AXES	  mFalse	/* no grid plane axes shown */
#define FaDFL_BINCELLOCS  mFalse	/* show actual shot locations */
#define FaDFL_BLEND	  mFalse	/* do not interpolate colors */
/* The cell dimensions below must be set to zero so that they are not
   mistaken for user-configured defaults which would override computed
   values. */
#define FaDFL_HCELSZ      100.0	/* hor. cell dimensions in target units */
#define FaDFL_VCELSZ      100.0	/* vertical */
#define FaDFL_HEIGHT	  10	/* vertical cell dimensions in pixels */
#define FaDFL_WIDTH	  10	/* horizontal */
#define FaDFL_HSPACE	  1	/* hor. spacing between cells in pixels */
#define FaDFL_VSPACE	  1	/* vertical */
#define FaDFL_KEYCOLOR	  mTrue	/* display color key */
#define FaDFL_MONOCHROME  mFalse	/* do not use monochrome unless necessary */
#define FaDFL_NUMBINS	  11	/* historically, 11 bins have been used */
#define FaDFL_MINBIN	  -1	/* no default, if not specified, min value
will be calculated from data */
#define FaDFL_MAXBIN	  -1	/* no default, if not specified, max value
will be calculated from data */
#define FaDFL_SHOWBORDER  mFalse	/* do not show border of cells */
#define FaDFL_SHOWNUMERIC mFalse /* do not show numeric value of cells */
#define FaDFL_USEFILL	  mFalse	/* use filled cells */
#define FaDFL_USERECT	  mTrue	/* use rectangular cells */
#define FaDFL_USESIZE	  mTrue	/* size cells to show value */
#define FaDFL_BROWSER	  "netscape %s"	/* most popular WWW browser */

/* Suffixes for output files. */
#define FaSUF_FINRES	".fr"
#define FaSUF_INTRES	".ir"
#define FaSUF_LOGRES	".log"
#define FaSUF_IUA	".iua"
#define FaSUF_AVG	".avg"
#define FaSUF_SUM	".sum"
#define FaSUF_AUDIT	".as"

/* Suffixes for compressed output files. */
#define FaSUF_COMPRESS	".Z"

#define FaBUFLEN BUFSIZ
#define FaLINELEN 256
#define FaMAXTEXT	1000	/* maximum remembered text lines */
#define FaPATHLEN 256

/* Sane UNIX shell to use when executing programs. */
#ifndef FaP_SHELL
#define FaP_SHELL	"/bin/sh"
#endif

/* Default database/archive server to use. */
#ifndef FaP_DBSERVER
#define FaP_DBSERVER    "bin/dbserver"
#endif

/* X11 file browser */
#define FaP_XFILEBROWSER	"xfilebrowser"

/* MUVES back-end process (processes Ap key word input) */
#define FaP_MUVERAT	"muverat"

/* Post-processor executable names (found in $MUVES/bin). */
#define FaP_XCELLBROWSER "xcellbrowser"	/* cell-by-cell plot post-processor */
#define FaP_CBC "cellxcell" 		/* cell-by-cell file post-processor */
#define FaP_VAMP "siv"			/* VAMP-style file post-processor */

/* For use with Dx package. */
#ifndef FaP_RSH
#define FaP_RSH		"/usr/ucb/rsh"	/* UNIX remote shell utility */
#endif

/* For compressing/uncompressing archives. */
#ifndef FaP_COMPRESS
#define FaP_COMPRESS	"/usr/bsd/compress"
#endif
#ifndef FaP_UNCOMPRESS
#define FaP_UNCOMPRESS	"/usr/bsd/uncompress"
#endif

#ifndef FaP_MDQSBATCH
#define FaP_MDQSBATCH	"/usr/mdqs/bin/batch"	/* MDQS batch executable */
#endif

#ifndef FaP_HOSTNAME
#define FaP_HOSTNAME	"host"			/* hostname executable */
#endif

/* UNIX umasks to use so that file permissions get set right. */
#define FaUMASK         0007            /* world permissions off */
#define FaRESUMASK      (FaUMASK&0772)  /* world write bit off for results */

/* White-space characters seperating typical key word input tokens. */
#define FaWHITESPACE	" \t"

#define FaSafCopy(s1,s2) FaSafNCopy(s1,s2,sizeof(s1))

/* Convenience bit operations. */
#define FaBitSet(b,m)	( (m) |  (b))
#define FaBitClear(b,m)	( (m) & ~(b))
#define FaBitTest(b,m)	( (m) &  (b))

/* Used to pass args into FaMkDir(). */
typedef struct {
    const char *name;	/* Directory path name. */
    const char *desc;	/* User handle. */
    int umask;		/* UMASK to use when creating directory. */
    MuvesBool isuser;		/* Is this a user directory? */
}
FaDirSpec;

typedef struct {
    const char *title; /* description of file/directory type */
    int type;	   /* identifier for file/directory type */
    MuvesBool isdir;	   /* is entry a directory? */
    MuvesBool lockable;	   /* is entry needed for audit trail? */
    MuvesBool critical;	   /* is entry needed for project to be usable? */
}
FaFilInfo;

/* Node type for building directory listing sorted by mod times. */
typedef struct {
    DqNode link;
    time_t mtime;	/* time of last data modification */
    char *dname;	/* name of file */
    MuvesBool isdir;	/* is entry a directory? */
}
FaFilNode;

/* Trie tree node. */
typedef union trienode FaTriNode; /* incomplete forward reference */
union trienode {
    struct {	/* Internal nodes: datum is current letter. */
        FaTriNode *altp;	/* -> alternate letter node */
        FaTriNode *nextp;	/* -> next letter node */
        int curchr;		/* current letter */
    }
    n;
    struct {	/* Leaf nodes: datum is a file information node ptr. */
        FaTriNode *altp;	/* NULL -> alternate letter node */
        FaTriNode *nextp;	/* NULL -> next letter node */
        FaFilInfo *infop;	/* -> file information node */
    }
    l;
};

/**
	Default settings for behavior of the MUVES user interface and some
	of the postprocessors are stored in the FaGlobals structure.  Here
	we define supporting types.

	typedef struct
		{
		int h;	// horizontal measurement in pixels
		int v;  // vertical measurement in pixels
		}
	FaPixels;

	typedef struct
		{
		double wid;	// width in model coordinates
		double hgt;	// height in model coordinates
		}
	FaDimensions;

	typedef struct
		{
		MuvesBool bincells;	      // show randomized shots at center-of-cell
		MuvesBool cellszfromrc;    // cell size read from RC file
		MuvesBool interpcolors;    // interpolate colors
		MuvesBool monitoranalysis; // monitor the analysis log file
		MuvesBool monochrome;      // use black and white only
		MuvesBool showborder;      // display border of cells
		MuvesBool showcolorkey;    // display color key beneath image
		MuvesBool showgrid;        // display grid underlay
		MuvesBool shownumeric;     // display numeric value in cell
		MuvesBool usefill;         // use filled cells
		MuvesBool userect;         // use rectangular cells (not round)
		MuvesBool usesize;         // size cells to show value
		const char *display;  // name of X Windows display
		const char *browser;  // command to start up WWW browser
		FaDimensions cellsz;  // width and height of grid cell
		FaPixels celldispsz;  // display size of grid cell
		FaPixels cellspacing; // display spacing between grid cells
		int nbins;	      // number of bins for values
		double minbinval;     // minimum bin value
		double maxbinval;     // maximum bin value
		}
	FaDefaults;

	This is the top-level structure for accessing Fa pkg globals.

	typedef struct
		{
		int rgid;		// real (user's) GID
		int ruid;		// real (user's) UID
		int rumask;		// real (user's) umask
		int egid;		// effective GID
		int euid;		// effective UID
		int eumask;		// effective umask
		int ngroups;		// number of groups user is in
		gid_t *rgidlist;	// dymamic array of "ngroup" group IDs
		char user[L_cuserid];	// user's login name
		char *path;	// value of PATH environment variable
		char *homedir;	// absolute path name to user's home directory
		char *workdir;	// absolute path name to current working dir.
		char *rootdir;	// absolute path name to top MUVES directory
		char *analdir;	// absolute path name to analysis directory
		char *tempdir;	// absolute path name to scratch directory
		FaTriNode *catalog;	// pointer to directory catalogue
		FaDefaults defaults;	// default UI settings
		}
	FaInfo FaGlobals;
**/

typedef struct {
    int h;
    int v;
}
FaPixels;

typedef struct {
    double wid;
    double hgt;
}
FaDimensions;

typedef struct {
    MuvesBool bincells;
    MuvesBool cellszfromrc;
    MuvesBool interpcolors;
    MuvesBool monitoranalysis;
    MuvesBool monochrome;
    MuvesBool showborder;
    MuvesBool showcolorkey;
    MuvesBool showgrid;
    MuvesBool shownumeric;
    MuvesBool usefill;
    MuvesBool userect;
    MuvesBool usesize;
    const char *display;
    const char *browser;
    FaDimensions cellsz;
    FaPixels celldispsz;
    FaPixels cellspacing;
    int nbins;
    double minbinval;
    double maxbinval;
}
FaDefaults;

/* File access information, returned by FaInit(). */
typedef struct {
    int rgid;		/* real (user's) GID */
    int ruid;		/* real (user's) UID */
    int rumask;		/* real (user's) umask */
#if defined(MUVES_USER_ENABLE)
    int egid;		/* effective GID */
    int euid;		/* effective UID */
    int eumask;		/* effective umask */
#endif
    int ngroups;		/* number of groups user is in */
    gid_t *rgidlist;	/* dymamic array of "ngroup" group IDs */
    char user[L_cuserid];	/* user's login name */
    char *path;		/* value of PATH environment variable */
    char *homedir;		/* absolute path name to user home directory */
    char *workdir;		/* absolute path name to current working dir. */
    char *rootdir;		/* absolute path name to top MUVES directory */
    char *analdir;		/* absolute path name to analysis directory */
    char *tempdir;		/* absolute path name to scratch directory */
    FaTriNode *catalog;	/* pointer to root of directory catalogue */
    FaDefaults defaults;	/* default UI settings */
}
FaInfo;

typedef struct {
    char *runfile;		/* name of run file (portion of session) */
    char *archfile;		/* name of actual archive to be saved */
    char *hostname;		/* name of local host */
    char *archhost;		/* name of remote host where archive goes */
    char *timestamp;	/* time stamp from F. R. file */
    char *user;		/* user name from F. R. file */
    char *project;		/* project name */
    long ses;		/* session number */
    long run;		/* run number */
    char *target;		/* target name */
    char **threats;		/* NULL-terminated array of threat names. */
}
FaDbInfoNode;

/*	Node type for FaAddQueue() and FaDelQueue().

	typedef struct
		{
		DqNode link;
		char *pathname; // relative path name to file
		}
	FaDelNode;
*/
typedef struct {
    DqNode link;
    char *pathname;
}
FaDelNode;

/* Advertised function declarations. */
#if STD_C
extern MuvesBool FaAccess( const char *pth, unsigned short md, MuvesBool isus, MuvesBool rep );
extern MuvesBool FaAddQueue( DqNode *dq, const char *name );
extern MuvesBool FaArchive( DqNode *qp, FaDbInfoNode *info, long *id );
#if defined(MUVES_USER_ENABLE)
extern MuvesBool FaBeUnReal( void );
#endif
extern MuvesBool FaBldSortedList( const char *path, DqNode **qpp, int cmpflag, int *nfiles );
extern MuvesBool FaCpData( FILE *rfp, FILE *wfp );
extern MuvesBool FaCpFile( const char *, MuvesBool, const char *, MuvesBool );
extern MuvesBool FaFClose( const char *name, FILE *fp, MuvesBool isuser );
extern MuvesBool FaFUnLock( FILE *fp );
extern MuvesBool FaEmptyDir( const char *name );
extern MuvesBool FaIsDir( const char *pathname );
extern MuvesBool FaIsLockable( const char *pathname );
extern MuvesBool FaIsRemovable( const char *dirname, const char *filename );
extern MuvesBool FaIsUserFile( const char *name );
extern MuvesBool FaLink( const char *to, const char *from, MuvesBool isuser );
extern MuvesBool FaMkAccessList( const char *projpath );
extern MuvesBool FaMkDir( const char *rootdir, FaDirSpec *dirspecp );
extern MuvesBool FaMkLockAdmFile( const char *projpath );
extern MuvesBool FaOpnQueue( DqNode **qpp, const char *funcname );
extern MuvesBool FaRmDir( const char *name, MuvesBool isuser, MuvesBool report );
extern MuvesBool FaRmDirHierarchy( const char *name, MuvesBool isuser, MuvesBool report );
extern MuvesBool FaUnlink( const char *name, MuvesBool isuser );
extern MuvesBool FaUStat( const char *pat, struct stat *stat, MuvesBool isuse, MuvesBool rep );
extern bs_type FaLkExpendable( const char *project, const char *pathname );
extern const char *FaDirCat( const char *s1, const char *s2 );
extern const char *FaGetArchiveHost( void );
extern const char *FaGetDbServerHost( void );
extern const char *FaTrunkName( const char *filepath );
extern DIR *FaOpnDir( const char *name, MuvesBool isuser, MuvesBool report );
extern struct dirent *FaRdDir( DIR *dirp );
extern FaTriNode *FaAddTrie( const char *name, FaTriNode **triepp );
extern FaFilInfo *FaDelTrie( const char *name, FaTriNode **triepp );
extern FaFilInfo *FaFilGetInfo( const char *projpath );
extern FaInfo *FaInit( const char *workdir );
extern FILE *FaOpnUserFile( const char *, const char *, MuvesBool, MuvesBool );
extern int FaCkAccess( const char *projpath );
#if defined(MUVES_USER_ENABLE)
extern void FaBeForReal( void );
#endif
extern void FaDelQueue( DqNode *dq );
extern void FaFreInfo( FaFilInfo *infop );
extern void FaLsFile( const char *path );
extern void FaRCReadFile( const char *filname );
extern void FaRegisterErrorFunc( void (*func)(const char *fmt, va_list ap) );
extern void FaRegisterNotifyFunc( void (*func)(const char *fmt, va_list ap) );
extern void FaPrAccess( const char *projpath );
extern void FaProtect( DqNode *qp, const char *lockfil );
extern void FaPrtTrie( const FaTriNode *triep, int level );
extern void FaUnprotect( DqNode *qp, const char *lockfil );
extern void FaVNotify( const char *format, ... );
#else
extern MuvesBool FaAccess();
extern MuvesBool FaAddQueue();
extern MuvesBool FaArchive();
#if defined(MUVES_USER_ENABLE)
extern MuvesBool FaBeUnReal();
#endif
extern MuvesBool FaBldSortedList();
extern MuvesBool FaCpData();
extern MuvesBool FaCpFile();
extern MuvesBool FaFClose();
extern MuvesBool FaFUnLock();
extern MuvesBool FaEmptyDir();
extern MuvesBool FaIsDir();
extern MuvesBool FaIsLockable();
extern MuvesBool FaIsRemovable();
extern MuvesBool FaIsUserFile();
extern MuvesBool FaLink();
extern MuvesBool FaMkAccessList();
extern MuvesBool FaMkDir();
extern MuvesBool FaMkLockAdmFile();
extern MuvesBool FaOpnQueue();
extern MuvesBool FaRmDir();
extern MuvesBool FaRmDirHierarchy();
extern MuvesBool FaUnlink();
extern MuvesBool FaUStat();
extern bs_type FaLkExpendable();
extern const char *FaDirCat();
extern const char *FaGetArchiveHost();
extern const char *FaGetDbServerHost();
extern const char *FaTrunkName();
extern DIR *FaOpnDir();
extern struct dirent *FaRdDir();
extern FaTriNode *FaAddTrie();
extern FaFilInfo *FaDelTrie();
extern FaFilInfo *FaFilGetInfo();
extern FaInfo *FaInit();
extern FILE *FaOpnUserFile();
extern int FaCkAccess();
#if defined(MUVES_USER_ENABLE)
extern void FaBeForReal();
#endif
extern void FaDelQueue();
extern void FaFreInfo();
extern void FaRCReadFile();
extern void FaRegisterErrorFunc();
extern void FaRegisterNotifyFunc();
extern void FaPrAccess();
extern void FaLsFile();
extern void FaProtect();
extern void FaPrtTrie();
extern void FaUnprotect();
extern void FaVNotify();
#endif

extern FaInfo FaGlobals; /* package global vars */

/* Private function declarations. */
#if STD_C
extern MuvesBool FaBldDirList( const char *path, DqNode **qpp, MuvesBool isuser );
extern const char *FaBaseName( const char *pathname );
extern const char *FaGetTag( const char *file, const char *tag, MuvesBool imbedded );
extern void FaErPrt( const char *format, ... );
extern void FaFreTrie( FaTriNode **triepp );
extern void FaMmFail( const char *funcname );
extern void FaSafNCopy( char *s1, const char *s2, unsigned n );
extern void FaSysErPrt( MuvesBool errnoset, const char *format, ... );
#else
extern MuvesBool FaBldDirList();
extern const char *FaBaseName();
extern const char *FaGetTag();
extern void FaErPrt();
extern void FaFreTrie();
extern void FaMmFail();
extern void FaSafNCopy();
extern void FaSysErPrt();
#endif

#if STD_C
extern MuvesBool FaIsResultsFileName( const char *name, int flag );
extern MuvesBool FaIsSessionFileName( const char *name );
extern void FaFree(void);
#else
extern MuvesBool FaIsResultsFileName( );
extern MuvesBool FaIsSessionFileName( );
extern void FaFree();
#endif

/* Private global variable declarations. */
extern char FaScratch[];	/* temporary storage for building strings */

/* 03-06-02 kb: added the following two prototypes */
#if defined(MUVES_USER_ENABLE)
extern void FaBeReal();
extern void FaBeEffective();
#endif
extern void FaPkgInit();

#endif /* Fa_H_INCLUDED */
