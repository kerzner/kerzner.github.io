/*******************************************************************************
* RnTcl.c  MUVES "Rn" (random) package TCL interface routines
*
* Contents:
*   rn_tcl_init()     initialize the Rn package TCL interface
*   rn_tcl_help()     display Rn package TCL command help information
*   rn_tcl_seed()     seed the random number package
*   rn_tcl_uniform()  generate an uniform distributed random number
*   rn_tcl_normal()   generate an normal distributed random number
*
* Created:  01/02/16  C Hunt III
* Edited:   03/06/02  K Bowman
*           changed include <strings.h> to <string.h> so that correct
*           definitions are included (corrected for SCR380)
*******************************************************************************/
#ifndef lint
static char RCSid[] = "$Id: RnTcl.c,v 1.2 2003/06/07 03:37:03 chunt Exp $";
#endif

#include <stdio.h>
#include <string.h>  /* 03-06-02 kb: changed from strings.h */
#include <stdlib.h>
#include <tcl.h>
#include <tk.h>

#include <Rn.h>


/*
#include <math.h>
#include <std.h>
#include <Er.h>
#include <Dq.h>
#include <Se.h>
#include <FrSelect.h>
#include <Vm.h>
*/

/* tcl command function prototypes */

int rn_tcl_help(ClientData clientData, Tcl_Interp *interp, int objc,
	Tcl_Obj *const objv[]);

int rn_tcl_seed(ClientData clientData, Tcl_Interp *interp, int objc,
	Tcl_Obj *const objv[]);

int rn_tcl_uniform(ClientData clientData, Tcl_Interp *interp, int objc,
	Tcl_Obj *const objv[]);

int rn_tcl_normal(ClientData clientData, Tcl_Interp *interp, int objc,
	Tcl_Obj *const objv[]);


static struct tclcmd {
	char *cmdName;
	int (*cmdFunc)();
	char *cmdDesc;
}  tcl_cmds[] = {
	"rn_help", rn_tcl_help,	
		"Prints this help message.",
	"rn_seed", rn_tcl_seed,
		"Seeds the random number package",
	"rn_uniform", rn_tcl_uniform,
		"Returns uniform distributed random number from low to high",
	"rn_normal", rn_tcl_normal,
		"Returns normal distributed random number for mu and sigma",
	(char *)0, (int (*)())0, (char *)NULL
};


/*******************************************************************************
* rn_tcl_init()  initialize the Rn package TCL interface
*
* Arguments:
*   interp   pointer to the TCL interpreter information structure
*
* Returns: TCL_OK if successful, TCL_ERROR if not
*******************************************************************************/

int
rn_tcl_init(Tcl_Interp *interp)
{
	struct tclcmd *tclcp;

	if (Tcl_PkgProvide(interp, "RnSupport", TCL_VERSION) == TCL_ERROR) {
		return TCL_ERROR;
	}

	for (tclcp = tcl_cmds; tclcp->cmdName != (char *)0; ++tclcp) {
		Tcl_CreateObjCommand(interp, tclcp->cmdName, tclcp->cmdFunc,
			(ClientData)NULL, (Tcl_CmdDeleteProc *)NULL);
	}

	return TCL_OK;

}  /* rn_tcl_init() */


/*******************************************************************************
* rn_tcl_help()  display Rn package TCL command help information
*	
* Arguments:
*   clientData   client data
*   interp       pointer to the TCL interpreter information structure
*   objc         command argument object count
*   objv         pointer to an array of argument object pointers
*
* Returns: TCL_OK
*******************************************************************************/

int
rn_tcl_help(ClientData clientData, Tcl_Interp *interp, int objc,
	Tcl_Obj *const objv[])
{
	struct tclcmd *tclcp;

	Tcl_AppendResult(interp, "\nAvailable commands in the RnTcl package:\n"
		"(for individual command usage, use -help with command)\n\n",
		(char *)NULL);

	for (tclcp = tcl_cmds; tclcp->cmdName != (char *)0; ++tclcp) {
		Tcl_AppendResult(interp, "    ", tclcp->cmdName, " -- \n\t",
			tclcp->cmdDesc, "\n", (char *)NULL);
	}

	return TCL_OK;

}  /* rn_tcl_help */


/*******************************************************************************
* rn_tcl_seed()  seed the random number package
*	
* Arguments:
*   clientData   client data
*   interp       pointer to the TCL interpreter information structure
*   objc         command argument object count
*   objv         pointer to an array of argument object pointers
*
* Returns: TCL_OK if successful, TCL_ERROR if error
*******************************************************************************/

int
rn_tcl_seed(ClientData clientData, Tcl_Interp *interp, int objc,
	Tcl_Obj *const objv[])
{
	Tcl_Obj *resultPtr;  /* pointer to result object */
	int error;           /* error return status variable */
	int seed;            /* seed value */

	if (objc != 2 || objc > 1 && StrEq(Tcl_GetString(objv[1]), "-help")) {
		Tcl_SetResult(interp, "usage: rn_seed seed", TCL_STATIC);
		return TCL_ERROR;
	}

	error = Tcl_GetIntFromObj(interp, objv[1], &seed);
	if (error != TCL_OK) {
		return error;
	}

	RnSeed((unsigned long)seed);

	return TCL_OK;

}  /* rn_tcl_seed() */


/*******************************************************************************
* rn_tcl_uniform()  generate an uniform distributed random number
*	
* Arguments:
*   clientData   client data
*   interp       pointer to the TCL interpreter information structure
*   objc         command argument object count
*   objv         pointer to an array of argument object pointers
*
* Returns: TCL_OK if successful, TCL_ERROR if error
*******************************************************************************/

int
rn_tcl_uniform(ClientData clientData, Tcl_Interp *interp, int objc,
	Tcl_Obj *const objv[])
{
	Tcl_Obj *resultPtr;  /* pointer to result object */
	int error;           /* error return status variable */
	double low;          /* low value for random range */
	double high;         /* high value for random range */
	double uniform;      /* a uniform random number */

	if (objc != 3 || objc > 1 && StrEq(Tcl_GetString(objv[1]), "-help")) {
		Tcl_SetResult(interp, "usage: rn_uniform low high", TCL_STATIC);
		return TCL_ERROR;
	}

	error = Tcl_GetDoubleFromObj(interp, objv[1], &low);
	if (error != TCL_OK) {
		return error;
	}

	error = Tcl_GetDoubleFromObj(interp, objv[2], &high);
	if (error != TCL_OK) {
		return error;
	}

	uniform = RnUniform(0, low, high);

	resultPtr = Tcl_GetObjResult(interp);
	Tcl_SetDoubleObj(resultPtr, uniform);
	return TCL_OK;

}  /* rn_tcl_uniform() */


/*******************************************************************************
* rn_tcl_normal()  generate an normal distributed random number
*	
* Arguments:
*   clientData   client data
*   interp       pointer to the TCL interpreter information structure
*   objc         command argument object count
*   objv         pointer to an array of argument object pointers
*
* Returns: TCL_OK if successful, TCL_ERROR if error
*******************************************************************************/

int
rn_tcl_normal(ClientData clientData, Tcl_Interp *interp, int objc,
	Tcl_Obj *const objv[])
{
	Tcl_Obj *resultPtr;  /* pointer to result object */
	int error;           /* error return status variable */
	double mu;           /* mu value for normal distribution */
	double sigma;        /* sigma value for normal distribution */
	double normal;       /* a normal random number */

	if (objc != 3 || objc > 1 && StrEq(Tcl_GetString(objv[1]), "-help")) {
		Tcl_SetResult(interp, "usage: rn_normal mu sigma", TCL_STATIC);
		return TCL_ERROR;
	}

	error = Tcl_GetDoubleFromObj(interp, objv[1], &mu);
	if (error != TCL_OK) {
		return error;
	}

	error = Tcl_GetDoubleFromObj(interp, objv[1], &sigma);
	if (error != TCL_OK) {
		return error;
	}

	normal = RnNorm(0, mu, sigma);

	resultPtr = Tcl_GetObjResult(interp);
	Tcl_SetDoubleObj(resultPtr, normal);
	return TCL_OK;

}  /* rn_tcl_normal() */


/* RnTcl.c */
