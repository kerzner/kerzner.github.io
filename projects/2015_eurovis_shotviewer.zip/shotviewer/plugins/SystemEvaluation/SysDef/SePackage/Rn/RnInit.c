/*
	RnInit -- randomly initialize (seed) random number generators

	created:	86/01/04	D A Gwyn
 */
#ifndef lint
static char RCSid[] = "$Id: RnInit.c,v 1.6 2000/10/16 14:32:34 rbowers Exp $";

#endif

#ifdef CTRACE
#include	<stdio.h>		/* for _iob; see ../Make.conf CTFLAGS */
#endif

#include	<std.h>			/* for STD_C */

#if STD_C
#include	<time.h>

extern int	getpid( void );
#else
typedef long	time_t;

extern int	getpid();
extern time_t	time();
#endif

#include	<Rn.h>

/**
	void RnInit(void)
	
	RnInit() devises a "truly random" (i.e., nonreproducible) seed
	and uses it to initialize the pseudo-random number generator.
	This should be called before using any of the other
	functions in this package, unless reproducible sequences are
	desired (as they may be during testing).
**/

void
#if STD_C
RnInit( void )
#else
RnInit()
#endif
	{
	RnSeed( (unsigned long)time( (time_t *)NULL )
	      ^ (unsigned long)getpid() );
	}


void RnPkgInit() 
{
    static int done = 0;
    if (!done) {
	done = 1;
	/* no packages included.*/
	#ifdef DEBUG
	ErPLog("Rn package initialized.\n");
	#endif
    }
}
