/*
	RnDblExp - Double Exponential Distribution

	created:	97/02/06	J. Yi
*/
#ifndef lint
static char RCSid[] = "$Id: RnDblExp.c,v 1.2 1999/04/27 15:19:20 mjo Exp $";
#endif

#ifndef DEBUG
#define NDEBUG
#endif

#include <std.h>
#include <math.h>
#include <assert.h>
#include "Rn.h"

/**
	double RnDblExp ( RnStreamSelect stream, double a, double b )

	Use distribution formula shown by:
	if draw is > 0.5 return a - b * log ( U() )
	otherwise  return a + b * log ( U() )
**/

double 
#if STD_C
RnDblExp ( RnStreamSelect stream, double a, double b )   /* DblExp Distribution */
#else
RnDblExp ( stream, a, b )   
RnStreamSelect stream;
double a;
double b;
#endif
	{
		assert ( b > 0. );
		if ( Unif() > 0.5 )
			return a - b * log ( Unif() );
		else
			return a + b * log ( Unif() );
	}
