/*
	RnUserSpecified - UserSpecified Distribution

	created:	97/02/06	J. Yi

Algorithm:

	Use distribution formula shown by:
*/
#ifndef lint
static char RCSid[] = "$Id: RnUserSpecified.c,v 1.4 1999/04/27 15:19:25 mjo Exp $";
#endif

#ifndef DEBUG
#define NDEBUG
#endif

#include <std.h>
#include <math.h>
#include <assert.h>
#include "Rn.h"

/**
	double RnUserSpecified ( double ( *usf ) ( double, double, double ),
	double xMin, double xMax, double yMin, double yMax )

	A random number is generated using the function passed into it.
**/

double 
#if STD_C
RnUserSpecified ( double ( *usf ) ( double, double, double ), 
	double xMin, double xMax, double yMin, double yMax )
#else
RnUserSpecified ( usf, xMin, xMax, yMin, yMax )
double ( *usf ) ();
double xMin;
double xMax;
double yMin;
double yMax;
#endif
      {
         double x, y, areaMax = ( xMax - xMin ) * ( yMax - yMin );
         
         assert ( xMin < xMax && yMin < yMax );
         
      /* acceptance-rejection method */

         do {
            x = RnUniform ( (RnStreamSelect)0, 0.0, areaMax ) / ( yMax - yMin ) + xMin;
            y = RnUniform ( (RnStreamSelect)0, yMin, yMax );
         } while ( y > usf ( x, xMin, xMax ) );
         return x;
      }
