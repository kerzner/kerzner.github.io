/*
	RnErlang - Erlang Distribution

	created:	95/05/14	B. Mermagen

	The erlang random variate is the sum of c exponentially distributed
	random variates, each with mean b.
*/
#ifndef lint
static char RCSid[] = "$Id: RnErlang.c,v 1.6 1999/04/27 15:19:21 mjo Exp $";
#endif

#ifndef DEBUG
#define NDEBUG
#endif
 
#include <math.h>
#include <assert.h>
#include "Rn.h"

/**
        double RnErlang ( RnStreamSelect stream, double b, int c )

        The erlang random variate is the sum of c exponentially
        distributed random variates, each with mean b.
**/

#if STD_C
double RnErlang ( RnStreamSelect stream, double b, int c )
#else
double RnErlang ( stream, b, c )   /* Erlang Distribution */
	RnStreamSelect stream;
	double b;
	double c;
#endif
	{
	int i;
	double prod;

	assert ( b > 0. && c >= 1 );

	for ( i = 0, prod = 1.; i < c; i++ )
		prod *= Unif();

	return -b * log ( prod );
	}
