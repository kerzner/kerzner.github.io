/*
	RnDisEmp --  Discrete Empirical Distribution

	created:	95/05/14	B. Mermagen
*/
#ifndef lint
static char RCSid[] = "$Id: RnDisEmp.c,v 1.7 1999/04/27 15:19:20 mjo Exp $";
#endif

#ifndef DEBUG
#define NDEBUG
#endif

#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include "Rn.h"

#define N 100   /* maximum number of empirical data pairs */

/**
        int RnDisEmp ( RnStreamSelect stream, char *inname, int disempflag )

        Requires an input file "empiricalDiscrete" of probability
        density data pairs.
        The number of data pairs is not to exceed the constantN.
**/

#if STD_C
int RnDisEmp ( RnStreamSelect stream, char *inname, int disempflag )
#else
int RnDisEmp ( stream, inname, disempflag)   /* Discrete Empirical Distribution */
RnStreamSelect stream;
char *inname;
int disempflag;
#endif
	{
	static FILE *in;
	float p;
	int i;
	static int k[N];           /* integer data points */
	static float f[N], F[N];   /* probability density & cumulative distribution*/
	static int n = 0;          /* actual number of data pairs */

	if ( !disempflag ) 
		{
		if ( ( in = fopen ( inname, "r" ) ) == NULL ) 
			{
			printf ( "Can't open %s \"empiricalDiscrete\" input file\n",inname );
			exit(1);
		}

		while ( fscanf ( in, "%d %f", &k[n], &f[n] ) != EOF ) 
			{
			if ( n < N )  n++;
			else 
				{
			printf ( "Arrays are too small to hold all data pairs " ); 
			printf ( "in \"empiricalDiscrete\" file.\n" );
			printf ( "The current maximum number is %d.\n", N );
			exit(1);
				 }
			}
		disempflag = 1; /* flag that data has been correctly read in */
		fclose ( in );
		} /* if */

	/* form the cumulative distribution */

	F[0] = f[0];
	for ( i = 1; i <= n; i++ )
		F[i] = F[i-1] + f[i];

	/* check that the integer points are in ascending order */
	/* and that the cumulative distribution has a maximum of 1. */

	for ( i = 1; i <  n; i++ ) 
		assert ( k[i-1] < k[i] );
	assert ( F[n-1] == 1.0 );

	p = Unif();
	for ( i = 1; i < n; i++ )
		if ( F[i-1] <= p && p < F[i] )
			return k[i];

	return k[n-1];
	}
