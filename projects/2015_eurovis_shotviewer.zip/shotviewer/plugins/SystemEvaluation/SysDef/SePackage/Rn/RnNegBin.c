/*
	RnNegBin -- Negative Binomial Distribution

	created:	95/05/14	B. Mermagen
*/
#ifndef lint
static char RCSid[] = "$Id: RnNegBin.c,v 1.6 1999/04/27 15:19:23 mjo Exp $";
#endif

#ifndef DEBUG
#define NDEBUG
#endif

#include <assert.h>
#include "Rn.h"

/**
        int RnNegBin ( RnStreamSelect stream, double p, int n )

        This routine computes the sum of independent geometric random
        variables.
**/

#ifdef STD_C
int RnNegBin ( RnStreamSelect stream, double p, int n )   /* Negative Binomial Dist */
#else
int RnNegBin ( stream, p, n )   /* Negative Binomial Dist */
	RnStreamSelect stream;
	double p;
	int n;
#endif
	{
	int i, sum;

	assert ( n >= 1 );

	for ( i = 0, sum = 0; i < n; i++ )
		sum += RnGeometric ( stream, p );

	return sum;
	}
