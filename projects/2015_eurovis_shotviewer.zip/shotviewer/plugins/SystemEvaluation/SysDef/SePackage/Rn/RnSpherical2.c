/*
	RnSpherical2 -- Uniform Spherical Distribution

	created:	05/03/08	A. Ross
			created to hold new function RnShperical2() for SCR518
*/
#ifndef lint
static char RCSid[] = "$Id: RnSpherical2.c,v 1.2 2010/11/03 17:06:36 cmurray Exp $";
#endif

#ifndef DEBUG
#define NDEBUG
#endif

#include <math.h>
#include <assert.h>
#include "Rn.h"

/**
        th_ph_ps RnSpherical2 ( RnStreamSelect stream, double pitch, double yaw,
                                double cone_min, double cone_max )

        Generates Uniform distribution of angles (radians) over the
        unit sphere. th == pitch, ph == yaw, ps == roll.
**/

#ifdef STD_C
th_ph_ps RnSpherical2 ( RnStreamSelect stream, double pitch, double yaw,
	double roll, double cone_min, double cone_max, double s_roll )
					        /* Spherical Distribution */
#else
th_ph_ps RnSpherical2 ( stream, pitch, yaw, roll, cone_min, cone_max, s_roll )   /* Spherical Distribution */
RnStreamSelect stream;
double pitch;
double yaw;
double roll;
double cone_min;
double cone_max;
double s_roll;
#endif
{
	th_ph_ps p;		/* return values */
	double s, t;		/* polar coordinates */
	double x, y, z;		/* temporary variables */

	assert(-M_PI <= pitch && pitch <= M_PI);
	assert(-M_PI/2 <= yaw && yaw <= M_PI/2);
	/*  assert(-M_PI <= roll && roll <= M_PI); **may require an scr**/
	assert(0 <= cone_min && cone_min <= cone_max && cone_max <= M_PI);
	assert(0 <= s_roll && s_roll <= M_PI);

	if (cone_max == 0.0)
	{
		p.th = pitch;
		p.ph = yaw;
	}
	else if (cone_min == 0.0 && cone_max == M_PI)
	{
		p.th = RnUniform(stream, -M_PI, M_PI);
		p.ph = asin(RnUniform(stream, -1, 1));
	}
	else
	{
		s = RnUniform(stream, -M_PI, M_PI);
		t = acos(RnUniform(stream, cos(cone_max), cos(cone_min)));

		x = cos(yaw) * cos(s) * sin(t) + sin(yaw) * cos(t);
		y = -sin(pitch) * sin(yaw) * cos(s) * sin(t)
			- cos(pitch) * sin(s) * sin(t)
			+ sin(pitch) * cos(yaw) * cos(t);
		z = -cos(pitch) * sin(yaw) * cos(s) * sin(t)
			+ sin(pitch) * sin(s) * sin(t)
			+ cos(pitch) * cos(yaw) * cos(t);

		p.th = atan2(y, z);
		p.ph = asin(x);
	}

	if (s_roll != 0)
	{
  		p.ps = RnUniform(stream, roll - s_roll, roll + s_roll);
	}
	else
	{
		p.ps = roll;
	}

	return p;
}
