/*
	RnUnif -- uniform random floating-point number in range [0,1)

	created:	90/02/08	D A Gwyn
 */
#ifndef lint
static char RCSid[] = "$Id: RnUnif.c,v 1.4 1999/04/27 15:19:25 mjo Exp $";
#endif

#ifdef CTRACE
#include	<stdio.h>		/* for _iob; see ../Make.conf CTFLAGS */
#endif

#include	<std.h>			/* for STD_C */

#include	<Rn.h>

/*
	RnUnif( RnStreamSelect stream ) returns a floating-point random number
	distributed uniformly over the range 0.0 (inclusive) to 1.0 (exclusive),
	with 15 bits of resolution.
 */

double
#if STD_C
RnUnif( RnStreamSelect stream )
#else
RnUnif( stream )
RnStreamSelect stream;
#endif
	{
	return (double)RnRand( stream ) / (double)((unsigned)RnRAND_MAX + 1);
	}
