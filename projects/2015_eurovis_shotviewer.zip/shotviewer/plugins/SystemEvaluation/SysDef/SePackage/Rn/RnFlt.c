/*
	RnFlt -- uniform random floating-point number in given range

	created:	86/01/04	D A Gwyn
 */
#ifndef lint
static char RCSid[] = "$Id: RnFlt.c,v 1.6 1999/04/27 15:19:21 mjo Exp $";
#endif

#ifndef DEBUG
#define	NDEBUG
#endif

#include	<assert.h>
#ifdef CTRACE
#include	<stdio.h>		/* for _iob; see ../Make.conf CTFLAGS */
#endif

#include	<std.h>			/* for STD_C */

#include	<Rn.h>

/**
	double RnFlt( RnStreamSelect stream, double min, double max )

	RnFlt() returns a floating-point random number greater than or
	equal to the minimum value and less than the maximum value,
	distributed uniformly over the range of possible values, with
	15 bits of resolution.
**/

double
#if STD_C
RnFlt( RnStreamSelect stream, double min, double max )
#else
RnFlt( stream, min, max )
	RnStreamSelect stream;
	double	min, max;		/* desired range */
#endif
	{
	/* Note: this function computes a sensible result even if min > max */

	return min + (max - min) * RnUnif( stream );
	}
