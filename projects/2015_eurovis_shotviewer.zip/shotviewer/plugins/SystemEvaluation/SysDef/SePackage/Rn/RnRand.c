/*
	RnRand -- portable pseudo-random number generator

	created:	90/02/08	D A Gwyn
	edited:		03/06/05	C Hunt
			added 'U' to constant to eliminate 'decimal constant is
			so large that it is unsigned' compiler warning in
			RnSetStreamSeeds()
*/
#ifndef lint
static char RCSid[] = "$Id: RnRand.c,v 1.9 2010/06/23 19:54:50 geoffs Exp $";
#endif

#ifndef DEBUG
#define	NDEBUG
#endif

#include	<assert.h>
#ifdef CTRACE
#include	<stdio.h>		/* for _iob; see ../Make.conf CTFLAGS */
#endif

#include	<math.h>

#include	<std.h>			/* for STD_C */

#include	<Rn.h>

#ifndef	STATIC
#define	STATIC	static
#endif

const char *RnStreamName[] =
	{
	"ShotPattern",
	"Cluster",
	"ShotAssessment",
	"BAD",
	"Stream5",
	"Stream6",
	"Stream7",
	"Stream8",
	};

STATIC unsigned long	RnNext = 1;	/* current RNG state information */
STATIC RnStream		RNGStream[RnMAX_STREAMS]; /* current RNG stream states */
MuvesBool RnAlreadySeeded = mFalse; /* stops reseed by iteration seed */

#ifdef DEBUG
/*
	RnPrintStreamStats() - this function prints stream hit statistics. This
				function exist only in debug mode.
*/

void
RnPrintStreamStats()
	{	int i;

	ErPLog( "RNG Stream Statistics\n");
	for(i=0;i<RnMAX_STREAMS;i++)
		{
		ErPLog( "%s Stream generated %d values and was seeded %d times.\n",
			RnStreamName[i], RNGStream[i].draw_cnt);
		}
	}
/*
	RnInitStreamStats() - this function initializes stream hit statistics.
		This function exist only in debug mode.
*/

void
RnInitStreamStats()
	{	int i;

	for(i=0;i<RnMAX_STREAMS;i++)
		{
		RNGStream[i].draw_cnt=0;
		RNGStream[i].seed_cnt=0;
		}
	}
#endif /* DEBUG */

void
#if STD_C
RnSeedStream( int stream, long seed )
#else
RnSeedStream( stream, seed )
int stream;
long seed;
#endif
	{
	assert( stream <= RnMAX_STREAMS );

	RNGStream[stream].RnNext= seed;
	RNGStream[stream].initial_seed= seed;
#ifdef DEBUG
	RNGStream[stream].draw_cnt= 0;
	RNGStream[stream].seed_cnt++;
#endif
	}
/**
	void RnSetStreamSeeds()

	RnSetStreamSeeds() sets up an array of seed values based on the
	current setting of RnNext. The constants used will calculate
	stream seeds for the linear congruential random number generator
	which are spaced 2^29 draws apart in the period. This allows us
	to break up the current	RNG into eight seperate streams. The constant
	values used are	specific to the following linear congruential values
	used by	RnRand():

		RnNext = RnNext * 1103515245 + 12345
	
**/

void
RnSetStreamSeeds()
	{
		int i;

	assert( RnNUM_STREAMS == RnMAX_STREAMS ); /* make sure enumeration hasn't
							been tampered with without
							fixing RNGStream array and
							magic beans used to calc offsets */

	RNGStream[0].RnNext= RnNext;
	RNGStream[0].initial_seed= RnNext;
#ifdef DEBUG
	RNGStream[0].draw_cnt= 0;
	RNGStream[0].seed_cnt++;
#endif

	for(i=1;i<RnMAX_STREAMS;i++)
		{
		/* 03-06-05 ch3: add 'U' to constant to eliminate warning */
		RNGStream[i].RnNext=  RNGStream[i-1].RnNext*2147483649U +
					1610612736; /* constants represent
						magic beans which divide
						the period into eight
						streams */
		RNGStream[i].initial_seed = RNGStream[i].RnNext;
#ifdef DEBUG
		RNGStream[i].draw_cnt = 0;
		RNGStream[i].seed_cnt++;
#endif
		}
	}
/**
	void RnSeed( unsigned long seed )

	RnSeed() resets the state of RnRand() to the specified seed
	value.  This should be called before using any of the other
	functions in this package when reproducible sequences are
	desired (as they may be during testing).
**/

void
#if STD_C
RnSeed( unsigned long seed )
#else
RnSeed( seed )
unsigned long	seed;		/* user-supplied seed value */
#endif
	{
	RnNext = seed;
	RnAlreadySeeded = mTrue;
	/* set stream seeds - based on single seed from user */
	RnSetStreamSeeds();
	}

/**
	unsigned long RnState( RnStreamSelect stream );


	RnState() returns the state of RnRand(); this value (which is
	guaranteed to be less than 2^32) is suitable for later use as
	an argument to RnSeed() to restore the exact internal state of
	the generator.  This should be called before using any of the
	other functions in this package and the returned value saved,
	if it is desired to be able to later reproduce the sequences.
**/

unsigned long				/* returns current value of seed */
#if STD_C
RnState( RnStreamSelect stream )
#else
RnState( stream )
RnStreamSelect stream;
#endif
	{
	return RNGStream[stream].RnNext & (unsigned long)0xFFFFFFFF;
	}

/**
	int RnRand( RnStreamSelect stream )

	RnRand() returns an integer "randomly" selected uniformly from
	the range 0 through RnRAND_MAX, inclusive.  The standard linear
	congruential rand() algorithm is used (period 2^32, 15 bits of
	significance), and the implementation is such that precisely
	the same sequence should be generated on all systems.
**/

int
#if STD_C
RnRand( RnStreamSelect stream )
#else
RnRand( stream )	/* return range [0,RnRAND_MAX] */
RnStreamSelect stream;
#endif
	{
	assert(RnRAND_MAX == 32767);	/* maximum value returned by RnRand() */

	RNGStream[stream].RnNext = RNGStream[stream].RnNext * 
			1103515245 + 12345;	/* unsigned overflow is safe */
#ifdef DEBUG
	RNGStream[stream].draw_cnt++;
#endif
	/* Note that only the lowest 32 bits of RnNext affect the result. */
	return (unsigned) (RNGStream[stream].RnNext / 65536)
				 % 32768;/* 0 .. 32767 */
	}
