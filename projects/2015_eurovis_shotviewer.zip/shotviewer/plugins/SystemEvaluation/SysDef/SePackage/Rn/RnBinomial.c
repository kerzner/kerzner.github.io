/*
	RnBinomial --  Binomial Distribution

	created:	95/05/14	B. Mermagen
*/
#ifndef lint
static char RCSid[] = "$Id: RnBinomial.c,v 1.6 1999/04/27 15:19:20 mjo Exp $";
#endif

#ifndef DEBUG
#define NDEBUG
#endif

#include <assert.h>
#include "Rn.h"

/**
        int RnBinomial ( RnStreamSelect stream, double p, int n )

        This routine computes the sum of independent Bernoulli trials.
**/

#if STD_C
int RnBinomial ( RnStreamSelect stream, double p, int n )/* Binomial Distribution */
#else
int RnBinomial ( stream, p, n )   /* Binomial Distribution */
RnStreamSelect stream;
double p;
int n;
#endif
	{
	int i, sum;

	assert ( 0. <= p && p <= 1. && n >= 1 );

	for ( i = 0, sum = 0; i < n; i++ )
	sum += RnBernoulli ( stream, p );

	return sum;
	}
