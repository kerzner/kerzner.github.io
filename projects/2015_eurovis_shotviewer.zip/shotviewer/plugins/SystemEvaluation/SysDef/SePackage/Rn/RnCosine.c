/*
	RnCosine - Cosine Distribution

	created:	97/02/06	J. Yi
*/
#ifndef lint
static char RCSid[] = "$Id: RnCosine.c,v 1.3 1999/04/27 15:19:20 mjo Exp $";
#endif


#ifndef DEBUG
#define NDEBUG
#endif

#include <std.h>
#include <math.h>
#include <assert.h>
#include "Rn.h"

/**
	double RnCosine ( RnStreamSelect stream, double xMin, double xMax )

	Use distribution formula shown by:
	asin ( RnUniform ( -1., 1. ) )
**/

double 
#if STD_C
RnCosine ( RnStreamSelect stream, double xMin, double xMax )   /* Cosine Distribution */
#else
RnCosine ( stream, xMin, xMax ) 
RnStreamSelect stream;
double xMin;
double xMax;
#endif
      {
         double a = 0.5 * ( xMin + xMax );    /* location parameter */
         double b = ( xMax - xMin ) / M_PI;   /* scale parameter */
         
         assert ( xMin < xMax );
         
         return a + b * asin ( RnUniform ( (RnStreamSelect)0, -1., 1. ) );
      }
