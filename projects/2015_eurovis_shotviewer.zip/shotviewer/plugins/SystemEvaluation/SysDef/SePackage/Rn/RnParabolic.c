/*
	RnParabolic - Parabolic Distribution

	created:	97/02/06	J. Yi

Algorithm:

	Use distribution formula shown by:

*/
#ifndef lint
static char RCSid[] = "$Id: RnParabolic.c,v 1.3 1999/09/29 16:33:20 bparker Exp $";
#endif

#ifndef DEBUG
#define NDEBUG
#endif

#include <std.h>
#include <math.h>
#include <assert.h>
#include "Rn.h"

/**
	doublec RnParabolic ( RnStreamSelect stream, double xMin, double xMax )

	A random numer based on a parabolic distribution is returned. 
**/

double       
#if STD_C
parabola ( double x, double xMin, double xMax )
#else
parabola ( x, xMin, xMax )   
double x;
double xMin;
double xMax;
#endif
	{

	double a    = 0.5 * ( xMin + xMax );   /* location parameter */
	double b    = 0.5 * ( xMax - xMin );   /* scale parameter */
	double yMax = 0.75 / b;

	if ( x < xMin || x > xMax ) return 0.0;

	return yMax * ( 1. - ( x - a ) * ( x - a ) / ( b * b ) );
	}


double       
#if STD_C
RnParabolic ( RnStreamSelect stream, double xMin, double xMax )   /* Parabolic Distribution */
#else
RnParabolic ( stream, xMin, xMax )   
RnStreamSelect stream;
double xMin;
double xMax;
#endif
	{
	double a, yMax;
	assert ( xMin < xMax );

	a = 0.5 * ( xMin + xMax );           /* location parameter */
	yMax = parabola ( a, xMin, xMax );   /* maximum function range */

	return RnUserSpecified ( parabola, xMin, xMax, 0., yMax );
	}
