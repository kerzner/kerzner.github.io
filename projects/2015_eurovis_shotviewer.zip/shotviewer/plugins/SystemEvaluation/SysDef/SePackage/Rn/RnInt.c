/*
	RnInt -- uniform random integer in given range

	created:	86/01/04	D A Gwyn
*/
#ifndef lint
static char RCSid[] = "$Id: RnInt.c,v 1.5 1999/04/27 15:19:22 mjo Exp $";
#endif

#ifndef DEBUG
#define	NDEBUG
#endif

#include	<assert.h>
#ifdef CTRACE
#include	<stdio.h>		/* for _iob; see ../Make.conf CTFLAGS */
#endif

#include	<std.h>			/* for STD_C */

#include	<Rn.h>

/**
	int RnInt( RnStreamSelect stream, int min, int max )

	RnInt() returns an integral random number greater than or equal
	to the minimum value and less than the maximum value,
	distributed uniformly over the range of possible values.
**/

int
#if STD_C
RnInt(  RnStreamSelect stream, int min, int max )
#else
RnInt( stream, min, max )			/* return range [min,max) */
	RnStreamSelect stream;
	int	min, max;		/* desired range */
#endif
	{
	/* Note: this function computes a sensible result even if min > max */
	assert(min < max);

	return min + (int)((double)(max - min) * RnUnif( stream ));
	}
