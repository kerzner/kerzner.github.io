/*
	RnTriangle - Triangle Distribution

	created:	97/02/06	J. Yi
*/
#ifndef lint
static char RCSid[] = "$Id: RnTriangle.c,v 1.2 1999/04/27 15:19:25 mjo Exp $";
#endif

#ifndef DEBUG
#define NDEBUG
#endif

#include <std.h>
#include <math.h>
#include <assert.h>
#include "Rn.h"

/**
	double RnTriangle ( RnStreamSelect stream, double xMin, double xMax )

	A random number based on a triangular distribution is returned. 
**/

double 
#if STD_C
RnTriangle ( RnStreamSelect stream, double xMin, double xMax )   /* Triangle Distribution */
#else
RnTriangle ( stream, xMin, xMax )   
RnStreamSelect stream;
double xMin;
double xMax;
#endif
	{
	double a = 0.5 * ( xMin + xMax );   /* location parameter */
	double b = 0.5 * ( xMax - xMin );   /* scale parameter */
	double p = Unif();

	assert ( xMin < xMax );

	if ( p <= 0.5 )
		return a - b * sqrt ( 2. * p );
	else
		return a + b - b * sqrt ( 2. * ( 1. - p ) );
	}
