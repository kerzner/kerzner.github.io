/*
	RnBeta -- Beta Distribution - Probability Density Function

	created:	95/05/14	B. Mermagen
*/
#ifndef lint
static char RCSid[] = "$Id: RnBeta.c,v 1.8 1999/04/27 15:19:19 mjo Exp $";
#endif

#ifndef DEBUG
#define NDEBUG
#endif

#include "Rn.h"

/**
        double RnBeta ( double v, double w, double a, double b )

        This function computes a beta distributed random variable over
        an interval (a,b) based on 2 positive shape parameters.
**/

#if STD_C 
double RnBeta ( RnStreamSelect stream, double v, double w,
			double a, double b )
#else
double RnBeta ( stream, v, w, a, b)
	RnStreamSelect stream;
	double v;
	double w;
	double a;
	double b;
#endif
	{
	double y, z;

	y = RnGamma ( stream, 0., 1., v );
	z = RnGamma ( stream, 0., 1., w );

	return a + ( b - a ) * y / ( y + z );
	}
