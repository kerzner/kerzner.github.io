/*
	RnDisUni --     Discrete Uniform Distribution

	created:	95/05/14	B. Mermagen
*/
#ifndef lint
static char RCSid[] = "$Id: RnDisUni.c,v 1.6 1999/04/27 15:19:21 mjo Exp $";
#endif

#ifndef DEBUG
#define NDEBUG
#endif
 
#include <assert.h>
#include "Rn.h"

/**
        int RnDisUni ( RnStreamSelect stream, int i, int j )

        Algorithm:

        Let p be a uniformly distributed random variable in
        the interval [0,1) : p ~ U(0,1). Then

                x = i + int((j - i + 1) p)
**/

#if STD_C
int RnDisUni ( RnStreamSelect stream, int i, int j )   /* Discrete Uniform Dist */
#else
int RnDisUni ( stream, i, j )   /* Discrete Uniform Dist */
	RnStreamSelect stream;
	int i;
	int j;
#endif
	{
	assert ( i < j );
	return i + ( int ) ( ( j - i + 1 ) * Unif() );
	}
