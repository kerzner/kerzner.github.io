/*
	RnWeibull - Weibull Distribution

	created:	95/05/14	B. Mermagen
*/
#ifndef lint
static char RCSid[] = "$Id: RnWeibull.c,v 1.7 1999/04/27 15:19:25 mjo Exp $";
#endif

#ifndef DEBUG
#define NDEBUG
#endif

#include <math.h>
#include <assert.h>
#include "Rn.h"

/**
        double RnWeibull ( RnStreamSelect stream, double a, double b, double c )

        Algorithm:

        Let p be a uniformly distributed random variable in the
        interval (0,1): p ~ U(0,1). Then

                        x = b(-log p)**(1/c)

        where b is a positive scale parameter, and c is a positive
        shape factor.
**/

#if STD_C
double RnWeibull ( RnStreamSelect stream, double a, double b, double c )
#else
double RnWeibull ( stream, a, b, c )   /* Weibull Distribution */
RnStreamSelect stream;
double a;
double b;
double c;
#endif
	{
	assert ( b > 0. && c > 0. );

	return a + b * pow ( -log ( Unif() ), 1. / c );
	}
