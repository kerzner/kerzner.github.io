/*
	RnGamma -- Gamma Distribution

	created:	95/05/14	B. Mermagen

Method:

	P. 255 of "Simulation Modeling and Analysis" by Averill Law
	and W. David Kelton, McGraw-Hill, 1982.

  	The name is capitalized in order to distinquish it from the 
	gamma function in the math library.
*/ 
#ifndef lint
static char RCSid[] = "$Id: RnGamma.c,v 1.9 2005/09/01 19:18:57 mjo Exp $";
#endif

#ifndef DEBUG
#define NDEBUG
#endif

#include <math.h>
#include <assert.h>
#include "Rn.h"

/**
        double RnGamma ( RnStreamSelect stream, double a, double b, double c )

        Two doubles as input, b - positive scale parameter,
        c- the positive shape factor, returns a double that
        represents a Gamma Distribution draw.
**/

#if STD_C
double RnGamma ( RnStreamSelect stream, double a, double b, double c )
#else
double RnGamma ( stream, a, b, c )   /* Gamma Distribution */
RnStreamSelect stream;
double a;
double b;
double c;
#endif
	{
	const double C = 1. + c / M_E;
	const double A = 1. / sqrt ( 2. * c - 1. );
	const double B = c - log ( 4. );
	const double Q = c + 1. / A;
	const double T = 4.5;
	const double D = 1. + log ( T );
	double p, p1, p2, v, y, z, w;

	assert ( b > 0. && c > 0. );

	if ( c < 1. ) 
		{  
		for ( ;; ) 
			{
			p = C * Unif();      
			if ( p > 1. ) 
				{
				y = -log ( ( C - p ) / c );
				if ( Unif() <= pow ( y, c - 1. ) )
					return a + b * y;
				}
			else 
				{
				y = pow ( p, 1. / c );
				if ( Unif() <= exp ( -y ) )
					return a + b * y;
				}
			}
		}
	else if ( c == 1.0 )
		return RnExponential ( stream, a, b );
	else 
		{
		for ( ;; ) 
			{
			p1 = Unif();
			p2 = Unif();
			v = A * log ( p1 / ( 1. - p1 ) );
			y = c * exp ( v );
			z = p1 * p1 * p2;
			w = B + Q * v - y;
			if ( w + D - T * z >= 0. || w >= log ( z ) )
				return a + b * y;
			}
		}
	}
