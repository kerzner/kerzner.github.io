/**
	<Rn.h> -- definitions for random number generators

	edited:		05/03/08	A Ross
			added th_ph_ps structure and function prototype for
			RnSpherical2() for SCR518
	RCSid:	 		$Id: Rn.h,v 1.16 2010/06/23 19:54:50 geoffs Exp $
 */
/**
	The "Rn" package provides several random number generators for
	use in the MUVES environment.  These functions return pseudo-
	random numbers from a variety of distributions for use in
	various situations.  More distributions are of course possible,
	but so far we have needed only the ones shown below.

	This package obtains its "randomness" from the RnRand() uniform
	random number generator, which is our own fully portable
	implementation of the standard library function rand().
**/

#ifndef Rn_H_INCLUDED
#define Rn_H_INCLUDED			/* once-only latch */

#include	<std.h>
#define	RnRAND_MAX	32767		/* maximum value returned by RnRand() */


/* if DRAND48 is defined then 'Rn' uses the systems drand48() as its random
		number generator */
#ifdef DRAND48
#define Unif() drand48()
#else
#define Unif() RnUnif( stream )
#endif

typedef struct {
    double th, ph;
} th_ph;
/* 05-03-08 adr: added struct to hold RnSpherical2 result (SCR518) */
typedef struct {
    double th, ph, ps;
} th_ph_ps;

typedef struct {
    unsigned long RnNext;
    unsigned long initial_seed;
#ifdef DEBUG
    unsigned long draw_cnt;
    unsigned long seed_cnt;
#endif
} RnStream;
extern MuvesBool RnAlreadySeeded;

#ifdef DEBUG
/*
	The following functions are debug mode only functions used
		for looking at RNG stream statistics.
*/
extern void RnInitStreamStats();
extern void RnPrintStreamStats();
#endif

/*
	enumeration of current random number streams
*/
typedef enum {
    RnStreamInvalid = -1,			/* must be first */
    RnShotPatternStream,
    RnClusterStream,
    RnShotAssessmentStream,
    RnBADStream,
    RnStream5,
    RnStream6,
    RnStream7,
    RnStream8,
    RnStreamSentinel				/* must be last */
}
RnStreamSelect;

extern const char *RnStreamName[];

#define RnSINGLE_STREAM	RnShotPatternStream
#define RnNUM_STREAMS	RnStreamSentinel

/*
	The maximum number of streams is based on LCG subdivision
	and has currently been calculated out for eight(every 2^29
	samples apart) divisions of the period. See magic beans in
	'RnSetSeeds()'.
*/
#define RnMAX_STREAMS	8
#define RnSTREAMS_INUSE	4	/* current number of streams in use */


#if STD_C
extern int	RnRand( RnStreamSelect );
extern void	RnSeed( unsigned long );
extern void	RnSeedStream( int stream, long seed );
extern unsigned long	RnState( RnStreamSelect );
extern void	RnInit( void );
extern double	RnUnif( RnStreamSelect );
extern double	RnFlt( RnStreamSelect, double, double );
extern int	RnInt( RnStreamSelect, int, int );
extern double	RnNorm( RnStreamSelect, double, double );
extern void	RnDir( RnStreamSelect, double *, double *, double *);
extern double	RnBeta ( RnStreamSelect, double, double, double, double ); /* Beta Distribution */
extern double RnChiSquared ( RnStreamSelect, int );	/* Chi-Squared Distribution */
extern double RnEmpirical (  RnStreamSelect, char *, int ); /* Empirical Distribution */
extern double RnErlang ( RnStreamSelect, double, int );
extern double RnExponential ( RnStreamSelect, double, double );	/* Exponential Distribution */
extern double	RnFlt( RnStreamSelect, double, double );
extern double RnGamma ( RnStreamSelect, double, double, double );  /* Gamma Distribution */
extern double RnLogistic ( RnStreamSelect, double, double );  /* Logistic Distribution */
extern double RnLogNormal ( RnStreamSelect, double, double ); /* Lognormal Distribution */
extern double RnNormal ( RnStreamSelect, double, double );   /* Normal Distribution */
extern th_ph RnSpherical ( RnStreamSelect, double, double, double, double );/* Spherical Distribution */
/* 05-03-08 adr: added new distribution for SCR518 */
extern th_ph_ps RnSpherical2 ( RnStreamSelect, double, double, double, double,
                               double, double );
extern double RnStudent ( RnStreamSelect, int );      /* Student's T Distribution */
extern double RnUniform (RnStreamSelect, double, double ); /* Uniform Distribution */
extern double RnWeibull ( RnStreamSelect, double, double, double );  /* Weibull Distribution */
extern int RnBernoulli ( RnStreamSelect, double );	/* Bernoulli Distribution */
extern int RnBinomial ( RnStreamSelect, double, int );	/* Binomial Distribution */
extern int RnDisEmpirical ( RnStreamSelect, char *, int ); /* Discrete Empirical */
extern int RnDisUni ( RnStreamSelect, int, int );	/* Discrete Uniform Dist */
extern int RnGeometric ( RnStreamSelect, double );	/* Geometric Distribution */
extern int RnNegBin ( RnStreamSelect, double, int );	/* Negative Binomial Dist */
extern int RnPoisson ( RnStreamSelect, double );	/* Poisson Distribution */
extern double RnCauchy ( RnStreamSelect, double, double );	/* Cauchy Distribution */
extern double RnCosine ( RnStreamSelect, double, double );	/* Cosine Distribution */
extern double RnDblExp ( RnStreamSelect, double, double );	/* Double Exponential Distribution */
extern double RnParabolic ( RnStreamSelect, double, double );  /* Parabolic Distribution */
extern double RnTriangle ( RnStreamSelect, double, double );   /* Triangle Distribution */
extern double RnUserSpecified (double ( *usf ) ( double, double, double ), double, double, double, double );
#else
extern int	RnRand();
extern void	RnSeed();
extern void	RnSeedStream();
extern unsigned long	RnState();
extern void	RnInit();
extern double	RnUnif();
extern double	RnFlt();
extern int	RnInt();
extern double	RnNorm();
extern void	RnDir();
extern double	RnBeta();
extern double RnChiSquared ();
extern double RnEmpirical ();
extern double RnErlang ();
extern double RnExponential ();
extern double RnF ();
extern double RnGamma ();
extern double RnLogistic ();
extern double RnLogNormal ();
extern double RnNormal ();
extern th_ph RnSpherical ();
/* 05-03-08 adr: added new distribution for SCR518 */
extern th_ph_ps RnSpherical2 ();
extern double RnStudent ();
extern double RnUniform ();
extern double RnWeibull ();
extern int RnBernoulli ();
extern int RnBinomial ();
extern int RnDisEmpirical ();
extern int RnDisUni ();
extern int RnGeometric ();
extern int RnNegBin ();
extern int RnPoisson ();
extern double RnCauchy ();
extern double RnCosine ();
extern double RnDblExp ();
extern double RnParabolic ();
extern double RnTriangle ();
extern double RnUserSpecified ();
#endif
extern void RnPkgInit();

/* backward compatibility flag to match old results. */
/* Use of RnNorm() function (which uses a static variable) changed to
   RnNormal() when we added the parallel Dmuves capability. */
extern MuvesBool RnNormOld;

#endif		/* for Rn_H_INCLUDED */

