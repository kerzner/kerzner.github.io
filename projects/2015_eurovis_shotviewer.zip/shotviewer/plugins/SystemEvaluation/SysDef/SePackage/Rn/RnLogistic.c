/*
	RnLogistic --  Logistic Distribution

	created:	95/05/14	B. Mermagen

Algorithm:

	Let p be a uniformly distributed random variable in the interval
	(0,1): p ~ U(0,1). Then

		x = a + b log [p/(1 - p)].
*/
#ifndef lint
static char RCSid[] = "$Id: RnLogistic.c,v 1.6 1999/04/27 15:19:22 mjo Exp $";
#endif

#ifndef DEBUG
#define NDEBUG
#endif

#include <math.h>
#include <assert.h>
#include "Rn.h"

/**
        double RnLogistic ( RnStreamSelect stream, double a, double b )

        Algorithm:

        Let p be a uniformly distributed random variable in the interval
        (0,1): p ~ U(0,1). Then

                   x = a + b log [p/(1 - p)].
**/

#if STD_C
double RnLogistic ( RnStreamSelect stream, double a, double b )
#else
double RnLogistic ( stream, a, b )   /* Logistic Distribution */
	RnStreamSelect stream;
	double a;
	double b;
#endif
	{
	double p = Unif();

	assert ( b > 0. );

	return a + b * log ( p / ( 1. - p ) );
	}
