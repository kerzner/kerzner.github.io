/*
  	RnUniform -- Uniform Distribution

	created:	95/05/14	B. Mermagen
*/
#ifndef lint
static char RCSid[] = "$Id: RnUnif2.c,v 1.7 1999/04/27 15:19:25 mjo Exp $";
#endif

#ifndef DEBUG
#define NDEBUG
#endif

#include <assert.h>
#include <math.h>
#include "Rn.h"

/**
        double RnUniform ( RnStreamSelect stream, double a, double b )

        Generate a random doubleing- point number in range [0,1)

        Algorithm:

        Let p be a uniformly distributed random variable in the
        interval (0,1): p ~ U(0,1).  Then

                        x = a + (b - a) p

         where a and b represent the minimum and maximum value of the
         random variable, respectively.
**/


#if STD_C
double RnUniform ( RnStreamSelect stream, double a, double b )
#else
double RnUniform ( stream, a, b )   /* Uniform Distribution */
RnStreamSelect stream;
double a;
double b;
#endif
	{
	assert ( a < b );

	return a + ( b - a ) * Unif();
	}
