/*
	RnPoisson -  Poisson Distribution

	created:	95/05/14	B. Mermagen

Method:

	P. 267 of "Simulation Modeling and Analysis" by Averill Law
	and W. David Kelton, McGraw-Hill, 1982.
*/
#ifndef lint
static char RCSid[] = "$Id: RnPoisson.c,v 1.8 1999/04/27 15:19:23 mjo Exp $";
#endif

#ifndef DEBUG
#define NDEBUG
#endif

#include <math.h>
#include <assert.h>
#include "Rn.h"

/**
        int RnPoisson ( RnStreamSelect stream, double rate )

        This routine returns a Poisson distributed value, with rate as input.
	For a large expected number, the Poisson distribution takes
	forever to run.  When the expected number exceeds 9, the Poisson
	distribution goes over to a Normal distribution with the same
	mean and variance as the Poisson.
**/

#if STD_C
int RnPoisson ( RnStreamSelect stream, double rate )   /* Poisson Distribution */
#else
int RnPoisson ( stream, rate )   /* Poisson Distribution */
RnStreamSelect stream;
double rate;
#endif
	{
	int i;
	double b, a = exp ( -rate );

	assert ( rate > 0. );

/* Poisson approximated by Normal distribution when rate is greater than 9 */

	if ( rate > 9 ) 
		return ( int ) ( RnNormal ((RnStreamSelect)0, rate, sqrt ( rate ) ) );

	for ( i = 0, b = 1.; b >= a; i++ )
		b *= Unif();

	return i - 1;
	}
