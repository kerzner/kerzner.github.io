/*
	RnNormal - Normal Distribution

	created:	95/05/14	B. Mermagen

Method:
	Polar method; see Donald E. Knuth's "The Art of Computer
	Programming -- Volume 2 / Seminumerical Algorithms" (2nd Ed. 1981
	Addison-Wesley), Section 3.4.1C(1).

*/
#ifndef lint
static char RCSid[] = "$Id: RnNorm2.c,v 1.9 2001/03/19 19:10:24 karen Exp $";
#endif

#ifndef DEBUG
#define NDEBUG
#endif

#include <math.h>
#include <assert.h>
#include "Rn.h"

/* The following is the smallest "computationally safe" value for s. */
#define	MIN_S	1.0e-30			/* plenty of leeway */

/**
        double RnNormal ( RnStreamSelect stream, double mu, double sigma )

        RnNormal() returns a floating-point random number distributed
        in a Gaussian fashion around the specified mean value (mu)
        with the specified standard deviation (sigma). This routine
        differs from RnNorm in the method of choosing random numbers.
**/

#if STD_C
double RnNormal ( RnStreamSelect stream, double mu, double sigma )
#else
double RnNormal ( stream, mu, sigma )   /* Normal Distribution */
RnStreamSelect stream;
double mu;
double sigma;
#endif
	{
	double p, p1, p2;


	do 
		{
		p1 = RnUniform ( stream, -1., 1. );
		p2 = RnUniform ( stream, -1., 1. );
		p = p1 * p1 + p2 * p2;
		} while  ( p >= 1. || p < MIN_S );
	
	return mu + sigma * p1 * sqrt ( -2. * log ( p ) / p );
	}
