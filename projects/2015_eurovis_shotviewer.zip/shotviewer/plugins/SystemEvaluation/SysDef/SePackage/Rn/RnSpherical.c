/*
	RnSpherical -- Spherical Distribution

	created:	95/05/14	B. Mermagen
*/
#ifndef lint
static char RCSid[] = "$Id: RnSpherical.c,v 1.6 1999/04/27 15:19:24 mjo Exp $";
#endif

#ifndef DEBUG
#define NDEBUG
#endif

#include <math.h>
#include <assert.h>
#include "Rn.h"


/**
        th_ph RnSpherical ( RnStreamSelect stream, double thMin, double thMax,
                                double phMin, double phMax )

        Generates Uniform distribution of angles (radians) over the
        unit sphere.
**/

#ifdef STD_C
th_ph RnSpherical ( RnStreamSelect stream, double thMin, double thMax,
			 double phMin, double phMax )
					        /* Spherical Distribution */
#else
th_ph RnSpherical ( stream, thMin, thMax, phMin, phMax)   /* Spherical Distribution */
RnStreamSelect stream;
double thMin;
double thMax;
double phMin;
double phMax;
#endif
	{
	th_ph p;

	assert ( 0. <= thMin && thMin < thMax && thMax <= M_PI &&
		0. <= phMin && phMin < phMax && phMax <= 2. * M_PI );

	p.th = acos ( RnUniform ( stream, cos ( thMax ), cos ( thMin ) ) );  /* polar */
	p.ph = RnUniform ( stream, phMin, phMax );                      /* azimuthal */

	return p;
	}
