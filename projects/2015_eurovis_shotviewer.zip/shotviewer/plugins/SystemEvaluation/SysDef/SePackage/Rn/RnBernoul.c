/*
	RnBernoulli --  Bernoulli Distribution

	created:	95/05/14	B. Mermagen
*/
#ifndef lint
static char RCSid[] = "$Id: RnBernoul.c,v 1.6 1999/04/27 15:19:19 mjo Exp $";
#endif

#ifndef DEBUG
#define NDEBUG
#endif

#include <assert.h>
#include "Rn.h"

/**
        int RnBernoulli ( RnStreamSelect stream, double p )

        Algorithm:

        Let p be given and let p' be a uniformly distributed random
        number drawn from the interval [0,1): p' - U(0,1). Then

                        x = 1 if p' <  p
                        x = 0 if p' >= p
**/

#if STD_C
int RnBernoulli ( RnStreamSelect stream, double p )   /* Bernoulli Distribution */
#else
int RnBernoulli ( stream, p )   /* Bernoulli Distribution */
	RnStreamSelect stream;
	double p;
#endif
	{
	assert ( 0. <= p && p <= 1. );

	return Unif() < p;
	}
