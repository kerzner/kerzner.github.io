/*
	RnGeometric --  Geometric Distribution

	created:	95/05/14	B. Mermagen
*/
#ifndef lint
static char RCSid[] = "$Id: RnGeometric.c,v 1.6 1999/04/27 15:19:22 mjo Exp $";
#endif

#ifndef DEBUG
#define NDEBUG
#endif

#include <math.h>
#include <assert.h>
#include "Rn.h"

/**
        int RnGeometric ( RnStreamSelect stream, double p )

        Algorithm:

        Let the probability of an event p be given, and let p' be a
        uniformly distributed random variable in the interval (0,1):
        p' - U(0,1).  Then

                        x = int ( log p'/ log (1 - p)).
**/

#if STD_C
int RnGeometric ( RnStreamSelect stream, double p )   /* Geometric Distribution */
#else
int RnGeometric ( stream, p )   /* Geometric Distribution */
	RnStreamSelect stream;
	double p;
#endif
	{
	assert ( 0. < p && p < 1. );

	return ( int ) ( log ( Unif() ) / log ( 1. - p ) );
	}
