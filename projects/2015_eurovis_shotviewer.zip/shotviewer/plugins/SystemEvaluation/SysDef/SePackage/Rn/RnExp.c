/*
	RnExponential -- Exponential Distribution

	created:	95/05/14	B. Mermagen

Algorithm:

	Let p be a uniformly distributed random variable in the interval
(0,1) : p ~ U(0,1). Then

		x = -b log(p).
*/
#ifndef lint
static char RCSid[] = "$Id: RnExp.c,v 1.7 1999/04/27 15:19:21 mjo Exp $";
#endif

#ifndef DEBUG
#define NDEBUG
#endif
 
#include <math.h>
#include <assert.h>
#include "Rn.h"

/**
        double RnExponential ( RnStreamSelect stream, double a, double b )

        Let p be a uniformly distributed random variable in the
        interval (0,1) : p ~ U(0,1). Then

                        x = -b log(p).
**/

#if STD_C
double RnExponential ( RnStreamSelect stream, double a, double b )
#else
double RnExponential ( stream, a, b )   /* Exponential Distribution */
	RnStreamSelect stream;
	double a;
	double b;
#endif
	{
	assert ( b > 0. );

	return a - b * log ( Unif() );
	}
