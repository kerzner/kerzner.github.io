/*
	RnNorm -- random normal deviate with specified mean & standard deviation

	created:	86/01/04	D A Gwyn

Method:
	Polar method; see Donald E. Knuth's "The Art of Computer
	Programming -- Volume 2 / Seminumerical Algorithms" (2nd Ed. 1981
	Addison-Wesley), Section 3.4.1C(1).
 */
#ifndef lint
static char RCSid[] = "$Id: RnNorm.c,v 1.7 2010/06/23 19:54:50 geoffs Exp $";
#endif

#include	<math.h>

#ifdef CTRACE
#include	<stdio.h>		/* for _iob; see ../Make.conf CTFLAGS */
#endif

#include	<std.h>			/* for STD_C, MuvesBool, mFalse, mTrue */

#include	<Rn.h>

/* backward compatibility flag to match old results. */
/* Use of RnNorm() function (which uses a static variable) changed to 
   RnNormal() when we added the parallel Dmuves capability. */
MuvesBool RnNormOld = mFalse;

/* The following is the smallest "computationally safe" value for s. */
#define	MIN_S	1.0e-30			/* plenty of leeway */

/**
	double RnNorm( RnStreamSelect stream, double mu, double sigma )

	RnNorm() returns a floating-point random number distributed in a
	Gaussian fashion around the specified mean value (mu) with the
	specified standard deviation (sigma).
**/

#if STD_C
double
RnNorm( RnStreamSelect stream, double mu, double sigma )	/* return range (-inf,inf) */
#else
double
RnNorm( stream, mu, sigma )			/* return range (-inf,inf) */
RnStreamSelect stream;
double		mu;		/* desired mean */
double		sigma;		/* desired std. deviation */
#endif
	{
	static MuvesBool	saved = mFalse;	/* "have saved value" flag */
	static double	rndsave;	/* saved value iff `saved' */
	register double	s, x, y;

	if( ! RnNormOld )
		return RnNormal( stream, mu, sigma );

	if ( saved )
		{
		x = rndsave;	 	/* already on hand */
		saved = mFalse;		/* now used up */
		}
	else	{
		/* generate a pair of numbers */

		do	{
			x = RnFlt( stream, -1.0, 1.0 );
			y = RnFlt( stream, -1.0, 1.0 );
			s = x * x + y * y;
			}
		while ( s >= 1.0	/* 0.25 probability */
		     || s < MIN_S	/* practically never */
		      );

		rndsave = sqrt( -2.0 * log( s ) / s );
		x *= rndsave;
		rndsave *= y;			/* save for next call */
		saved = mTrue;
		}

	return mu + sigma * x;
	}
