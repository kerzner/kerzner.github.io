/*
	RnCauchy - Cauchy Distribution

	created:	97/02/06	J. Yi
*/
#ifndef lint
static char RCSid[] = "$Id: RnCauchy.c,v 1.3 1999/04/27 15:19:20 mjo Exp $";
#endif

#ifndef DEBUG
#define NDEBUG
#endif

#include <std.h>
#include <math.h>
#include <assert.h>
#include "Rn.h"

/**
	double RnCauchy( RnStreamSelect stream, double a, double b )

	Use distribution formula shown by:
	tan ( M_PI * RnUniform ( -0.5, 0.5 ) )
**/

double 
#if STD_C
RnCauchy ( RnStreamSelect stream, double a, double b )   /* Cauchy Distribution */
#else
RnCauchy ( stream, a, b )   
RnStreamSelect stream;
double a;
double b;
#endif
	{
		double temp;

		assert ( b > 0. );
		temp = RnUniform ( (RnStreamSelect)0, -0.5, 0.5 );
		temp = tan ( M_PI * temp);
		temp = a + b * temp;
		return temp;
	}
