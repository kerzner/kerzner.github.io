/*
	RnChiSquared --  Chi-Squared Distribution

	created:	95/05/14	B. Mermagen
*/
#ifndef lint
static char RCSid[] = "$Id: RnChiSquared.c,v 1.7 1999/04/27 15:19:20 mjo Exp $";
#endif

#ifndef DEBUG
#define NDEBUG
#endif

#include <assert.h>
#include "Rn.h"

/**
        double RnChiSquared ( RnStreamSelect stream, int df )

        This routine computes the chi-squared distribution with v
        degrees of freedom from a Gamma distribution using a scale
        parameter of 2 and a shape parameter of v/2.
**/

#if STD_C
double RnChiSquared ( RnStreamSelect stream, int df )/* Chi-Squared Distribution */
#else
double RnChiSquared ( stream, df )
RnStreamSelect stream;
int df;
#endif
	{
	assert ( df >= 1 );

	return RnGamma ( stream, 0., 2., (double) df / 2. );
	}
