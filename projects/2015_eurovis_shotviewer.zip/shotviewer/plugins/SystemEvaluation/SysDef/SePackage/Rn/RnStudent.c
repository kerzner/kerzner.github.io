/*
	RnStudent - Student's T Distribution

	created:	95/05/14	B. Mermagen
*/
#ifndef lint
static char RCSid[] = "$Id: RnStudent.c,v 1.6 1999/04/27 15:19:24 mjo Exp $";
#endif

#ifndef DEBUG
#define NDEBUG
#endif

#include <math.h>
#include <assert.h>
#include "Rn.h"

/**
        double RnStudent ( RnStreamSelect stream, int df )

        Let p1 be a normally distributed random variable in the
        interval (0,1) and p2 be a ch-squared random variable with
        df degrees of freedom: p1 ~ N(0,1) and p2 ~ X**2(df), then

                       x = p1 / sqrt(p2/df).
**/

#if STD_C
double RnStudent ( RnStreamSelect stream, int df )   /* Student's T Distribution */
#else
double RnStudent ( stream, df )   /* Student's T Distribution */
RnStreamSelect stream;
int df;
#endif
	{
	assert ( df >= 1 );

	return RnNormal ( stream, 0., 1. ) / 
		sqrt ( RnChiSquared ( stream, df ) / df );
	}
