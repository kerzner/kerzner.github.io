/*
	RnEmpirical --  Empirical Distribution

	created:	95/05/14	B. Mermagen
*/
#ifndef lint
static char RCSid[] = "$Id: RnEmp.c,v 1.8 1999/04/27 15:19:21 mjo Exp $";
#endif

#ifndef DEBUG
#define NDEBUG
#endif

#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include "Rn.h"

#define N 100   /* maximum number of empirical data pairs */

/**
        double RnEmpirical (  RnStreamSelect stream, char *inname, int empflag )

        Requires an input file whose name is inname, that consists of
        cumulative data pairs. The number of data pairs is not to
        exceed the constant N in the program. False empflag indicates that
        a file is to be used.
**/

#if STD_C
double RnEmpirical ( RnStreamSelect stream, char *inname, int empflag )
#else
double RnEmpirical ( stream, inname, empflag )   /* Empirical Distribution */
RnStreamSelect stream;
char *inname;
int empflag;
#endif
	{
	static FILE *in;
	float p;
	int i;
	static float x[N], F[N];     /* data pairs for cumulative distribution */
	static int n = 0;            /* actual number of data pairs */

	if ( !empflag ) 
		{   /* empirical data has not been read in yet */

		if ( ( in = fopen ( inname, "r" ) ) == NULL ) 
			{
			printf ( "Can't open %s \"empiricalDistribution\" input file\n",
				inname );
			exit(1);
			}
		while ( fscanf ( in, "%f %f", &x[n], &F[n] ) != EOF ) 
			{
			if ( n < N ) 
				n++;
			else 
				{
				printf ( "Arrays are too small to hold all data pairs " ); 
				printf ( "in \"empiricalDistribution\" file.\n" );
				printf ( "The current maximum number is %d.\n", N );
				exit(1);
				}
			}

		/* check that this is indeed a cumulative distribution with a maximum of 1 */

		for ( i = 1; i < n; i++ ) 
			assert ( F[i-1] < F[i] );

		if (F[n-1] != 1.0 ) printf("WARNING:  F = %f and n = %d\n",F[n-1], n);

		assert ( F[n-1] == 1.0 );

		empflag = 1;   /* flag that data has been correctly read in */
		fclose ( in );
		}

	p = Unif();
	for ( i = 0; i < n; i++ )
		if ( F[i] <= p && p < F[i+1] )
			return x[i] + ( x[i+1] - x[i] ) * ( p - F[i] ) / (F[i+1] - F[i] );

	return x[n-1];
	}
