/*
	RnF -- F Distribution

	created:	95/05/14	B. Mermagen

*/
#ifndef lint
static char RCSid[] = "$Id: RnF.c,v 1.7 1999/04/27 15:19:21 mjo Exp $";
#endif

#ifndef DEBUG
#define NDEBUG
#endif

#include <assert.h>
#include "Rn.h"

/**
        double RnF ( RnStreamSelect stream, int v, int w )

        Algorithm:

        Let p1 ~ X**2(v) and p2 ~ X**2(w) be independent.  Then

                        x = (p1/v)/(p2/w)

        where v and w are positive integer shape parameters
        (degrees of freedom).
**/

#if STD_C
double RnF (  RnStreamSelect stream, int v, int w )   /* F Distribution */
#else
double RnF ( stream, v, w )   /* F Distribution */
	RnStreamSelect stream;
	int v;
	int w;
#endif
	{
	assert ( v >= 1 && w >= 1 );

	return ( RnChiSquared ( stream, v ) / v ) /
		( RnChiSquared ( stream, w ) / w );
	}
