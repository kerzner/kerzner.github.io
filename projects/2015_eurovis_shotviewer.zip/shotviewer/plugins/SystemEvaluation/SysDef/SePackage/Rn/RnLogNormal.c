/*
	RnLogNormal -- Lognormal Distribution

	created:	95/05/14	B. Mermagen

*/
#ifndef lint
static char RCSid[] = "$Id: RnLogNormal.c,v 1.6 1999/04/27 15:19:22 mjo Exp $";
#endif

#ifndef DEBUG
#define NDEBUG
#endif

#include <math.h>
#include "Rn.h"

/**
        double RnLogNormal ( RnStreamSelect stream, double mu, double sigma )

        Generates a lognormal distribution from a scale parameter mu
        and a positive shape parameter sigma, where mu and sigma are
        from

        mu      = log [ mu'**2/(sqrt(mu' + sigma'))]
        sigma   = sqrt (log [ (mu' + sigma')/ mu'**2])

        and mu' and sigma' are mean and standard deviation

        respectively of a normally distributed random variable p,
        hence
                          x = exp (p).
**/

#if STD_C
double RnLogNormal ( RnStreamSelect stream, double mu, double sigma )
#else
double RnLogNormal ( stream, mu, sigma )   /* Lognormal Distribution */
	RnStreamSelect stream;
	double mu;
	double sigma;
#endif
	{
	return exp ( RnNormal ( stream, mu, sigma ) );
	}
