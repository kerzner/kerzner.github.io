/*
	RnDir -- random normalized direction vector

	created:	86/06/19	D A Gwyn

Method:
	Knop's polar method; see Donald E. Knuth's "The Art of Computer
	Programming -- Volume 2 / Seminumerical Algorithms" (2nd Ed. 1981
	Addison-Wesley), Section 3.4.1E(6).
 */
#ifndef lint
static char RCSid[] = "$Id: RnDir.c,v 1.5 1999/04/27 15:19:20 mjo Exp $";
#endif

#include	<math.h>
#ifdef CTRACE
#include	<stdio.h>		/* for _iob; see ../Make.conf CTFLAGS */
#endif

#include	<std.h>			/* for STD_C */

#include	<Rn.h>

/**
	void RnDir( RnStreamSelect stream, double *xp, double *yp, double *zp )

	RnDir() inserts a set of three numbers into the locations
	specified by the pointers.  These three values constitute
	Cartesian components of a unit vector pointing in a random
	direction.  Alternatively, these values may be thought of as
	Cartesian components of a point uniformly distributed over the
	surface of a unit sphere.
**/

void
#if STD_C
RnDir( RnStreamSelect stream, double *xp, double *yp, double *zp )
#else
RnDir( stream, xp, yp, zp )
RnStreamSelect stream;
double		*xp, *yp, *zp;	/* -> coordinate storage */
#endif
	{
	register double	s, x, y;

	/* generate a pair of numbers */

	do	{
		x = RnFlt( stream, -1.0, 1.0 );
		y = RnFlt( stream, -1.0, 1.0 );
		s = x * x + y * y;
		}
	while ( s > 1.0 );		/* 0.25 probability */

	*zp = 2.0 * s - 1.0;
	s = 2.0 * sqrt( 1.0 - s );	/* "alpha" in Knuth */
	*xp = x * s;
	*yp = y * s;
	}
