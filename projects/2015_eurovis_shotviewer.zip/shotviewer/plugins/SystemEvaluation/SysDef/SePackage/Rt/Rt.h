#ifndef RT_H
#define RT_H

#include <Nm.h>

//typedef void* genptr_t;

/**
   extern NmPool	RtComponents

   RtComponents is the name pool associated with the
   "target".  This is the only globally visible variable in
   the Rt package.  It should be accessed only by external
   customers.  Internal Rt functions should use the NmPool which
   is associated with the specified RtTarget target structure.

   This approach is intended to incorporate as much multiple
   target infrastructure into Rt without breaking external
   hookups.

**/
extern NmPool RtComponents;	/* component name pool */

#endif
