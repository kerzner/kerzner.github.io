// vim:smarttab expandtab sw=4
#ifndef SYSDEFNAMES_H
#define SYSDEFNAMES_H

#include <QString>
#include <QRegExp>

//! Functions to sanitize names to be acceptable for System Definitions

//! Takes a C string name as an argument and returns the name sanitized
//! as a QString.  If the string is already a acceptable (only contains
//! alpha-numeric, underscores, periods and/or colons), then the name is
//! returned as is.  Otherwise, any double quotes found in name are quoted
//! with a back-slash, and the entire name is surrounded by double quotes.
QString SysDefSanitizeName(const char *cname);
//! Takes a QString name as an argument and returns the name sanitized
//! as a QString.  If the string is already a acceptable (only contains
//! alpha-numeric, underscores, periods and/or colons), then the name is
//! returned as is.  Otherwise, any double quotes found in name are quoted
//! with a back-slash, and the entire name is surrounded by double quotes.
QString SysDefSanitizeName(QString &name);

#endif // SYSDEFNAMES_H
