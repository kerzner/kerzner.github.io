#include "SysDefEvaluator.h"

#include "SysDefDocument.h"
#include "SeSysEvalInfo.h"
#include "SeVisitors.h"

#include "Er.h"

#include <math.h>

SysDefEvaluator::SysDefEvaluator(const SysDefDocument &document) :
    m_document(const_cast<SysDefDocument*>(&document)),
    m_results(NULL),
    m_instances(1),
    m_isMapped(false),
    m_evalData(new SeSysEvalInfo)
{
    /*no-op*/
}

SysDefEvaluator::~SysDefEvaluator()
{
    /*no-op*/
}

SysDefDocument *SysDefEvaluator::getDocument()
{
    return m_document;
}

void SysDefEvaluator::mapResultsBuffer(float *buffer, size_t size)
{
    m_isMapped = true;

    // Stash the number of instances that will be evaluated as a safety check
    // when evaluate(...) is called.
    m_instances = size;

    // Use the passed buffer as the one to be populated by evaluate(...)
    m_results = buffer;
}

void SysDefEvaluator::unmapResultsBuffer()
{
    m_results  = NULL;
    m_isMapped = false;
}

bool SysDefEvaluator::isMapped()
{
    return m_isMapped;
}

float *SysDefEvaluator::evaluate(size_t nInstances,
                                 QString systemName,
                                 float *compStates)
{
    return evaluate(nInstances,
                    m_document->getSystemID(systemName),
                    compStates);
}

float *SysDefEvaluator::evaluate(size_t nInstances,
                                 size_t systemID,
                                 float *compStates)
{
    if (isMapped() && m_instances != nInstances) {
        qDebug("SysDefEvaluator::evaluate --> mismatch results buffer sizes!");
        return NULL;
    }

    //TODO: implement
    return m_results;
}

QMap<QString, float> SysDefEvaluator::evaluateAllSystems(
    QMap<QString, float> inCompStates, SeTypeID seType)
{
    QMap<QString, float> outSysValues;

    // setup for Se package evaluation
    if (!m_document->setupQualifiedSystemsAndComps()) {
        return outSysValues;  // empty map indicates failure
    }

    // create a vector for component states and set to default states
    SeValue defState = {0.0, SeTypeUnset};
    QVector<SeValue> compStates(m_document->m_qualComps->size(), defState);

    // fill the component states from the inputs
    QMapIterator<QString, float> i(inCompStates);
    while (i.hasNext()) {
        i.next();
        int compIndex = m_document->m_qualComps->getIndex(qPrintable(i.key()));
        if (compIndex != NmNOT_FOUND) {
            compStates[compIndex].type = SeTypePK;
            compStates[compIndex].value = i.value();
        }
    }
    ErClear();

    // initialize system states to a default state (use Se package states)
    int nSystems = m_document->m_systems->size();  // includes qualified systems
    for (int sysIndex = SeSyDStart; sysIndex < nSystems; sysIndex++) {
        if (SeDataSystem[sysIndex] != NULL) {
            SeDataSystem[sysIndex]->state = SeINVALID;
            SeDataSystem[sysIndex]->save = defState;
        }
    }

    // evaluate all the systems
    // (each system is evaluated once, the first time it is seen)
    for (int sysIndex = SeSyDStart; sysIndex < nSystems; sysIndex++) {
        // evaluate defined unqualified systems not evaluated yet
        // (qualified systems get evaluated as part of other systems)
        if (SeDataSystem[sysIndex] != NULL
            && SeDataSystem[sysIndex]->state == SeINVALID) {
            // evaluate using the Se package system evaluation function
            char *qualifier;
            if (!m_document->isQualifiedSystem(sysIndex)) {
                qualifier = NULL;
            } else {
                // parse qualified name from qualified system name
                QString qualifierString;
                m_document->baseName(m_document->m_systems->getName(sysIndex),
                                     &qualifierString);
                qualifier = new char[qualifierString.size() + 1];
                strcpy(qualifier, qPrintable(qualifierString));
            }
            SeSysEval(sysIndex, compStates.data(), NULL, seType, qualifier);
            delete qualifier;

            if (SeDataSystem[sysIndex]->state != SeVALID) {
                //m_errorMessage = QString("error evaluating system '%1' "
                //    "status: %2").arg(m_systems->getName(sysIndex))
                //    .arg(evalStatus);
                return outSysValues;  // error, return empty map
            }
        }
    }

    // collect all non-zero system states and fill return map
    for (int sysIndex = SeSyDStart; sysIndex < nSystems; sysIndex++) {
        float sysValue;
        if (SeDataSystem[sysIndex] != NULL
            && SeDataSystem[sysIndex]->state == SeVALID
            && (sysValue = SeDataSystem[sysIndex]->save.value) > 0) {
            outSysValues.insert(m_document->m_systems->getName(sysIndex),
                                sysValue);
        }
    }

    return outSysValues;
}

bool SysDefEvaluator::initializeEvaluation(int index,
        QVector<int> *stateQualCompIndex)
{
    int compCount;
    SeQualHash qualSystems;
    SeQualHash qualComps;

    m_evalData->topIndex = index;
    //TODO: potentially remove
    if (index == -1) {
        m_evalData->topName = "<invalid>";
        return false;  // no system currently selected (evaluation disabled)
    }
    //////////////////////////
    m_evalData->topName = m_document->getSystemName(index);

    // only check if top level system is undefined (12-03-21 ch3)
    if (SeDataSystem[index] == NULL) {
        //m_errorMessage = "System not defined";
        //vslPrint("Undefined System (%d)", index);
        return false;
    }

    int compTotalCount = m_document->getNumComponents();

    //************************************
    //  GENERATE SYSTEM EVALUATION ORDER
    //************************************

    QList<int> localOrderList;
    bool singleEvaluation;//????????????????
    singleEvaluation = false;//?????????????????
    compCount = compTotalCount;

    // XXX only need to do this if system has changed XXX [S]
    // generate order list for system if not already generated (11-12-09 ch3)
    int nSystems = m_document->getNumSystems();
    if (!systemGenerateOrderList(localOrderList,
                                 qualSystems,
                                 qualComps,
                                 index,
                                 -1,
                                 singleEvaluation)) {
        // TODO this may not be a fatal error situation
        // TODO main errors that can occur are bad system/component indexes
        // TODO mostly due to incomplete system definitions
        // check if error is fatal, i.e. there is a message (12-03-14 ch3)
        //if (!m_errorMessage.isEmpty()) {
        //    QMessageBox::warning(0, tr("Evaluation Initialization Error"),
        //        QString("System '%1' contains errors:\n\n%2")
        //        .arg(systemNameGet(index)).arg(m_errorMessage),
        //        QMessageBox::Ok);
        //    return false;
        //} else {
        //    vslDebug(UNDEF, "Cannot evaluate system (%d-%s), contains "
        //        "undefined elements\n", index, m_systems->getName(index));
        //}
        return false;
    }

    //***********************************************************
    //  SETUP CODE ARRAY
    //  (DETERMINE STACK/FRAME SIZES, GET LOCKED SYSTEM VALUES)
    //***********************************************************

    int totalCount = nSystems + m_document->getNumQualifiedSystems();
    m_evalData->locked.clear();

    m_evalData->stackSize = 0;  // maximum stack size that will be needed
    m_evalData->frameSize = 0;  // maximum frame size that will be needed

    m_evalData->code.clear();
    m_evalData->index.fill(-1, totalCount);
    m_evalData->count = 0;
    m_evalData->compCount = 0;
    QVector<int> compStateIndex;            // indexed by qualified component ID
    compStateIndex.fill(-1, compCount);
    // NOTE if SETUP CODE ARRAY is a separate function
    //      then these three vectors need to be returned
    //      for SETUP EVALUATION TABLE below
    QVector<int> localStateQualCompIndex;        // indexed by state index
    if (stateQualCompIndex == NULL) {
        stateQualCompIndex = &localStateQualCompIndex;
    }
    QVector<int> stateQualIndex;            // indexed by state index
    QVector<QList<int> > compStateIndexList(compTotalCount);  // by compIndex

    QVector<int> &code = m_evalData->code;
    foreach (int index, localOrderList) {
        int qualIndex;          // index of qualifier to apply to unqual comps
        int sysIndex;           // actual system index

        if (index >= 0) {  // unqualified system?
            sysIndex = index;
            qualIndex = -1;
            //vslDebugCont(EVAL, " %s", m_systems->getName(index));
        } else {  // qualified system
            // convert to a system index after regular systems
            index = m_document->negateIndex(index);
            qualSystems.value(index).get(sysIndex, qualIndex);
            //vslDebugCont(EVAL, " %s", m_qualSystems->getName(index));
            index += nSystems;  // index of system into evaluation arrays
        }

        // ignore undefined systems
        if (SeDataSystem[sysIndex] == NULL) {
            continue;
        }

        // only count code for unlocked systems
        // FLAG can qualifier systems by locked?
        if (SeDataSystem[sysIndex]->state == SeLOCKED) {
            // for locked systems, save locked value
            SeLockedSystem lockedSystem;
            lockedSystem.index = index;
            lockedSystem.value = SeDataSystem[sysIndex]->save;
            m_evalData->locked.append(lockedSystem);
            // FLAG can qualifier systems by locked?
            if (qualIndex == -1) {
                continue;  // skip locked unqualified systems
            }
        }

        // look for largest stack size needed
        if (m_evalData->stackSize < m_document->m_sysCode[sysIndex].stackSize) {
            m_evalData->stackSize = m_document->m_sysCode[sysIndex].stackSize;
        }
        // calculate frame size needed for function calls (12-03-16 ch3)
        if (m_evalData->frameSize < m_document->m_sysCode[sysIndex].frameSize) {
            m_evalData->frameSize = m_document->m_sysCode[sysIndex].frameSize;
        }


        // copy code for each non-locked system to code array
        // convert qualified systems/comps to absolute systems/comps
        // apply qualifier for a qualified system
        SeCodeInfo &sysCode = m_document->m_sysCode[sysIndex];
        QList<int> &sysCodeArray = sysCode.codeArray;
        for (int j = 0; j < sysCodeArray.size(); j++) {
            int codeWord = sysCodeArray[j];
            int codeIndex;
            int compIndex;
            int stateIndex;
            int tmpQualIndex;
            int qualCompIndex;
            QString qualName;
            switch (codeWord) {
            case SeNT_QUALSYS:
                // CONVERT NODE TYPE AND GENERATE GLOBAL INDEX
                // get qualified system index and
                // change to a global system index (qualified systems at end)
                codeIndex = sysCodeArray.at(++j) + nSystems;

                if (!singleEvaluation) {
                    // get translated index (next index if not seen before)
                    if (m_evalData->index.at(codeIndex) == -1) {
                        m_evalData->index.replace(codeIndex,
                                                  m_evalData->count++);
                    }
                    codeIndex = m_evalData->index.at(codeIndex);
                }

                // change node type to SYSNAME and copy system index
                code.append(SeNT_SYSNAME);
                code.append(codeIndex);
                break;

            case SeNT_QUALCOMP:
                // CONVERT NODE TYPE AND GENERATE GLOBAL INDEX
                // get qualified component index
                codeIndex = sysCodeArray.at(++j);
                qualComps.value(codeIndex).get(compIndex, tmpQualIndex);
                qualCompIndex = codeIndex;
                // get state index
                stateIndex = compStateIndex.at(codeIndex);
                if (stateIndex == -1) {  // not seen before?
                    // assign to next state index
                    stateIndex = m_evalData->compCount++;
                    compStateIndex.replace(codeIndex, stateIndex);
                    // save qualified component index for this state
                    stateQualCompIndex->append(qualCompIndex);
                    // save qualifier index for this state
                    stateQualIndex.append(tmpQualIndex);
                    // add to list of state for component
                    compStateIndexList[compIndex].append(stateIndex);
                }
                codeIndex = stateIndex;
                // change node type to COMPNAME and set component index
                code.append(SeNT_COMPNAME);
                code.append(codeIndex);
                break;

                // two word instructions
            case SeNT_COMPNAME:
                compIndex = sysCodeArray.at(++j);

                // only apply qualifer when not single evaluation
                if (qualIndex == -1) {
                    //errorMessageAppend(QString("unallowed unqualified "
                    //    "component '%1'")
                    //    .arg(m_components->getName(compIndex)));
                    break;  // will catch at end
                }
                qualName =
                    m_document
                    ->qualifiedName(m_document
                                    ->getComponentName(compIndex),
                                    qualIndex);
                codeIndex = m_document->getQualifiedComponentID(qualName);
                if (codeIndex < 0) {
                    // this should not happen (something is not working)
                    //errorMessageAppend(QString("qualified component "
                    //    "'%1' not present").arg(qualName));
                    break;  // will catch at end
                }
                qualCompIndex = codeIndex;

                // get state index
                stateIndex = compStateIndex.at(codeIndex);
                if (stateIndex == -1) {  // not seen before?
                    // assign to next state index
                    stateIndex = m_evalData->compCount++;
                    compStateIndex.replace(codeIndex, stateIndex);
                    // save qualified component index for this state
                    stateQualCompIndex->append(qualCompIndex);
                    // save qualifier index for this state
                    stateQualIndex.append(qualIndex);
                    // add to list of state for component
                    compStateIndexList[compIndex].append(stateIndex);
                }
                codeIndex = stateIndex;
                code.append(codeWord);
                code.append(codeIndex);
                //----------------------------------------
                break;

            case SeNT_SYSNAME:
            case SeNT_ASSIGNMENT:
                codeIndex = sysCodeArray.at(++j);
                if (qualIndex >= 0) {
                    //qualName = qualifiedName(m_systems->getName(codeIndex),
                    //    qualIndex);
                    qualName = m_document
                               ->qualifiedName(m_document
                                               ->getSystemName(codeIndex),
                                               qualIndex);
                    //codeIndex = m_qualSystems->getIndex(qPrintable(qualName));
                    codeIndex = m_document->getQualifiedSystemID(qualName);
                    if (codeIndex < 0) {
                        // this should not happen (something is not working)
                        //errorMessageAppend(QString("qualified system '%1' not "
                        //    "present").arg(qualName));
                        break;  // will catch at end
                    }
                    // change to a global system index
                    codeIndex += nSystems;
                }
                // get state index (next index if not seen before)
                if (m_evalData->index.at(codeIndex) == -1) {
                    m_evalData->index.replace(codeIndex,
                                              m_evalData->count++);
                }
                codeIndex = m_evalData->index.at(codeIndex);
                code.append(codeWord);
                code.append(codeIndex);
                break;

            case SeNT_CONSTANT:
            case SeNT_FNCALL:
            case SeNT_PARAM:
                code.append(codeWord);  // copy instruction
                // copy second word of instruction
                code.append(sysCodeArray.at(++j));
                break;

                // one word instructions
            default:
                code.append(codeWord);  // copy instruction
                break;
            }
        }
    }
    // lastly copy code terminator word
    code.append(SeNT_UNSET);  // expression code terminator word

    return true;
}

bool SysDefEvaluator::systemGenerateOrderList(QList<int> &orderList,
        SeQualHash &qualSystems,
        SeQualHash &qualComps,
        int index,
        int qualIndex,
        bool singleEvaluation)
{
    if (SeDataSystem[index] == NULL) {  // is system not defined?
        // this is not a fatal error (this system will be set to an unset
        // value and when evaluated, a type appropriate value will be used)
        //vslDebug(UNDEF, "System (%d) undefined\n", i);
    } else {
        SeCodeInfo &sysCode = m_document->m_sysCode[index];

        // get each system's order list
        for (int i = 0; i < sysCode.orderList.size(); i++) {
            int sysIndex;
            int sysQualIndex;

            // get qualifier and base system index if qualified system
            int index = sysCode.orderList.at(i);
            if (index >= 0) {  // unqualified system?
                sysIndex = index;
                sysQualIndex = qualIndex;
            } else {  // qualified system
                // QUALIFIER ON SYSTEM OVERRIDES INCOMING QUALIFIER

                // get actual system index for stored list index
                index = m_document->negateIndex(index);
                sysCode.qualSystems.value(index).get(sysIndex, sysQualIndex);
            }

            // check and add to order list for system with qualifier
            if (!systemGenerateOrderList(orderList, qualSystems, qualComps,
                                         sysIndex, sysQualIndex, singleEvaluation)) {
                return false;
            }
        }

        if (SeDataSystem[index]->sysdef == NULL) {
            //errorMessageAppend("Null sysdef pointer");
            return false;
        }
        // apply qualifier and add any new qualified components to list
        GetQualCompsSysdefVisitor getQualComps(m_document, qualComps,
                                               m_document->getNumComponents(), singleEvaluation);
        getQualComps.traverse(SeDataSystem[index]->sysdef, qualIndex);
        if (getQualComps.hasError()) {
            //  errorMessageAppend(getQualComps.errorMessage());
            return false;
        }
    }

    // add this system to end of order list
    if (qualIndex >= 0) {
        // apply qualifier to system name and get negated system index
        QString qualName =
            m_document->qualifiedName(m_document->getSystemName(index),
                                      qualIndex);
        int qualSysIndex = m_document
                           ->m_qualSystems
                           ->addName(qPrintable(qualName));
        qualSystems.insert(qualSysIndex, SeQualItem(index, qualIndex));
        index = m_document->negateIndex(qualSysIndex);
    }
    orderList.append(index);
    return true;
}

void SysDefEvaluator::evaluateSysDefs(int    *code,
                                      qint8  *sysTyps,
                                      float  *sysVals,
                                      qint8  *compTyps,
                                      float  *compVals,
                                      float  *stack,
                                      qint16 *frame,
                                      qint8  *status)
{
    int sp;       // stack pointer
    int fp;       // function call frame pointer (12-03-16 ch3)
    int index;    // system/component index
    float lvalue; // cache for left value (stack[sp])
    float rvalue; // cache for right value (stack[sp + 1])
    float lrprod; // work variable

    // 12-01-02 ch3: initialize status for all threads at beginning
    //               only threads with errors will set status to an error
    *status = EvaluateGood;
    sp = fp = -1;
    for (int pc = 0;;) {
        switch (code[pc++]) {
        case SeNT_SYSNAME:
            index = code[pc++];
            if (sysTyps[index] == SeTypeUnset) {
                // set value depending on type
                // TODO: for now assume desired type is SeTypeHit
                stack[++sp] = 0.0f;  // value to use for unset
            } else {
                stack[++sp] = sysVals[index];
            }
            continue;

        case SeNT_ASSIGNMENT:
            index = code[pc++];
            // set value depending on desired type
            // TODO: for now assume type is SeTypeHit
            sysTyps[index] = SeTypeHit;
            sysVals[index] = stack[sp--];
            continue;

        case SeNT_COMPNAME:
            index = code[pc++];
            if (compTyps[index] == SeTypeUnset) {
                // set value depending on type
                // TODO: for now assume desired type is SeTypeHit
                stack[++sp] = 0.0f;  // value to use for unset
            } else {
                lvalue = stack[++sp] = compVals[index];
                // FIXME not sure this is the correct action
                if (lvalue < 0) {
                    // bad component evaluation (or penetration)
                    *status = EvaluateSentinel;
                    break;
                }
            }
            continue;

        case SeNT_CONSTANT:
            // push constant value in next code word on stack as float
#if defined(__CUDA_ARCH__)
            stack[++sp] = __int_as_float(code[pc++]);
#else  // host
            stack[++sp] = *(float *)&code[pc++];
#endif
            // non-CUDA: stack[++sp] = *(float *)&code[pc++];
            continue;

            // added support for functions calls (12-03-16 ch3)
        case SeNT_FNCALL:
            // beginning of function call
            // arguments have already been evaluated and are on the stack
            // need to create a frame so that arguments can be found when
            // processing a parameter
            // (note the next value is the number of arguments minus one)
            frame[++fp] = sp - code[pc++];
            continue;

        case SeNT_PARAM:
            // push function parameter on stack (argument)
            // (note the next value is the parameter number)
            stack[++sp] = stack[frame[fp] + code[pc++]];
            continue;

        case SeNT_FUNCNAME:
            // end of function call
            // result of function expression is on top of stack
            // need to move this value and remove the frame containing
            // the values of all the parameters
            index = frame[fp--];       // get old stack pointer and remove frame
            stack[index] = stack[sp];  // move value
            sp = index;                // reset stack pointer
            continue;

        case SeNT_NOT:  // '!' or '~'
            // return the logical complement of value on top of stack
            stack[sp] = 1.0f - stack[sp];
            continue;

        case SeNT_ABS:  // '@'
            // return the absolute value of value on top of stack
            stack[sp] = fabsf(stack[sp]);
            continue;

        case SeNT_BOOL:  // '?'
            // return 1.0 if the value on top of stack is > 0.0,
            // and 0.0 otherwise */
            stack[sp] = stack[sp] > 0.0f ? 1.0f : 0.0f;
            continue;

        case SeNT_AND:   // '&'
        case SeNT_PROD:  // '*'
            // return the product of the two values on top of stack
            // if lvalue == 0 then just need to decrement stack pointer
            rvalue = stack[sp--];
            lvalue = stack[sp];
            if (lvalue != 0.0f) {
                stack[sp] = lvalue * rvalue;
            }
            continue;

        case SeNT_OR:  // '|' assumes statistical independence
            // return the complement of the conjunction of the complements
            // of left-hand and right-hand sides (De Morgan's law).  In
            // case of small values for both sides, return the difference
            // of the sum and product of the left-hand and right-hand
            // sides to guard against floating-point inaccuracies
            rvalue = stack[sp--];
            lvalue = stack[sp];
            if (lvalue == 1.0f || rvalue == 1.0f) {
                stack[sp] = 1.0f;  // saves time
            } else if (lvalue == 0.0f) {
                stack[sp] = rvalue;  // save a small amount of time
            } else if (rvalue == 0.0f) {
                continue;  // stack[sp] already set to lvalue
            } else if (fabsf(lvalue) < 0.5f && fabsf(rvalue) < 0.5f) {
                stack[sp] = lvalue + rvalue - lvalue * rvalue;
            } else {
                stack[sp] = 1.0f - (1.0f - lvalue) * (1.0f - rvalue);
            }
            continue;

        case SeNT_MIN:  // ':' or '<<'
            // return the minimum of the two values on top of stack
            rvalue = stack[sp--];
            lvalue = stack[sp];
            stack[sp] = lvalue < rvalue ? lvalue : rvalue;
            continue;

        case SeNT_MAX:  // ';' or '>>'
            // return the minimum of the two values on top of stack
            rvalue = stack[sp--];
            lvalue = stack[sp];
            stack[sp] = lvalue > rvalue ? lvalue : rvalue;
            continue;

        case SeNT_XOR:  // '^' assumes statistical independence
            // return the probability of either-L-or-R-but-not-both,
            // where the L and R probabilities are given as the left-hand
            // and right-hand operands.  In case of a large value for
            // either operand, a rearranged expression is used, to guard
            // against floating-point inaccuracies
            rvalue = stack[sp--];
            lvalue = stack[sp];
            if (lvalue == 0.0f) {
                stack[sp] = rvalue;  // saves a small amount of time
            } else if (lvalue == 1.0f) {
                stack[sp] = 1.0f - rvalue;  // saves small amount of time
            } else if (rvalue == 0.0f) {
                continue;  // stack[sp] already set to lvalue
            } else if (rvalue == 1.0f) {
                stack[sp] = 1.0f - lvalue;  // save a small amount of time
            } else if (fabsf(lvalue) < 0.5f && fabsf(rvalue) < 0.5f) {
                lrprod = lvalue * rvalue;
                stack[sp] = (lvalue + rvalue - lrprod) * (1.0f - lrprod);
            } else {
                lvalue = 1.0f - lvalue;
                rvalue = 1.0f - rvalue;
                lrprod = lvalue * rvalue;
                stack[sp] = (lvalue + rvalue - lrprod) * (lrprod - 1.0f);
            }
            continue;

        case SeNT_SUM:  // '+'
            // return sum of the two values on top of the stack
            rvalue = stack[sp--];
            lvalue = stack[sp];
            stack[sp] = lvalue + rvalue;
            continue;

        case SeNT_DIFF:  // '-'
            // return difference of the two values on top of the stack
            rvalue = stack[sp--];
            lvalue = stack[sp];
            stack[sp] = lvalue - rvalue;
            continue;

        case SeNT_QUOT:  // '/'
            // return the quotient of the two values on top of the stack
            rvalue = stack[sp--];
            if (rvalue == 0.0f) {
                *status = EvaluateDivByZero;
                break;  // this thread is done, exit for loop
            }
            lvalue = stack[sp];
            stack[sp] = lvalue / rvalue;
            continue;

        case SeNT_LT:  // '<'
            // return 1 if the left side value is less than
            // that of the right side value, otherwise 0
            rvalue = stack[sp--];
            lvalue = stack[sp];
            stack[sp] = lvalue < rvalue;
            continue;

        case SeNT_GT:  // '>'
            // return 1 if the left side value is greater than
            // that of the right side value, otherwise 0
            rvalue = stack[sp--];
            lvalue = stack[sp];
            stack[sp] = lvalue > rvalue;
            continue;

        case SeNT_LTEQ:  // '%' or '<='
            // return 1 if the left side value is less than or equal to
            // that of the right side value, otherwise 0
            rvalue = stack[sp--];
            lvalue = stack[sp];
            stack[sp] = lvalue <= rvalue;
            continue;

        case SeNT_GTEQ:  // "'" or '>='
            // return 1 if the left side value is greater than or equal to
            // that of the right side value, otherwise 0
            rvalue = stack[sp--];
            lvalue = stack[sp];
            stack[sp] = lvalue >= rvalue;
            continue;

        case SeNT_UNSET:
            // end of code, check stack pointer and return
            // only set if if there was no previous error (12-01-02 ch3)
            // added frame error (12-03-16 ch3)
            if (*status == EvaluateGood) {
                // use atomic operation to set status (12-03-23 ch3)
                if (sp != -1) {
                    *status = EvaluateStackErr;
                } else if (fp != -1) {
                    *status = EvaluateFrameErr;
                }
            }
            break;  // exit for loop

        default:
            *status = EvaluateBadCode;
            break;  // exit for loop
        }
        break;  // reached here, so exit for (pc) loop
    }
}
