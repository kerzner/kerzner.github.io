#ifndef SYSDEFDOCUMENT_H
#define SYSDEFDOCUMENT_H

#include <QSet>

#include "ApplicationDocument.h"

class NamePool;

extern "C" {
#include "Se.h"
#include "SeDefs.h"
}

//TODO: check to see what can be removed from SeEvaluation.h
#include "SeEvaluation.h"

class SysDefDocument : public ApplicationDocument
{
    Q_OBJECT

public:

    SysDefDocument(QObject *parent = 0);
    ~SysDefDocument();

    //---------------- Application Document -----------------

    /// Import a file to the document.  This will set the document file name if
    /// the document was previously empty. This method emits "documentLoaded"
    /// when the document is finished loading. (on first import only?)
    bool importFileByName(QString fileName);

    /// Save the document to the current file name.
    void saveFile();

    /// Save the document to an alternate file name.
    /// Sets the current document name
    void saveFileByName(QString fileName);

    /// Gets the text string which indicates the type or category of this
    /// document within the application. (eg "Text" or "SysDef" or "Geometry")
    QString getDocumentType();

    //--------------- Imported from SeWrapper ---------------

    /// Get qualified component index for component and qualifier indexes
    int qualifiedComponentIndex(int compIndex, int qualIndex);

    /// Get qualified component index from name
    int qualifiedComponentIndex(const QString qualName);

    /// Register a new component (or replace an existing one)
    void componentRegister(const int compindex);

    /// register a new system (or replace an existing one)
    void systemRegister(const int index);

    /// Set the type/value for a single system
    ///
    /// This will be the value used until it is changed
    /// or asked to be recomputed
    /// removed systemValueSetByName() (11-07-01 ch3)
    /// renamed systemValueSetByIndex() (11-07-01 ch3)
    /// added lock argument (11-12-13 ch3)
    //void systemValueSet(int index, SeTypeID type, float value, bool lock);

    /// Get component name from index
    /// NOTE: renamed, was 'componentNameGet'
    QString getComponentName(int compindex);

    /// Get system name from index
    /// NOTE: renamed, was 'systemNameGet'
    QString getSystemName(int sysindex);

    //---------------- Added Functoinality ------------------

    /// Get the number of components in this sysdef
    int getNumComponents();

    /// Get the number of systems in this sysdef
    int getNumSystems();

    /// Get the number of qualifiers in this sysdef
    int getNumQualifiers();

    /// Get the number of qualified components in this sysdef
    int getNumQualifiedComponents();

    /// Get the number of qualified systems in this sysdef
    int getNumQualifiedSystems();

    /// Get component ID from the component name
    int getComponentID(QString componentName);

    /// Get system ID from the system name
    int getSystemID(QString systemName);

    /// Get qualified component ID from the qualified component name
    int getQualifiedComponentID(QString componentName);

    /// Get qualified system ID from the qualified system name
    int getQualifiedSystemID(QString systemName);

    /// Get qualified component name from the qualified component ID
    QString getQualifiedComponentName(int index);

    /// Get qualified system name from the qualified system ID
    QString getQualifiedSystemName(int index);

    /// Setup qualified systems and components for Se package evaluation
    bool setupQualifiedSystemsAndComps();

    /// Added a system index to the qualified system index set
    void addQualfiedSysIndex(int sysIndex);

    /// Checks if system index refers to a qualified system
    bool isQualifiedSystem(int sysIndex);

    /// Returns a list of all systems
    QStringList getSystemNames();

    /// Returns a list of components in a system
    QStringList getComponentsInSystem(QString systemName);

    /// Returns the string system definition
    QString getSystemString(QString systemName);

    /// Parse base name from qualified name and optionally the qualifier name
    QString baseName(const QString &qualifiedName, QString *qualifier = NULL);

    /// Returns indx for the qualifierName.
    int getQualifierIndex(QString qualifierName);

    /// Create qualified name from base name and qualifier name
    QString qualifiedName(const QString &baseName, int qualIndex,
                          const QString &qualifier = QString());

private:


    // Friend types ///////////////////////////////////////////////////////////

    friend class SysdefVisitor;
    friend class SysDefEvaluator;

    // Helper functions ///////////////////////////////////////////////////////

    void setFileName(const QString &fileName);

    //--------------- Imported from SeWrapper ---------------

    // Scan new systems and report if systems are allowed
    // (allowed systems have only qualified components and no undefined systems)
    void systemScanForAllowedSystems(void);

    ///TODO: document
    ///XXX: can be removed?
    bool hasTable(void);//???????????????????????????????????

    ///TODO: document
    int negateIndex(int index);

    /// Encode a system
    ///TODO: better description
    bool systemEncode(int index, QString &errmsg);

    ///TODO: document
    void findSubSystems(QVector<bool> &topLevel, int sysIndex);

#if 0
    QList<int> componentTableList(const QString &qualCompName, int qualIndex);
#endif

    //--------------- Imported from SePrivate ---------------

    /// Resize the table to include at least newSize entries
    void resizeValueTable(const int newSize);//??????????????????????????

    /// Clear all the values
    void clearValues(int start = 0);//???????????????????????????????

    // Private data memebers //////////////////////////////////////////////////

    NamePool *m_components;    // pointer to RtComponents
    NamePool *m_qualifiers;    // pointer to SeQualifiers
    NamePool *m_qualComps;     // pointer to SeComponents
    NamePool *m_systems;       // pointer to SeSystems
    NmPool    m_seQualSystems; // qualifier system name pool
    NamePool *m_qualSystems;   // pointer to m_seQualSystems

    SeValue     *m_seValues;  // Component values array, ??????????????????
    int          m_tableSize; // size of the seValues storage array, ?????????
    SeParseVars *m_vars;      // variables needed for parsing

    // list of indexes to newly registered system
    QList<int> m_newSysIndexList;

    // coded system expressions (11-12-07 ch3)
    QVector<SeCodeInfo> m_sysCode;

    // internal hierarchy, owned by Se
    SeSyDat **&m_SeDataSystem;

    // set of qualified system indexes
    QSet<int> m_qualSysIndexes;
};

#endif // SYSDEFDOCUMENT_H
