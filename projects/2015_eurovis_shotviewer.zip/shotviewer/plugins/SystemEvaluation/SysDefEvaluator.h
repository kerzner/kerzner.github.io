#ifndef SYSDEFEVALUATOR_H
#define SYSDEFEVALUATOR_H

#include <QObject>
#include <QMap>

class SeSysEvalInfo;

#include "SysDefDocument.h"
#include "SeEvaluation.h"

/* This class encapsulates the evaluation of N sysdef trees.
 *
 */
class SysDefEvaluator : public QObject
{
    Q_OBJECT

public:

    /// Constructor, created from a SysDefDocument
    /// NOTE: 'explicit' used to ensure that the object is a SysDefDocument,
    ///       not any ApplicationDocument
    explicit SysDefEvaluator(const SysDefDocument &document);

    /// Destructor
    ~SysDefEvaluator();

    /// Accessor to get the underlying document for this evaluator
    SysDefDocument *getDocument();

    /// Map/unmap the results buffer.
    ///
    /// NOTE: If evaluate(...) is called without a mapped buffer, it will create
    ///       the buffer of results to be returned. Mapping the buffer here is
    ///       useful when the results buffer has been pre-allocated;
    void mapResultsBuffer(float *buffer, size_t size);
    void unmapResultsBuffer();
    bool isMapped();

    /// Evaluate the sysdefs based on set component pks, returns success
    ///
    /// NOTE: The returned memory pointer will be 'new' memory if there is no
    ///       mapped results buffer.
    /// NOTE: The first version of the function here is for convienience, it
    ///       simply calls the second.
    float *evaluate(size_t nInstances, QString systemName, float *compStates);
    float *evaluate(size_t nInstances, size_t  systemID,   float *compStates);

    /// For one sysdef instance, evaluate ALL systems given all component states
    QMap<QString, float> evaluateAllSystems(QMap<QString, float> inCompStates,
        SeTypeID seType = SeTypePK);

private:

    // Helper functions ///////////////////////////////////////////////////////

    bool initializeEvaluation(int index,
                              QVector<int> *stateQualCompIndex = NULL);

    // generate reverse system evaluation order list (11-12-07 ch3)
    //
    //   - a system with an empty order list indicates either the system
    //     calls no other systems or is not defined (later is okay)
    //   - builds order list recursively by prepending order list of each
    //     system called
    //   - qualified systems found are appended to the info qualified
    //     systems list
    // possible errors:
    //   system not defined (unlikely)
    //   system not encoded (possibly due to system containing undefined systems)
    //   null sysdef pointer (unlikely)
    //   invalid system index (incomplete)
    //   invalid component index (incomplete)
    //   unexpected sysdef type node (unlikely should have been caught when encoded)
    bool systemGenerateOrderList(QList<int> &orderList,
                                 SeQualHash &qualSystems,
                                 SeQualHash &qualComps,
                                 int index,
                                 int qualIndex,
                                 bool singleEvaluation);

    // device/host function to evaluate a series of encode system definitions
    void evaluateSysDefs(int    *code,
                         qint8  *sysTyps,
                         float  *sysVals,
                         qint8  *compTyps,
                         float  *compVals,
                         float  *stack,
                         qint16 *frame,
                         qint8  *status);

    // Private Data ///////////////////////////////////////////////////////////

    // Document that this evaluator runs on
    SysDefDocument *m_document;

    // Buffer of top level system results to be populated by evaluate(...)
    float *m_results;

    // Number of instances to be evaluated
    uint m_instances;

    // Is the results buffer mapped?
    bool m_isMapped;

    // Internal data necessary to evaluate the sysdef
    SeSysEvalInfo *m_evalData;
};

#endif // SYSDEFEVALUATOR_H
