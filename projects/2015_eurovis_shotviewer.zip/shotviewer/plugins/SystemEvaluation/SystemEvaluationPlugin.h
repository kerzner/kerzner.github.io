#ifndef OSGPLUGIN_H
#define OSGPLUGIN_H

#include "SystemEvaluationPlugin_global.h"
#include <QObject>
#include <QMap>
#include "IDocPlugin.h"
#include "IViewPlugin.h"
#include "ApplicationDocument.h"
#include "ApplicationView.h"

/**
 * @brief The SystemEvaluationPlugin class.
 *
 * This implements a trivial plugin using the PluginInterface
 */
class SYSEVALPLUGINSHARED_EXPORT SystemEvaluationPlugin : public QObject,
    public IDocPlugin
{
    Q_OBJECT
    Q_INTERFACES(IDocPlugin)
#if QT_VERSION >= 0x050000
    Q_PLUGIN_METADATA (IID "mil.army.arl.lee.SystemEvaluationPlugin")
#endif

public:

    SystemEvaluationPlugin(QObject *parent = 0);

    ~SystemEvaluationPlugin();

    //---------------- IDocPlugin -----------------

    /// Returns a list of filename extensions the plugin can load
    QStringList getFilenameExtensions();

    /// Get the category of document (eg. "Text" or "Sysdef" or "Geometry")
    /// This must also be the name of the type of application model that is
    /// created.
    QString getDocumentCategory();

    /// Generate a document of the type this plugin supports.
    ApplicationDocument * createDocument();

    /// Returns a human-readable name of the plugin.
    /// This should be indicative of the function(s) provided.
    QString getPluginName();

    /// The list of views that are opened by default when this type of
    /// document is loaded.
    QStringList defaultViews();
};

#endif // OSGPLUGIN_H
