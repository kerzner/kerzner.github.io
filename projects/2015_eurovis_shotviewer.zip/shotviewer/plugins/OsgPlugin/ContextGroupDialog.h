#ifndef CONTEXTGROUPDIALOG_H
#define CONTEXTGROUPDIALOG_H

#include <QDialog>

namespace Ui
{
class ContextGroupDialog;
}

/** This class is used to get a list strings that will define the context
 * or landmark geometry shown in the OsgViewer.
 *
 * A major limitation of this class is that it just displays a text box
 * and the user is supposed to know that each line will be parsed into a regexp.
 * For each of these regexps, we'll search for MUVES component names that match
 * it and display those components.
 *
 * TODO: This could be improved by giving the user immediate feedback on the
 * selected geometry, say, by showing a list of the selected component names.
 * This could also be modified to preserve context geometry sets between
 * application runs.
 */
class ContextGroupDialog : public QDialog
{
    Q_OBJECT

public:

    /// Constructor.
    explicit ContextGroupDialog(QWidget *parent = 0);

    /// List that will be shown in the text edit.
    void setContextNameList(const QStringList &list);

    /// Returns the list of names user has entered. Although this returns a list
    /// of strings, they really get treated as QRegExps.
    QStringList getContextNameList();

    ~ContextGroupDialog();

private:

    Ui::ContextGroupDialog *ui;
};
#endif // CONTEXTGROUPDIALOG_H
