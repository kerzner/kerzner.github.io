#ifndef OSGVIEW_H
#define OSGVIEW_H

#include <QWidget>
#include <QTimer>
#include <QTime>

#include <osgViewer/Viewer>
#include <osgGA/TrackballManipulator>

#include "OSGWidget.h"
#include "ApplicationView.h"

#include "ShotlineView.h"
#include "IrData.h"
class OsgDocument;
class RegmapApplicationDocument;
class IRDocument;
class IRShotlineThreat;
class SysDefDocument;
class QLabel;
class QSlider;
class QCheckBox;
class QHBoxLayout;

namespace Ui
{
class OsgView;
}

/** The OsgView is responsible for drawing the 3D vehicle geometry and a 3D
 * representation of all loaded aimPoints. It needs the following documents:
 *  1. IRDocument
 *  2. OsgDocument containing the target geometry
 *  3. RegmapDocument for mapping MUVES names to BRL-CAD region ids
 *  4. SysDefDocument for allowing users to draw individual systems
 * The view will simply not work unless it has all four of these documents.
 *
 * IMPORTANT NOTE: I created this class to rapidly test ideas of 3D rendering. I
 * made design decisions based on what would be fastest to implement--as opposed
 * to easiest to maintain or most computationally efficient. I *strongly*
 * recommend re-writing a 3D geometry viewing class instead of using this one.
 *
 * Interaction with EBOsgViewer
 *
 * The OsgView displays geometry using an EBOsgViewer. The EBOsgViewer uses
 * libembree to render open scenegraph geometry. OsgView manages the scenegraph
 * which gets handed to EBOsgViewer. This scenegraph includes information about
 * the vehicle geometry, shotline visualizations, and current highlighting.
 * This will call EBOsgViewer::setSceneGeometry(...) or
 * EBOsgViewer::setSceneMaterials(...) when the selected geometry, shotlines,
 * or highlighting changes.
 *
 * The scene that gets passed to EBOsgViewer is the private member of this:
 * m_root. This m_root is different from the root of loaded osg model.
 * In particular, this m_root contains the shotline visualization and
 * highlighting information too.
 *
 * Managing m_root
 *
 * m_root contains the scene that this is displaying. This maintains the
 * children of m_root, which include:
 *  1. m_shot: all shot components
 *  2. m_context: user-defined context geometry
 *  3. m_other: all other vehicle geometry
 *  4. per-shotline cylinder geometry (stored in m_shotlines)
 *  5. m_system: user-selected system of interest
 *
 * When the slot updateShotlines gets called, this will update the children
 * of m_shot #1, #2, and #3 with the methods updateShotGroup(),
 * updateContextGroup(), and updateOtherGroup(). The construction of these
 * geometry groups is order DEPENDENT. At a high level, we start with a set
 * of all loaded geometry, then take the shot and context geometry from that
 * group. Whatever is left in the group of all geometry gets stuck in the
 * other group.
 *
 * The child #4 is updated after all of these other groups have been updated. It
 * is updated by creating shotline geometry and adding to the root.
 *
 * The m_system group only changes when the user selects a new system to be
 * drawn. The SelectSystemDialog is used to prompt the user for a system to
 * be displayed.
 *
 * Context Geometry
 *
 * This uses the idea of user-recognizable so-called "context geometry" sets
 * that provide spatial context to the shotlines and shot components. These
 * sets are defined with regular expressions. The ContextGroupDialog is used
 * to prompt the user for regular expressions.
 *
 * Managing Materials
 *
 * Information about the color and opacity of 3D geometry gets sent to the
 * renderer through osg materials. In particular, each osg drawable gets a
 * material assigned to it. This calls EBOsgViewer::updateSceneMaterials or
 * EBOsgViewer::updateSceneGeometry when the materials have changed. This tells
 * the EBOsgViewer to rip out the new material information from the scene.
 *
 * User Interaction for Opacity and Color
 *
 * When the user changes the color or opacity of geometry from the GUI, then
 * this will update the material of user-specified geometry that is getting
 * changed. It then calls EBOsgViewer::updateSceneMaterials(...).
 *
 * Receiving Highlighting
 *
 * Highlighting is also done through the use of materials. In particular, for a
 * given shotline, this has one geode per trace. When the user highlights a
 * trace, this will change the material of that geode to black, then call
 * EBOsgViewer::updateSceneMaterials(...).
 *
 * Sending Highlighting
 *
 * This relies on the EBOsgViewer to tell it when the user is mousing over a
 * component. The EBOsgViewer calls mouserOverComponentEvent(...) which sends
 * a highlighting signal to all the other views.
 */
class OsgView : public ShotlineView
{
    Q_OBJECT

public:

    OsgView(QWidget *parent=0);

    ~OsgView();

    QStringList getRequiredDocTypes();

public slots:

    /// This is always displaying the root node. We toggle visibility of
    /// geometry groups by removing children from the root.
    void rootAddOrRemoveGroup(osg::ref_ptr<osg::Group> child, bool add);

    /// Toggle visibility of m_other.
    void on_checkBoxOtherVisible_stateChanged(int);

    /// Toggle visibility of m_context.
    void on_checkBoxContextVisible_stateChanged(int);

    /// Toggle visibility of m_system.
    void on_checkBoxSystemVisible_stateChanged(int);

    /// Displays the ContextGroupDialog to get a list of regular expressions.
    void on_pushButtonContextSet_pressed();

    /// Change opacity of m_shot group.
    void on_sliderShotOpacity_valueChanged(int);

    /// Change opacity of m_context.
    void on_sliderContextOpacity_valueChanged(int);

    /// Change opacity of m_other.
    void on_sliderOtherOpacity_valueChanged(int);

    /// Change opacity of m_system.
    void on_sliderSystemOpacity_valueChanged(int);

    /// Change the radius of the shotline cylinders. This is done by deleting
    /// and recreating the osg cylinder representation.
    void on_sliderShotRadius_valueChanged(int);

    /// Displays the SelectSystemDialog to let user select system.
    void on_pushButtonSystemSelect_pressed();

    /// Prompts user for color and updates color of m_system.
    void on_pushButtonSystemColorChange_pressed();

    /// Prompts user for color and updates color of m_other.
    void on_pushButtonOtherColorChange_pressed();

    /// Prompts user for color and updates color of m_context.
    void on_pushButtonContextColorChange_pressed();

    /// Prompts user for color and updates color of m_shot.
    void on_pushButtonShotColorChange_pressed();

    /// Called when the user changes visibility of one of the shotlines.
    void checkBoxShotAimpointVisibleStateChanged(int);

    /// Gets called when the user has changed the shotlines displayed.
    void updateShotlines();

    /// Toggles highlighting on shotline traces. See ShotlineView.h for descr.
    /// of parameters.
    virtual void setMouseHoverHighlight(const QMap<int, QList<int> > &,
                                        const int &,
                                        const bool &,
                                        const int &);

    /// Called by EBOsgViewer when the mouse is on top of a components.
    /// map: key = aim point, value = list of traces under mouse
    /// aimPoint = the aimpoint that the mouse is on top of.
    virtual void mouseOverComponentEvent(const QMap<int, QList<int> > &map,
                                         int aimPoint);

    /// Returns just the EBOsgViewer--used for saving screenshots.
    virtual QWidget *getImageWidget() const;

private slots:

    /// Thes are overridden from ApplicationView. They don't do much now.
    void fileImportCompleted();
    void fileImportFailed();
    void fileSaveCompleted();
    void fileSaveFailed();
    void fileNameWillChange(const QString &oldFileName,
                            const QString &newFileName);
    void documentClosing();

    /// QActions signal this to change the mouse mode on the OSGWidget
    void menuSetMouseMode();

    /// When OSGWidget changes mouse mode this gets signaled
    void mouseModeChanged(OSGWidget::MouseMode mode);

protected:

    Ui::OsgView *ui;

private:

    /// Save internal state
    void settingsLoad();

    /// Load internal state
    void settingsSave();

    /// Creates a context group of geometry from a list of regexps.
    void updateContextGroup();

    /// Creates shot group of geometry from IRDocument.
    void updateShotGroup();

    /// Creates group of everything that is not in context, shot or system.
    void updateOtherGroup();

    /// Set the color and opacity of the group.
    /// -labelPatch: label containing color that is displayed in the GUI
    /// -group: the group getting its color changed
    /// -opacity: desired alpha value in the range (0, 1)
    void updateColor(QLabel *labelPatch, osg::ref_ptr<osg::Group> group,
                     float opacity);

    /// Populates the GUI with colors of shotlines.
    void updateShotSetGUI();

    /// Set the alpha of group. Calls EBOsgViewer::updateSceneMaterials(...).
    void groupSetOpacity(osg::ref_ptr<osg::Group> group, float alpha);

    /// Set the color of the group.
    void groupSetColor(osg::ref_ptr<osg::Group> group, QColor color);

    /// Returns the color and opacity from GUI elements.
    QColor getColorFromUi(QLabel *labelPatch, QSlider *opacitySlider);

    /// Creates a set of tubes representing a shotline.
    osg::ref_ptr<osg::Group> shotlineGeometryCreate(int aimPoint, float radius);

    /// Creates a single tube used in shotline geometry.
    osg::ref_ptr<osg::Geode> shotlineGeodeCreate(const IRTrace *first,
            const IRTrace *last,
            float radius,
            osg::Vec4 color);

    /// Attach a OsgDocument, otherwise does nothing
    void attachDocument(ApplicationDocument *doc);

    /// These track the QActions that are used to set mouse modes
    QList<QAction *> m_mouseModeActions;

    // Overridden from ApplicationView ////////////////////////////////////////

    /// Create menu items for the camera to be inserted in MainWindow's menus
    QList<QMenu*> createMenus();

    /// Create the toolbar to be used by MainWindow
    QToolBar *createToolBar();

    // Private data ///////////////////////////////////////////////////////////

    /// Document mapping from muves names to brlcad region ids.
    RegmapApplicationDocument *m_regmapDoc;

    /// Document containing target geometry.
    OsgDocument *m_osgDoc;

    /// IR Document.
    IRDocument *m_irDoc;

    /// SysDefDocument (for displaying individual systems).
    SysDefDocument *m_sysDefDoc;

    /// List of regexps used for creating the context set.
    QList<QRegExp> m_contextNames;

    /// Group that holds all geometry currently being drawn by embree
    osg::ref_ptr<osg::Group> m_root;

    /// Geometry that does not fit into one of the groups below
    osg::ref_ptr<osg::Group> m_other;

    /// User-defined context geometry
    osg::ref_ptr<osg::Group> m_context;

    /// Children are sets of shot components
    osg::ref_ptr<osg::Group> m_shot;

    /// User-selected system being drawn
    osg::ref_ptr<osg::Group> m_system;

    /// keys = aimPoints, values = groups of shotline tubes
    QMap<int, osg::ref_ptr<osg::Group> > *m_shotlines;

    /// keys = aimPoints, values = sets of shot geometry
    QMap<int, osg::ref_ptr<osg::Group> > *m_shotSets;

    /// Layouts that hold the check boxes for controlling shot geometry sets
    QList<QHBoxLayout*> *m_aimPointCheckBoxes;

    /// Menu item. If checked then tube names appear on mouse over.
    QAction *m_showTubeNamesAction;

    /// Menu item. If checked then all component names appear under the mouse.
    QAction *m_showComponentNamesAction;
};

#endif // OSGVIEW_H
