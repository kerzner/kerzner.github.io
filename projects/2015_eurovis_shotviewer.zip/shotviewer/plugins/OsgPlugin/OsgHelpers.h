#ifndef OSGHELPERS_H
#define OSGHELPERS_H

#include <osg/Vec3>
#include <QColor>
#include <osg/Geode>

/** This file contains some helper functions for converting between osg and qt
 * data structures. It also has methods for searching osg node descriptions.
 */

/// Converts array of 3 doubles into a osg::Vec3
inline osg::Vec3 osgVecFromDoubles(const double values[])
{
    return osg::Vec3(values[0], values[1], values[2]);
}

/// Converts QColor to osg::Vec4
inline osg::Vec4 osgVecFromQColor(const QColor &color)
{
    return osg::Vec4(color.redF(), color.greenF(), color.blueF(), color.alphaF());
}

/// Returns the region id of a geode by looking for osg descriptions formatted:
/// "regionId=X" or "region_id=X". This is based on the nissan and bmp2 test
/// data, not a formal definition of osg node descriptions.
/// If there is no valid regionId found then this method will abort the
/// application. It should probably do something more intelligent.
inline int geodeRegionId(const osg::Geode &geode)
{
    // Loop over all descriptions.
    std::vector<std::string> list = geode.getDescriptions();
    for (uint i = 0; i < list.size(); i++) {

        QString description = QString::fromStdString(list.at(i));

        if (description.contains("regionId") || description.contains("region_id"))   {
            int region = description.split("=")[1].toInt();
            return region;
        }
    }

    // Should never happen.
    abort();
    return -1;
}

/// Returns the muves name of a geode. Expects the osg node description to be
/// in the form "muvesName=X." If no muves name is found then it will return an
/// empty string.
inline QString geodeMuvesName(const osg::Geode &geode)
{
    std::vector<std::string> list = geode.getDescriptions();
    for (uint i = 0; i < list.size(); i++) {
        QString description = QString::fromStdString(geode.getDescriptions().at(i));
        if (description.contains("muvesName")) {
            return description.split("=")[1];
        }
    }
    return QString();
}

/// If a geode represents part of a shotline cylinder, then we add a description
/// "AP=X". This returns the aimpoint value for a geode or 0 if one doesn't
/// exist.
inline int geodeAimPoint(const osg::Geode &geode)
{
    std::vector<std::string> list = geode.getDescriptions();
    for (uint i = 0; i < list.size(); i++) {
        QString description = QString::fromStdString(geode.getDescriptions().at(i));
        if (description.contains("AP=")) {
            return description.split("=").at(1).toInt();
        }
    }
    return 0;
}

/// If a geode represents part of a shotline cylinder, then we add a description
/// "component=X" where component here is really a trace index. This will return
/// -1 if there is no valid description.
inline int geodeComponentId(const osg::Geode &geode)
{
    std::vector<std::string> list = geode.getDescriptions();
    for (uint i = 0; i < list.size(); i++) {
        QString description = QString::fromStdString(geode.getDescriptions().at(i));
        if (description.contains("component=")) {
            return description.split("=").at(1).toInt();
        }
    }
    return -1;
}

#endif // OSGHELPERS_H
