#include "OsgDocument.h"

#include <osgDB/ReadFile>
#include <QStringList>
#include <QDebug>
#include <QMessageBox>
#include <QApplication>

#include "OsgVisitors.hpp"

OsgDocument::OsgDocument(QObject *parent)
    : ApplicationDocument(parent)
    , m_geometry(new osg::Group)
{
    /*no-op*/
}

bool OsgDocument::importFileByName(QString fileName)
{
    //TODO: check for errors!

    // Tell the user that we're loading geometry.
    // TODO: thread this.
    QMessageBox box;
    box.setText("Loading geometry file. This may take a while...");
    box.setWindowTitle("Loading geometry file");
    box.show();
    qApp->processEvents();
    osg::Node *newNode = osgDB::readNodeFile(fileName.toStdString());
    if (!newNode) {
        emit fileImportFailed();
        return false;
    }

    m_geometry->addChild(newNode);

    // if the document was previously "untitled"
    if (m_fileName.isEmpty()) {
        this->setFileName(fileName);
    }

    emit fileImportCompleted();
    return true;
}

void OsgDocument::setFileName(const QString &fileName)
{
    emit fileNameWillChange(m_fileName, fileName);
    m_fileName = fileName;
}

void OsgDocument::saveFile()
{
    saveFileByName(m_fileName);
}

void OsgDocument::saveFileByName(QString fileName)
{
    //TODO: implement saving the geometry

    // emit fileSaveFailed();

    emit fileSaveCompleted();
}

QString OsgDocument::getDocumentType()
{
    return QString("OSG");
}

osg::ref_ptr<osg::Group> OsgDocument::getData()
{
    return m_geometry;
}

osg::ref_ptr<osg::Group> OsgDocument::groupCreate(const QList<int> &regions)
{
    OsgMuvesFinder visitor(regions);
    osg::Node *node = getData();
    visitor.traverse(*node);

    return visitor.getGroup();
}

void OsgDocument::groupDelete(osg::ref_ptr<osg::Group> &group)
{
    qDebug() << Q_FUNC_INFO;
}

void OsgDocument::groupSetStateSet(osg::ref_ptr<osg::Group> &group, osg::StateSet &stateSet)
{
    qDebug() << Q_FUNC_INFO;
}
