#include "OsgPlugin.h"

#include "OsgDocument.h"
#include "OsgView.h"

OsgPlugin::OsgPlugin(QObject *parent) :
    QObject(parent)
{
    /*no-op*/
}

OsgPlugin::~OsgPlugin()
{
    /*no-op*/
}

//---------------- IDocPlugin -----------------

QStringList OsgPlugin::getFilenameExtensions()
{
    QStringList extList;
    extList.append("osg");
    extList.append("ive");
    return extList;
}

QString OsgPlugin::getDocumentCategory()
{
    return QString("OSG");
}

ApplicationDocument * OsgPlugin::createDocument()
{
    return new OsgDocument;
}

QString OsgPlugin::getPluginName()
{
    return QString("OsgPlugin");
}

QStringList OsgPlugin::defaultViews()
{
    QStringList views;
    views.append("OsgView");
    return views;
}

//---------------- IViewPlugin -----------------

QStringList OsgPlugin::getViewNames()
{
    QStringList viewNames;
    viewNames.append("OsgView");
    return viewNames;
}

QStringList OsgPlugin::dataModelTypesSupported(const QString viewName)
{
    QStringList models;

    if (!viewName.compare("OsgView")) {
        models.append("OSG");
    }

    return models;
}

ApplicationView *OsgPlugin::genView(const QString name)
{
    if (name == "OsgView") {
        return new OsgView;
    } else {
        return NULL;
    }
}

#if QT_VERSION < 0x050000
Q_EXPORT_PLUGIN2(OsgPlugin, OsgPlugin)
#endif
