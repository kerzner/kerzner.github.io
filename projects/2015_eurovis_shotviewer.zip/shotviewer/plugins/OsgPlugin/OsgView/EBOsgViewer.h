#ifndef EBOSGVIEWER_H
#define EBOSGVIEWER_H

#include "OSGWidget.h"

typedef int32_t int32;
#include "embree2/rtcore.h"
#include "embree2/rtcore_ray.h"

#include <string>
using std::string;

/** A class for rendering geometry using Embree. This class inherits the
 * OSGWidget so that we can use the existing OSG camera manipulation code. Just
 * like the OsgView, I recommend not using this class for future work.
 *
 * This class was originally written by Jefferson Amstutz at SURVICE Engineering
 * but I have modified it to work within Shotviewer. Jeff's class would be a
 * good starting place for rewriting this one.
 *
 * Setting up the Scene
 *
 * To setup the scene, the root node hsould be passed into setScene(...). In
 * addition to converting OSG geometry into something that embree can render
 * (by calling processOsgGeometry(...), setScene also updates the camera so that
 * the scene fits nicely in the window.
 *
 * Changing the Scene
 *
 * When the user changes the visibility of geometry, the setSceneGeometry(...)
 * method should be called. This will update only the geometry being rendered.
 * It does NOT change the camera.
 *
 * Changing Materials
 *
 * Highlighting is done through materials. The method updateSceneMaterials(...)
 * will rip out new material information from the osg scene. It assumes that the
 * scene currently being rendered is the same one passed into the method.
 *
 * Handing Mouse Interaction
 *
 * The mouse interaction is currently handled by the paintGL method. paintGL
 * shoots rays for the entire camera. If one of those rays is currently under
 * the mouse, then this class tracks what components were along that ray. This
 * will then send that information to OsgView, and OsgView sends it to the
 * entire application.
 *
 * The mouse interaction should probably be handled in a mouseMove callback. I
 * was just lazy when implementing it, so it got thrown into the paintGL method.
 *
 */
class EBOsgViewer : public OSGWidget
{
    Q_OBJECT

public:
    EBOsgViewer(QWidget *parent);
    ~EBOsgViewer();

    // Overridden functions from QtOSGViewer //////////////////////////////////

    /// Sets the geom from the root node it is passed by extracting triangles.
    /// Updates camera parameters so geometry fits nicely in the window.
    virtual void setScene(osg::Node *root);

    /// Updates the scene geometry without changing camera paramters.
    virtual void setSceneGeometry(osg::Node *root);

    /// Updates only the material indexes and colors.
    void updateSceneMaterials(osg::Node *root);

    /// Extracts geometry from osg scene.
    void processOsgGeometry(osg::Node *root);

    //! Initialization
    virtual void initializeGL();

    //! Resize window
    virtual void resizeGL(int width, int height)
    {
        resize(width, height);
    }

    //! Render a frame
    virtual void paintGL();

private:

    // Helper functions ///////////////////////////////////////////////////////

    //! Allocate buffers
    void allocateBuffers();

    //! Release buffers
    void freeBuffers();

    //! Resize buffers to window size
    void resize(uint width, uint height);

    // Data members ///////////////////////////////////////////////////////////

    //! Indicates whether or not EBOsgViewer is in a valid state
    bool valid;
    bool inited;
    bool meshed;

    //! Image width and height
    uint width;
    uint height;

    //! Pixel coordinates
    float xinit;
    float yinit;

    float dx;
    float dy;

    // Ray origin --> camera position
    float org[3];

    //! Background color
    uint bg;

    //! Framebuffer
    uint* framebuffer;

    // Embree data members ////////////////////////////////////////////////////

    //! Embree scene
    RTCScene scene;

    typedef float color[4];

    //! Materials buffer
    color *materials;
    uint  *matIds;

    //! Muves names buffer
    uint *muvesNameIds;
    QStringList *muvesNames;
    uint *aimPoints;
    uint *componentIds;

};

#endif // EBOSGVIEWER_H
