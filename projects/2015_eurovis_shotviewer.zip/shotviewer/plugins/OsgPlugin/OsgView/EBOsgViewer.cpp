#include "EBOsgViewer.h"

#include "TriangleContainer.h"
#include "OSGTriangleExtractor.h"

#include <QTime>

#include <iostream>
using std::cerr;
using std::endl;
using std::flush;

#include <exception>

#include <limits>
#include <math.h>
#define Pi M_PI
#define DegreesToRadians M_PI/180.f
#include <stdio.h>

#include <QDebug>

#include "OsgView.h"

typedef int   Triangle[3];
typedef float Vertex[4];
typedef Vertex color;

EBOsgViewer::EBOsgViewer(QWidget *parent):
    OSGWidget(parent),
    valid(false),
    inited(false),
    meshed(false),
    width(0),
    height(0),
    xinit(0.f),
    yinit(0.f),
    dx(0.f),
    dy(0.f),
    bg(0),
    framebuffer(0)
    ,scene(0)
    ,materials(0)
    ,matIds(0)
    ,muvesNames(new QStringList())
{
}

EBOsgViewer::~EBOsgViewer()
{
    // ////////////////////////////////////////////////////////////////////////
    // Release acquired resources

    freeBuffers();

    rtcDeleteScene(scene);
    delete materials;
    delete matIds;
}

void EBOsgViewer::initializeGL()
{
    if (inited)
        return;

    //TODO: add initialization code
    try {
        rtcInit();
    } catch(std::exception e) {
        qDebug("catching init error: %s", e.what());
    }

    inited = true;
    valid  = (inited && meshed);
}

void EBOsgViewer::setScene(osg::Node *root)
{
    OSGWidget::setScene(root);
    processOsgGeometry(root);
}

void EBOsgViewer::setSceneGeometry(osg::Node *root)
{
    OSGWidget::setSceneGeometry(root);
    processOsgGeometry(root);
}

void EBOsgViewer::updateSceneMaterials(osg::Node *root)
{
    // Process OSG geometry ///////////////////////////////////////////////////

    TriangleContainer container;

    TriangleExtractor extractVisitor(&container);

    root->accept(extractVisitor);

    const vector<osg::Vec3> &v = container.getVertices();
    const vector<uint>      &t = container.getIndices();
    const vector<osg::Vec4> &m = container.getMaterials();
    const vector<uint>      &d = container.getMaterialIds();

    const uint ntris  = container.getNumTriangles();

    materials = new color[m.size()];
    for (uint i = 0; i < m.size(); ++i) {
        materials[i][0] = m[i].r();
        materials[i][1] = m[i].g();
        materials[i][2] = m[i].b();
        materials[i][3] = m[i].a();
    }

    matIds = new uint[ntris];
    for (uint i = 0; i < ntris; ++i)
        matIds[i] = d[i];

}

void EBOsgViewer::processOsgGeometry(osg::Node *root)
{
    this->advance();
    this->eventTraversal();
    this->updateTraversal();

    // Destroy current Embree scene (if necessary) ////////////////////////////

    if (meshed)
        rtcDeleteScene(scene);

    meshed = false;
    valid  = false;

    // Initialize Embree (if necessary)
    initializeGL();
    if (!inited) {
        meshed = false;
        valid  = false;

        return;
    }

    // Process OSG geometry ///////////////////////////////////////////////////

    TriangleContainer container;

    TriangleExtractor extractVisitor(&container);

    root->accept(extractVisitor);

    const vector<osg::Vec3> &v = container.getVertices();
    const vector<uint>      &t = container.getIndices();
    const vector<osg::Vec4> &m = container.getMaterials();
    const vector<uint>      &d = container.getMaterialIds();

    const vector<QString>   &names = container.getMuvesNames();
    const vector<uint>      &nIds = container.getMuvesNamesIds();
    const vector<uint>      &aps = container.getAimPoints();
    const vector<uint>      &cIds = container.getComponentIds();

    const uint nverts = v.size();
    const uint nind   = t.size();
    const uint ntris  = container.getNumTriangles();
    const uint nnames = container.getNumMuvesNames();

    if (ntris < 1) {
        fprintf(stderr, "No triangles present!\n");
        return;
    }

    float* verts = new float[3*nverts];
    for (uint i = 0; i < nverts; ++i) {
        verts[3*i+0] = v[i].x();
        verts[3*i+1] = v[i].y();
        verts[3*i+2] = v[i].z();
    }

    uint* inds = new uint[nind];
    for (uint i = 0; i < nind; ++i)
        inds[i] = t[i];

    materials = new color[m.size()];
    for (uint i = 0; i < m.size(); ++i) {
        materials[i][0] = m[i].r();
        materials[i][1] = m[i].g();
        materials[i][2] = m[i].b();
        materials[i][3] = m[i].a();
    }

    matIds       = new uint[ntris];
    muvesNameIds = new uint[ntris];
    aimPoints    = new uint[ntris];
    componentIds = new uint[ntris];
    for (uint i = 0; i < ntris; ++i) {
        matIds[i] = d[i];
        muvesNameIds[i] = nIds[i];
        aimPoints[i] = aps[i];
        componentIds[i] = cIds[i];
    }

    muvesNames->clear();
    for (uint i = 0; i < nnames; i++) {
        muvesNames->append(names.at(i));
    }

    // Create Embree scene ////////////////////////////////////////////////////

    scene = rtcNewScene(RTC_SCENE_STATIC, RTC_INTERSECT1 | RTC_INTERSECT4 |
                        RTC_INTERSECT8 | RTC_INTERSECT16);
    uint mesh = rtcNewTriangleMesh(scene, RTC_GEOMETRY_STATIC, ntris, nverts);

    Triangle* triangles = (Triangle*)rtcMapBuffer(scene,mesh,RTC_INDEX_BUFFER);
    Vertex*    vertices = (Vertex*)rtcMapBuffer(scene,mesh,RTC_VERTEX_BUFFER);

    for (uint i = 0; i < nverts; ++i) {
        vertices[i][0] = verts[3*i+0];
        vertices[i][1] = verts[3*i+1];
        vertices[i][2] = verts[3*i+2];
    }

    for (uint i = 0; i < ntris; ++i) {
        triangles[i][0] = t[3*i+0];
        triangles[i][1] = t[3*i+1];
        triangles[i][2] = t[3*i+2];
    }

    rtcUnmapBuffer(scene, mesh, RTC_INDEX_BUFFER);
    rtcUnmapBuffer(scene, mesh, RTC_VERTEX_BUFFER);

    rtcCommit(scene);

    delete verts;
    delete inds;

    // Update related state ///////////////////////////////////////////////////

    meshed = true;
    valid  = (inited && meshed);

    resize(width, height);
}

void EBOsgViewer::resize(uint width, uint height)
{
    OSGWidget::resizeGL(width, height);

    this->width  = width;
    this->height = height;

    if (!valid)
        return;

    freeBuffers();

    // Update state ///////////////////////////////////////////////////////////

    float iw = 1.f/static_cast<float>(width);
    float ih = 1.f/static_cast<float>(height);

    xinit = -1.f + iw;
    yinit = -1.f + ih;

    dx = 2.f*iw;
    dy = 2.f*ih;

    // Allocate buffers ///////////////////////////////////////////////////////

    allocateBuffers();
}

void EBOsgViewer::paintGL()
{
    osg::Camera *cam = this->getCamera();
    const osg::Viewport* vp = cam->getViewport();

    m_viewingCore->setAspect(vp->width() / vp->height());

    cam->setViewMatrix(m_viewingCore->getInverseMatrix());
    cam->setProjectionMatrix(m_viewingCore->computeProjection());

    if (!valid || !framebuffer)
        return;

    this->advance();
    this->eventTraversal();
    this->updateTraversal();

    // Update camera //////////////////////////////////////////////////////////

    osg::Vec3f eye;
    osg::Vec3f lookat;
    osg::Vec3f up;

    getCamera()->getViewMatrixAsLookAt(eye, lookat, up);

    osg::Vec3f v = lookat - eye;
    v.normalize();

    osg::Vec3f u = v^up;
    osg::Vec3f w = u^v;

    u.normalize();
    w.normalize();

    double fov, aspectRatio, zNear, zFar;
    getCamera()->getProjectionMatrixAsPerspective(fov,
            aspectRatio,
            zNear,
            zFar);

    float wlen = ::tan(0.5f*(float)fov*DegreesToRadians);
    float ulen = wlen*width/height;

    u *= ulen;
    w *= wlen;

    org[0] = eye[0];
    org[1] = eye[1];
    org[2] = eye[2];

    // Render on CPU //////////////////////////////////////////////////////////

    QTime timer;

    timer.start();

    QStringList componentsUnderMouse;
    QMap<int, QList<int> > tubeMap;
    int firstAimPointUnderMouse = -1;
    #pragma omp parallel for
    for (uint y = 0; y < height; ++y) {
        for (uint x = 0; x < width; ++x) {

            bool isUnderMouse = (QPoint(x, height - y) == m_mousePositionSS);
            float xf = xinit + dx*x;
            float yf = yinit + dy*y;

            uint* pixel = framebuffer + (y*width+x);

            // Generate ray direction
            float dir[3] = {
                xf*u[0] + yf*w[0] + v[0],
                xf*u[1] + yf*w[1] + v[1],
                xf*u[2] + yf*w[2] + v[2],
            };

            // Normalize direction
            float ilen = 1.f/sqrt(dir[0]*dir[0] +
                                  dir[1]*dir[1] + dir[2]*dir[2]);

            dir[0] *= ilen;
            dir[1] *= ilen;
            dir[2] *= ilen;

            // Initialize per-ray data
            RTCRay ray;

            ray.org[0] = org[0];
            ray.org[1] = org[1];
            ray.org[2] = org[2];

            ray.dir[0] = dir[0];
            ray.dir[1] = dir[1];
            ray.dir[2] = dir[2];

            ray.tnear = 0.0f;
            ray.tfar  = std::numeric_limits<float>::infinity();

            ray.geomID = -1;
            ray.primID = -1;

            ray.mask = 0xFFFFFFFF;
            ray.time = 0;

            int nHits = 0;
            osg::Vec4f color = osg::Vec4f(0.0f, 0.0f, 0.0f, 1.0f);

            // Trace ray
            while(true) {
                rtcIntersect(scene, ray);

                // Shade pixel
                if (ray.geomID == (int)RTC_INVALID_GEOMETRY_ID)
                    break;
                // Normalize the geometry normal
                ilen = 1.f/sqrt(ray.Ng[0]*ray.Ng[0] +
                                ray.Ng[1]*ray.Ng[1] +
                                ray.Ng[2]*ray.Ng[2]);

                ray.Ng[0] *= ilen;
                ray.Ng[1] *= ilen;
                ray.Ng[2] *= ilen;

                // Get the lighting intensity value (eye light)
                float intensity = 255.0f * fabsf(dir[0]*ray.Ng[0] +
                                                 dir[1]*ray.Ng[1] +
                                                 dir[2]*ray.Ng[2]);

                // Get the r,g,b values from the material
                uint mid = matIds[ray.primID];
                float _a = materials[mid][3];
                float _r = intensity * materials[mid][0] * _a;
                float _g = intensity * materials[mid][1] * _a;
                float _b = intensity * materials[mid][2] * _a;

                float rSrc = color[0];
                float gSrc = color[1];
                float bSrc = color[2];
                float importance = color[3];

                float rOut = (rSrc + _r * importance);
                float bOut = (bSrc + _b * importance);
                float gOut = (gSrc + _g * importance);

                color[0] = rOut;
                color[1] = gOut;
                color[2] = bOut;
                color[3] = importance * (1.0f - _a);
                nHits++;

                if (isUnderMouse) {
                    uint aimPoint = aimPoints[ray.primID];
                    uint muvesNameId = muvesNameIds[ray.primID];
                    uint component = componentIds[ray.primID];
                    if (aimPoint > 0) {
                        firstAimPointUnderMouse = firstAimPointUnderMouse == -1 ? aimPoint : firstAimPointUnderMouse;
                        QList<int> comps = tubeMap.value(aimPoint);
                        comps.append(component);
                        tubeMap.insert(aimPoint, comps);
                        if (m_showTubeNames) {
                            componentsUnderMouse << muvesNames->at(muvesNameId);
                        }
                    } else if (m_showComponentNames) {
                        componentsUnderMouse << muvesNames->at(muvesNameId);
                    }
                }

                if (color[3] <= 0.0f && !isUnderMouse) {
                    break;
                }

                ray.tnear = ray.tfar * 1.001f;
                ray.tfar = std::numeric_limits<float>::infinity();
                ray.geomID = RTC_INVALID_GEOMETRY_ID;
                ray.primID = RTC_INVALID_GEOMETRY_ID;
            }

            if (nHits == 0) {
                *pixel = 0xFFFFFFFF;
            } else {

                // Clamp to < 255.0f
                float _r = color[0];
                float _g = color[1];
                float _b = color[2];
                float importance = color[3];
                _r = _r + importance * 255.0f;
                _g = _g + importance * 255.0f;
                _b = _b + importance * 255.0f;
                uchar r = _r > 255.f ? 255.f : (uchar)_r;
                uchar g = _g > 255.f ? 255.f : (uchar)_g;
                uchar b = _b > 255.f ? 255.f : (uchar)_b;
                *pixel = (((b << 16) | (g << 8)) | r);
            }
        }
    }
    // qDebug("frame: %i ms %f fps", timer.elapsed(), 1/(timer.elapsed()/1000.f));

    // Display image //////////////////////////////////////////////////////////

    glDrawPixels(width, height, GL_RGBA, GL_UNSIGNED_BYTE, framebuffer);
    glClear(GL_DEPTH_BUFFER_BIT);

    if (m_isUnderMouse) {
        // Update mouse hover information.
        componentsUnderMouse.removeDuplicates();
        updateListWidget(componentsUnderMouse);

        // Update highlight information.
        m_view->mouseOverComponentEvent(tubeMap, firstAimPointUnderMouse);
    }

    m_redrawTimer.start();
}

void EBOsgViewer::allocateBuffers()
{
    // Allocate framebuffer ///////////////////////////////////////////////////

    framebuffer = new uint[width*height];
    if (!framebuffer) {
        valid = false;
        return;
    }
}

void EBOsgViewer::freeBuffers()
{
    if (framebuffer)
        delete [] framebuffer;
    framebuffer = 0;
}
