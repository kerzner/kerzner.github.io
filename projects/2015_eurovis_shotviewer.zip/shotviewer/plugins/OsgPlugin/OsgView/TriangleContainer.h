#ifndef TRIANGLECONTAINER_H
#define TRIANGLECONTAINER_H

#include <osg/Vec3>
#include <osg/Vec4>
#include <vector>
using std::vector;

#include <QString>
#include <QDebug>

typedef unsigned int uint;

class TriangleContainer
{
public:
    TriangleContainer():
        m_numVertices(0),
        m_numIndices(0),
        m_numTriangles(0) {}
    ~TriangleContainer() {}

    void addMaterial(const osg::Vec4& color) {
        m_materials.push_back(color);
    }

    void addTriangle(const osg::Vec3& v1,
                     const osg::Vec3& v2,
                     const osg::Vec3& v3) {
        //add triangle to current list
        m_vertices.push_back(v1);
        m_indices.push_back(m_numIndices++);

        m_vertices.push_back(v2);
        m_indices.push_back(m_numIndices++);

        m_vertices.push_back(v3);
        m_indices.push_back(m_numIndices++);

        m_numVertices += 3;
        m_numTriangles++;

        m_matIds.push_back(m_materials.size()-1);
        m_componentIds.push_back(m_currentComponentId);
        m_muvesNamesIds.push_back(m_currentMuvesNameId);
        m_aimPoints.push_back(m_currentAimPoint);
    }

    vector<osg::Vec3>& getVertices() {
        return m_vertices;
    }

    vector<uint>& getIndices() {
        return m_indices;
    }

    vector<osg::Vec4>& getMaterials() {
        return m_materials;
    }

    vector<uint>& getMaterialIds() {
        return m_matIds;
    }

    uint getNumVertices() {
        return m_numVertices;
    }

    uint getNumTriangles() {
        return m_numTriangles;
    }

    void setCurrentComponentId(uint componentId) {
        m_currentComponentId = componentId;
    }

    void setCurrentMuvesNameId(uint muvesNameId) {
        m_currentMuvesNameId = muvesNameId;
    }

    void addMuvesName(QString muvesName) {
        m_muvesNames.push_back(muvesName);
    }

    void setCurrentAimPoint(uint aimPoint) {
        m_currentAimPoint = aimPoint;
    }

    uint getMuvesNameId(QString muvesName, bool &found) {
        for(uint i = 0; i < m_muvesNames.size(); i++) {
            if (m_muvesNames.at(i) == muvesName) {
                found = true;
                return i;
            }
        }
        found = false;
        return 0;
    }

    uint getNumMuvesNames() {
        return m_muvesNames.size();
    }

    vector<QString>& getMuvesNames() {
        return m_muvesNames;
    }

    vector<uint>& getMuvesNamesIds() {
        return m_muvesNamesIds;
    }

    vector<uint>& getAimPoints() {
        return m_aimPoints;
    }

    vector<uint>& getComponentIds() {
        return m_componentIds;
    }

private:
    //keep a list of triangles
    vector<osg::Vec3> m_vertices;
    vector<uint> m_indices;
    vector<osg::Vec4> m_materials;
    vector<uint> m_matIds;

    // All muves component names.
    vector<QString> m_muvesNames;

    // Per-triangle indexes into m_muvesNames
    vector<uint> m_muvesNamesIds;

    // Per-triangle index of what aimpoint hit this.
    vector<uint> m_aimPoints;

    // This will be non-zero if a triangle is one that has been shot.
    vector<uint> m_componentIds;

    uint m_numVertices;
    uint m_numIndices;
    uint m_numTriangles;

    uint m_currentComponentId;
    uint m_currentMuvesNameId;
    uint m_currentAimPoint;
};

#endif // TRIANGLECONTAINER_H
