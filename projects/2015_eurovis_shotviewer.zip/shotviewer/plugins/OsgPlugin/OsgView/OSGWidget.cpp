#include "OSGWidget.h"

#include <math.h>

#include <QApplication>
#include <QDesktopWidget>
#include <QAction>
#include <QDebug>
#include <QListWidget>
#include <QHBoxLayout>
#include <QListWidgetItem>
#include <QFontMetrics>
#include <QtGui/QKeyEvent>

#include <osg/LightModel>
#include <osgViewer/Renderer>
#include <osgGA/TrackballManipulator>

#include "OsgView.h"
#include "OsgDocument.h"
#include "OsgHelpers.h"

// Uncomment this to let users throw geometry
// define OSGWIDGET_ENABLE_THROW 1

OSGWidget::OSGWidget(QWidget *parent)
    : QGLWidget(parent)
    , m_mouseButtons(Qt::NoButton)
    , m_mouseModifiers(Qt::NoModifier)
    , m_mouseMode(MM_ORBIT)
    , m_viewingCore(new ViewingCore)
#if defined(OSGWIDGET_ENABLE_THROW)
    , m_lastMouseEventTime(QTime::currentTime())
    , m_mouseReleaseJustHappened(false)
    , m_throwTimeTolerance(100)
    , m_throwDistTolerance(0.1)
#endif // defined(OSGWIDGET_ENABLE_THROW)
    , m_view(NULL)
    , m_listWidget(new QListWidget(this))
    , m_showComponentNames(false)
    , m_showTubeNames(false)
    , m_isUnderMouse(false)
{
    setObjectName("osgv");
    // Strong focus policy needs to be set to capture keyboard events
    setFocusPolicy(Qt::StrongFocus);
    setMouseTracking(true); // get mouse move events even without button press

    // Construct the embedded graphics window
    m_osgGraphicsWindow = new osgViewer::GraphicsWindowEmbedded(0,0,width(),height());
    getCamera()->setGraphicsContext(m_osgGraphicsWindow);

    // Set up the camera
    getCamera()->setViewport(new osg::Viewport(0,0,width(),height()));
    getCamera()->setProjectionMatrixAsPerspective(30.0f,
            static_cast<double>(width())/static_cast<double>(height()),
            1.0f,
            10000.0f);

    // By default draw everthing that has even 1 bit set in the nodemask
    getCamera()->setCullMask( (unsigned)~0 );
    //getCamera()->setDataVariance(osg::Object::DYNAMIC);

    // As of July 2010 there wasn't really a good way to multi-thread OSG
    // under Qt so just set the threading model to be SingleThreaded
    setThreadingModel(osgViewer::Viewer::SingleThreaded);

    // draw both sides of polygons
    setLightingTwoSided();

    // wake up and re-draw the window every so often
    connect(&m_redrawTimer, SIGNAL(timeout()), this, SLOT(updateGL()));
    m_redrawTimer.setSingleShot(true);
    m_redrawTimer.start(10);
    //m_frameTimer.start();

    // Signal-slot to handle animating the camera for 'tossing' the geometry
    connect(&m_animateTimer, SIGNAL(timeout()),
            this, SLOT(animateCameraThrow()));

    // Set the minimum size for this viewer window
    setMinimumSize(200, 200);

    m_listWidget->setVisible(false);
    m_listWidget->setHorizontalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
    m_listWidget->setVerticalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
}


//#define DEBUG_MOUSE 1

void OSGWidget::mousePressEvent( QMouseEvent* event )
{
    m_animateTimer.stop();
#if defined (OSGWIDGET_ENABLE_THROW)
    m_mouseReleaseJustHappened = false;
#endif // defined (OSGWIDGET_ENABLE_THROW)
    m_lastMouseEventNDCoords = getNormalized(event->x(), event->y());

    m_mouseButtons |= event->buttons();

    m_mouseModifiers = event->modifiers();

    // handle overrides
    if (m_mouseButtons == Qt::LeftButton) {
        if (m_mouseModifiers == Qt::ShiftModifier) {
            pushState();
            m_viewingCore->setViewingCoreMode(ViewingCore::THIRD_PERSON);
            setMouseMode(MM_PAN);
        } else if (m_mouseModifiers == Qt::ControlModifier) {
            pushState();
            m_viewingCore->setViewingCoreMode(ViewingCore::THIRD_PERSON);
            setMouseMode(MM_ORBIT);
        } else if ((unsigned)m_mouseModifiers == (unsigned)(Qt::ControlModifier | Qt::ShiftModifier) ) {
            pushState();
            m_viewingCore->setViewingCoreMode(ViewingCore::THIRD_PERSON);
            setMouseMode(MM_ZOOM);
        }
    } else if (m_mouseButtons == Qt::RightButton) {
        m_viewingCore->pickCenter(m_lastMouseEventNDCoords.x(),
                                  m_lastMouseEventNDCoords.y() );
    }

    // Do the job asked
    if (m_mouseMode & (MM_PAN|MM_ROTATE|MM_ORBIT|MM_ZOOM) )
        m_viewingCore->setPanStart( m_lastMouseEventNDCoords.x(), m_lastMouseEventNDCoords.y() );
    else if (m_mouseMode & MM_PICK_CENTER) {
        m_viewingCore->pickCenter(m_lastMouseEventNDCoords.x(),
                                  m_lastMouseEventNDCoords.y() );
    }

#if defined (OSGWIDGET_ENABLE_THROW)
    m_lastMouseEventTime.start();
#endif // defined (OSGWIDGET_ENABLE_THROW)
}


void OSGWidget::mouseReleaseEvent( QMouseEvent* event )
{
#if defined (OSGWIDGET_ENABLE_THROW)
    m_mouseReleaseJustHappened = true;
#endif // defined (OSGWIDGET_ENABLE_THROW)

    m_lastMouseEventNDCoords = getNormalized(event->x(), event->y());

    m_mouseButtons &= event->buttons();

    if (m_mouseModifiers != Qt::NoModifier) {
        popState();
    }

    m_mouseModifiers = Qt::NoModifier;
#if defined (OSGWIDGET_ENABLE_THROW)
    m_lastMouseEventTime.start();
#endif // defined (OSGWIDGET_ENABLE_THROW)
}

void OSGWidget::mouseMoveEvent( QMouseEvent* event )
{
    m_mousePositionSS = event->pos();

    // either a button is pressed or a mouse release just happened
    osg::Vec2d currentNDC = getNormalized(event->x(), event->y());
#if defined(OSGWIDGET_ENABLE_THROW)
    if ( m_mouseReleaseJustHappened) {
        // We are potentially starting a throw of the camera
        // Look to see if we meet the tolerance criteria for space and time
        // for starting camera animation

        int deltaT = m_lastMouseEventTime.elapsed();

        if (deltaT < m_throwTimeTolerance) {
            // compute the motion of the cursor

            float distance = inchesToLastMouseEvent(event);
            if (distance > m_throwDistTolerance) {
                // start animation

                m_animateStart = m_lastMouseEventNDCoords;

                osg::Vec2d kalmanNDC = (currentNDC + m_predictedPos) * 0.5;
                m_animateDelta = kalmanNDC - m_animateStart;

                m_animateTimer.start(deltaT);
            }
        }
        m_mouseReleaseJustHappened = false;
        return;
    }
#endif // defined(OSGWIDGET_ENABLE_THROW)
    if (m_mouseButtons == Qt::NoButton)
        return;

    osg::Vec2d delta = currentNDC - m_lastMouseEventNDCoords;

    switch (m_mouseMode) {
    case MM_ORBIT:
        m_viewingCore->rotate(  m_lastMouseEventNDCoords, delta );
        break;
    case MM_PAN:
        m_viewingCore->pan(delta.x(), delta.y());
        break;
    case MM_ZOOM: {
        double tempScale = m_viewingCore->getFovyScale();
        m_viewingCore->setFovyScale(1.03);

        if(delta.y() > 0)
            m_viewingCore->fovyScaleDown();

        if(delta.y() < 0)
            m_viewingCore->fovyScaleUp();

        m_viewingCore->setFovyScale(tempScale);
        break;
    }
    case MM_ROTATE:
        m_viewingCore->rotate(  m_lastMouseEventNDCoords, delta );
        break;
    default:
        break;
    }

    m_predictedPos.set(currentNDC.x() + delta.x(), currentNDC.y() + delta.y());

    m_lastMouseEventNDCoords = currentNDC;

#if defined (OSGWIDGET_ENABLE_THROW)
    m_lastMouseEventTime.start();
#endif // defined (OSGWIDGET_ENABLE_THROW)
}

void OSGWidget::wheelEvent(QWheelEvent *event)
{
    if(event->delta() > 0)
        m_viewingCore->dolly(0.5);
    else
        m_viewingCore->dolly(-0.5);
}

void OSGWidget::animateCameraThrow()
{
    switch (m_mouseMode) {
    case MM_ORBIT:
        m_viewingCore->rotate( m_animateStart, m_animateDelta );
        break;
    case MM_PAN:
        m_viewingCore->pan(m_animateDelta.x(), m_animateDelta.y());
        break;
    case MM_ZOOM: {
        double tempScale = m_viewingCore->getFovyScale();
        m_viewingCore->setFovyScale(1.03);

        if(m_animateDelta.y() > 0)
            m_viewingCore->fovyScaleDown();
        else
            m_viewingCore->fovyScaleUp();

        m_viewingCore->setFovyScale(tempScale);
        break;
    }
    case MM_ROTATE:
        m_viewingCore->rotate( m_animateStart, m_animateDelta );
        break;
    default:
        break;
    }
}

void OSGWidget::setScene(osg::Node *root)
{
    this->setSceneData(root);
    m_viewingCore->setSceneData(root);
    m_viewingCore->fitToScreen();
}

void OSGWidget::setSceneGeometry(osg::Node *root)
{
    this->setSceneData(root);
    m_viewingCore->setSceneGeometry(root);
}

void OSGWidget::setLightingTwoSided()
{
    osg::ref_ptr<osg::LightModel> lm = new osg::LightModel;
    lm->setTwoSided(true);
    lm->setAmbientIntensity(osg::Vec4(0.1f,0.1f,0.1f,1.0f));

    osg::StateSet *ss;

    for (int i=0 ; i < 2 ; i++ ) {
        ss = ((osgViewer::Renderer *)getCamera()
              ->getRenderer())->getSceneView(i)->getGlobalStateSet();

        ss->setAttributeAndModes(lm, osg::StateAttribute::ON);
    }
}

void OSGWidget::resizeGL(int width, int height)
{
    m_osgGraphicsWindow->getEventQueue()->windowResize(0, 0, width, height );
    m_osgGraphicsWindow->resized(0,0,width,height);
}

void OSGWidget::setView(OsgView *view)
{
    m_view = view;
}

osg::Vec2d OSGWidget::getNormalized(const int ix, const int iy)
{
    int x, y, width, height;
    osg::Vec2d ndc;

    // we don't really need the x, y values but the width/height are important
    m_osgGraphicsWindow->getWindowRectangle(x, y, width, height);
    int center = width/2;
    ndc[0] = ((double)ix - (double)center) / (double)center;
    if (ndc[0] > 1.0) ndc[0] = 1.0;

    center = height/2;
    int invertedY = height - iy;
    ndc[1] = ((double)invertedY - (double)center) / (double)center;
    if (ndc[1] > 1.0) ndc[1] = 1.0;

    return ndc;
}

void OSGWidget::setMouseMode(MouseMode mode)
{
    m_mouseMode = mode;

    if(mode == MM_ROTATE)
        m_viewingCore->setViewingCoreMode( ViewingCore::FIRST_PERSON );
    else {
        m_viewingCore->setViewingCoreMode( ViewingCore::THIRD_PERSON );
    }

    emit mouseModeChanged(mode);
    m_animateTimer.stop();
}



float OSGWidget::inchesToLastMouseEvent(QMouseEvent* thisMouseEvent)
{
    // we don't really need the x, y values but the width/height are important
    int x, y, width, height;
    m_osgGraphicsWindow->getWindowRectangle(x, y, width, height);

    // un-normalize last event
    float center = width/2.0;
    int oldX = (m_lastMouseEventNDCoords.x() * center) + center;

    center = height/2.0;
    int oldY = (m_lastMouseEventNDCoords.y() * center) + center;

    float deltaX = thisMouseEvent->x() - oldX;
    float deltaY = (height - thisMouseEvent->y()) - oldY;

    float distXinches = deltaX / (float)qApp->desktop()->logicalDpiX();
    float distYinches = deltaY / (float)qApp->desktop()->logicalDpiY();

    float distSquared = distXinches * distXinches +
                        distYinches * distYinches;

    return sqrt(distSquared);
}


void OSGWidget::pushState()
{
    stashState state;
    state.mm = m_mouseMode;
    state.vcm = m_viewingCore->getViewingCoreMode();
    m_stashState.push_back(state);
}


void OSGWidget::popState()
{
    if (m_stashState.size() < 1)
        return;

    stashState state = m_stashState.last();
    m_stashState.pop_back();
    m_viewingCore->setViewingCoreMode(state.vcm);
    setMouseMode(state.mm);
}

void OSGWidget::setShowComponentNames(bool value)
{
    m_showComponentNames = value;
}

void OSGWidget::setShowTubeNames(bool value)
{
    m_showTubeNames = value;
}

void OSGWidget::updateListWidget(QStringList itemsUnderMouse)
{
    if ((m_showComponentNames || m_showTubeNames) && itemsUnderMouse.size() > 0) {

        m_listWidget->clear();
        m_listWidget->addItems(itemsUnderMouse);

        // there's something odd going on here with the font height.
        // list height should be just height_of_font * number_of_items_in_list
        // but I don't know how to do that, so instead we pad by 20 pixels
        QFontMetrics fontMetric  = m_listWidget->fontMetrics();
        int listHeight = fontMetric.height() * m_listWidget->count() + 20;

        float x = m_mousePositionSS.x() + 10;
        float y = m_mousePositionSS.y() + 10;

        // if box will go left off screen then shift to the left
        if (x + 256 > width()) {
            x = x - 256 - 20;
        }

        // if box will go below screen then shift up
        if (y + listHeight > height()) {
            y = y - listHeight  - 10;
        }

        m_listWidget->setGeometry(x, y, 256, listHeight );
        m_listWidget->show();

    } else {
        m_listWidget->hide();
    }
}

void OSGWidget::enterEvent(QEvent *)
{
    m_isUnderMouse = true;
}

void OSGWidget::leaveEvent(QEvent *)
{
    m_isUnderMouse = false;
}
