#ifndef OSGTRIANGLEEXTRACTOR_H
#define OSGTRIANGLEEXTRACTOR_H

#include <osg/TriangleFunctor>
#include "TriangleContainer.h"

#include <osg/Geometry>
#include <osg/Drawable>
#include <osg/Material>
using osg::MatrixList;
using osg::StateSet;
using osg::StateAttribute;
using osg::Material;

#include "OsgHelpers.h"

struct GetVertexArray {
    void setAttachedContainer(TriangleContainer *container) {
        m_container = container;
    }

    void setMatrix(const osg::Matrix& m) {
        m_matrix = m;
    }

    void operator() (const osg::Vec3& _v1,
                     const osg::Vec3& _v2,
                     const osg::Vec3& _v3,
                     bool) const {
        osg::Vec3 v1 = _v1 * m_matrix;
        osg::Vec3 v2 = _v2 * m_matrix;
        osg::Vec3 v3 = _v3 * m_matrix;

        //add triangle
        m_container->addTriangle(v1, v2, v3);
    }

    //keep reference to group of triangles
    TriangleContainer *m_container;

    osg::Matrix m_matrix;
};

class TriangleExtractor : public osg::NodeVisitor
{

public:
    TriangleExtractor(TriangleContainer *container) :
        osg::NodeVisitor(osg::NodeVisitor::TRAVERSE_ALL_CHILDREN),
        m_container(container) { }

    virtual void apply(osg::Node &node) {
        osg::ref_ptr<osg::Geode> geode = node.asGeode();

        if(geode.get()) {
            // Tell the container what muves name we're about to extract.
            QString muvesName = geodeMuvesName(*geode);
            bool foundName = false;
            uint muvesNameId = m_container->getMuvesNameId(muvesName, foundName);
            if (foundName) {
                m_container->setCurrentMuvesNameId(muvesNameId);
            } else {
                m_container->addMuvesName(muvesName);
                m_container->setCurrentMuvesNameId(m_container->getNumMuvesNames() - 1);
            }

            m_container->setCurrentComponentId(geodeComponentId(*geode));

            m_container->setCurrentAimPoint(geodeAimPoint(*geode));

            for (unsigned i=0; i<geode->getNumDrawables(); i++) {
                osg::ref_ptr<osg::Drawable> drawable = geode->getDrawable(i);
                osg::ref_ptr<osg::Geometry> geometry = drawable->asGeometry();

                if(geometry) {
                    StateSet *ss =geometry->getStateSet();
                    if(ss) {
                        // Get this object's material from its state set
                        StateAttribute *sa =
                            ss->getAttribute(StateAttribute::MATERIAL);
                        Material *mat = (Material*)(sa);
                        osg::Vec4 dif = mat->getDiffuse(Material::FRONT);

                        m_container->addMaterial(dif);
                    } else {
                        // No state set...just add white as a placeholder
                        m_container->addMaterial(osg::Vec4(1.0f,
                                                           1.0f,
                                                           1.0f,
                                                           1.0f));
                    }

                    osg::TriangleFunctor<GetVertexArray> tf;
                    tf.setAttachedContainer(m_container);
                    tf.setMatrix(geometry->getWorldMatrices()[0]);
                    geometry->accept(tf);
                }
            }
        }

        traverse(node);
    }

private:
    TriangleContainer *m_container;
};

#endif // OSGTRIANGLEEXTRACTOR_H
