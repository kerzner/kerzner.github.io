#include "SelectSystemDialog.h"
#include "ui_SelectSystemDialog.h"

#include <QDebug>

SelectSystemDialog::SelectSystemDialog(QStringList systems, QStringList damagedSystems, QWidget *parent)
    : QDialog(parent)
    , m_systems(systems)
    , m_damagedSystems(damagedSystems)
    , ui(new Ui::SelectSystemDialog)
{
    ui->setupUi(this);

    ui->listWidget->addItems(m_damagedSystems);
}

SelectSystemDialog::~SelectSystemDialog()
{
    delete ui;
}

QString SelectSystemDialog::getSelectedSystem()
{
    QList<QListWidgetItem *> items = ui->listWidget->selectedItems();
    if (items.size() > 0) {
        return items.first()->text();
    }
}

void SelectSystemDialog::on_checkBoxDamaged_stateChanged(int onlyDamaged)
{
    ui->listWidget->clear();
    ui->listWidget->addItems(onlyDamaged ? m_damagedSystems : m_systems);
    on_lineEditFilter_textChanged(ui->lineEditFilter->text());
}

void SelectSystemDialog::on_lineEditFilter_textChanged(const QString &text)
{
    QRegExp regExp(text, Qt::CaseInsensitive, QRegExp::Wildcard);
    ui->listWidget->clear();
    QStringList itemsToAdd = ui->checkBoxDamaged->isChecked() ? m_damagedSystems : m_systems;
    ui->listWidget->addItems(itemsToAdd.filter(regExp));
}
