#include "OsgView.h"
#include "ui_OsgView.h"

#include <math.h>
#include <QApplication>
#include <QDesktopWidget>
#include <QMessageBox>
#include <QMenu>
#include <QToolBar>
#include <QDebug>
#include <QColorDialog>
#include <QVariant>
#include <QObjectUserData>
#include <QSettings>

#include <QtGui/QKeyEvent>
#include <osg/LightModel>
#include <osgViewer/Renderer>
#include <osgGA/TrackballManipulator>
#include <osg/Drawable>
#include <osg/ShapeDrawable>
#include <osg/Material>

#include "OSGWidget.h"
#include "OsgDocument.h"

#include "../plugins/RegmapPlugin/RegmapApplicationDocument.h"
#include "../plugins/ShotViewerPlugin/IRDocument.h"
#include "../plugins/SystemEvaluation/SysDefDocument.h"
#include "OsgVisitors.hpp"
#include "SanitizedFileName.h"
#include "../plugins/ShotViewerPlugin/IfrHelpers.h"
#include "OsgHelpers.h"
#include "ContextGroupDialog.h"
#include "OsgView/EBOsgViewer.h"
#include "SelectSystemDialog.h"
#include "SysDefEvaluator.h"
#include "IfrHelpers.h"
#define DEGTORAD M_PI/180.0

OsgView::OsgView(QWidget *parent)
    : ShotlineView(parent)
    , ui(new Ui::OsgView)
    , m_regmapDoc(NULL)
    , m_osgDoc(NULL)
    , m_irDoc(NULL)
    , m_root(new osg::Group())
    , m_context(new osg::Group())
    , m_shotlines(new QMap<int, osg::ref_ptr<osg::Group> >)
    , m_system(new osg::Group())
    , m_shotSets(new QMap<int, osg::ref_ptr<osg::Group> >)
    , m_shot(new osg::Group())
    , m_aimPointCheckBoxes(new QList<QHBoxLayout*>())
{
    ui->setupUi(this);
    setObjectName("OsgView");

    // Collapse the splitter to the right to make
    // the OSGWidget the only displayed one
    QList<int> sizes = ui->splitter->sizes();
    sizes[1] = 0;
    ui->splitter->setSizes(sizes);
    ui->splitter->setCollapsible(0, false);

    // Set the minimum size for this viewer window
    setMinimumSize(200, 200);

    connect(ui->glWidget, SIGNAL(mouseModeChanged(OSGWidget::MouseMode)),
            this, SLOT(mouseModeChanged(OSGWidget::MouseMode)));

    ui->glWidget->getCamera()->setClearColor(osg::Vec4(0.9f, 0.9f, 0.9f, 1.0f));
    osg::DisplaySettings::instance()->setNumMultiSamples(8);

    m_contextNames.append(QRegExp("*driver*", Qt::CaseInsensitive, QRegExp::Wildcard));
    m_contextNames.append(QRegExp("*gunner*", Qt::CaseInsensitive, QRegExp::Wildcard));
    m_contextNames.append(QRegExp("*passenger*", Qt::CaseInsensitive, QRegExp::Wildcard));
    m_contextNames.append(QRegExp("*tire*", Qt::CaseInsensitive, QRegExp::Wildcard));

    m_shot->setName("m_shot");
    m_context->setName("m_context");
    m_system->setName("m_system");

    ui->glWidget->setView(this);

    settingsLoad();
}

OsgView::~OsgView()
{
    settingsSave();
    delete ui;
}

void OsgView::rootAddOrRemoveGroup(osg::ref_ptr<osg::Group> child, bool add)
{
    if (add) {
        m_root->addChild(child);
    } else {
        m_root->removeChild(child);
    }
    ui->glWidget->setSceneGeometry(m_root);
}

void OsgView::on_checkBoxOtherVisible_stateChanged(int state)
{
    rootAddOrRemoveGroup(m_other, state);
}

void OsgView::on_checkBoxContextVisible_stateChanged(int state)
{
    rootAddOrRemoveGroup(m_context, state);
}

void OsgView::on_checkBoxSystemVisible_stateChanged(int state)
{
    rootAddOrRemoveGroup(m_system, state);
}

void OsgView::on_pushButtonContextSet_pressed()
{
    ContextGroupDialog dialog;

    QStringList patterns;
    foreach (QRegExp regexp, m_contextNames) {
        patterns << regexp.pattern();
    }

    dialog.setContextNameList(patterns);
    if (dialog.exec()) {
        m_contextNames.clear();
        patterns = dialog.getContextNameList();
        foreach (QString pattern, patterns) {
            m_contextNames << QRegExp(pattern, Qt::CaseInsensitive, QRegExp::Wildcard);
        }
    }

    updateShotlines();
}

void OsgView::on_sliderShotOpacity_valueChanged(int value)
{
    groupSetOpacity(m_shot, float(value) / ui->sliderShotOpacity->maximum());
}

void OsgView::on_sliderContextOpacity_valueChanged(int value)
{
    groupSetOpacity(m_context, float(value) / ui->sliderContextOpacity->maximum());
}

void OsgView::on_sliderOtherOpacity_valueChanged(int value)
{
    groupSetOpacity(m_other, float(value) / ui->sliderOtherOpacity->maximum());
}

void OsgView::on_sliderSystemOpacity_valueChanged(int value)
{
    groupSetOpacity(m_system, float(value) / ui->sliderSystemOpacity->maximum());
}

void OsgView::on_sliderShotRadius_valueChanged(int value)
{
    m_root->removeChildren(0, m_root->getNumChildren());

    foreach (int aimPoint, m_irDoc->getAimPoints()) {
        osg::ref_ptr<osg::Group> group = shotlineGeometryCreate(aimPoint, value / 2.0f);
        m_root->addChild(group);
        m_shotlines->insert(aimPoint, group);
    }

    if (ui->checkBoxContextVisible->isChecked()) {
        m_root->addChild(m_context);
    }

    m_root->addChild(m_shot);

    if (ui->checkBoxOtherVisible->isChecked()) {
        m_root->addChild(m_other);
    }

    ui->glWidget->setSceneGeometry(m_root);
}

void OsgView::on_pushButtonSystemSelect_pressed()
{
    // Allow user to select from all systems or only damaged systems.
    QStringList allSystems = m_sysDefDoc->getSystemNames();
    QStringList damagedSystems;

    // Evaluate damage for to populate the widget.
    SysDefEvaluator evaluator(*m_sysDefDoc);
    QList<int> aimPoints = m_irDoc->getAimPoints();
    foreach (int aimPoint, aimPoints) {

        // Qualified components damaged for aimpoint.
        QMap<QString, float> componentsQualified = m_irDoc->getDamagedComponentsFromShotline(aimPoint);

        // Qualified systems damaged from aimpoint.
        QMap<QString, float> systemsQualified = evaluator.evaluateAllSystems(componentsQualified);

        // Add the list of damaged systems to the all damage map.
        QMapIterator<QString, float> itr(systemsQualified);
        while (itr.hasNext()) {
            itr.next();
            damagedSystems << removeQualifier(itr.key());
        }
    }

    // Ask the user what system should be displayed.
    SelectSystemDialog dialog(allSystems, damagedSystems, this);

    if (dialog.exec()) {

        QString selectedSystem = dialog.getSelectedSystem();

        // Convert system to a list of components.
        QStringList selectedComponents = m_sysDefDoc->getComponentsInSystem(selectedSystem);

        // Convert components into regions.
        QList<int> regions;
        foreach (QString component, selectedComponents) {
            regions << m_regmapDoc->getRegions(component);
        }

        // Convert regions into osg group.
        m_system = m_osgDoc->groupCreate(regions);

        // Update material of this group

        groupSetColor(m_system, getColorFromUi(ui->labelSystemColorPatch, ui->sliderSystemOpacity));
        ui->checkBoxSystemVisible->setChecked(true);
        ui->lineEditSystem->setText(selectedSystem);
        rootAddOrRemoveGroup(m_system, true);

        // TODO: Here we only need to update the "other" group.
        updateShotlines();
    }
}

void OsgView::on_pushButtonSystemColorChange_pressed()
{
    updateColor(ui->labelSystemColorPatch, m_system, (float) ui->sliderSystemOpacity->value() / 100.0f);
}

void OsgView::on_pushButtonOtherColorChange_pressed()
{
    updateColor(ui->labelOtherColorPatch, m_other, (float) ui->sliderOtherOpacity->value() / 100.0f);
}

void OsgView::on_pushButtonContextColorChange_pressed()
{
    updateColor(ui->labelContextColorPatch, m_context, (float) ui->sliderContextOpacity->value() / 100.0f);
}

void OsgView::on_pushButtonShotColorChange_pressed()
{
    updateColor(ui->labelShotColorPatch, m_shot, (float) ui->sliderShotOpacity->value() / 100.0f);
}

void OsgView::checkBoxShotAimpointVisibleStateChanged(int value)
{
    int aimPoint = sender()->property("aimPoint").toInt();

    osg::ref_ptr<osg::Group> group = m_shotSets->value(aimPoint);

    if (value) { // turn visibility on
        m_shot->addChild(group);
    } else { // turn visibility off
        m_shot->removeChild(group);
    }

    ui->glWidget->setSceneGeometry(m_root);
}

void OsgView::updateShotlines()
{
    // Start with drawing none of the children.
    m_root->removeChildren(0, m_root->getNumChildren());

    updateShotGroup();
    updateContextGroup();
    updateOtherGroup();

    groupSetColor(m_shot, getColorFromUi(ui->labelShotColorPatch, ui->sliderShotOpacity));
    groupSetColor(m_system, getColorFromUi(ui->labelSystemColorPatch, ui->sliderSystemOpacity));
    groupSetColor(m_context, getColorFromUi(ui->labelContextColorPatch, ui->sliderContextOpacity));
    groupSetColor(m_other, getColorFromUi(ui->labelOtherColorPatch, ui->sliderOtherOpacity));

    m_shotlines->clear();
    foreach (int aimPoint, m_irDoc->getAimPoints()) {
        osg::ref_ptr<osg::Group> group = shotlineGeometryCreate(aimPoint, ui->sliderShotRadius->value() / 2.0);
        m_root->addChild(group);
        m_shotlines->insert(aimPoint, group);
    }

    ui->glWidget->setSceneGeometry(m_root);
}

void OsgView::setMouseHoverHighlight(const QMap<int, QList<int> > &map,
                                     const int &traceUnderMouse,
                                     const bool &highlight,
                                     const int &aimPointUnderMouse)
{
    Q_UNUSED(traceUnderMouse);
    Q_UNUSED(aimPointUnderMouse);

    /// Loop over all aimpoints that we have osg representations for.
    foreach (int aimPoint, m_shotlines->keys()) {

        QList<int> traceIdxes;
        if (map.contains(aimPoint)) {
            foreach(int traceIdx, map.value(aimPoint)) {
                traceIdxes << traceIdx;
            }
        }

        osg::ref_ptr<osg::Group> group = m_shotlines->value(aimPoint);

        for (uint component = 0; component < group->getNumChildren(); component++) {

            osg::ref_ptr<osg::Geode> geode = group->getChild(component)->asGeode();
            osg::StateSet *stateSet = geode->getOrCreateStateSet();
            osg::Material *material = (osg::Material*) stateSet->getAttribute(osg::StateAttribute::MATERIAL);

            if (!material) {
                material = new osg::Material();
            }

            if (traceIdxes.contains(component) && highlight) {
                material->setDiffuse(osg::Material::FRONT_AND_BACK, osg::Vec4(0.0f, 0.0f, 0.0f, 1.0f));
            } else {
                material->setDiffuse(osg::Material::FRONT_AND_BACK, osgVecFromQColor(m_irDoc->getThreatColor(aimPoint)));
            }

            stateSet->setAttributeAndModes(material, osg::StateAttribute::OVERRIDE);
            OsgMaterialApplier visitor(stateSet);
            visitor.apply(*geode);
        }
    }
    ui->glWidget->updateSceneMaterials(m_root);
}

void OsgView::mouseOverComponentEvent(const QMap<int, QList<int> > &map, int aimPoint)
{
    int firstValue = -1;
    if (map.keys().size() > 0) {
        firstValue = map.values().first().first();
    }

    setMouseHoverHighlight(map, firstValue, map.keys().size() > 0, aimPoint);

    emit mouseHoverHighlightChanged(map, firstValue, map.keys().size() > 0, aimPoint);
}

QWidget *OsgView::getImageWidget() const
{
    return ui->glWidget;
}

QStringList OsgView::getRequiredDocTypes()
{
    QStringList types;
    types.append("OSG");
    return types;
}

void OsgView::fileImportCompleted()
{
    ui->glWidget->fitToScreen();
}

void OsgView::fileImportFailed()
{
    fprintf(stderr, "fileImportFailed()\n");
}

void OsgView::fileSaveCompleted()
{
    fprintf(stderr, "fileSaveCompleted()\n");
}

void OsgView::fileSaveFailed()
{
    fprintf(stderr, "fileSaveFailed()\n");
}

void OsgView::fileNameWillChange(const QString &oldFileName,
                                 const QString &newFileName)
{
    this->setObjectName(QString("OsgViewHi%2").arg(sanitizedFileName(newFileName)) );
    this->setWindowTitle(newFileName);
}

void OsgView::documentClosing()
{
    fprintf(stderr, "TODO: implement documentClosing()\n");
}

void OsgView::attachDocument(ApplicationDocument *doc)
{
    RegmapApplicationDocument *regmap = dynamic_cast<RegmapApplicationDocument*>(doc);
    OsgDocument *osgdoc = dynamic_cast<OsgDocument*>(doc);
    IRDocument *irDoc = dynamic_cast<IRDocument*>(doc);
    SysDefDocument *sysDefDoc = dynamic_cast<SysDefDocument*>(doc);
    if (regmap) {
        m_regmapDoc = regmap;
    } else if (osgdoc) {
        m_osgDoc = osgdoc;

        // Add the entire model to the root of our scene graph.
        // This sets up nice viewport and manipulation parameters.
        // Remove entire model to avoid redundant geometry drawing.
        m_root->addChild(m_osgDoc->getData());
        ui->glWidget->setScene(m_root);
        m_root->removeChild(m_osgDoc->getData());

    } else if (irDoc) {
        m_irDoc = irDoc;
        connect(m_irDoc, SIGNAL(changeAllShotlines()), this, SLOT(updateShotlines()));
    } else if (sysDefDoc) {
        m_sysDefDoc = sysDefDoc;
    }

    if (m_irDoc && m_osgDoc && m_regmapDoc && m_sysDefDoc) {
        // At this point we have all the documents necessary to draw stuff.
        // First, tag all the geodes with their muves names so that we can display
        // them on demand later.
        OsgMuvesApplier visitor(m_regmapDoc);
        visitor.traverse(*m_osgDoc->getData());

        // Actually draw the stuff.
        updateShotlines();
    }
}

QList<QMenu*> OsgView::createMenus()
{
    QList<QMenu*> menus;

    QMenu *menu= new QMenu("CameraViews", this);

    QAction *action = menu->addAction("Top", ui->glWidget, SLOT(viewTop()));
    action = menu->addAction("Bottom", ui->glWidget, SLOT(viewbottom()));
    action = menu->addAction("Front", ui->glWidget, SLOT(viewFront()));
    action = menu->addAction("Back", ui->glWidget, SLOT(viewBack()));
    action = menu->addAction("Left", ui->glWidget, SLOT(viewLeft()));
    action = menu->addAction("Right", ui->glWidget, SLOT(viewRight()));

    action = menu->addAction("Restore");

    connect(action, SIGNAL(triggered()),
            ui->glWidget, SLOT(resetView()));

    menus.push_back(menu);

    menu= new QMenu("Preferences", this);

    // Checkable action to show all component names under mouse.
    m_showComponentNamesAction = menu->addAction("Show component names");
    m_showComponentNamesAction->setCheckable(true);
    m_showComponentNamesAction->setChecked(ui->glWidget->getShowComponentNames());
    connect(m_showComponentNamesAction, SIGNAL(triggered(bool)),
            ui->glWidget, SLOT(setShowComponentNames(bool)));

    // Checkable action to show just the tube names under mouse.
    m_showTubeNamesAction = menu->addAction("Show tube names");
    m_showTubeNamesAction->setCheckable(true);
    m_showTubeNamesAction->setChecked(ui->glWidget->getShowTubeNames());
    connect(m_showTubeNamesAction, SIGNAL(triggered(bool)),
            ui->glWidget, SLOT(setShowTubeNames(bool)));

    menus << menu;

    return menus;
}

void OsgView::menuSetMouseMode()
{
    QObject *obj = sender();
    if (!obj) return;

    QAction *a = qobject_cast<QAction *>(obj);
    if (!a) return;

    OSGWidget::MouseMode mode =
        (OSGWidget::MouseMode)a->property("mouseMode").toInt();

    ui->glWidget->setMouseMode(mode);
}

void OsgView::mouseModeChanged(OSGWidget::MouseMode mode)
{
    // reset all the menu items to cleared except selected
    foreach (QAction *a, m_mouseModeActions) {
        if (a->property("mouseMode").toInt() == mode)
            a->setChecked(true);
        else
            a->setChecked(false);
    }
}

void OsgView::settingsLoad()
{
    QSettings settings(qApp->organizationName(), qApp->applicationName());
    QVariant variant;
    variant = settings.value("showTubeNames", QVariant(true));
    ui->glWidget->setShowTubeNames(variant.toBool());

    variant = settings.value("showComponentNames", QVariant(true));
    ui->glWidget->setShowComponentNames(variant.toBool());
}

void OsgView::settingsSave()
{
    QSettings settings(qApp->organizationName(), qApp->applicationName());
    settings.setValue("showTubeNames", ui->glWidget->getShowTubeNames());
    settings.setValue("showComponentNames", ui->glWidget->getShowComponentNames());
}

void OsgView::updateContextGroup()
{
    m_root->removeChild(m_context);

    // Create the context from the list of components that user input.
    QList<int> regions = m_regmapDoc->getRegions(m_contextNames);
    m_context = m_osgDoc->groupCreate(regions);

    // Context group should be mutually exclusive with shot and system.
    QList<osg::Node*> nodes;
    for (uint child = 0; child < m_shot->getNumChildren(); child++) {
        osg::Group *group = m_shot->getChild(child)->asGroup();
        for (uint geode = 0; geode < group->getNumChildren(); geode++) {
            nodes << group->getChild(geode);
        }
    }

    for (uint child = 0; child < m_system->getNumChildren(); child++) {
        nodes << m_system->getChild(child);
    }

    OsgMutuallyExclusiveBuilder visitor(nodes);
    osg::Node *node = m_context;
    visitor.traverse(*node);
    m_context = visitor.getGroup();

    if (ui->checkBoxContextVisible->isChecked()) {
        m_root->addChild(m_context);
    }
}

void OsgView::updateShotGroup()
{
    m_shot->removeChildren(0, m_shot->getNumChildren());

    QList<int> aimPoints = m_irDoc->getAimPoints();

    // List of all nodes that are in shot groups.
    // Used for creating mutually exclusive sets.
    QList<osg::Node*> nodes;

    foreach (int aimPoint, aimPoints) {

        // muves component names damaged by aimpoint.
        QStringList components = m_irDoc->getComponentNames(aimPoint);

        // Brlcad regions damaged by aimpoint.
        QList<int> regions = m_regmapDoc->getRegions(components);

        // Check for errors in the regmap doc.
        if (m_regmapDoc->hasErrors()) {
            qDebug() << "Warning! I found the following components in the IR, but they're not in the regmap." << endl;
            qDebug() << m_regmapDoc->getErrors();
            m_regmapDoc->clearErrors();
        }

        // Create group from list of brlcad regions
        osg::ref_ptr<osg::Group> group = m_osgDoc->groupCreate(regions);

        for(uint child = 0; child < group->getNumChildren(); child++) {
            nodes << group->getChild(child);
        }

        // Clear existing shot sets.
        if (m_shotSets->contains(aimPoint)) {
            osg::ref_ptr<osg::Group> existing = m_shotSets->take(aimPoint);
            m_shot->removeChild(existing);
        }

        // Save the set we just created.
        m_shotSets->insert(aimPoint, group);
        m_shot->addChild(group);
    }

    m_root->addChild(m_shot);

    OsgMutuallyExclusiveBuilder visitor(nodes);
    visitor.traverse(*m_context);
    m_context = visitor.getGroup();

    if (ui->checkBoxContextVisible->isChecked()) {
        m_root->addChild(m_context);
    }

    if (ui->checkBoxSystemVisible->isChecked()) {
        m_root->addChild(m_system);
    }

    updateShotSetGUI();
}

void OsgView::updateOtherGroup()
{
    m_root->removeChild(m_other);
    QList<osg::Node*> nodes;
    for (uint child = 0; child < m_shot->getNumChildren(); child++) {
        osg::Group *group = m_shot->getChild(child)->asGroup();
        for (uint geode = 0; geode < group->getNumChildren(); geode++) {
            nodes << group->getChild(geode);
        }
    }

    for (uint child = 0; child < m_context->getNumChildren(); child++) {
        nodes << m_context->getChild(child);
    }

    for (uint child = 0; child < m_system->getNumChildren(); child++) {
        nodes << m_system->getChild(child);
    }

    OsgMutuallyExclusiveBuilder visitor(nodes);
    osg::Node *node = m_osgDoc->getData();
    visitor.traverse(*node);
    m_other = visitor.getGroup();

    if (ui->checkBoxOtherVisible->isChecked()) {
        m_root->addChild(m_other);
    }
}

void OsgView::updateColor(QLabel *labelPatch, osg::ref_ptr<osg::Group> group, float opacity)
{
    // Used to access color from the label
    QPalette::ColorRole backgroundRole = labelPatch->backgroundRole();

    // Current background color
    QPalette palette = ui->labelSystemColorPatch->palette();
    QColor currentColor = palette.color(backgroundRole);

    // Ask user for color
    QColor newColor = QColorDialog::getColor(currentColor);

    // Update color in ui
    palette.setColor(backgroundRole, newColor);
    labelPatch->setPalette(palette);

    // Update color in osg and embree
    newColor = newColor.toRgb();
    newColor.setAlphaF(opacity);
    groupSetColor(group, newColor);
}

void OsgView::updateShotSetGUI()
{
    QList<int> aimPoints = m_irDoc->getAimPoints();
    QGroupBox *box = ui->groupShot;
    QHBoxLayout *layout = static_cast<QHBoxLayout*>(box->layout());

    // If we've already populated the checkboxes,
    // then we'll need to erase them.
    foreach (QHBoxLayout *checkBoxLayout, *m_aimPointCheckBoxes) {

        // Remove the layout item from the top level widget.
        layout->removeItem(checkBoxLayout);

        // Delete all items within the check box layout.
        while (QLayoutItem *item = checkBoxLayout->takeAt(0)) {

            // Not really sure why this is necessary. Deleting item should invoke
            // the widget's destructor but it does not.
            if (QWidget *widget = item->widget()) {
                delete widget;
            }

            delete item;
        }

        // Finally delete the layout.
        delete checkBoxLayout;
    }

    m_aimPointCheckBoxes->clear();

    foreach (int aimPoint, aimPoints) {
        // Layout to hold the check boxes.
        QHBoxLayout *checkBoxLayout = new QHBoxLayout();

        // Create and connect checkbox
        QCheckBox *checkBox = new QCheckBox("Shot by aimpoint:" + QString::number(aimPoint));
        checkBoxLayout->addWidget(checkBox);
        checkBox->setProperty("aimPoint", QVariant::fromValue(aimPoint));
        checkBox->setChecked(true);

        connect(checkBox, SIGNAL(stateChanged(int)),
                this, SLOT(checkBoxShotAimpointVisibleStateChanged(int)));

        // Create a color patch for next to the checkbox.
        QLabel *label = new QLabel("   ");
        label->setAutoFillBackground(true);

        // Set the background color of label
        QColor color = m_irDoc->getThreatColor(aimPoint);
        QPalette palette = label->palette();
        palette.setColor(label->backgroundRole(), color);
        label->setPalette(palette);

        checkBoxLayout->addWidget(label);

        m_aimPointCheckBoxes->append(checkBoxLayout);
    }

    for(int i = m_aimPointCheckBoxes->count() - 1; i >= 0; i--) {
        layout->insertLayout(0, m_aimPointCheckBoxes->at(i));
    }
}

void OsgView::groupSetOpacity(osg::ref_ptr<osg::Group> group, float alpha)
{
    OsgAlphaApplier visitor(alpha);
    visitor.traverse(*group);

    ui->glWidget->updateSceneMaterials(m_root);
}

void OsgView::groupSetColor(osg::ref_ptr<osg::Group> group, QColor color)
{
    osg::Vec4 osgColor = osgVecFromQColor(color);
    osg::StateSet *stateSet = group->getOrCreateStateSet();
    osg::Material *material = (osg::Material*) stateSet->getAttribute(osg::StateAttribute::MATERIAL);

    if (!material) {
        material = new osg::Material();
    }

    material->setDiffuse(osg::Material::FRONT_AND_BACK, osgColor);
    stateSet->setAttributeAndModes(material, osg::StateAttribute::OVERRIDE);

    OsgMaterialApplier visitor(stateSet);
    visitor.traverse(*group);

    ui->glWidget->updateSceneMaterials(m_root);
}

QColor OsgView::getColorFromUi(QLabel *labelPatch, QSlider *opacitySlider)
{
    float alpha = (float) opacitySlider->value() / (float) opacitySlider->maximum();
    QColor color = labelPatch->palette().color(labelPatch->backgroundRole());
    color.setAlphaF(alpha);
    return color;
}

osg::ref_ptr<osg::Group> OsgView::shotlineGeometryCreate(int aimPoint, float radius)
{
    // Create group to hold the geodes.
    osg::ref_ptr<osg::Group> group = new osg::Group;

    const IRShotlineThreat *threat = m_irDoc->getThreat(aimPoint);
    for (int trace = 0; trace < threat->traces.size() - 1; trace++) {
        osg::ref_ptr<osg::Geode> geode = shotlineGeodeCreate(threat->traces.at(trace), threat->traces.at(trace+1),
                                         radius / (traceIsAir(threat->traces.at(trace)) ? 3.0f : 1.0f),
                                         osgVecFromQColor(m_irDoc->getThreatColor(aimPoint)));
        QString muvesName = QString("muvesName=AP:" + QString::number(aimPoint) + QString("--") + threat->traces.at(trace)->compName);
        geode->addDescription(muvesName.toStdString());

        QString componentId = QString("component=" + QString::number(trace));
        geode->addDescription(componentId.toStdString());

        QString apId = QString("AP=" + QString::number(aimPoint));
        geode->addDescription(apId.toStdString());
        group->addChild(geode);
    }

    return group;
}

osg::ref_ptr<osg::Geode> OsgView::shotlineGeodeCreate(const IRTrace *first, const IRTrace *last, float radius, osg::Vec4 color)
{
    float radius1 = radius;
    float radius2 = radius;
    osg::Vec3 from = osgVecFromDoubles(first->geom.entry);
    osg::Vec3 to  = osgVecFromDoubles(last->geom.entry);

    osg::Vec3 pathDir= to - from;
    pathDir = to - from;
    float length = pathDir.length();
    pathDir.normalize();

    osg::ref_ptr<osg::Vec3Array> verts = new osg::Vec3Array;
    osg::ref_ptr<osg::Vec3Array> norms = new osg::Vec3Array;
    osg::ref_ptr<osg::Vec3Array> topVerts = new osg::Vec3Array;
    osg::ref_ptr<osg::Vec3Array> bottomVerts = new osg::Vec3Array;
    // matOrient spins around the z-axis of the tube.
    osg::Matrix matOrient;
    osg::Vec3 zAxis(0.0, 0.0, 1.0);
    matOrient.makeRotate(zAxis, pathDir);

    // matPosition moves between start and end points.
    osg::Matrix matPosition;
    matPosition.makeTranslate(from);

    osg::Vec3 p1(radius1, 0.0, 0.0);
    osg::Vec3 p2(radius2, 0.0, length);
    osg::Vec3 yaxis(0.0, 1.0, 0.0);

    osg::Vec3 dir = p2 - p1;
    osg::Vec3 cylinderNormal = yaxis ^ dir;
    cylinderNormal.normalize();

    osg::Vec3 v1, v2, n;
    osg::Matrix matSpin;

    // Actually create the tube vertex info.
    for (int i=0 ; i <= 360/15 ; i++) {
        matSpin.makeRotate(i*15*DEGTORAD, osg::Vec3(0.0, 0.0, -1.0));
        v1 = p1 * matSpin * matOrient * matPosition;
        v2 = p2 * matSpin * matOrient * matPosition;

        verts->push_back(v1);
        verts->push_back(v2);

        topVerts->push_back(v1);
        bottomVerts->push_back(v2);

        n =  (cylinderNormal) * matSpin * matOrient;

        norms->push_back(n);
        norms->push_back(n);
    }

    // Add the top and bottom of the tube.
    osg::Vec3 topCenter    = p1 * matOrient * matPosition;
    osg::Vec3 bottomCenter = p2 * matOrient * matPosition;

    for (int vertIndex = 0; vertIndex < topVerts->size() - 1; vertIndex++) {

        verts->push_back(topVerts->at(vertIndex));
        verts->push_back(topVerts->at(vertIndex+1));
        verts->push_back(topCenter);
        verts->push_back(topCenter);

        verts->push_back(bottomVerts->at(vertIndex));
        verts->push_back(bottomVerts->at(vertIndex+1));
        verts->push_back(bottomCenter);
        verts->push_back(bottomCenter);

        // TODO: Check that these are correct.
        osg::Vec3 normal = norms->at(vertIndex);
        norms->push_back(normal);
        norms->push_back(normal);
        norms->push_back(normal);
        norms->push_back(normal);
        norms->push_back(normal);
        norms->push_back(normal);
        norms->push_back(normal);
        norms->push_back(normal);
    }

    // Create geometry to hold the vertex info.
    osg::ref_ptr<osg::Geometry> geometry = new osg::Geometry;
    geometry->setVertexArray(verts);
    geometry->setNormalArray(norms);
    geometry->setNormalBinding(osg::Geometry::BIND_PER_VERTEX);
    geometry->addPrimitiveSet(new osg::DrawArrays(osg::PrimitiveSet::QUAD_STRIP, 0, verts->size()));

    osg::ref_ptr<osg::StateSet> stateSet = geometry->getOrCreateStateSet();
    osg::Material *material = (osg::Material*) stateSet->getAttribute(osg::StateAttribute::MATERIAL);
    if (!material) {
        material = new osg::Material();
    }

    stateSet->setMode(GL_BLEND, osg::StateAttribute::ON);
    material->setDiffuse(osg::Material::FRONT_AND_BACK, osg::Vec4(color));
    stateSet->setAttributeAndModes(material, osg::StateAttribute::OVERRIDE);
    stateSet->setRenderingHint(osg::StateSet::TRANSPARENT_BIN);

    osg::ref_ptr<osg::Geode> geode = new osg::Geode();
    geode->addDrawable(geometry);
    return geode;
}

QToolBar *OsgView::createToolBar()
{
    QToolBar *toolbar = new QToolBar();
    toolbar->setObjectName("osgvToolBar");

    QAction *action = new QAction(toolbar);
    action->setIconText("Reset View");
    connect(action, SIGNAL(triggered()), ui->glWidget, SLOT(resetView()));
    toolbar->addAction(action);

    toolbar->addSeparator();
    action = toolbar->addAction("Orbit", this, SLOT(menuSetMouseMode()));
    action->setCheckable(true);
    action->setChecked(true);
    action->setProperty("mouseMode", OSGWidget::MM_ORBIT);
    action->setObjectName("actionOrbit");
    m_mouseModeActions << action;

    action = toolbar->addAction("Pan", this, SLOT(menuSetMouseMode()));
    action->setCheckable(true);
    action->setObjectName("actionPan");
    action->setProperty("mouseMode", OSGWidget::MM_PAN);
    m_mouseModeActions << action;

    action = toolbar->addAction("Zoom", this, SLOT(menuSetMouseMode()));
    action->setCheckable(true);
    action->setObjectName("actionZoom");
    action->setProperty("mouseMode", OSGWidget::MM_ZOOM);
    m_mouseModeActions << action;

    action = toolbar->addAction("PickCenter", this, SLOT(menuSetMouseMode()));
    action->setCheckable(true);
    action->setObjectName("actionPickCenter");
    action->setProperty("mouseMode", OSGWidget::MM_PICK_CENTER);
    m_mouseModeActions << action;

    return toolbar;
}
