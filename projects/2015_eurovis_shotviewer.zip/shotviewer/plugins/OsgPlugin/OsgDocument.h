#ifndef OSGDOCUMENT_H
#define OSGDOCUMENT_H

#include "ApplicationDocument.h"
#include <osg/Group>

#include <QList>

class OsgDocument : public ApplicationDocument
{
    Q_OBJECT

public:

    OsgDocument(QObject *parent = 0);

    /// Import a file to the document.  This will set the document file name if
    /// the document was previously empty. This method emits "documentLoaded"
    /// when the document is finished loading. (on first import only?)
    bool importFileByName(QString fileName);

    /// Save the document to the current file name.
    void saveFile();

    /// Save the document to an alternate file name.
    /// Sets the current document name
    void saveFileByName(QString fileName);

    /// Gets the text string which indicates the type or category of this
    /// document within the application. (eg "Text" or "SysDef" or "Geometry")
    QString getDocumentType();

    /// Get the underlying geometry
    /// XXX: LAYER VIOLATION
    osg::ref_ptr<osg::Group> getData();

    /// Methods for manipulating groups in the scene graph. ////////////////////

    /// Create a geometry group from a list region ids
    osg::ref_ptr<osg::Group> groupCreate(const QList<int> &regions);

    /// Deletes a group.
    void groupDelete(osg::ref_ptr<osg::Group> &group);

    /// Set group state set.
    void groupSetStateSet(osg::ref_ptr<osg::Group> &group,
                          osg::StateSet &stateSet);

private:

    // Helper functions ///////////////////////////////////////////////////////

    void setFileName(const QString &fileName);

    // Private data memebers //////////////////////////////////////////////////

    osg::ref_ptr<osg::Group> m_geometry;
};

#endif // OSGDOCUMENT_H
