#ifndef OSGVISITORS_HPP
#define OSGVISITORS_HPP

#include <osg/NodeVisitor>
#include <osg/Group>
#include <osg/Geode>
#include <osg/ref_ptr>
#include <osg/Node>
#include <osg/Drawable>
#include <osg/Geometry>
#include <osg/Vec4>
#include <osg/Material>

#include <QDebug>
#include <QList>

#include <RegmapApplicationDocument.h>

#include "OsgHelpers.h"

/** This class is used for finding osg::Geodes that have geometry representing
 * a list of region ids. It should be applied to the osg root. Then the method
 * getGroup will return a group containing all of the geodes with regionIds
 * specified in the constructor.
 */
class OsgMuvesFinder : public osg::NodeVisitor
{

public:

    /// Constructor.
    /// -regions is the list of region ids to find in the graph.
    OsgMuvesFinder(const QList<int> &regions)
        : osg::NodeVisitor(osg::NodeVisitor::TRAVERSE_ALL_CHILDREN)
        , m_regions(regions)
        , m_group(new osg::Group)
    {
    }

    /// Search only geodes for a list of region Ids.
    virtual void apply(osg::Geode &node)
    {
        int region = geodeRegionId(node);
        if (m_regions.contains(region)) {
            m_group->addChild(&node);
        }
        traverse(node);
    }

    osg::ref_ptr<osg::Group> getGroup() const
    {
        return m_group;
    }

private:

    /// List of regions that we are trying to find.
    const QList<int> &m_regions;

    /// Group of geodes in m_regions.
    osg::ref_ptr<osg::Group> m_group;
};

/** A visitor for constructing mutually exclusive groups of geometry. When
 * applied to a node, this creates a group of that node's children with the
 * nodes listed in "existing" removed.
 */
class OsgMutuallyExclusiveBuilder : public osg::NodeVisitor
{

public:

    /// Existing is a list of nodes that we do not want to appear in the new
    /// group.
    OsgMutuallyExclusiveBuilder(const QList<osg::Node*> existing)
        : osg::NodeVisitor(osg::NodeVisitor::TRAVERSE_ALL_CHILDREN)
        , m_existing(existing)
        , m_group(new osg::Group)
    {
    }

    virtual void apply(osg::Geode &node)
    {
        if (!m_existing.contains(&node)) {
            m_group->addChild(&node);
        }
    }

    osg::ref_ptr<osg::Group> getGroup()
    {
        return m_group;
    }

private:
    /// List of nodes that will not be in the new group.
    const QList<osg::Node*> m_existing;

    /// New group with existing nodes removed.
    osg::ref_ptr<osg::Group> m_group;
};

/** Visitor that applies a material to all drawables of a geode. This is
 * necessary b/c the embree geometry extractor only uses per-drawable
 * materials.
 */
class OsgMaterialApplier : public osg::NodeVisitor
{

public:

    /// Existing is a list of nodes that we do not want to appear in the new group.
    OsgMaterialApplier(osg::ref_ptr<osg::StateSet> stateSet)
        : osg::NodeVisitor(osg::NodeVisitor::TRAVERSE_ALL_CHILDREN)
        , m_stateSet(stateSet)
    {
    }

    virtual void apply(osg::Geode &geode)
    {
        for (uint drawable = 0; drawable < geode.getNumDrawables(); drawable++) {
            osg::ref_ptr<osg::Geometry> geometry = geode.getDrawable(drawable)->asGeometry();
            if (geometry) {
                geometry->setStateSet(m_stateSet);
            }
        }
    }

protected:

    osg::ref_ptr<osg::StateSet> m_stateSet;
};

/** Visitor that applies an alpha value to all osg materials in a group. It does
 * not change the actual color value--just alpha.
 */
class OsgAlphaApplier: public osg::NodeVisitor
{

public:

    /// Existing is a list of nodes that we do not want to appear in the new group.
    OsgAlphaApplier(float alpha)
        : osg::NodeVisitor(osg::NodeVisitor::TRAVERSE_ALL_CHILDREN)
        , m_alpha(alpha)
    {
    }

    virtual void apply(osg::Geode &geode)
    {
        for (uint drawable = 0; drawable < geode.getNumDrawables(); drawable++) {
            osg::ref_ptr<osg::Geometry> geometry = geode.getDrawable(drawable)->asGeometry();
            if (geometry) {
                osg::StateSet *stateSet = geometry->getStateSet();
                osg::Material *material = (osg::Material*) stateSet->getAttribute(osg::StateAttribute::MATERIAL);
                osg::Vec4 color = material->getDiffuse(osg::Material::FRONT_AND_BACK);
                color[3] = m_alpha;
                material->setDiffuse(osg::Material::FRONT_AND_BACK, color);
            }
        }
    }

protected:

    float m_alpha;
};

/** This adds a muvesName to all geodes in the osg graph. It could probably be
 * removed and we could just regionIds instead.
 */
class OsgMuvesApplier : public osg::NodeVisitor
{

public:

    OsgMuvesApplier(RegmapApplicationDocument *regmapDoc)
        : osg::NodeVisitor(osg::NodeVisitor::TRAVERSE_ALL_CHILDREN)
        , m_regmapDoc(regmapDoc)
    {
    }

    virtual void apply(osg::Geode &node)
    {
        int region = geodeRegionId(node);
        QString name = m_regmapDoc->getMuvesName(region);
        node.addDescription(name.prepend("muvesName=").toStdString());
    }

private:

    RegmapApplicationDocument *m_regmapDoc;

};

#endif // OSGVISITORS_HPP
