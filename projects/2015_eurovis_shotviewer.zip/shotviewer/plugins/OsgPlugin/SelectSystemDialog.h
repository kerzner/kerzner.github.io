#ifndef SELECTSYSTEMDIALOG_H
#define SELECTSYSTEMDIALOG_H

#include <QDialog>

namespace Ui
{
class SelectSystemDialog;
}

/** This class allows the user to select a system from the loaded sysdef file.
 * This selected system then gets put into its own osg group that gets rendered.
 * The user can adjust the color and opacity of this group using the OsgView.
 *
 * This allows the user to select from either ALL systems or only damaged
 * systems. The user can filter the systems by name with the lineEditFilter.
 */
class SelectSystemDialog : public QDialog
{
    Q_OBJECT

public:

    /// Constructor
    /// -systems: list of ALL systems in the sysdef file
    /// -damagedSystems: only those systems whose components have pks != 0.0
    explicit SelectSystemDialog(QStringList systems,
                                QStringList damagedSystems,
                                QWidget *parent = 0);
    /// Destructor
    ~SelectSystemDialog();

    /// Returns name of the selected system.
    QString getSelectedSystem();

public slots:

    /// Toggles whether ALL systems or just damaged systems are displayed.
    void on_checkBoxDamaged_stateChanged(int);

    /// Filters the systems displayed by the string.
    void on_lineEditFilter_textChanged(const QString &);

private:

    Ui::SelectSystemDialog *ui;

    /// List of ALL systems that the user can select
    QStringList m_systems;

    /// List of only the damaged systems that the user can select.
    QStringList m_damagedSystems;
};

#endif // SELECTSYSTEMDIALOG_H
