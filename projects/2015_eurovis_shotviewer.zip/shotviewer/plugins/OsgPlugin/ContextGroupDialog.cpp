#include "ContextGroupDialog.h"
#include "ui_ContextGroupDialog.h"

#include <QTextBlock>

ContextGroupDialog::ContextGroupDialog(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::ContextGroupDialog)
{
    ui->setupUi(this);
}

void ContextGroupDialog::setContextNameList(const QStringList &list)
{
    ui->textEdit->clear();
    foreach (QString name, list) {
        ui->textEdit->append(name);
    }
}

QStringList ContextGroupDialog::getContextNameList()
{
    QStringList list;
    QTextDocument *document = ui->textEdit->document();
    int lineCount = document->lineCount();

    for (int line = 0; line < lineCount; line++) {
        QString text = document->findBlockByLineNumber(line).text();
        if (!text.isEmpty()) {
            list << text;
        }
    }

    return list;
}

ContextGroupDialog::~ContextGroupDialog()
{
    delete ui;
}
