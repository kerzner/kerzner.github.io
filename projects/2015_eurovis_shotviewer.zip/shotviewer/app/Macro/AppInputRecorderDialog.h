#ifndef APPRECORDERDIALOG_H
#define APPRECORDERDIALOG_H

#include <QDialog>
#include "AppInputRecorder.h"

namespace Ui
{
class AppRecorderDialog;
}

class AppInputRecorderDialog : public QDialog
{
    Q_OBJECT

public:
    explicit AppInputRecorderDialog(QWidget *parent = 0);
    ~AppInputRecorderDialog();

    /// Define
    void setObjectToRecord(QWidget *w);

public slots:
    void record();
    void replay();
    void stop();
    void save();
    void load();
    void reset();

    void showEvent(QShowEvent *ev);

    void executeFile(const QString &fileName);

    void showLog(bool tf);

private slots:
    void speedChanged(int i);
    void on_closeButton_clicked();
    void showNewLogSize(int length);

private:
    Ui::AppRecorderDialog *ui;
    AppInputRecorder *m_Recorder;
    QByteArray m_windowGeometry;
    float m_speedFactor;
};

#endif // APPRECORDERDIALOG_H
