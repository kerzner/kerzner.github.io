#include "AppInputRecorderDialog.h"
#include "ui_AppInputRecorderDialog.h"
#include <stdio.h>
#include <QFileDialog>


AppInputRecorderDialog::AppInputRecorderDialog(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::AppRecorderDialog),
    m_Recorder(NULL),
    m_speedFactor(1.0)
{
    ui->setupUi(this);
    ui->logText->hide();

    QObject::connect(ui->recordButton, SIGNAL(clicked()), this, SLOT(record()));
    QObject::connect(ui->replayButton, SIGNAL(clicked()), this, SLOT(replay()));
    QObject::connect(ui->resetButton , SIGNAL(clicked()), this, SLOT(reset()));
    QObject::connect(ui->stopButton, SIGNAL(clicked()), this, SLOT(stop()));
    QObject::connect(ui->saveButton, SIGNAL(clicked()), this, SLOT(save()));
    QObject::connect(ui->loadButton, SIGNAL(clicked()), this, SLOT(load()));
    QObject::connect(ui->debuggingCheckbox, SIGNAL(toggled(bool)),
                     this, SLOT(showLog(bool)));
    QObject::connect(ui->speedSlider, SIGNAL(valueChanged(int)),
                     this, SLOT(speedChanged(int)));
    //ui->minValueLabel->setText(QString("%1").arg(ui->speedSlider->minimum() * 0.1));
    //ui->maxValueLabel->setText(QString("%1").arg(ui->speedSlider->maximum() * 0.1));
}

AppInputRecorderDialog::~AppInputRecorderDialog()
{
    delete m_Recorder;
    delete ui;
}

void AppInputRecorderDialog::showLog(bool tf)
{
    m_Recorder->setDebugging(tf);

    ui->logText->setVisible(tf);
}

void AppInputRecorderDialog::setObjectToRecord(QWidget *w)
{
    if (!m_Recorder) {
        m_Recorder = new AppInputRecorder(*w);
        QObject::connect(m_Recorder, SIGNAL(debuggingToggled(bool)),
                         ui->debuggingCheckbox, SLOT(setChecked(bool)));
        QObject::connect(m_Recorder, SIGNAL(replayDone()),
                         this, SLOT(stop()));
        QObject::connect(m_Recorder, SIGNAL(recordingLength(int)),
                         this, SLOT(showNewLogSize(int)));
        QObject::connect(m_Recorder, SIGNAL(newLogEntry(QString)),
                         ui->logText, SLOT(appendPlainText(QString)));

        m_Recorder->setDebugging(true);
    }

    showNewLogSize(m_Recorder->size());
}

void AppInputRecorderDialog::record()
{
    m_Recorder->record();
    ui->recordButton->setEnabled(false);
    ui->stopButton->setEnabled(true);

    ui->replayButton->setEnabled(false);
    ui->resetButton->setEnabled(false);
}

#include <iostream>
void AppInputRecorderDialog::stop()
{
    m_Recorder->stop();
    ui->stopButton->setEnabled(false);
    ui->recordButton->setEnabled(true);
    ui->replayButton->setEnabled(true);
    ui->resetButton->setEnabled(true);
    ui->saveButton->setEnabled(true);
}


void AppInputRecorderDialog::speedChanged(int i)
{
    float v = i;

    if (v == 25.0) {
        m_speedFactor = 1.0;
        ui->speedReadout->setText(QString("%1x").arg(1.0/m_speedFactor));
    } else if (v < 25.0) {
        m_speedFactor = 4.0 - ( 3 * ( v / 24.0));
        ui->speedReadout->setText(QString("%1x").arg(1.0/m_speedFactor));
    } else if (v == 100) {
        m_speedFactor = 0.0;
        ui->speedReadout->setText(QString("inf"));
    } else {
        v -= 25.0;
        m_speedFactor = 1.0 / v;
        ui->speedReadout->setText(QString("%1x").arg(1.0/m_speedFactor));
    }
}

void AppInputRecorderDialog::replay()
{
    m_Recorder->replay(m_speedFactor);
    ui->replayButton->setEnabled(false);
    ui->stopButton->setEnabled(true);
    ui->recordButton->setEnabled(false);
}

void AppInputRecorderDialog::save()
{
    QString fileName =
        QFileDialog::getSaveFileName(this,
                                     "save Event Log",
                                     qApp->property("currentDirectory").toString(),
                                     "*.evt");
    if (fileName.isEmpty())
        return;

    if (!fileName.endsWith(".evt"))
        fileName.append(".evt");

    m_Recorder->save(fileName);
}
void AppInputRecorderDialog::reset()
{

    m_Recorder->stop();
    m_Recorder->clearRecording();
    ui->stopButton->setEnabled(false);
    ui->recordButton->setEnabled(true);
    ui->replayButton->setEnabled(false);
    ui->resetButton->setEnabled(false);
    ui->saveButton->setEnabled(false);

    ui->logText->clear();
}

void AppInputRecorderDialog::load()
{
    stop();

    QString fileName = QFileDialog::getOpenFileName(this);
    if (!fileName.isEmpty())
        m_Recorder->load(fileName);

    ui->saveButton->setEnabled(false);

}
void AppInputRecorderDialog::executeFile(const QString &fileName)
{
    reset();
    m_Recorder->load(fileName);
    replay();
}

void AppInputRecorderDialog::showEvent(QShowEvent *ev)
{
    if (m_windowGeometry.size() > 0)
        restoreGeometry(m_windowGeometry);

    QDialog::showEvent(ev);
}

void AppInputRecorderDialog::on_closeButton_clicked()
{
    ui->closeButton->setDefault(false);
    m_windowGeometry = saveGeometry();
    this->hide();
}
void AppInputRecorderDialog::showNewLogSize(int length)
{
    ui->statusLabel->setText(QString("%1").arg(length));
}
