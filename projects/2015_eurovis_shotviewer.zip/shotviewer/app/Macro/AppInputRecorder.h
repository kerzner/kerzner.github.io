/* Copyright 2011 Stanislaw Adaszewski. All rights reserved.

Redistribution and use in source and binary forms, with or without modification, are
permitted provided that the following conditions are met:

   1. Redistributions of source code must retain the above copyright notice, this list of
      conditions and the following disclaimer.

   2. Redistributions in binary form must reproduce the above copyright notice, this list
      of conditions and the following disclaimer in the documentation and/or other materials
      provided with the distribution.

THIS SOFTWARE IS PROVIDED BY STANISLAW ADASZEWSKI ``AS IS'' AND ANY EXPRESS OR IMPLIED
WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND
FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL STANISLAW ADASZEWSKI OR
CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF
ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

The views and conclusions contained in the software and documentation are those of the
authors and should not be interpreted as representing official policies, either expressed
or implied, of Stanislaw Adaszewski. */

#ifndef QINPUTEVENTRECORDER_H
#define QINPUTEVENTRECORDER_H

#include <QVector>
#include <QEvent>
#include <QDateTime>

class QTimer;

/**
 * @brief The QInputEventRecorder class allows recording/playback/save/load
 * of QEvent logs.
 *
 *
 */
class AppInputRecorder: public QObject
{
    Q_OBJECT
public:
    AppInputRecorder(QWidget &obj);
    ~AppInputRecorder();

    /// This is installed in qApp as an event filter.  It processes each event
    /// to save it in the event log before passing it on to the application.
    /// It is not intended for direct calling by application.
    bool eventFilter(QObject *obj, QEvent *ev);

    /// Report the number of events recorded/retained
    int size() const {
        return m_Recording.size();
    }

    /// turn on/off logging of events during capture/playback
    void setDebugging(bool tf);
    bool debugging() const {
        return m_debug;
    }

    /// provides the buffer of events logged during debugging
    QString logString() const {
        return m_logString;
    }

public slots:
    /// Begin recording events and appending them to the event log
    void record();

    /// stop recording events to the event log
    void stop();

    /// Replay the saved event log
    void replay(float speedFactor);

    /// Flush the contents of the event log
    void clearRecording();

    /// save the event log to a file for later re-use
    void save(const QString &fileName);

    /// load the event log from a file for replay
    void load(const QString &fileName);

signals:
    /// Indicates that replay of the event log has completed
    void replayDone();

    /// Indicates the new length of the log
    void recordingLength(int len);

    void newLogEntry(QString msg);

    void debuggingToggled(bool tf);

private slots:
    /// called when  m_Timer ticks.
    /// Emits replayDone() when the whole log has been played
    void replayOneEvent();

private:
    enum CurrentState { IDLE, PLAYING, RECORDING } m_currentState;
    QEvent *cloneEvent(QEvent*); ///< Duplicate one event

    void logEvent(QObject *obj, QEvent *ev);

    /// Give any un-named widgets a unique name so that we can find that widget
    /// by name when we replay.
    void nameAllWidgets(QWidget *w = NULL);

    /**
     * @brief The EventDelivery class holds an event, timestamp, and the object
     * that recieved the event
     */
    class EventDelivery
    {
    public:
        /// Implemented to allow insertion into QVector
        EventDelivery();

        /// Construct from within eventFilter()
        EventDelivery(int timeOffset, QObject *obj, QEvent *ev);

        /// Construct when reading from a file
        EventDelivery(int timeOffset, const QString &clsName, const QString &objName, QEvent *ev);

        int timeOffset() const {
            return m_TimeOffset;
        }
        const QString& clsName() const {
            return m_ClsName;
        }
        const QString& objName() const {
            return m_ObjName;
        }
        QEvent* event() const {
            return m_Ev.data();
        }

    private:
        int m_TimeOffset;
        QString m_ClsName;
        QString m_ObjName;
        QSharedPointer<QEvent> m_Ev;
    };


    QWidget *m_Obj; ///< This is the Widget we are recording events for
    QVector<EventDelivery> m_Recording; ///< Log of events that have been recorded
    int m_ReplayPos; ///< Where are we in m_Recording during playback
    QTimer *m_Timer; ///< replay timer
    QDateTime m_RecordingStartTime; ///< Time at which recording started
    float m_ReplaySpeedFactor; ///< speed at which events should be replayed

    bool m_debug; ///< should we print debugging?
    QString m_logString; ///< log of all events recieved/processed
    unsigned m_sequenceNumber; ///< index for event recieved
    void logReset(); ///< Clear the log of events processed
};

#endif // QINPUTEVENTRECORDER_H
