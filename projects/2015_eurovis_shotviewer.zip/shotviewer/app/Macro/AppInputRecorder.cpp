/* Copyright 2011 Stanislaw Adaszewski. All rights reserved.

Redistribution and use in source and binary forms, with or without modification, are
permitted provided that the following conditions are met:

   1. Redistributions of source code must retain the above copyright notice, this list of
      conditions and the following disclaimer.

   2. Redistributions in binary form must reproduce the above copyright notice, this list
      of conditions and the following disclaimer in the documentation and/or other materials
      provided with the distribution.

THIS SOFTWARE IS PROVIDED BY STANISLAW ADASZEWSKI ``AS IS'' AND ANY EXPRESS OR IMPLIED
WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND
FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL STANISLAW ADASZEWSKI OR
CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF
ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

The views and conclusions contained in the software and documentation are those of the
authors and should not be interpreted as representing official policies, either expressed
or implied, of Stanislaw Adaszewski. */

#include "AppInputRecorder.h"

#include <QContextMenuEvent>
#include <QFile>
#include <QDataStream>
#include <QTimer>
#include <QWidget>
#include <QApplication>
#include <QString>

#include <stdio.h>

#include "EventSerialization.h"

//
// Helper routines
//

static QString objectPath(QObject *obj)
{
    QString res;
    for(; obj; obj = obj->parent()) {
        if (!res.isEmpty())
            res.prepend("/");
        res.prepend(obj->objectName());
    }
    return res;
}

static bool isChild(QObject *obj, QObject *parent)
{
    while ((obj = obj->parent())) {
        if (obj == parent)
            return true;
    }

    return false;
}


//
// QInputEventRecorder
//

AppInputRecorder::AppInputRecorder(QWidget &obj):
    m_Obj(&obj),
    m_currentState(IDLE),
    m_Timer(new QTimer),
    m_debug(false)
{
    m_Timer->setSingleShot(true);
    QObject::connect(m_Timer, SIGNAL(timeout()), this, SLOT(replayOneEvent()));
}

AppInputRecorder::~AppInputRecorder()
{
    delete m_Timer;
}


void AppInputRecorder::nameAllWidgets(QWidget *w)
{
    static int uniqueId = 0;

    QObjectList children = w->children();
    foreach(QObject *o, children) {
        if (dynamic_cast<QWidget*>(o)) {
            if (o->objectName().isEmpty())
                o->setObjectName(QString("unique_%1_%2").arg(o->metaObject()->className()).arg(uniqueId++));
            nameAllWidgets(static_cast<QWidget*>(o));
        }
    }
}


QEvent* AppInputRecorder::cloneEvent(QEvent *ev)
{
    if (dynamic_cast<QContextMenuEvent*>(ev))
        return new QContextMenuEvent(*static_cast<QContextMenuEvent*>(ev));
    else if (dynamic_cast<QKeyEvent*>(ev)) {
#if 0
        // XXX there are some issues with getting Shortcut events without \
        // Key events to go with them.  Specifically with file->open dialogs
        QKeyEvent *ke = (QKeyEvent *)ev;
        return new QKeyEvent(QEvent::KeyPress, ke->key(), ke->modifiers(), ke->text());
#else
        return new QKeyEvent(*static_cast<QKeyEvent*>(ev));
#endif
    } else if (dynamic_cast<QMouseEvent*>(ev))
        return new QMouseEvent(*static_cast<QMouseEvent*>(ev));
    else if (dynamic_cast<QTabletEvent*>(ev))
        return new QTabletEvent(*static_cast<QTabletEvent*>(ev));
    else if (dynamic_cast<QTouchEvent*>(ev))
        return new QTouchEvent(*static_cast<QTouchEvent*>(ev));
    else if (dynamic_cast<QWheelEvent*>(ev))
        return new QWheelEvent(*static_cast<QWheelEvent*>(ev));

    return 0;
}


void AppInputRecorder::save(const QString &fileName)
{
    QFile f(fileName);
    if (!f.open(QFile::WriteOnly))
        return;

    QDataStream ds(&f);
    foreach(EventDelivery ed, m_Recording) {
        ds << (qint32) ed.timeOffset() << ed.clsName() << ed.objName();
        QEvent *ev(ed.event());
        ds << static_cast<QInputEvent*>(ev);
    }
}

void AppInputRecorder::load(const QString &fileName)
{
    QFile f(fileName);
    if (!f.open(QFile::ReadOnly))
        return;

    // empty the existing recording (if any)
    m_Recording.clear();

    // load the events from the file
    QDataStream ds(&f);
    while (!ds.atEnd()) {
        qint32 timeOffset;
        QString clsName, objName;
        ds >> timeOffset >> clsName >> objName;
        QInputEvent *ev;
        ds >> ev;
        m_Recording.push_back(EventDelivery(timeOffset, clsName, objName, ev));
    }

    // let the UI know the new length of the recording
    emit recordingLength(m_Recording.size());
}


void AppInputRecorder::clearRecording()
{
    stop();
    m_Recording.clear();
    logReset();
    emit recordingLength(m_Recording.size());
}

void AppInputRecorder::stop()
{
    qApp->removeEventFilter(this);
    m_Timer->stop();
    m_currentState = IDLE;
}

void AppInputRecorder::record()
{
    stop();

    nameAllWidgets(m_Obj);

    m_currentState = RECORDING;
    m_RecordingStartTime = QDateTime::currentDateTime();

    qApp->installEventFilter(this);
}

void AppInputRecorder::logReset()
{
    m_logString.clear();
    m_sequenceNumber = 0;
}

void AppInputRecorder::replay(float speedFactor)
{
    stop();

    m_currentState = PLAYING;

    if (m_Recording.size() == 0) {
        emit replayDone();
        return;
    }

    if (m_debug) {
        // if we are debugging we need to see the events that
        // get processed as a result of our replay
        logReset();
        qApp->installEventFilter(this);
    }

    m_ReplayPos = 0;
    m_ReplaySpeedFactor = speedFactor;
    m_Timer->setInterval(0);
    m_Timer->start();
}


bool AppInputRecorder::eventFilter(QObject *obj, QEvent *ev)
{
    if (!isChild(obj, m_Obj)) {
        return false;
    }

    switch (m_currentState) {
    case IDLE:
        break;
    case PLAYING: {
        // see if this is an event we would normally record
        QEvent *clonedEv = cloneEvent(ev);
        if (clonedEv) {
            // this is a recordable event, so make note of it
            logEvent(obj, ev);
            delete clonedEv;
        }
        break;
    }
    case RECORDING: {
        QEvent *clonedEv = cloneEvent(ev);
        if (clonedEv) {
            int timeOffset;
            QDateTime curDt(QDateTime::currentDateTime());
            timeOffset = m_RecordingStartTime.daysTo(curDt) * 24 * 3600 * 1000 + m_RecordingStartTime.time().msecsTo(curDt.time());
            m_Recording.push_back(EventDelivery(timeOffset, obj, clonedEv));
            emit recordingLength(m_Recording.size());
            logEvent(obj, ev);
        }
        break;
    }
    }

    return false;
}
void AppInputRecorder::replayOneEvent()
{
    EventDelivery& rec(m_Recording[m_ReplayPos++]);

    QStringList path = rec.objName().split("/", QString::KeepEmptyParts);
    if (path.size() > 0) {
        QList<QObject*> objects = m_Obj->findChildren<QObject*>(path.last());
        foreach(QObject *obj, objects) {
            if (obj->metaObject()->className() == rec.clsName() && objectPath(obj) == rec.objName()) {
                //logEvent(obj, rec.event());
                qApp->postEvent(obj, cloneEvent(rec.event()));
                goto foundObject;
            }
        }

        fprintf(stderr, "did ont find <%s> at <%s>\n",
                qPrintable(rec.clsName()), qPrintable(rec.objName()));

foundObject:
        ;
    }

    if (m_ReplayPos >= m_Recording.size()) {
        emit replayDone();
        return;
    }

    int delta = m_Recording[m_ReplayPos].timeOffset() - m_Recording[m_ReplayPos - 1].timeOffset();
    m_Timer->setInterval(delta > 0 ? delta * m_ReplaySpeedFactor : 0);
    m_Timer->start();
}


void AppInputRecorder::setDebugging(bool tf)
{
    if (tf != m_debug) {
        logReset();
    }

    m_debug = tf;
    emit debuggingToggled(m_debug);
}

void AppInputRecorder::logEvent(QObject *obj, QEvent *ev)
{
    QString message;
    if (!this->m_debug)
        return;

    QString path = obj->objectName();
    for (QObject *parent = obj->parent(); parent ; parent = parent->parent()) {
        QString name = parent->objectName();
        if (name.size() == 0) {
            name = QString("__UnNamedAtLogTime_%1__").arg(parent->metaObject()->className());
        }
        path.prepend("/");
        path.prepend(name);
    }

    message.append( QString("%1 %2 ").arg(++m_sequenceNumber).arg(path) );

    switch (ev->type()) {
    case QEvent::None :
        message.append("QEvent::None");
        break;
#if QT_VERSION < 0x050000
    case QEvent::AccessibilityDescription :
        message.append("QEvent::AccessibilityDescription");
        break;
    case QEvent::AccessibilityHelp :
        message.append("QEvent::AccessibilityHelp");
        break;
    case QEvent::AccessibilityPrepare :
        message.append("QEvent::AccessibilityPrepare");
        break;
#endif
    case QEvent::ActionAdded :
        message.append("QEvent::ActionAdded");
        break;
    case QEvent::ActionChanged :
        message.append("QEvent::ActionChanged");
        break;
    case QEvent::ActionRemoved :
        message.append("QEvent::ActionRemoved");
        break;
    case QEvent::ActivationChange :
        message.append("QEvent::ActivationChange");
        break;
    case QEvent::ApplicationActivate :
        message.append("QEvent::ApplicationActivate");
        break;
        //case QEvent::ApplicationActivated : message.append("QEvent::ApplicationActivated"); break;
    case QEvent::ApplicationDeactivate :
        message.append("QEvent::ApplicationDeactivate");
        break;
    case QEvent::ApplicationFontChange :
        message.append("QEvent::ApplicationFontChange");
        break;
    case QEvent::ApplicationLayoutDirectionChange :
        message.append("QEvent::ApplicationLayoutDirectionChange");
        break;
    case QEvent::ApplicationPaletteChange :
        message.append("QEvent::ApplicationPaletteChange");
        break;
    case QEvent::ApplicationWindowIconChange :
        message.append("QEvent::ApplicationWindowIconChange");
        break;
    case QEvent::ChildAdded :
        message.append("QEvent::ChildAdded");
        break;
        //case QEvent::ChildInserted : message.append("QEvent::ChildInserted"); break;
    case QEvent::ChildPolished :
        message.append("QEvent::ChildPolished");
        break;
    case QEvent::ChildRemoved :
        message.append("QEvent::ChildRemoved");
        break;
    case QEvent::Clipboard :
        message.append("QEvent::Clipboard");
        break;
    case QEvent::Close :
        message.append("QEvent::Close");
        break;
    case QEvent::CloseSoftwareInputPanel :
        message.append("QEvent::CloseSoftwareInputPanel");
        break;
    case QEvent::ContentsRectChange :
        message.append("QEvent::ContentsRectChange");
        break;
    case QEvent::ContextMenu :
        message.append("QEvent::ContextMenu");
        break;
    case QEvent::CursorChange :
        message.append("QEvent::CursorChange");
        break;
    case QEvent::DeferredDelete :
        message.append("QEvent::DeferredDelete");
        break;
    case QEvent::DragEnter :
        message.append("QEvent::DragEnter");
        break;
    case QEvent::DragLeave :
        message.append("QEvent::DragLeave");
        break;
    case QEvent::DragMove :
        message.append("QEvent::DragMove");
        break;
    case QEvent::Drop :
        message.append("QEvent::Drop");
        break;
    case QEvent::EnabledChange :
        message.append("QEvent::EnabledChange");
        break;
    case QEvent::Enter :
        message.append("QEvent::Enter");
        break;
        //case QEvent::EnterEditFocus : message.append("QEvent::EnterEditFocus"); break;
    case QEvent::EnterWhatsThisMode :
        message.append("QEvent::EnterWhatsThisMode");
        break;
    case QEvent::FileOpen :
        message.append("QEvent::FileOpen");
        break;
    case QEvent::FocusIn :
        message.append("QEvent::FocusIn");
        break;
    case QEvent::FocusOut :
        message.append("QEvent::FocusOut");
        break;
    case QEvent::FontChange :
        message.append("QEvent::FontChange");
        break;
    case QEvent::GrabKeyboard :
        message.append("QEvent::GrabKeyboard");
        break;
    case QEvent::GrabMouse :
        message.append("QEvent::GrabMouse");
        break;
    case QEvent::GraphicsSceneContextMenu :
        message.append("QEvent::GraphicsSceneContextMenu");
        break;
    case QEvent::GraphicsSceneDragEnter :
        message.append("QEvent::GraphicsSceneDragEnter");
        break;
    case QEvent::GraphicsSceneDragLeave :
        message.append("QEvent::GraphicsSceneDragLeave");
        break;
    case QEvent::GraphicsSceneDragMove :
        message.append("QEvent::GraphicsSceneDragMove");
        break;
    case QEvent::GraphicsSceneDrop :
        message.append("QEvent::GraphicsSceneDrop");
        break;
    case QEvent::GraphicsSceneHelp :
        message.append("QEvent::GraphicsSceneHelp");
        break;
    case QEvent::GraphicsSceneHoverEnter :
        message.append("QEvent::GraphicsSceneHoverEnter");
        break;
    case QEvent::GraphicsSceneHoverLeave :
        message.append("QEvent::GraphicsSceneHoverLeave");
        break;
    case QEvent::GraphicsSceneHoverMove :
        message.append("QEvent::GraphicsSceneHoverMove");
        break;
    case QEvent::GraphicsSceneMouseDoubleClick :
        message.append("QEvent::GraphicsSceneMouseDoubleClick");
        break;
    case QEvent::GraphicsSceneMouseMove :
        message.append("QEvent::GraphicsSceneMouseMove");
        break;
    case QEvent::GraphicsSceneMousePress :
        message.append("QEvent::GraphicsSceneMousePress");
        break;
    case QEvent::GraphicsSceneMouseRelease :
        message.append("QEvent::GraphicsSceneMouseRelease");
        break;
    case QEvent::GraphicsSceneMove :
        message.append("QEvent::GraphicsSceneMove");
        break;
    case QEvent::GraphicsSceneResize :
        message.append("QEvent::GraphicsSceneResize");
        break;
    case QEvent::GraphicsSceneWheel :
        message.append("QEvent::GraphicsSceneWheel");
        break;
    case QEvent::Hide :
        message.append("QEvent::Hide");
        break;
    case QEvent::HideToParent :
        message.append("QEvent::HideToParent");
        break;
    case QEvent::HoverEnter :
        message.append("QEvent::HoverEnter");
        break;
    case QEvent::HoverLeave :
        message.append("QEvent::HoverLeave");
        break;
    case QEvent::HoverMove :
        message.append("QEvent::HoverMove");
        break;
    case QEvent::IconDrag :
        message.append("QEvent::IconDrag");
        break;
    case QEvent::IconTextChange :
        message.append("QEvent::IconTextChange");
        break;
    case QEvent::InputMethod :
        message.append("QEvent::InputMethod");
        break;
    case QEvent::KeyPress : {
        message.append("QEvent::KeyPress");
        QKeyEvent *ke = dynamic_cast<QKeyEvent*>(ev);
        if (ke) {
            message.append(QString("(%1/%2)").arg(ke->text()).arg(ke->key()));
        }
        break;
    }
    case QEvent::KeyRelease :
        message.append("QEvent::KeyRelease");
        break;
    case QEvent::LanguageChange :
        message.append("QEvent::LanguageChange");
        break;
    case QEvent::LayoutDirectionChange :
        message.append("QEvent::LayoutDirectionChange");
        break;
    case QEvent::LayoutRequest :
        message.append("QEvent::LayoutRequest");
        break;
    case QEvent::Leave :
        message.append("QEvent::Leave");
        break;
        //case QEvent::LeaveEditFocus : message.append("QEvent::LeaveEditFocus"); break;
    case QEvent::LeaveWhatsThisMode :
        message.append("QEvent::LeaveWhatsThisMode");
        break;
    case QEvent::LocaleChange :
        message.append("QEvent::LocaleChange");
        break;
    case QEvent::NonClientAreaMouseButtonDblClick :
        message.append("QEvent::NonClientAreaMouseButtonDblClick");
        break;
    case QEvent::NonClientAreaMouseButtonPress :
        message.append("QEvent::NonClientAreaMouseButtonPress");
        break;
    case QEvent::NonClientAreaMouseButtonRelease :
        message.append("QEvent::NonClientAreaMouseButtonRelease");
        break;
    case QEvent::NonClientAreaMouseMove :
        message.append("QEvent::NonClientAreaMouseMove");
        break;
    case QEvent::MacSizeChange :
        message.append("QEvent::MacSizeChange");
        break;
#if QT_VERSION < 0x050000
    case QEvent::MenubarUpdated :
        message.append("QEvent::MenubarUpdated");
        break;
#endif
    case QEvent::MetaCall :
        message.append("QEvent::MetaCall");
        break;
    case QEvent::ModifiedChange :
        message.append("QEvent::ModifiedChange");
        break;
    case QEvent::MouseButtonDblClick : {
        message.append("QEvent::MouseButtonDblClick");
        QMouseEvent *me = dynamic_cast<QMouseEvent *>(ev);
        if (me) {
            message.append(QString("(%1,%2)").arg(me->x()).arg(me->y()));
        }
        break;
    }
    case QEvent::MouseButtonPress : {
        message.append("QEvent::MouseButtonPress");
        QMouseEvent *me = dynamic_cast<QMouseEvent *>(ev);
        if (me) {
            message.append(QString("(%1,%2)").arg(me->x()).arg(me->y()));
        }
        break;
    }
    case QEvent::MouseButtonRelease : {
        message.append("QEvent::MouseButtonRelease");
        QMouseEvent *me = dynamic_cast<QMouseEvent *>(ev);
        if (me) {
            message.append(QString("(%1,%2)").arg(me->x()).arg(me->y()));
        }
        break;
    }
    case QEvent::MouseMove : {
        message.append("QEvent::MouseMove");
        QMouseEvent *me = dynamic_cast<QMouseEvent *>(ev);
        if (me) {
            message.append(QString("(%1,%2)").arg(me->x()).arg(me->y()));
        }
        break;
    }
    case QEvent::MouseTrackingChange :
        message.append("QEvent::MouseTrackingChange");
        break;
    case QEvent::Move :
        message.append("QEvent::Move");
        break;
    case QEvent::Paint :
        message.append("QEvent::Paint");
        break;
    case QEvent::PaletteChange :
        message.append("QEvent::PaletteChange");
        break;
    case QEvent::ParentAboutToChange :
        message.append("QEvent::ParentAboutToChange");
        break;
    case QEvent::ParentChange :
        message.append("QEvent::ParentChange");
        break;
#if 0
    case QEvent::PlatformPanel :
        message.append("QEvent::PlatformPanel");
        break;
#endif
    case QEvent::Polish :
        message.append("QEvent::Polish");
        break;
    case QEvent::PolishRequest :
        message.append("QEvent::PolishRequest");
        break;
    case QEvent::QueryWhatsThis :
        message.append("QEvent::QueryWhatsThis");
        break;
    case QEvent::RequestSoftwareInputPanel :
        message.append("QEvent::RequestSoftwareInputPanel");
        break;
    case QEvent::Resize :
        message.append("QEvent::Resize");
        break;
    case QEvent::Shortcut :
        message.append("QEvent::Shortcut");
        break;
    case QEvent::ShortcutOverride : {
        message.append("QEvent::ShortcutOverride");
        QKeyEvent *ke = dynamic_cast<QKeyEvent*>(ev);
        if (ke) {
            message.append(QString("(%1/%2)").arg(ke->text()).arg(ke->key()));
        }
        break;
    }
    case QEvent::Show :
        message.append("QEvent::Show");
        break;
    case QEvent::ShowToParent :
        message.append("QEvent::ShowToParent");
        break;
    case QEvent::SockAct :
        message.append("QEvent::SockAct");
        break;
    case QEvent::StateMachineSignal :
        message.append("QEvent::StateMachineSignal");
        break;
    case QEvent::StateMachineWrapped :
        message.append("QEvent::StateMachineWrapped");
        break;
    case QEvent::StatusTip :
        message.append("QEvent::StatusTip");
        break;
    case QEvent::StyleChange :
        message.append("QEvent::StyleChange");
        break;
    case QEvent::TabletMove :
        message.append("QEvent::TabletMove");
        break;
    case QEvent::TabletPress :
        message.append("QEvent::TabletPress");
        break;
    case QEvent::TabletRelease :
        message.append("QEvent::TabletRelease");
        break;
    case QEvent::OkRequest :
        message.append("QEvent::OkRequest");
        break;
    case QEvent::TabletEnterProximity :
        message.append("QEvent::TabletEnterProximity");
        break;
    case QEvent::TabletLeaveProximity :
        message.append("QEvent::TabletLeaveProximity");
        break;
    case QEvent::Timer :
        message.append("QEvent::Timer");
        break;
    case QEvent::ToolBarChange :
        message.append("QEvent::ToolBarChange");
        break;
    case QEvent::ToolTip :
        message.append("QEvent::ToolTip");
        break;
    case QEvent::ToolTipChange :
        message.append("QEvent::ToolTipChange");
        break;
    case QEvent::UngrabKeyboard :
        message.append("QEvent::UngrabKeyboard");
        break;
    case QEvent::UngrabMouse :
        message.append("QEvent::UngrabMouse");
        break;
    case QEvent::UpdateLater :
        message.append("QEvent::UpdateLater");
        break;
    case QEvent::UpdateRequest :
        message.append("QEvent::UpdateRequest");
        break;
    case QEvent::WhatsThis :
        message.append("QEvent::WhatsThis");
        break;
    case QEvent::WhatsThisClicked :
        message.append("QEvent::WhatsThisClicked");
        break;
    case QEvent::Wheel :
        message.append("QEvent::Wheel");
        break;
    case QEvent::WinEventAct :
        message.append("QEvent::WinEventAct");
        break;
    case QEvent::WindowActivate :
        message.append("QEvent::WindowActivate");
        break;
    case QEvent::WindowBlocked :
        message.append("QEvent::WindowBlocked");
        break;
    case QEvent::WindowDeactivate :
        message.append("QEvent::WindowDeactivate");
        break;
    case QEvent::WindowIconChange :
        message.append("QEvent::WindowIconChange");
        break;
    case QEvent::WindowStateChange :
        message.append("QEvent::WindowStateChange");
        break;
    case QEvent::WindowTitleChange :
        message.append("QEvent::WindowTitleChange");
        break;
    case QEvent::WindowUnblocked :
        message.append("QEvent::WindowUnblocked");
        break;
    case QEvent::ZOrderChange :
        message.append("QEvent::ZOrderChange");
        break;
    case QEvent::KeyboardLayoutChange :
        message.append("QEvent::KeyboardLayoutChange");
        break;
    case QEvent::DynamicPropertyChange :
        message.append("QEvent::DynamicPropertyChange");
        break;
    case QEvent::TouchBegin :
        message.append("QEvent::TouchBegin");
        break;
    case QEvent::TouchUpdate :
        message.append("QEvent::TouchUpdate");
        break;
    case QEvent::TouchEnd :
        message.append("QEvent::TouchEnd");
        break;
    case QEvent::WinIdChange :
        message.append("QEvent::WinIdChange");
        break;
    case QEvent::Gesture :
        message.append("QEvent::Gesture");
        break;
    case QEvent::GestureOverride :
        message.append("QEvent::GestureOverride");
        break;

    default:
        QString msg(QString("unknown QEvent %1").arg(ev->type()));
        message.append(msg);
        break;
    }

    emit newLogEntry(message);

    m_logString.append(message);
}



//
// QInputEventRecorder::EventDelivery
//

AppInputRecorder::EventDelivery::EventDelivery(int timeOffset, QObject *obj, QEvent *ev):
    m_TimeOffset(timeOffset),
    m_ClsName(obj->metaObject()->className()),
    m_ObjName(objectPath(obj)),
    m_Ev(ev)
{
}
AppInputRecorder::EventDelivery::EventDelivery(int timeOffset, const QString &clsName, const QString &objName, QEvent *ev):
    m_TimeOffset(timeOffset),
    m_ClsName(clsName),
    m_ObjName(objName),
    m_Ev(ev)
{
    if (objName.isEmpty() || objName.isNull())
        fprintf(stderr, "null object name\n");
}
AppInputRecorder::EventDelivery::EventDelivery() : m_Ev(0)
{

}
