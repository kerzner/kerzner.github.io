#ifndef ATTACH_H
#define ATTACH_H

#include "ApplicationDocument.h"
#include "ApplicationView.h"

/// Function to attch an ApplicationDocument to an ApplicationView.
///
/// It appropriately calls ApplicationDocument::attachView() and
/// ApplicationView::attachDocument(), which are only accessible via this
/// function call. This prevents API users from only calling only one instead of
/// both. Each class's attach*() function allows specific views and documents
/// to connect signals/slots to each other, do reference counting, etc...
///
/// This API pattern was inspired by the Qt connect(...) function.

inline void attach(ApplicationDocument* doc, ApplicationView* view)
{
    doc->attachView(view);
    view->connectToDocument(doc);
}

inline void attach(ApplicationView *view0, ApplicationView *view1)
{
    view0->connectToView(view1);
    view1->connectToView(view0);
}

inline void attach(ApplicationView *view, ApplicationDocument *doc)
{
    attach(doc, view);
}

#endif // ATTACH_H
