#ifndef RECENTFILES_H
#define RECENTFILES_H

#include <QObject>
#include <QStringList>
#include <QMainWindow>

class QMenu;
class QAction;

/**
 * @brief The RecentFiles class manages a list of recently accessed files.
 *
 * It handles user-settable number of most recently accessed files, provides
 * a sub-menu that allows the user to select recently used files for opening.
 */
class RecentFiles : public QObject
{
    Q_OBJECT
public:
    explicit RecentFiles(QMainWindow *parent=NULL); /* Parent mainwindow, just for proper heirarchy, not actually used outside QObject constr */
    ~RecentFiles();

    /// Inserts the sub-menu into another Menu
    ///  \param menu   The parent menu where the sub-menu should be inserted
    ///  \param before  Action in menu before which Recent menu should be inserted
    void setMenu(QMenu *menu, QAction *before);

    QStringList getRecentFiles() const;                     ///< application calls this to get list of recent files
    void        setRecentFilesList(const QStringList& recents); ///< application can set file list with this
    void        setMostRecentFile(const QString fileName);  ///< called when each new file is opened
    QString     strippedName(const QString &fullFileName);  ///< returns filename from full path

    /// returns how many recent files are being remenbered.  see setNumOfRecentFiles()
    int         getRecentFileCount() {
        return m_numOfRecentFiles;
    }

    static const int MaxRecentFiles = 20;  ///< Max number of names we keep.

public slots:
    /// The application can set the number of recent files retained/reported here
    void setNumOfRecentFiles(int n);

signals:
    void openFile(QString fileName); ///< emitted when user selects item from "Open Recent" sub-menu
    void newMaxFilesShown(int);     ///< tells observers that the number of recent files being remembered has changed.

private slots:
    void openRecentFile(); ///< menu items signal this when user selects item from "Open Recent" sub-menu

private:
    void updateRecentFiles();  ///< call this with each new filename

    QStringList m_recentFiles; ///< List of recent file names
    QMenu *m_recentMenu;
    QAction *m_recentMenuTriggeredAction;
    int m_numOfRecentFiles; ///< How many recent file names do we remember
    QAction *m_recentFileActions[MaxRecentFiles]; ///< QActions created in file menu for storing recent files
};

#endif // RECENTFILES_H
