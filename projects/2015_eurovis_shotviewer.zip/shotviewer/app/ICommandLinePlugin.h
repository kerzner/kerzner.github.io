#ifndef ICOMMANDLINEPLUGIN_H
#define ICOMMANDLINEPLUGIN_H

#include <QtPlugin>
#include <QString>
#include <QStringList>
#include <QApplication>
/**
 * The interface for plugins that want to handle command line options/arguments.
 *
 * This is the API that any command line plugins must provide
 */
class ICommandLinePlugin
{
public:

    /// Report a list of command line extensions to be handled by this plugin
    /// NOTE: hyphens must be included in the extension string
    virtual QStringList getCommandLineOptions() = 0;

    /// Function to handle a command and the corresponding argument
    virtual void handleArguments(QStringList arguments) = 0;

    /// Function to parse command line arguments.
    static QString argByKey(QString key, QChar sep, QStringList arguments = qApp->arguments()) {
        bool sepd = sep != QChar('\0');
        int pos = sepd ? arguments.indexOf(QRegExp('^'+key+sep+"\\S*")) :
                  arguments.indexOf(QRegExp(key));
        return pos == -1 ? QString::null :
               (sepd ? arguments.at(pos).split(sep).at(1) :
                (++pos<arguments.size( ) ?
                 arguments.at(pos) : QString::null));
    }
};

Q_DECLARE_INTERFACE(ICommandLinePlugin, "mil.army.arl.lee.ICommandLinePlugin/1.0")

#endif // ICOMMANDLINEPLUGIN_H
