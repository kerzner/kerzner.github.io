﻿#include "ApplicationView.h"
#include "ApplicationDocument.h"

#include <QMenu>
#include <QToolBar>

ApplicationView::ApplicationView(QWidget *parent) :
    QWidget(parent)
    ,m_appDoc(0)
    ,m_toolbar(0)
{
    /*no-op*/
}

ApplicationView::~ApplicationView()
{
    // Detach this view from its document
    if (m_appDoc) m_appDoc->detachView(this);

    // Delete menus
    foreach (QMenu* menu, m_menus) delete menu;

    // Delete the toolbar
    delete m_toolbar;
}

ApplicationDocument *ApplicationView::getCurrentDocument()
{
    return m_appDoc;
}

QList<QMenu*> ApplicationView::getMenus()
{
    if (m_menus.empty()) buildMenus();
    return m_menus;
}

QToolBar *ApplicationView::getToolBar()
{
    if (!m_toolbar) buildToolBar();
    return m_toolbar;
}

QList<QDockWidget *> ApplicationView::getDockWidgets()
{
    if (m_dockWidgets.empty()) buildDockWidgets();
    return m_dockWidgets;
}

void ApplicationView::setSubElementVisibility(bool isVisible)
{
    // Set the toolbar visibility
    if (m_toolbar) m_toolbar->setVisible(isVisible);

    // Set menu visibility
    foreach (QMenu *menu, m_menus) menu->menuAction()->setVisible(isVisible);
}

bool ApplicationView::isConnectedToDoc(ApplicationDocument *doc)
{
    return doc == getCurrentDocument();
}

QList<QMenu*> ApplicationView::createMenus()
{
    // Return an empty list --> to be populated by a subclasses's createMenus()
    return QList<QMenu*>();
}

QToolBar *ApplicationView::createToolBar()
{
    // Return NULL --> to be populated by a subclasses's createToolBar()
    return NULL;
}

QList<QDockWidget *> ApplicationView::createDockWidgets()
{
    // Return NULL --> to be populated by a subclasses's createDockWidgets()
    return QList<QDockWidget *>();
}

void ApplicationView::connectToDocument(ApplicationDocument *doc)
{
    connect(doc, SIGNAL(fileImportCompleted()),
            this, SLOT(fileImportCompleted()));
    connect(doc, SIGNAL(fileImportFailed()), this, SLOT(fileImportFailed()));
    connect(doc, SIGNAL(fileSaveCompleted()), this, SLOT(fileSaveCompleted()));
    connect(doc, SIGNAL(fileSaveFailed()), this, SLOT(fileSaveFailed()));
    connect(doc, SIGNAL(fileNameWillChange(QString,QString)),
            this, SLOT(fileNameWillChange(QString,QString)));
    connect(doc, SIGNAL(documentClosing()), this, SLOT(documentClosing()));
    attachDocument(doc);
}

void ApplicationView::fileImportCompleted()
{
    /*no-op*/
}

void ApplicationView::fileImportFailed()
{
    /*no-op*/
}

void ApplicationView::fileSaveCompleted()
{
    /*no-op*/
}

void ApplicationView::fileSaveFailed()
{
    /*no-op*/
}

void ApplicationView::fileNameWillChange(const QString &oldFileName,
        const QString &newFileName)
{
    /*no-op*/
}

void ApplicationView::documentClosing()
{
    /*no-op*/
}

void ApplicationView::buildMenus()
{
    QList<QMenu*> menus = createMenus();
    if (!menus.empty()) m_menus = menus;
}

void ApplicationView::buildToolBar()
{
    QToolBar *toolbar = createToolBar();
    if (toolbar) m_toolbar = toolbar;
}

void ApplicationView::buildDockWidgets()
{
    QList<QDockWidget *> dockWidgets = createDockWidgets();
    if (!dockWidgets.empty()) m_dockWidgets = dockWidgets;
}
