#include "ApplicationDocument.h"

ApplicationDocument::ApplicationDocument(QObject *parent) :
    QObject(parent),
    m_viewReferences(0)
{
    /*no-op*/
}

ApplicationDocument::~ApplicationDocument()
{
    emit documentClosing();
}

QString ApplicationDocument::getCurrentOpenFileName() const
{
    return m_fileName;
}

void ApplicationDocument::newDocumentExists(ApplicationDocument *doc)
{
    /*no-op*/
}

void ApplicationDocument::detachView(ApplicationView */*view*/)
{
    --m_viewReferences;
}

void ApplicationDocument::attachView(ApplicationView */*view*/)
{
    m_viewReferences++;
}
