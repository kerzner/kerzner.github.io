#include "SanitizedFileName.h"

#include <QRegExp>

QString sanitizedFileName(const QString &name)
{
    QString clean = name;
    return clean.replace(QRegExp("[^A-Za-z0-9]"), QString("_"));
}
