#ifndef IVIEWPLUGIN_H
#define IVIEWPLUGIN_H

#include <QtPlugin>
#include <QString>
class ApplicationView;


/**
 * The interface for Document Plugins.
 *
 * This is the API that any Document model plugins must provide
 */
class IViewPlugin
{
public:
    virtual ~IViewPlugin() { }

    /// get the category of view (eg. "3D" or "Tree" )
    /// this is also the name of view type
    virtual QStringList getViewNames() = 0;

    /// get the type of application model we know how to display
    virtual QStringList dataModelTypesSupported(const QString name) = 0;

    virtual ApplicationView * genView(const QString name) = 0;

    /// Returns a human-readable name of the plugin.
    /// This should be indicative of the function(s) provided.
    virtual QString getPluginName() = 0;

};

Q_DECLARE_INTERFACE(IViewPlugin, "mil.army.arl.lee.IViewPlugin/1.0")

#endif // PLUGININTERFACE_H
