#ifndef IDOCUMENT_H
#define IDOCUMENT_H

#include <QString>

/**
 * This is the interface all Document models implement,
 *
 * These are created by an IDocumentFactory for each instance of a file that the
 * application opens.
 *
 */
class IDocument
{
public:
    /// Allow IDocument pointers to correctly be destroyed by 'delete'
    virtual ~IDocument() = 0;

    virtual bool importFileByName(const QString &fileName) = 0;

    /// Return a human-readable string of the document type.
    virtual QString getDocumentType() = 0;
};

#endif // IDOCUMENT_H
