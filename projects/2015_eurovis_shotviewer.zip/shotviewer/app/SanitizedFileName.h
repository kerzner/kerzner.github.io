#ifndef SANITIZEDFILENAME_H
#define SANITIZEDFILENAME_H

#include <QString>
QString sanitizedFileName(const QString &name);

#endif // SANITIZEDFILENAME_H
