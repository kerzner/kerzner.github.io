#ifndef IDOCPLUGIN_H
#define IDOCPLUGIN_H

#include <QtPlugin>
#include <QString>
#include <QStringList>
#include "ApplicationDocument.h"

/**
 * The interface for Document Plugins.
 *
 * This is the API that any Document model plugins must provide
 */
class IDocPlugin
{
public:
    virtual ~IDocPlugin() { }

    /// return a list of filename extensions the plugin can load
    virtual QStringList getFilenameExtensions() = 0;

    /// get the category of document (eg. "Text" or "Sysdef" or "Geometry"
    /// This must also be the name of the type of application model that is created
    virtual QString getDocumentCategory() = 0;

    /// generate a document of the type this plugin supports
    virtual ApplicationDocument * createDocument() = 0;

    /// Returns a human-readable name of the plugin.
    /// This should be indicative of the function(s) provided.
    virtual QString getPluginName() = 0;

    virtual QStringList defaultViews() = 0;
};

Q_DECLARE_INTERFACE(IDocPlugin, "mil.army.arl.lee.IDocPlugin/1.0")

#endif // PLUGININTERFACE_H
