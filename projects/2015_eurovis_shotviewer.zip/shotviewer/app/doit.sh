#!/bin/sh

moc ApplicationDocument.h > moc_ApplicationDocument.cpp
moc ApplicationView.h > moc_ApplicationView.cpp
moc MainWindow.h > moc_MainWindow.cpp
moc RecentFiles.h > moc_RecentFiles.cpp
moc Macro/AppInputRecorder.h > Macro/moc_AppInputRecorder.cpp
moc Macro/AppInputRecorderDialog.h > Macro/moc_AppInputRecorderDialog.cpp

uic Macro/AppInputRecorderDialog.ui > Macro/ui_AppInputRecorderDialog.h
uic MainWindow.ui > ui_MainWindow.h

g++ -I. -IMacro -DCMAKE_BUILD_USER=\"butler\" \
    -DCMAKE_HOSTNAME=\"m6600\" \
-I/usr/include/qt5 \
-I/usr/include/qt5/Qt \
-I/usr/include/qt5/QtCore \
-I/usr/include/qt5/QtGui \
-I/usr/include/qt5/QtOpenGL \
-I/usr/include/qt5/QtScript \
-I/usr/include/qt5/QtScriptTools \
-I/usr/include/qt5/QtUiTools \
-I/usr/include/qt5/QtWidgets \
    -o appCore -fPIC\
    ApplicationDocument.cpp moc_ApplicationDocument.cpp \
    ApplicationView.cpp moc_ApplicationView.cpp \
    main.cpp \
    MainWindow.cpp moc_MainWindow.cpp \
    RecentFiles.cpp moc_RecentFiles.cpp \
    SanitizedFileName.cpp \
    Macro/AppInputRecorder.cpp \
    Macro/AppInputRecorderDialog.cpp \
    Macro/EventSerialization.cpp \
    Macro/moc_AppInputRecorder.cpp \
    Macro/moc_AppInputRecorderDialog.cpp \
    -lQt5Core -lQt5Gui -lQt5Widgets -lQt5OpenGL -lQt5Script -lQt5ScriptTools
