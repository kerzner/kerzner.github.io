#ifndef APPLICATIONVIEW_H
#define APPLICATIONVIEW_H

#include "AppCore_global.h"

#include <QWidget>
#include <QList>

class ApplicationDocument;
class QMenu;
class QToolBar;
class QDockWidget;

class APPCORESHARED_EXPORT ApplicationView : public QWidget
{
    Q_OBJECT

public:

    /// Constructor
    ApplicationView(QWidget *parent = NULL);

    /// Virtual destructor
    virtual ~ApplicationView();

    /// Accessor to this view's ApplicationDocument
    /// NOTE: NULL if not successfully attached
    ApplicationDocument *getCurrentDocument();

    /// Accessor to get the menus for this view
    QList<QMenu*> getMenus();

    /// Accessor to get the toolbar for this view
    QToolBar *getToolBar();

    /// Accessor to get any docwidgets for this view
    QList<QDockWidget *> getDockWidgets();

    /// Make this view's menus and toolbar visible/hidden
    void setSubElementVisibility(bool isVisible = true);

    /// Return a string list of document types that this view needs
    virtual QStringList getRequiredDocTypes() = 0;

    /// Returns true if this is connected to doc.
    virtual bool isConnectedToDoc(ApplicationDocument *doc);

signals:

    /// Signal to tell whoever owns the view that this view wants to be closed
    void closeView();

protected:

    /// Create a list of menu instances for this particular ApplicationView
    /// NOTE: this is optional, returns NULL unless a subclass provides them
    ///
    /// NOTE: should be overridden as 'private' in subclasses
    virtual QList<QMenu*> createMenus();

    /// Create an instance of this particular ApplicationView's toolbar
    /// NOTE: this is optional, returns NULL unless a subclass provides it
    ///
    /// NOTE: should be overridden as 'private' in subclasses
    virtual QToolBar *createToolBar();

    /// Create a list of dockwidget instances for this particular
    /// ApplicationView.
    /// NOTE: this is optional, returns NULL unless a subclass provides them
    ///
    /// NOTE: should be overridden as 'private' in subclasses
    virtual QList<QDockWidget*> createDockWidgets();

    /// Function to be called when this view is attached to a document
    ///
    /// NOTE: should be overridden as 'private' in subclasses
    virtual void attachDocument(ApplicationDocument *doc) = 0;

    /// Pointer to the document this view observes
    ///FIXME: this should be surrounded by construction routines similar to
    ///       menus and toolbars --> see 'TextApplicationView::attachDocument()'
    ApplicationDocument *m_appDoc;

    /// Function that MainWindow calls to start the document attach operation
    void connectToDocument(ApplicationDocument *doc);

    /// Function that MainWindow calls to start the view attach operation.
    virtual void connectToView(ApplicationView *view) { }

protected slots:

    /// These are connected to signals that ApplicationDocument produces
    ///
    /// NOTE: They are implemented as a no-op unless overridden in a child class
    virtual void fileImportCompleted();
    virtual void fileImportFailed();
    virtual void fileSaveCompleted();
    virtual void fileSaveFailed();
    virtual void fileNameWillChange(const QString &oldFileName,
                                    const QString &newFileName);
    virtual void documentClosing();

private:

    // Friend functions ///////////////////////////////////////////////////////

    /// Allows attachDocument() to be callable from the 'attach()' free function
    /// found in MainWindow's source h/cpp.
    friend void attach(ApplicationDocument* doc, ApplicationView* view);
    friend void attach(ApplicationView *view0, ApplicationView *view1);

    // Helper functions ///////////////////////////////////////////////////////

    /// Builds the menus on construction, calling the subclass's createMenus()
    /// function.  Sets the member m_menus after construction (so the subclass
    /// writer doesn't have to know to set m_menus)
    void buildMenus();

    /// Builds the toolbar on construction, calling the subclass's
    /// createToolBar() function. Sets the member m_toolbar after construction
    /// (so the subclass writer doesn't have to know to set m_meus)
    void buildToolBar();

    /// Builds the DockWidets on construction, calling the subclass's
    /// createMenus() function.  Sets the member m_dockWidgets after
    /// construction (so the subclass writer doesn't have to know to set m_meus)
    void buildDockWidgets();

    // Private data members ///////////////////////////////////////////////////

    /// Menus for this view (optionally populated)
    QList<QMenu*> m_menus;

    /// Toolbar for this view (NULL if not populated)
    QToolBar *m_toolbar;

    /// List of DockWidgets for this view (optionally populated)
    QList<QDockWidget *> m_dockWidgets;
};

#endif // APPLICATIONVIEW_H
