#ifndef IDOCUMENTFACTORY_H
#define IDOCUMENTFACTORY_H

#include "IDocument.h"
class MdiChild;

/**
 * This is the API that IDocument factories (which are a part of an IPlugin)
 * must implement so that the application knows what kind of files can be
 * opened/created and which object is responsible for doing so.  Classes derived
 * from this interfrace class construct the appropriate IDocument-derived
 * instance for each file the application opens.
 */
class IDocumentFactory
{
public:
    /// Allow IDocumentFactory pointers to correctly be destroyed by 'delete'
    virtual ~IDocumentFactory() = 0;

    /** Method to be implemented to return the file extension types the
     * DocumentFactory can handle.
     * This string is of a form suitable for handing to QFileDialog::getOpenFileName():
     *   "*.txt *.asc *.rtf *rtfd"
     */
    virtual QString fileExtensions() = 0;

    /**
     * @brief This provides a brief description of the file types supported
     * @return A title string for the class of documents that can be opened.
     * This is typically something like "Text files" or "Geometry" or "Sysdef"
     */
    virtual QString fileDescription() = 0;

    /** Method to be implemented as the factory for creating a document object
     * from a given input file.
     */
    virtual IDocument * createDocument() = 0;

    virtual MdiChild * createDocumentWindow(IDocument *iDocument) = 0;
};

#endif // IDOCUMENTFACTORY_H
