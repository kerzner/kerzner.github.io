#include "MainWindow.h"
#include <QFileInfo>

#include <QDateTime>
#include <stdio.h> // fwrite/fopen/fclose
#include <sys/file.h> // flock()
#include <errno.h> // EWOULDBLOCK
#include <unistd.h>

#if QT_VERSION > 0x050000
#include <QtWidgets/QApplication>
#else
#include <QtGui/QApplication>
#endif

bool showGui = true;

// Log usage of the application so that we can track usage statistics
void logUsage(QFileInfo &appFile)
{
    QString fileName = QString("%1%2.%3.log")
                       .arg(appFile.dir().absolutePath())
                       .arg(appFile.dir().separator())
                       .arg(appFile.fileName());
    QFileInfo logFileInfo(fileName);

    if (logFileInfo.exists()) {
        QString message = QString("%1%2\n")
                          .arg(QDateTime::currentDateTime().toString("yyyyMMddhhmmss"))
                          .arg(getuid());

        // Since Qt4 does not have a locked file class we have to do this in C
        FILE *fd = fopen(logFileInfo.absoluteFilePath().toStdString()
                         .c_str(),
                         "a");
        int count;
        int lockLimit = 2; // number of times to try to get the lock
        for (count = 0; count < lockLimit ; count++) {
            int result = flock(fileno(fd), LOCK_SH | LOCK_NB);
            if (result == EWOULDBLOCK) {
                // lock busy, try again
                sleep(1);
                continue;
            }

            // we either got the lock or we wont get the lock ever, so we
            // are done
            if (result != 0)
                count = lockLimit; // error so give up

            break;
        }
        if (count < lockLimit) {
            // we have the lock and did not time out
            fwrite(message.toStdString().c_str(), message.size(), 1, fd);
            flock(fileno(fd), LOCK_UN);
        }
        fclose(fd);
    }
}

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);

    QFileInfo appFile(QApplication::applicationFilePath());
    a.setApplicationName(appFile.fileName());
    a.setOrganizationName("US Army Research Laboratory");

    logUsage(appFile);

    MainWindow w;

    a.processEvents(); // get the UI up and displayed

    // Process command line arguments
    QStringList args = a.arguments();

    for (int i = 1; i < args.size(); i++) {

        QString s = args.at(i);

        if (!s.compare("-g")) {
            showGui = ! showGui;
        } else if (!s.compare("-f")) {
            w.fileLoad(args.at(i+1));
        } else if (s.startsWith("--ir=")) {
            QString name = s.split("=").last();
            w.fileLoad(name, name.endsWith(".ir") ? QString() : QString("ir"));
        } else if (s.startsWith("--sys")) {
            QString name = s.split("=").last();
            w.fileLoad(name, name.endsWith(".sysdef") ? QString() : QString("sysdef"));
        } else if (s.startsWith("--f=")
                   || s.startsWith("-f=")) {
            w.fileLoad(s.split("=").last());
        } else if (s.startsWith("--reg=")) {
            QString name = s.split("=").last();
            w.fileLoad(name, name.endsWith(".regmap") ? QString() : QString("regmap"));
        }
    }

    // Launch the user interface
    if (!showGui) {
        w.hide();
    }

    // start the event loop
    return a.exec();
}
