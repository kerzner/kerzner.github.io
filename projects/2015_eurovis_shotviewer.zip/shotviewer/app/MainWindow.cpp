#include "MainWindow.h"
#include "ui_MainWindow.h"

#include <QCloseEvent>
#include <QDir>
#include <QFileDialog>
#include <QFileInfo>
#include <QMessageBox>
#include <QPluginLoader>
#include <QSettings>
#include <QMenu>
#include <QToolBar>
#include <QMdiSubWindow>

#include "RecentFiles.h"

#include "ApplicationDocument.h"

#include "ApplicationView.h"

#include "ICommandLinePlugin.h"
#include "IDocPlugin.h"
#include "IViewPlugin.h"

#include "Macro/AppInputRecorderDialog.h"

#include "SanitizedFileName.h"
#include <QtScriptTools>
#include "Attach.h"
// MainWindow definitions /////////////////////////////////////////////////////

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
    , m_fileNewMenu(new QMenu(this))
    , m_recentFiles(this)
    , m_fileDialog(new QFileDialog(this))
    , m_appInputRecorderDialog(NULL)
{
    ui->setupUi(this);
    m_fileNewMenu->setObjectName("fileNewMenu");

    // make sure all MdiArea children (the widget that holds sub-windows
    // in particular) are given a name
    QObjectList kids = ui->mdiArea->children();
    int i = 1;
    foreach (QObject *child, kids) {
        if (child->objectName().isNull())
            child->setObjectName(QString("mswWindowParent%1").arg(i++));
    }

    // set up the preferences dockWidget
    ui->prefsDockWidget->setVisible(false);
    QAction *a = ui->prefsDockWidget->toggleViewAction();
    a->setText("Preferences");
    ui->menuPanels->addAction(a);

    // set up the open files dockWidget
    ui->openDocumentsDock->setVisible(false);
    a = ui->openDocumentsDock->toggleViewAction();
    a->setText("Open Doc List");
    ui->menuPanels->addAction(a);

    // set up open files right-click menu
    ui->openDocumentsList->setContextMenuPolicy(Qt::CustomContextMenu);
    connect(ui->openDocumentsList, SIGNAL(customContextMenuRequested(QPoint)),
            this, SLOT(showOpenDocContextMenu(QPoint)));

    // stich the preferences DockWidget to the recentFiles
    ui->maxRecentSpinBox->setMaximum(m_recentFiles.MaxRecentFiles);
    ui->maxRecentSpinBox->setValue(m_recentFiles.MaxRecentFiles);
    connect(ui->maxRecentSpinBox, SIGNAL(valueChanged(int)),
            &m_recentFiles, SLOT(setNumOfRecentFiles(int)));
    connect(&m_recentFiles, SIGNAL(newMaxFilesShown(int)),
            ui->maxRecentSpinBox, SLOT(setValue(int)));

    /*
     *Insert the recent files sub-menu into the file menu
     * and let the user open a file from the recent files list
     */
    m_recentFiles.setMenu(ui->menuFile, ui->actionFileSave);
    connect(&m_recentFiles, SIGNAL(openFile(QString)),
            this, SLOT(fileLoad(const QString)));

    // Load plugins, registering document types
    pluginsLoad();

    addFileNewMenu();

    // Read settings from user defined preferences
    settingsRead();

    // Setup window focus event
    connect(ui->mdiArea, SIGNAL(subWindowActivated(QMdiSubWindow*)),
            this, SLOT(activeWindowChanged(QMdiSubWindow*)));

    // Fire the focus event
    // XXX: why?
    activeWindowChanged();

    // Setup window configuration events from menu actions
    connect(ui->actionTile, SIGNAL(triggered()),
            ui->mdiArea, SLOT(tileSubWindows()));
    connect(ui->actionCascade, SIGNAL(triggered()),
            ui->mdiArea, SLOT(cascadeSubWindows()));
    connect(ui->actionFileClose, SIGNAL(triggered()),
            ui->mdiArea, SLOT(closeActiveSubWindow()));

    /// XXX Remove the "Open" action from the tool bar. Why is it there?
    ui->toolBar->setMinimumHeight(ui->toolBar->height());
    ui->toolBar->removeAction(ui->toolBar->actions().first());

    // Show the window as large as possible.
    // Need the repaint to force window geometry update.
    showMaximized();
    repaint();
}

MainWindow::~MainWindow()
{
#if 0
    while (m_plugins.size() > 0) {
        PluginInterface *pi = m_plugins.first();
        delete pi;
    }
#endif
    if (m_appInputRecorderDialog)
        m_appInputRecorderDialog->close();
    delete m_appInputRecorderDialog;
    delete m_fileDialog;
    delete ui;
}

QDir MainWindow::getApplicationDir()
{
    QDir applicationDir(qApp->applicationDirPath());

#if defined(Q_OS_WIN)
    if (applicationDir.dirName().toLower() == "debug" ||
        applicationDir.dirName().toLower() == "release"
#ifdef CMAKE_INTDIR
        || applicationDir.dirName() == CMAKE_INTDIR
#endif
       )
        applicationDir.cdUp();
#elif defined(Q_OS_MAC)
    if (applicationDir.dirName() == "MacOS") {
        applicationDir.cdUp();
        applicationDir.cdUp();
        applicationDir.cdUp();
    }
#endif

    return applicationDir;
}

#ifdef CMAKE_INTDIR
#define PLUGIN_DIR "plugins/" CMAKE_INTDIR
#else
#define PLUGIN_DIR "plugins"
#endif

void MainWindow::pluginsLoad()
{
    QDir pluginsDir = getApplicationDir();
    QList<IDocPlugin *> m_docPlugins;

    if ( ! pluginsDir.cd(PLUGIN_DIR) )
        if ( ! pluginsDir.cd("plugins") )
            return;

    foreach (QString fileName, pluginsDir.entryList(QDir::Files)) {
        // If it isn't a shared library, we don't need to try to load it.
        if (!fileName.startsWith("lib") && !fileName.endsWith("dll")) {
            continue;
        }

        // Only load dynamic libraries
        if (!(fileName.endsWith("so") || fileName.endsWith("dll") || fileName.endsWith("dylib"))) {
            continue;
        }

        // Try loading the plugin
        QPluginLoader loader(pluginsDir.absoluteFilePath(fileName));
        loader.load();
        QString error = loader.errorString();
        QObject *plugin = loader.instance();

        // Check if the plugin succeeded to load, if not, continue to the next
        if (!plugin) {
            fprintf(stderr,
                    "%s couldn't make QPluginLoader for %s:\n%s\n", qPrintable(qApp->applicationName()),
                    qPrintable(fileName), qPrintable(error));
            continue;
        }

        bool validPlugin = false;

        // Check to see if the plugin implements the command line interface
        if (ICommandLinePlugin *iclp =
                qobject_cast<ICommandLinePlugin*>(plugin)) {
            registerApplicationOptionHandler(iclp);
            iclp->handleArguments(qApp->arguments());
            validPlugin = true;
        }

        // Check to see if the plugin implements a document
        if (IDocPlugin *idp = qobject_cast<IDocPlugin *>(plugin)) {
            registerApplicationDocumentCreator(idp);
            validPlugin = true;
            m_docPlugins.append(idp);
        }

        // See if the plugin implements a view
        if (IViewPlugin *ivp = qobject_cast<IViewPlugin *>(plugin)) {
            registerApplicationViewCreator(ivp);
            validPlugin = true;
        }

        // Delete the plugin and inform the user if it does not implement either
        // document or view interface.
        if (!validPlugin) {
            delete plugin;
            fprintf(stderr,
                    "plugin <%s> not loaded\n%s\n",
                    qPrintable(pluginsDir.absoluteFilePath(fileName)),
                    qPrintable(error));
        }
    }

    // Construct the file filter from all our IDocPlugins
    QString fileFilter = "All (*.*)";

    foreach (IDocPlugin *dp, m_docPlugins) {
        fileFilter.append(QString(";;%1 (").arg(dp->getDocumentCategory()));
        foreach (QString ext, dp->getFilenameExtensions()) {
            fileFilter.append(QString("*.%1 ").arg(ext));
        }
        fileFilter.append(")");
    }

    qApp->setProperty("validFileExtensions", fileFilter);
}

void MainWindow::registerApplicationOptionHandler(ICommandLinePlugin *iclp)
{
    foreach (QString option, iclp->getCommandLineOptions())
    m_optionToPlugin.insertMulti(option, iclp);
}

void MainWindow::registerApplicationDocumentCreator(IDocPlugin *idp)
{
    foreach( QString ext, idp->getFilenameExtensions()) {
        m_fileNameExtensionToCreator.insertMulti(ext, idp);
    }

    m_stdViewsByNameForDocumentTypeName[idp->getDocumentCategory()]
    .append(idp->defaultViews());
}

void MainWindow::registerApplicationViewCreator(IViewPlugin *ivp)
{
    foreach (QString viewName, ivp->getViewNames()) {
        m_viewCreatorForName[viewName] = ivp;
        QStringList docTypes = ivp->dataModelTypesSupported(viewName);
        foreach (QString doc, docTypes) {
            m_availViewsByNameForDocumentTypeName[doc].append(viewName);
        }
    }
}

#if 0
void MainWindow::buildFileNewMenu()
{
    QMenu *newMenu = new QMenu("New ...", this);
    ui->menuFile->insertMenu(ui->actionFileOpen, newMenu);

    QList<QString> stringList;
    stringList.append("Text .txt");
    stringList.append("Geometry .osg");
    stringList.append("Script .js");

    QAction *act;
    QList<QAction *> actions;
    foreach (QString name, stringList) {
        QStringList tokens = name.split(" ");
        act = newMenu->addAction(tokens.at(0));
        act->setObjectName(QString("actionNew%1").arg(tokens.at(0)));
        act->setProperty("extension", QVariant(tokens.at(1)));
        connect(act, SIGNAL(triggered()), this, SLOT(createNew()));
    }
}
#endif

void MainWindow::on_actionFileSave_triggered()
{
    ApplicationView *view = getCurrentView();

    if(view)
        view->getCurrentDocument()->saveFile();
}

void MainWindow::on_actionFileSaveAs_triggered()
{
    ApplicationView *view = getCurrentView();

    if(view) {
        QString fileName = QFileDialog::getSaveFileName(this, "Save File As");

        if(fileName.size() > 0)
            view->getCurrentDocument()->saveFileByName(fileName);
    }
}

QStringList MainWindow::getOpenFileNames(const QString &caption,
        const QString &dir,
        const QString &filter,
        const bool &openFileAs)
{
    QStringList fileList;
    m_fileDialog->setAcceptMode(QFileDialog::AcceptOpen);
    m_fileDialog->setFileMode(QFileDialog::ExistingFiles);
    m_fileDialog->setDirectory(dir);
    // m_fileDialog->setFilter(filter);
    m_fileDialog->setWindowTitle(caption);

    if(m_fileDialog->exec()) {
        fileList = m_fileDialog->selectedFiles();
    }

    return fileList;
}

QString MainWindow::getSaveFileName(const QString &caption, // not used
                                    const QString &dir,
                                    const QString &filter)
{
    QString fileName;
    m_fileDialog->setAcceptMode(QFileDialog::AcceptSave);
    m_fileDialog->setFileMode(QFileDialog::AnyFile);
    m_fileDialog->setDirectory(dir);
    // m_fileDialog->setFilter(filter);
    m_fileDialog->setWindowTitle(caption);
    if (m_fileDialog->exec())
        fileName = m_fileDialog->selectedFiles().at(0);

    return fileName;
}

void MainWindow::on_actionFileOpen_triggered()
{
    QString currentDirectory = qApp->property("currentDirectory").toString();
    QString fileExtensions   = qApp->property("validFileExtensions").toString();

    // get a filename
    QStringList fileNames =
        getOpenFileNames("Select files to open",
                         currentDirectory,
                         fileExtensions);

    foreach (QString name, fileNames) {
        fileLoad(name);
    }
}

void MainWindow::on_actionFileOpenAs_triggered()
{
    QString currentDirectory = qApp->property("currentDirectory").toString();

    QStringList fileList;
    m_fileDialog->setAcceptMode(QFileDialog::AcceptOpen);
    m_fileDialog->setFileMode(QFileDialog::ExistingFiles);
    m_fileDialog->setDirectory(currentDirectory);
    // m_fileDialog->setFilter(filter);
    m_fileDialog->setWindowTitle("Select file to open as");


    // Add the combo box for selecting file type.
    QGridLayout *layout = (QGridLayout*) m_fileDialog->layout();
    QLabel extensionLabel("Open file as:");
    QComboBox extensionComboBox;

    // Select from all possible extensions.
    extensionComboBox.addItems(m_fileNameExtensionToCreator.keys());

    // Positions correspond to the last entries of the dialog's layout.
    layout->addWidget(&extensionLabel, 4, 0);
    layout->addWidget(&extensionComboBox, 4, 1);

    if (m_fileDialog->exec()) {
        fileList = m_fileDialog->selectedFiles();
    }

    // Clean up the dialog's layout.
    layout->removeWidget(&extensionComboBox);
    layout->removeWidget(&extensionLabel);

    // Append the correct file extension, if there isn't already one.
    QString currentExtension = extensionComboBox.currentText();
    foreach (QString fileName, fileList) {
        if (!fileName.endsWith(currentExtension)) {
            fileLoad(fileName, currentExtension);
        } else {
            fileLoad(fileName);
        }
    }
}

void MainWindow::addFileNewMenu()
{
    QAction *newByTypeMenuAction =
        ui->menuFile->insertMenu(ui->actionFileOpen, m_fileNewMenu);
    newByTypeMenuAction->setText("New...");

    QList<IDocPlugin *>handled; // handle each IDocPlugin only once
    QStringList keys = m_fileNameExtensionToCreator.keys();
    foreach(QString key, keys) {
        QList<IDocPlugin *> idpList = m_fileNameExtensionToCreator.values();
        foreach (IDocPlugin *idp, idpList) {
            if (handled.contains(idp))
                continue;
            handled.append(idp);

            QAction * a = m_fileNewMenu->addAction( QString("%1 %2")
                                                    .arg(idp->getPluginName())
                                                    .arg(idp->getDocumentCategory()) );

            connect(a, SIGNAL(triggered()), this, SLOT(createNewFileFromMenu()));
            a->setProperty("idp", VariantPtr<IDocPlugin>::asQVariant(idp) );
        }
    }
}

void MainWindow::closeEvent(QCloseEvent *event)
{
    foreach (QMdiSubWindow *msw, ui->mdiArea->subWindowList()) {
        msw->removeEventFilter(this);
    }

    ui->mdiArea->closeAllSubWindows();
    if (ui->mdiArea->currentSubWindow()) {
        event->ignore();
    } else {
        settingsWrite();
        if (m_appInputRecorderDialog) {
            m_appInputRecorderDialog->close();
        }
        event->accept();
    }
}

void MainWindow::createNewFileFromMenu()
{
    QAction *a = qobject_cast<QAction *>(sender());

    QVariant v = a->property("idp");

    if (v.isNull() || !v.isValid())
        return;

    IDocPlugin *idp = VariantPtr<IDocPlugin>::asPtr(v);

    createNewDocument(idp);
}

void MainWindow::documentImportCompleted()
{
    // XXX check the document to see if it should change its name
}

ApplicationDocument *MainWindow::createNewDocument(IDocPlugin *idp)
{
    ApplicationDocument *doc = idp->createDocument();

    // Abort if the document comes back NULL
    if (!doc) abort();

    // create the standard views for this data model
    foreach (QString viewName,
             m_stdViewsByNameForDocumentTypeName[doc->getDocumentType()]) {
        createAndAddView(doc, viewName);
    }

    // Add the filename to the 'Open Doc List' dockwidget
    OpenFileWidgetItem *item = new OpenFileWidgetItem("untitled", doc);
    ui->openDocumentsList->addItem(item);

    connect(doc, SIGNAL(fileNameWillChange(QString,QString)),
            this, SLOT(documentNameChanging(QString,QString)));

    connect(doc, SIGNAL(fileImportCompleted()),
            this, SLOT(documentImportCompleted()));

    // Connect main window to the document's closing signal (when it is deleted)
    connect(doc, SIGNAL(closeDocument()), this, SLOT(closeDocument()));
    connect(doc, SIGNAL(documentClosing()), this, SLOT(documentIsClosing()));

    // Declare that a new document exists
    emit newDocument(doc);

    // Process all events to make sure the previous 'emit newDocument(doc)'
    // propagates before we connect that signal to the newly created document.
    qApp->processEvents();

    // Connect main window's new document notification signal so the document
    // can be aware of other new documents.
    connect(this, SIGNAL(newDocument(ApplicationDocument*)),
            doc, SLOT(newDocumentExists(ApplicationDocument*)));

    // For each of the open documents, let the newly created document (doc)
    // become aware of them.
    foreach (ApplicationDocument *openDoc, m_openListeners)
    doc->newDocumentExists(openDoc);

    // Add the new document to the list of open documents
    m_openListeners.append(doc);

    return doc;
}

void MainWindow::fileLoad(const QString fileName, const QString fileType)
{

    QString extension;
    if (fileType.isEmpty()) {
        extension = QFileInfo(fileName).suffix();
    } else {
        extension = fileType;
    }

    QList<ApplicationDocument *> openDocs = getOpenDocuments();
    foreach (ApplicationDocument *doc, openDocs) {
        if (!doc->getDocumentType().compare(extension, Qt::CaseInsensitive)) {
            QMessageBox box;
            box.setText("You tried to open:\n" + fileName + "\n but I can only open "
                        "one of each type of file at a time. \nYou need to close:\n"
                        + doc->getCurrentOpenFileName() + "\nbefore I can open the file"
                        " you asked for.");
            box.exec();
            return;
        }
    }

    if (!m_fileNameExtensionToCreator.contains(extension)) {
        if(!extension.isEmpty())
            qDebug("No plugin for extention: %s", qPrintable(extension));
        return;
    }

    // Create the data model for the file and open the file
    QList<IDocPlugin *> idps = m_fileNameExtensionToCreator.values(extension);

    // XXX if there is more than one entry in idps we need to ask the user which
    // document type they want.

    ApplicationDocument *doc = NULL;

    // Add the new document to the list of open documents
    m_openListeners.append(doc);
    QFile file(fileName);
    if (file.exists()) {
        doc = idps[0]->createDocument();
        doc->importFileByName(fileName);
    } else {
        QMessageBox box;
        box.setText("I could not find file:" + fileName);
        box.exec();
        return;
    }

    // Tell all other views that we have a new document. Try connecting them.
    foreach (QMdiSubWindow *msw, ui->mdiArea->subWindowList()) {
        ApplicationView *view = dynamic_cast<ApplicationView*>(msw->widget());
        if (view) {
            attach(doc, view);
        }
    }

    // create the standard views for this data model
    foreach (QString viewName,
             m_stdViewsByNameForDocumentTypeName[doc->getDocumentType()]) {
        createAndAddView(doc, viewName);
    }

    // update the last directory visited in settings
    m_recentFiles.setMostRecentFile(fileName);
    QDir dir(fileName);
    QString name = dir.path();
    QString dirPath = name.left(name.lastIndexOf(QDir::separator()));

    qApp->setProperty("currentDirectory", QVariant(dirPath));
    settingsWrite();

    // Add the filename to the 'Open Doc List' dockwidget
    QString shortFileName = fileName.split("/").last();
    OpenFileWidgetItem *item = new OpenFileWidgetItem(shortFileName, doc);
    item->setToolTip(fileName);
    ui->openDocumentsList->addItem(item);

    // Connect main window to the document's closing signal (when it is deleted)
    connect(doc, SIGNAL(closeDocument()), this, SLOT(closeDocument()));
    connect(doc, SIGNAL(documentClosing()), this, SLOT(documentIsClosing()));

    // Attempt to create a smart layout for opening sysdef or ir files.
    if ((!extension.compare("ir", Qt::CaseInsensitive))
        || (!extension.compare("sysdef", Qt::CaseInsensitive))) {
        on_actionShotviewer_triggered();
    }
}

void MainWindow::settingsRead()
{
    QSettings settings(qApp->organizationName(), qApp->applicationName());
    qApp->setProperty("currentDirectory",
                      settings.value("currentDreictory",
                                     QVariant(QString("%1").arg(getenv("CWD"))))
                     );
    m_recentFiles.setNumOfRecentFiles(
        settings.value("numOfRecentFiles", 4).toInt());
    m_recentFiles.setRecentFilesList(settings
                                     .value("recentFiles")
                                     .toStringList());
}

void MainWindow::settingsWrite()
{
    QSettings settings(qApp->organizationName(), qApp->applicationName());

    settings.setValue("recentFiles", m_recentFiles.getRecentFiles());
    settings.setValue("numOfRecentFiles", m_recentFiles.getRecentFileCount());
    settings.setValue("currentDirectory", qApp->property("currentDirectory"));
}

void MainWindow::on_actionAbout_triggered()
{
    QDir d = getApplicationDir();

    QString text = QString("%1\n%2\n%3\n%4\n")
                   .arg(qApp->applicationName())
                   .arg(qApp->organizationName())
                   .arg(d.absolutePath())
                   .arg("\nBuild: " __DATE__ " " __TIME__
                        "\nby " CMAKE_BUILD_USER " on " CMAKE_HOSTNAME);

    //            .arg((char*)glGetString(GL_VERSION))
    //            .arg((char*)glGetString(GL_RENDERER))

    QMessageBox::about(this,
                       QString("About %1").arg(qApp->applicationName()),
                       text);
}

#include "Macro/AppInputRecorderDialog.h"
void MainWindow::on_actionMacro_triggered()
{
    if (! m_appInputRecorderDialog) {
        m_appInputRecorderDialog = new AppInputRecorderDialog(NULL);
        m_appInputRecorderDialog->setObjectToRecord(this);
    }
    m_appInputRecorderDialog->show();
}

void MainWindow::activeWindowChanged(QMdiSubWindow *msw )
{
    bool hasWin = (msw != NULL);
    ui->actionFileSave->setEnabled(hasWin);
    ui->actionFileSaveAs->setEnabled(hasWin);
    ui->actionFileClose->setEnabled(hasWin);
    if (!hasWin)
        return;

    ApplicationView *view = dynamic_cast<ApplicationView*>(msw->widget());

    if (view) {
        view->setSubElementVisibility(true);
    } else {
        ui->actionFileSave->setEnabled(false);
        ui->actionFileSaveAs->setEnabled(false);
    }
}

void MainWindow::switchWindowState(Qt::WindowStates /* prev */,
                                   Qt::WindowStates next)
{
    QMdiSubWindow *win = dynamic_cast<QMdiSubWindow *>(sender());
    if (!win)
        return;

    ApplicationView *view = dynamic_cast<ApplicationView *>(win->widget());
    if (!view)
        return;

    if ( (next & Qt::WindowActive) ) {
        // going active
        view->setSubElementVisibility(true);
    } else if ( !(next & Qt::WindowActive) ) {
        // going inactive
        view->setSubElementVisibility(false);
    }
}

void MainWindow::closeDocument()
{
    // Make sure that the sender is indeed an ApplicationDocument
    ApplicationDocument* doc = dynamic_cast<ApplicationDocument*>(sender());
    if(doc) {
        delete doc;
        m_openListeners.removeOne(doc);
    }
}

void MainWindow::documentNameChanging(QString oldName, QString newName)
{
    // Make sure that the sender is indeed an ApplicationDocument
    ApplicationDocument* doc = dynamic_cast<ApplicationDocument*>(sender());

    if(doc) {
        // We have a document! Now change the filename in the Open Docs Widget
        for(int i = 0; i < ui->openDocumentsList->count(); ++i) {
            OpenFileWidgetItem *item = (OpenFileWidgetItem *)ui->openDocumentsList->item(i);
            if(item->doc() == doc) {
                item->setText(newName);
                return;
            }
        }
    }
}

void MainWindow::documentIsClosing()
{
    // Make sure that the sender is indeed an ApplicationDocument
    ApplicationDocument* doc = dynamic_cast<ApplicationDocument*>(sender());

    if(doc) {
        typedef OpenFileWidgetItem OFWI;

        // We have a document! Now remove the filename from the Open Docs Widget
        for(int i = 0; i < ui->openDocumentsList->count(); ++i) {
            OFWI *item = (OFWI*)ui->openDocumentsList->item(i);
            if (item->doc() == doc) {
                ui->openDocumentsList->takeItem(i);
            }
        }

        // Close all views connected to this document
        QList<QMdiSubWindow*> windows = ui->mdiArea->subWindowList();
        for (int i = 0; i < windows.size(); ++i) {
            ApplicationView* v =
                dynamic_cast<ApplicationView*>(windows[i]->widget());
            if(v->isConnectedToDoc(doc)) {
                windows[i]->close();
            }
        }
    }
}

void MainWindow::closeDocumentFromOpenDocList()
{
    // Close the selected item in the open docs list
    QList<QListWidgetItem*> selected = ui->openDocumentsList->selectedItems();

    // Remove the item from the list of open documents
    for (uint i = 0; i < selected.size(); ++i) {
        for (uint j = 0; j < ui->openDocumentsList->count(); ++j) {
            if (ui->openDocumentsList->item(j) == selected[i]) {
                delete ui->openDocumentsList->takeItem(j);
                return;
            }
        }
    }
}

void MainWindow::showOpenDocContextMenu(QPoint p)
{
    QMenu *m = new QMenu(this);
    QAction *a;

    // Cast to the underlying file widget item
    ApplicationDocument *doc = getSelectedDocumentFromOpenList();

    // User may have right clicked without selecting anything.
    if (!doc) {
        return;
    }

    QString docType = doc->getDocumentType();

    // Add a menu item for each view type
    foreach (QString text, m_availViewsByNameForDocumentTypeName[docType]) {
        a = new QAction(text, ui->openDocumentsList);
        connect(a, SIGNAL(triggered()),
                this, SLOT(handleCreateViewFromOpenDoc()));
        m->addAction(a);
    }

    m->addSeparator();

    a = new QAction(tr("Close"), ui->openDocumentsList);
    connect(a, SIGNAL(triggered()), this, SLOT(closeDocumentFromOpenDocList()));
    m->addAction(a);

    m->popup(ui->openDocumentsList->viewport()->mapToGlobal(p));
}

void MainWindow::handleCreateViewFromOpenDoc()
{
    // Make sure that the sender is indeed an ApplicationDocument
    QAction* a = dynamic_cast<QAction*>(sender());

    if (a) createAndAddView(getSelectedDocumentFromOpenList(), a->text());
}

void MainWindow::on_actionTileVertically_triggered()
{
    QList<QMdiSubWindow*> subwindowlist = ui->mdiArea->subWindowList();
    if (subwindowlist.count() < 2) {
        ui->mdiArea->tileSubWindows();
        return;
    }

    // Get the height of the title bar in the QMdiArea to adjust the vertical
    // scaling for each window
    QStyleOptionTitleBar options;
    options.initFrom(subwindowlist[0]);
    int titleBarHeight = subwindowlist[0]
                         ->style()
                         ->pixelMetric(QStyle::PM_TitleBarHeight, &options, subwindowlist[0]);

    int nWins = subwindowlist.count();
    int wHeight = (height() - (nWins*titleBarHeight)) / nWins;
    int y = 0;

    foreach (QMdiSubWindow *pSubWindow, subwindowlist) {
        pSubWindow->resize(width(), wHeight);
        pSubWindow->move(0 , y);
        y += wHeight;
    }
}

void MainWindow::on_actionTileHorizontally_triggered()
{
    QList<QMdiSubWindow*> subwindowlist = ui->mdiArea->subWindowList();
    if (subwindowlist.count() < 2) {
        ui->mdiArea->tileSubWindows();
        return ;
    }
    int wWidth = width() / subwindowlist.count();
    int x = 0;
    foreach (QMdiSubWindow *pSubWindow, subwindowlist) {
        pSubWindow->resize (wWidth, height());
        pSubWindow->move (x , 0);
        x += wWidth;
    }
}

void MainWindow::on_actionShotviewer_triggered()
{
    QList<QMdiSubWindow*> subwindowlist = ui->mdiArea->subWindowList();
    if (subwindowlist.count() == 4) {
        foreach (QMdiSubWindow *msw, subwindowlist) {
            QRect mdiArea = ui->mdiArea->rect();
            QRect winArea;
            qreal tableHeight  = mdiArea.height() * 1.0f / 3.0f;
            qreal spatialWidth = mdiArea.width() * 2.0f / 3.0f;
            qreal spatialHeight = mdiArea.height() * 1.0f / 4.0f;
            qreal linePlotWidth = mdiArea.width() * 1.0f / 3.0f;
            qreal sysdefHeight = mdiArea.height() * 5.0f / 12.0f;
            if (msw->windowTitle().contains("Table")) {
                winArea = QRect(mdiArea.x(), mdiArea.y(), mdiArea.width(), tableHeight);
                msw->setGeometry(winArea);
            } else if (msw->windowTitle().contains("Spatial")) {
                winArea = QRect(mdiArea.x(), mdiArea.y() + tableHeight, spatialWidth, spatialHeight);
                msw->setGeometry(winArea);
            } else if (msw->windowTitle().contains("Lineplot")) {
                winArea = QRect(mdiArea.x() + spatialWidth, mdiArea.y() + tableHeight, linePlotWidth, spatialHeight);
                msw->setGeometry(winArea);
            } else if (msw->windowTitle().contains("SysDef")) {
                winArea = QRect(mdiArea.x(), mdiArea.y() + spatialHeight + tableHeight, mdiArea.width(), sysdefHeight);
                msw->setGeometry(winArea);
            }
        }
    } else if (subwindowlist.count() == 3) {
        on_actionTileVertically_triggered();
    }
}

ApplicationView *MainWindow::getCurrentView()
{
    return dynamic_cast<ApplicationView*>(ui
                                          ->mdiArea
                                          ->currentSubWindow()
                                          ->widget());
}

void MainWindow::insertControlsFromView(ApplicationView *view)
{
    // Add the menus to the menu bar
    QList<QMenu*> menus = view->getMenus();
    if (!menus.empty()) {
        QMenuBar *menuBar = this->menuBar();

        QMenu *windowsMenu = menuBar->findChild<QMenu*>(QString("menuWindows"));
        if (windowsMenu) {
            foreach (QMenu *m, menus) {
                menuBar->insertMenu(windowsMenu->menuAction(), m);
            }
        } else {
            qDebug("Where did the windows menu go?");
            return;
        }
    }

    // Insert the toolbar
    QToolBar *toolbar = view->getToolBar();
    if (toolbar) addToolBar(toolbar);
}

#include <QFileInfo>

QString sanitizedName(const QString &name)
{
    QString clean = name;
    QString sanitized = clean.replace(QRegExp("[^A-Za-z0-9]"), QString("_"));
    return sanitized;
}

void MainWindow::createAndAddView(ApplicationDocument *doc, QString viewName)
{
    // Do not allow more than one instance of a view to be created.
    foreach (QMdiSubWindow *msw, ui->mdiArea->subWindowList()) {
        if (msw->windowTitle().contains(viewName)) {
            msw->raise();
            return;
        }
    }

    if (m_viewCreatorForName.contains(viewName)) {
        // Create a new view
        ApplicationView *view = m_viewCreatorForName[viewName]
                                ->genView(viewName);

        // Couple the document and new view together
        attach(doc, view);

        // Couple the view with all other documents.
        QList<ApplicationDocument*> docs = getOpenDocuments();
        foreach (ApplicationDocument *document, docs) {
            attach(document, view);
        }

        // Insert its menus and toolbar
        insertControlsFromView(view);

        QWidget *w = dynamic_cast<QWidget *>(view);
        if (w) {
            QMdiSubWindow *msw = ui->mdiArea->addSubWindow(w);

            msw->setWindowTitle(w->windowTitle());

            QFileInfo fi(doc->getCurrentOpenFileName());
            msw->setObjectName(QString("%1_%2")
                               .arg(viewName)
                               .arg(sanitizedName(fi.fileName())));

            // Wire up the show/hide connection for menus/toolbar
            connect(msw,
                    SIGNAL(windowStateChanged(Qt::WindowStates,
                                              Qt::WindowStates)),
                    this,
                    SLOT(switchWindowState(Qt::WindowStates,
                                           Qt::WindowStates)));

            if(w->windowTitle().contains("regmap")) {
                msw->show();
                msw->setWindowState(Qt::WindowMinimized);
            } else {
                msw->show();
            }

            // Connect this view too all other views
            foreach (QMdiSubWindow *existingWindow, ui->mdiArea->subWindowList()) {
                ApplicationView *existingView = dynamic_cast<ApplicationView*>(existingWindow->widget());
                // Do not connect this view to itself
                if (existingView != view) {
                    attach(existingView, view);
                }
            }
        } else {
            // XXX Are you kidding me??????
            abort();
            ;
        }
    }
}

ApplicationDocument *MainWindow::getSelectedDocumentFromOpenList()
{
    // Get the list of selected items from the open docs list (always 1)
    QList<QListWidgetItem*> selected = ui->openDocumentsList->selectedItems();

    OpenFileWidgetItem *w = 0;
    for (uint i = 0; i < selected.size(); ++i) {
        for (uint j = 0; j < ui->openDocumentsList->count(); ++j) {
            if (ui->openDocumentsList->item(j) == selected[i]) {
                w = static_cast<OpenFileWidgetItem*>(ui
                                                     ->openDocumentsList
                                                     ->item(j));
                goto found;
            }
        }
    }

found:

    if (w) return w->doc();
    else return 0;
}

QList<ApplicationDocument *> MainWindow::getOpenDocuments()
{
    QList<ApplicationDocument*> docs;
    for(uint i = 0; i < ui->openDocumentsList->count(); i++) {
        OpenFileWidgetItem *widget = static_cast<OpenFileWidgetItem*>(ui->openDocumentsList->item(i));
        docs << widget->doc();
    }
    return docs;
}

QStringList MainWindow::getOpenDocumentsByType(const QString &docType)
{
    QStringList documentNames;
    QList<OpenFileWidgetItem*> docItems;

    for (int i = 0; i < ui->openDocumentsList->count(); ++i)
        docItems.append((OpenFileWidgetItem*)ui->openDocumentsList->item(i));

    foreach (OpenFileWidgetItem* docItem, docItems) {
        if (!docItem->doc()->getDocumentType().compare(docType)) {
            documentNames.append(docItem->text());
        }
    }

    return documentNames;
}

AppInputRecorderDialog *MainWindow::getOrCreateEventRecorder()
{
    if (! m_appInputRecorderDialog) {
        m_appInputRecorderDialog = new AppInputRecorderDialog(NULL);
        m_appInputRecorderDialog->setObjectToRecord(this);
    }
    return m_appInputRecorderDialog;
}

// OpenFileWidgetItem definitions /////////////////////////////////////////////

int MainWindow::OpenFileWidgetItem::type = 1001;

/// Custom class to hold both the file name text (in QListWidgetItem) and
/// the pointer to the corresponding ApplicationDocument.
class OpenFileWidgetItem : public QListWidgetItem
{

public:

    /// Qt usertype (see QListWidgetItem documentation for subclassing)
    static int type;

    ~OpenFileWidgetItem();

    /// Constructor
    OpenFileWidgetItem(const QString& label, ApplicationDocument* doc);

    /// Accessor for this item's document
    ApplicationDocument *doc();
public slots:
    void changingFileName(QString, QString);
private:

    ApplicationDocument* m_document;
};

MainWindow::OpenFileWidgetItem::~OpenFileWidgetItem()
{
    delete m_document;
}

MainWindow::OpenFileWidgetItem::OpenFileWidgetItem(const QString& label,
        ApplicationDocument *doc) :
    QListWidgetItem(label, 0, this->type),
    m_document(doc)
{
    /*no-op*/
}

ApplicationDocument *MainWindow::OpenFileWidgetItem::doc()
{
    return m_document;
}

