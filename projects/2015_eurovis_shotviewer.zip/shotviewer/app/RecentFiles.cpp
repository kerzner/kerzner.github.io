#include "RecentFiles.h"
#include <QMenu>
#include <QAction>
#include <QFileInfo>
#include <QFile>
#include <QString>
#include <QStringList>

#include "SanitizedFileName.h"

RecentFiles::RecentFiles(QMainWindow *parent)
    : QObject(parent)
    , m_recentMenu(new QMenu(parent))
    , m_recentMenuTriggeredAction(NULL)
    , m_numOfRecentFiles(MaxRecentFiles)
{
    // create the sub-menu
    m_recentMenu->setTitle("Open Recent...");
    m_recentMenu->setObjectName("RecentMenu");

    // create an action for all possible entries in the sub-menu
    for (int i=0 ; i < MaxRecentFiles; i++) {
        m_recentFileActions[i] = new QAction(m_recentMenu);
        m_recentFileActions[i]->setText("---");
        m_recentFileActions[i]->setVisible(false);
        connect(m_recentFileActions[i], SIGNAL(triggered()),
                this, SLOT(openRecentFile()));
        m_recentMenu->addAction(m_recentFileActions[i]);
    }
}
RecentFiles::~RecentFiles()
{
    // delete m_recentMenu; // might be bad because parent menu will delete.
    m_recentMenu = NULL;
}

void RecentFiles::setMenu(QMenu *menu,         /* menu that "Recent" sub-menu should be inserted into */
                          QAction *before)     /* Action in menu before which Recent menu should be inserted */
{
    // insert the sub-menu in the menu
    m_recentMenuTriggeredAction = menu->insertMenu(before, m_recentMenu);
    m_recentMenuTriggeredAction->setObjectName("recentMenuAction");
    menu->insertSeparator(before);
}
void RecentFiles::openRecentFile()
{
    QAction *action = qobject_cast<QAction *>(sender());
    if (action)
        emit openFile(action->data().toString());
}

QString RecentFiles::strippedName(const QString &fullFileName)
{
    return QFileInfo(fullFileName).fileName();
}

void RecentFiles::setRecentFilesList(const QStringList& recents)
{
    m_recentFiles = recents;

    updateRecentFiles();
}

void RecentFiles::setMostRecentFile(const QString fileName)
{
    if (!fileName.isEmpty()) {
        m_recentFiles.removeAll(fileName);
        m_recentFiles.prepend(fileName);
    }
    updateRecentFiles();
}

void RecentFiles::setNumOfRecentFiles(int n)
{
    //fprintf(stderr, "setNumRecent(%d)\n", n);

    if (n == m_numOfRecentFiles)
        return;

    m_numOfRecentFiles = n;
    updateRecentFiles();
    emit newMaxFilesShown(n);
}

QStringList RecentFiles::getRecentFiles() const
{
    QStringList r;

    for (int i=0;
         i<m_recentFiles.count() && i<m_numOfRecentFiles;
         i++)
        r.push_back(m_recentFiles[i]);

    return r;
}


void RecentFiles::updateRecentFiles()
{


    // remove any files that don't exist from the list
    QMutableStringListIterator i(m_recentFiles);
    while (i.hasNext()) {
        if (!QFile::exists(i.next()))
            i.remove();
    }

    // If there are no recent files, then the menu item (that would show the list)
    // should not be visible.
    if (m_recentMenuTriggeredAction) {
        if (m_numOfRecentFiles == 0) {
            m_recentMenuTriggeredAction->setVisible(false);
        } else {
            m_recentMenuTriggeredAction->setVisible(true);
        }
    }

    for (int j = 0; j < MaxRecentFiles; ++j) {
        if (j < m_recentFiles.count() && j < m_numOfRecentFiles) {
            QString text = strippedName(m_recentFiles[j]);
            m_recentFileActions[j]->setText(text);
            m_recentFileActions[j]->setData(m_recentFiles[j]);
            m_recentFileActions[j]->setObjectName(sanitizedFileName(text));

            m_recentFileActions[j]->setVisible(true);

        } else {

            m_recentFileActions[j]->setVisible(false);
        }
    }

    for (int j = m_numOfRecentFiles; j < m_recentFiles.count(); j++)
        m_recentFileActions[j]->setVisible(false);
}
