#ifndef APPLICATIONDOCUMENT_H
#define APPLICATIONDOCUMENT_H

#include "AppCore_global.h"

#include <QObject>

class ApplicationView;

class APPCORESHARED_EXPORT ApplicationDocument : public QObject
{
    Q_OBJECT

public:

    ApplicationDocument(QObject *parent);

    virtual ~ApplicationDocument();

    /// Import a file to the document.
    ///
    /// This must set the document file name if the document was previously
    /// empty This method emits "fileImportCompleted" when the document is
    /// finished loading (on first import only?). It emits "fileImportFailed"
    /// if the document is not loaded properly sets the current document name
    /// on first import.
    virtual bool importFileByName(QString fileName) = 0;

    /// Save the document to the current file name.
    ///
    /// emits "fileSaveCompleted" when completed
    /// XXX: This probably just calls fileSaveByName()
    virtual void saveFile() = 0;

    /// Save the document to an alternate file name.
    ///
    /// Sets the current docuemnt name
    /// emits "fileSaveCompleted" when completed
    virtual void saveFileByName(QString fileName) = 0;

    /// A text string which indicates the type or category of this document
    /// within the application
    virtual QString getDocumentType() = 0; // eg "SysDef" or "Geometry"

    /// Return the current filename
    QString getCurrentOpenFileName() const;

signals:

    void fileImportCompleted();
    void fileImportFailed();
    void fileSaveCompleted();
    void fileSaveFailed();
    void fileNameWillChange(const QString &oldFileName,
                            const QString &newFileName);

    /// Signal to tell whoever owns the document that this document wants to be
    /// closed
    void closeDocument();

    /// Signal to tell observers that this document is being closed (deleted)
    void documentClosing();

public slots:

    /// This slot is invoked when a new document comes into existence.
    virtual void newDocumentExists(ApplicationDocument *doc);

    /// Handle when a view has been closed/deleted
    void detachView(ApplicationView *view);

protected:

    /// Function called when this document is attached to a view
    void attachView(ApplicationView *view);

    /// Name of the original file from which the document was loaded
    QString m_fileName;

private:

    // Friend function declarations ///////////////////////////////////////////

    /// Allows attachView() to be callable from the attach() free function found
    /// in MainWindow's source h/cpp.
    friend void attach(ApplicationDocument* doc, ApplicationView* view);

    // Private data members ///////////////////////////////////////////////////

    /// Track the number of references to this document
    int m_viewReferences;
};

#endif // APPLICATIONDOCUMENT_H
