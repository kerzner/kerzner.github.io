#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include "AppCore_global.h"

#include "RecentFiles.h"

#include <QDir>
#include <QListWidgetItem>
#include <QMainWindow>
#include <QMap>
#include <QtScript/QScriptable>
#include <QFileDialog>

class AppInputRecorderDialog;
class QProgressBar;
class QScriptEngine;
class QScriptEngineDebugger;
class QMdiSubWindow;


class RecentFiles;
class ICommandLinePlugin;
class IDocPlugin;
class IViewPlugin;

class ApplicationDocument;
class ApplicationView;

class QComboBox;

namespace Ui
{
class MainWindow;
}

/** The Main application window/controller
 *
 * The MainWindow acts as the controller for the application.  It is
 * responsible for application start-up and shutdown.  In addition it provides
 * an API for document windows to operate inside.  The API is defined in the
 * MdiChild class.
 *
 *
 *
 * In general it is better to write methods as slots, as these are automatically
 * connected to the scripting engine.
 */
class APPCORESHARED_EXPORT MainWindow : public QMainWindow,
    protected QScriptable
{
    Q_OBJECT

public:

    MainWindow(QWidget *parent = 0);
    ~MainWindow();

    /// This returns a QDir for the directory where the application was started.
    /// Resources and plugins should be loaded/saved relative to this location.
    QDir getApplicationDir();

public slots:

    /// When the user clicks File->Open ... we end up here
    void on_actionFileOpen_triggered();
    void on_actionFileOpenAs_triggered();

    void on_actionFileSave_triggered();
    void on_actionFileSaveAs_triggered();

    /// construct/display a reasonable
    void on_actionAbout_triggered();

    void on_actionMacro_triggered();

    /// Load a file of the given type.
    void fileLoad(const QString fileName, const QString fileType = QString());

    /// Called to clean up when the window is about to close
    void closeEvent(QCloseEvent *event);

signals:

    void newDocument(ApplicationDocument *doc);

private slots:

    /// Handle when a new window comes into focus
    void activeWindowChanged(QMdiSubWindow *msw = NULL);

    /// Handle when a window's state changes (hide/show menu items, toolbar)
    void switchWindowState(Qt::WindowStates prev, Qt::WindowStates next);

    /// Defines the behavior when a document signals that it wants to be closed
    void closeDocument();

    /// Defines the behavior when a document is being deleted
    void documentIsClosing();

    /// Slot to handle closing a document from the open doc list context menu
    void closeDocumentFromOpenDocList();

    /// Slot to handle right-click event on the open document list
    void showOpenDocContextMenu(QPoint p);

    /// Slot to handle the user creating a new view from the open doc list
    void handleCreateViewFromOpenDoc();

    /// Manual code to tile the QMdiArea vertically
    void on_actionTileVertically_triggered();

    /// Manual code to tile the QMdiArea horizontally
    void on_actionTileHorizontally_triggered();

    /// Manual code to create a shotviewer layout for QMdiArea.
    void on_actionShotviewer_triggered();

    /// create an empty new document
    void createNewFileFromMenu();

    void documentImportCompleted();
    void documentNameChanging(QString oldName, QString newName);

private:

    // Helper type ////////////////////////////////////////////////////////////

    /// Custom class to hold both the file name text (in QListWidgetItem) and
    /// the pointer to the corresponding ApplicationDocument.
    class OpenFileWidgetItem : public QListWidgetItem
    {

    public:

        /// Qt usertype (see QListWidgetItem documentation for subclassing)
        static int type;

        ~OpenFileWidgetItem();

        /// Constructor
        OpenFileWidgetItem(const QString& label, ApplicationDocument* doc);

        /// Accessor for this item's document
        ApplicationDocument *doc();

    private:

        ApplicationDocument* m_document;
    };

    // Helper functions ///////////////////////////////////////////////////////

    ApplicationDocument *createNewDocument(IDocPlugin *idp);

    void settingsRead();
    void settingsWrite();
    void pluginsLoad();
    void addFileNewMenu();

    // TODO: document!
    void registerApplicationOptionHandler(ICommandLinePlugin *iclp);

    // puts a documentCreator in fileNameExtensionToCreator,
    // registers default standard views for a document type
    // (stdViewsByNameForDocumentTypeName)
    void registerApplicationDocumentCreator(IDocPlugin *);

    // registers viewCreator in viewCreatorForName
    // fills in availViewsByNameForDocumentTypeName
    void registerApplicationViewCreator(IViewPlugin *);

    // Get the application view for the window that is in focus, none == NULL
    ApplicationView *getCurrentView();

    void insertControlsFromView(ApplicationView *view);

    // Creates a view for the given document and adds it to the MdiArea
    void createAndAddView(ApplicationDocument *doc, QString viewName);
    void createAndAddView(QList<ApplicationDocument *> docs, QString viewName);

    ApplicationDocument *getSelectedDocumentFromOpenList();
    QList<ApplicationDocument*> getOpenDocuments();

    QStringList getOpenDocumentsByType(const QString &docType);

    AppInputRecorderDialog *getOrCreateEventRecorder();

    // Private data members ///////////////////////////////////////////////////

    Ui::MainWindow *ui;
    QMenu * m_fileNewMenu;
    RecentFiles m_recentFiles;  ///< Class which handles recent file history
    QFileDialog *m_fileDialog;  ///< needed for recording of file open events
    QStringList getOpenFileNames(const QString &caption = QString(),
                                 const QString &dir = QString(),
                                 const QString &filter = QString(),
                                 const bool &openFileAs = false);
    QString getSaveFileName(const QString &caption = QString(),
                            const QString &dir = QString(),
                            const QString &filter = QString());

    /// documents who want to listen for the creation of others
    QList<ApplicationDocument *> m_openListeners;

    QMap<QString, IDocPlugin *> m_fileNameExtensionToCreator;
    QMap<QString, QStringList> m_stdViewsByNameForDocumentTypeName;// preference
    QMap<QString, QStringList> m_availViewsByNameForDocumentTypeName;
    QMap<QString, IViewPlugin *> m_viewCreatorForName;
    QMap<QString, ICommandLinePlugin *> m_optionToPlugin;

    AppInputRecorderDialog *m_appInputRecorderDialog;

};

template <class T> class VariantPtr
{

public:

    static T* asPtr(QVariant v) {
        return  (T *) v.value<void *>();
    }

    static QVariant asQVariant(T* ptr) {
        return qVariantFromValue((void *) ptr);
    }
};
#endif // MAINWINDOW_H
