#include "ShotViewerDialog.h"
#include "ui_ShotViewerDialog.h"

#include <QDebug>
#include <QFileDialog>
#include <QSettings>
#include <QMenu>

ShotViewerDialog::ShotViewerDialog(QWidget *parent)
    : QDialog(parent)
    , ui(new Ui::ShotViewerDialog)
    , m_buttonMap(new QMap<QPushButton*, QLineEdit *>)
    , m_maxRecent(4)
{
    ui->setupUi(this);

    // Button map is used to map from button actions to the correct line edit.
    m_buttonMap->insert(ui->buttonIrRecent, ui->lineEditIr);
    m_buttonMap->insert(ui->buttonGeometryRecent, ui->lineEditGeometry);
    m_buttonMap->insert(ui->buttonRegmapRecent, ui->lineEditRegmap);
    m_buttonMap->insert(ui->buttonSysDefRecent, ui->lineEditSysDef);

    loadRecent();
}

ShotViewerDialog::~ShotViewerDialog()
{
    saveRecent();
    delete ui;
}

QString ShotViewerDialog::getIrFileName() const
{
    return ui->lineEditIr->text();
}

QString ShotViewerDialog::getSysDefFileName() const
{
    return ui->lineEditSysDef->text();
}

QString ShotViewerDialog::getRegmapFileName() const
{
    return ui->lineEditRegmap->text();
}

QString ShotViewerDialog::getGeometryFileName() const
{
    return ui->lineEditGeometry->text();
}

void ShotViewerDialog::setIrFileName(const QString &name)
{
    setFileNameAndUpdateRecent(name, ui->lineEditIr, ui->buttonIrRecent);
}

void ShotViewerDialog::setSysDefFileName(const QString &name)
{
    setFileNameAndUpdateRecent(name, ui->lineEditSysDef, ui->buttonSysDefRecent);
}

void ShotViewerDialog::setRegmapFileName(const QString &name)
{
    setFileNameAndUpdateRecent(name, ui->lineEditRegmap, ui->buttonRegmapRecent);
}

void ShotViewerDialog::setGeometryFileName(const QString &name)
{
    setFileNameAndUpdateRecent(name, ui->lineEditGeometry, ui->buttonGeometryRecent);
}

void ShotViewerDialog::on_buttonIrFind_clicked()
{
    QString fileName;
    if (getFileName(fileName)) {
        setFileNameAndUpdateRecent(fileName, ui->lineEditIr, ui->buttonIrRecent);
    }
}

void ShotViewerDialog::on_buttonSysDefFind_clicked()
{
    QString fileName;
    if (getFileName(fileName)) {
        setFileNameAndUpdateRecent(fileName, ui->lineEditSysDef, ui->buttonSysDefRecent);
    }
}

void ShotViewerDialog::on_buttonRegmapFind_clicked()
{
    QString fileName;
    if (getFileName(fileName)) {
        setFileNameAndUpdateRecent(fileName, ui->lineEditRegmap, ui->buttonRegmapRecent);
    }
}

void ShotViewerDialog::on_buttonGeometryFind_clicked()
{
    QString fileName;
    if (getFileName(fileName)) {
        setFileNameAndUpdateRecent(fileName, ui->lineEditGeometry, ui->buttonGeometryRecent);
    }
}

void ShotViewerDialog::recentFileSelected()
{
    // Sender is the action. Sender->parent() is the menu. The menu's parent
    // is the recent button.
    QPushButton *button = (QPushButton*) sender()->parent()->parent();

    // Get the line edit that corresponds to the current action.
    QLineEdit *line = m_buttonMap->value(button);

    // Actually update the file name.
    setFileNameAndUpdateRecent(((QAction*) sender())->text(), line, button);
}

void ShotViewerDialog::setFileNameAndUpdateRecent(QString fileName, QLineEdit *line, QPushButton *button)
{
    if (!fileName.isEmpty()) {
        line->setText(fileName);
        updateRecent(button, line->text());
    }
}

bool ShotViewerDialog::getFileName(QString &fileName)
{
    const char* directoryKey = "currentDirectory";
    QSettings settings(qApp->organizationName(), qApp->applicationName());
    QVariant directory = qApp->applicationDirPath();
    directory = settings.value(directoryKey, directory);

    QFileDialog dialog(this, tr("Open file..."), directory.toString());
    bool ok = dialog.exec();

    if (ok) {
        fileName = dialog.selectedFiles().first();
        settings.remove(directoryKey);
        settings.setValue(directoryKey, dialog.directory().absolutePath());
    } else {
        fileName = QString();
    }

    return ok;
}

void ShotViewerDialog::loadRecent()
{
    foreach (QPushButton *button, getRecentButtons()) {
        loadRecent(button);
    }
}

void ShotViewerDialog::saveRecent()
{
    foreach (QPushButton *button, getRecentButtons()) {
        saveRecent(button);
    }
}

void ShotViewerDialog::loadRecent(QPushButton *button)
{
    QVariant emptyString = QString();
    QSettings settings(qApp->organizationName(), qApp->applicationName());

    QVariant values = settings.value(button->objectName(), emptyString);
    QStringList recentFiles = values.toStringList();

    QMenu *menu = new QMenu(button);

    foreach (QString fileName, recentFiles) {
        if (!fileName.isEmpty()) {
            QAction *action = new QAction(fileName, menu);
            connect(action, SIGNAL(triggered()), this, SLOT(recentFileSelected()));
            menu->addAction(action);
        }
    }

    button->setMenu(menu);

    // Automatically populate the line edit.
    if (menu->actions().size() > 0) {
        setFileNameAndUpdateRecent(menu->actions().first()->text(), m_buttonMap->value(button), button);
    }
}

void ShotViewerDialog::saveRecent(QPushButton *button)
{
    QStringList recentList;
    QMenu *menu = button->menu();

    foreach (QAction *action, menu->actions()) {
        recentList << action->text();
    }

    QSettings settings(qApp->organizationName(), qApp->applicationName());
    settings.setValue(button->objectName(), recentList);
}

void ShotViewerDialog::updateRecent(QPushButton *button, QString fileName)
{
    QMenu *menu = button->menu();
    if (!menu) {
        menu = new QMenu(button);
        menu->clear();
    }

    // Get the list of existing actions and create a list of new actions.
    QList<QAction*> actions = menu->actions();
    QList<QAction*> newActions = QList<QAction*>();

    // Keep list to the correct size.
    if (actions.size() > m_maxRecent) {
        actions.takeLast();
    }

    // Create new list of actions (preserve the rest of the recent list).
    foreach (QAction *action, actions) {
        if (action->text() != fileName) {
            newActions.push_back(new QAction(action->text(), menu));
        }
    }

    // Create action for the new file
    newActions.push_front(new QAction(fileName, menu));

    // Connect the actions to this.
    foreach (QAction *action, newActions) {
        connect(action, SIGNAL(triggered()), this, SLOT(recentFileSelected()));
    }

    menu->clear();
    menu->addActions(newActions);

    button->setMenu(menu);
}

QList<QPushButton*> ShotViewerDialog::getRecentButtons()
{
    QList<QPushButton*> buttons;
    buttons << ui->buttonIrRecent;
    buttons << ui->buttonSysDefRecent;
    buttons << ui->buttonRegmapRecent;
    buttons << ui->buttonGeometryRecent;
    return buttons;
}
