#include "ShotViewerWindow.h"
#include "ui_ShotViewerWindow.h"

#include <QDebug>
#include <QMessageBox>
#include <QCloseEvent>
#include <QPixmap>
#include <QFileDialog>
#include <QScrollArea>
#include <QSettings>
#include <QSplitter>

#include "ApplicationView.h"

ShotViewerWindow::ShotViewerWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::ShotViewerWindow)
    , m_imageWidget(NULL)
{
    ui->setupUi(this);
    connect(ui->actionClose_all, SIGNAL(triggered()), this, SLOT(close()));
    connect(ui->actionChange_aim_points, SIGNAL(triggered()), this, SIGNAL(changeAimPoints()));
}

ShotViewerWindow::~ShotViewerWindow()
{
    delete ui;
}

void ShotViewerWindow::takeMenus(ApplicationView *view)
{
    QList<QMenu*> menus = view->getMenus();
    foreach (QMenu *menu, menus) {
        ui->menubar->addMenu(menu);
    }
}

void ShotViewerWindow::takeToolBars(ApplicationView *view)
{
    addToolBar(view->getToolBar());
}

void ShotViewerWindow::setImageWidget(QWidget *widget)
{
    m_imageWidget = widget;
}

void ShotViewerWindow::settingsLoad()
{
    QSettings settings(qApp->organizationName(), qApp->applicationName());
    QString name = windowTitle();
    QVariant width;
    QVariant height;
    QVariant x;
    QVariant y;

    width = settings.value(name+"width", QVariant(600));
    height = settings.value(name+"height", QVariant(400));
    x = settings.value(name+"x", pos().x());
    y = settings.value(name+"y", pos().y());
    setGeometry(x.toInt(), y.toInt(), width.toInt(), height.toInt());

    // If this has a splitter load its state.
    QSplitter *splitter = dynamic_cast<QSplitter*>(centralWidget());
    if (splitter) {
        splitter->restoreState(settings.value(name+"splitter").toByteArray());
    }
}

void ShotViewerWindow::settingsSave()
{
    QSettings settings(qApp->organizationName(), qApp->applicationName());
    QString name = windowTitle();
    QRect rectangle = geometry();
    QVariant width = rectangle.width();
    QVariant height = rectangle.height();
    QVariant x = rectangle.x();
    QVariant y = rectangle.y();

    settings.setValue(name+"width", width);
    settings.setValue(name+"height", height);
    settings.setValue(name+"x", x);
    settings.setValue(name+"y", y);

    // If this has a splitter save its state.
    QSplitter *splitter = dynamic_cast<QSplitter*>(centralWidget());
    if (splitter) {
        settings.setValue(name+"splitter", splitter->saveState());
    }
}

void ShotViewerWindow::closeEvent(QCloseEvent *event)
{
    QMessageBox::StandardButton response =
        QMessageBox::question(this, "Close",
                              "This will close ALL windows. Are you sure?",
                              QMessageBox::No | QMessageBox::Yes);

    if (response == QMessageBox::No) {
        event->ignore();
    } else {
        event->ignore();
        qApp->quit();
    }
}

void ShotViewerWindow::on_actionSave_image_triggered()
{
    // Get file name from user.
    // XXX If the user types a name and then hits "Cancel" this will still
    // save the image...
    QString fileName = QFileDialog::getSaveFileName(this, "Save image as", qApp->applicationDirPath(), "png");
    if (!fileName.isEmpty()) {

        if (!fileName.endsWith(".png")) {
            fileName.append(".png");
        }

        QWidget *widget = centralWidget();
        QRect rectangle = widget->rect();
        QPixmap pixmap(rectangle.size());
        widget->render(&pixmap, QPoint(), QRegion(rectangle));
        pixmap.save(fileName);
    }
}

void ShotViewerWindow::on_actionSave_view_image_triggered()
{
    // See the XXX note above.
    QString fileName = QFileDialog::getSaveFileName(this, "Save image as", qApp->applicationDirPath(), "png");
    if (!fileName.isEmpty()) {

        if (!fileName.endsWith(".png")) {
            fileName.append(".png");
        }

        QWidget *widget = m_imageWidget ? m_imageWidget : centralWidget();
        QRect rectangle = widget->rect();
        QPixmap pixmap(rectangle.size());
        widget->render(&pixmap, QPoint(), QRegion(rectangle));
        pixmap.save(fileName);
    }
}
