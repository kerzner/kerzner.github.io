#ifndef SHOTVIEWERDIALOG_H
#define SHOTVIEWERDIALOG_H

#include <QDialog>
#include <QMap>
#include <QStringList>

class QLineEdit;

namespace Ui
{
class ShotViewerDialog;
}

/** This is the dialog that wrangles MUVES input files for this application. It
 * forces the user to specify an IR, SysDef, Regmap, and Geometry (.ive or .osg)
 * file. These can be input via command line, selected from a list of recent
 * files, or from a file open dialog.
 *
 * This tracks the recently opened files and makes them available to the user.
 * For each file type (e.g., ir, sysdef, ...) this has a QPushButton called a
 * "recent button." This "recent button" has a list of actions, and each action
 * contains a recently opened file name. When the user selecs one of these
 * actions then the corresponding line edit gets populated with the filename.
 * These actions get updated whenever the user opens a new file or selects a
 * file from the recent list.
 */
class ShotViewerDialog : public QDialog
{
    Q_OBJECT

public:
    explicit ShotViewerDialog(QWidget *parent = 0);

    ~ShotViewerDialog();

    QString getIrFileName() const;

    QString getSysDefFileName() const;

    QString getRegmapFileName() const;

    QString getGeometryFileName() const;

    /// Sets the current IR file name being displayed. This gets called in two
    /// places: when the user clicks on the "..." to select a file using a
    /// QFileDialog, and when this gets created and the user specified and IR
    /// file using the --ir= parameter. This is true for all set*FileNames(...).
    /// All of these call the setFileNameAndUpdateRecent(...) method.
    void setIrFileName(const QString &);

    void setSysDefFileName(const QString &);

    void setRegmapFileName(const QString &);

    void setGeometryFileName(const QString &);

public slots:

    /// Allows the user to search for an IR file using a QFileDialog. Same for
    /// all on_button*Find_clicked();
    void on_buttonIrFind_clicked();

    void on_buttonSysDefFind_clicked();

    void on_buttonRegmapFind_clicked();

    void on_buttonGeometryFind_clicked();

    /// Called when the user selects an item from the recent files list. This
    /// calls the setFileNameAndUpdateRecentMethod(...)
    void recentFileSelected();

private:

    /// Sets the lineEdit to contain fileName and updates the recent list that
    /// is owned by button.
    void setFileNameAndUpdateRecent(QString fileName, QLineEdit *line, QPushButton* button);

    /// Prompt the user to get a filename. We currently do not handle any file
    /// extensions b/c MUVES input files are often extensionless.
    bool getFileName(QString &fileName);

    /// Loads recent file names for all file types from QSettings.
    void loadRecent();

    /// Saves recent file names for all file types.
    void saveRecent();

    /// Loads the recent file names for one file type.
    /// -button is the recent button. We use its object name as a settings key.
    void loadRecent(QPushButton *button);

    /// Saves recent file names for one file type.
    /// -button is the recent button. We use its object name as a settings key.
    void saveRecent(QPushButton *button);

    /// Called when the user selects a new file.
    void updateRecent(QPushButton *button, QString fileName);

    /// Returns a list of all the recent buttons.
    QList<QPushButton*> getRecentButtons();

    Ui::ShotViewerDialog *ui;

    /// leys = recent buttons
    /// values = line edits for each of the recent buttons.
    QMap<QPushButton*, QLineEdit*> *m_buttonMap;

    const int m_maxRecent;
};

#endif // SHOTVIEWERDIALOG_H
