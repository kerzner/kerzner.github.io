#include <QApplication>
#include <QMainWindow>
#include <QGridLayout>
#include <QHBoxLayout>
#include <QFrame>
#include <QTextStream>
#include <QMessageBox>
#include <QObject>
#include <QSettings>
#include <QSplitter>

#include <stdio.h>

#include "IDocPlugin.h"
#include "ICommandLinePlugin.h"
#include "Attach.h"
#include "IRDocument.h"
#include "SysDefDocument.h"
#include "RegmapApplicationDocument.h"
#include "OsgDocument.h"

#include "CompareShotlineView.h"
#include "LineplotShotlineView.h"
#include "TableShotlineView.h"
#include "SysDefShotlineView.h"
#include "OsgView.h"

#include "ShotViewerWindow.h"
#include "ShotViewerDialog.h"

/// Prints a hint about command line parameters.
void printUsage();

/// Prints message to stdout and exits appliction.
void errorExit(QString message);

/// Prints message to stdout.
void showWarning(QString message);

/// Creates an IRDocument. This also parses the --ap and --pat command line
/// parameters and passes them into the IRDocument.
IRDocument *createIRDocument(QString irName);

/** The main method for the standalone shotviewer application. This assumes that
 * the user will always want to look a complete set of data, which consists of:
 * ir, sysdef, regmap, and geometry files. The application will fail silently if
 * all of these files are not specified.
 *
 *TODO: provide a way for the user to open just a subset of input files at a
 * time. For instance, just a sysdef and ir, or just an ir file.
 */
int main(int argc, char *argv[])
{
    // Overview of what this function does:
    // 0. Setup application.
    // 1. Get file names to open--either from command line or from the user
    // 2. Parse command line arguments
    // 3. Create documents based on the specified file names.
    // 4. Create views for the documents.
    // 5. Connect views and documents.
    // 6. Create windows and connect them to documents.
    // 7. Shove views into windows.
    // 8. Enter the application's main loop.
    // 7. Clean up.

    // 0. Setup application.
    QApplication app(argc, argv);
    qApp->setApplicationName("Shotviewer");
    qApp->setOrganizationName("SCI Institue");
    qApp->setOrganizationDomain("edu.utah.sci");

    // 1. Parse command line arguments.

    // Does the user want to use the ShotViewerDialog to open files?
    bool useGui = !qApp->arguments().contains("--noGui");

    // Does the user want help?
    if (qApp->arguments().contains("--?") ||
        (qApp->arguments().size() == 1 && !useGui)) {
        printUsage();
        return 0;
    }

    // Does user want to reset the window positions i.e., not load them
    bool resetWindows = qApp->arguments().contains("--resetWindows");

    // 1. Get file names to open.
    QString irName = ICommandLinePlugin::argByKey("--ir", '=');
    QString sysName = ICommandLinePlugin::argByKey("--sys", '=');
    QString regName = ICommandLinePlugin::argByKey("--reg", '=');
    QString geoName = ICommandLinePlugin::argByKey("--geo", '=');

    // Setup the dialog if the user asked for it. Here, we populate the fields
    // of the ShotViewerDialog with any filenames that the user specified. There
    // is no way to use the dialog and load a subset of the files. In other
    // words, the dialog does not allow the user to clear file names.
    if (useGui) {

        ShotViewerDialog dialog;

        if (!irName.isEmpty()) {
            dialog.setIrFileName(irName);
        }

        if (!sysName.isEmpty()) {
            dialog.setSysDefFileName(sysName);
        }

        if (!regName.isEmpty()) {
            dialog.setRegmapFileName(regName);
        }

        if (!geoName.isEmpty()) {
            dialog.setGeometryFileName(geoName);
        }

        if (dialog.exec()) {
            irName = dialog.getIrFileName();
            sysName = dialog.getSysDefFileName();
            regName = dialog.getRegmapFileName();
            geoName = dialog.getGeometryFileName();
        } else {
            return 0;
        }
    }

    // What files are we going to load?
    bool hasIr = !irName.isEmpty();
    bool hasSysDef = !sysName.isEmpty();
    bool hasRegmap = !regName.isEmpty();
    bool hasGeo = !geoName.isEmpty();

    // 3. Create documents.
    IRDocument *irDoc;
    SysDefDocument *sysDefDoc;
    RegmapApplicationDocument *regmapDoc;
    OsgDocument *osgDoc;

    // List of all documents
    QList<ApplicationDocument*> documents;

    if (hasIr) {
        irDoc = createIRDocument(irName);
        documents << irDoc;
    } else {
        errorExit("No ir file to load.");
    }

    if (hasSysDef) {
        sysDefDoc = new SysDefDocument();
        if (sysDefDoc->importFileByName(sysName)) {
            documents << sysDefDoc;
        } else {
            errorExit("Failed to load sysdef file:" + sysName);
        }
    }

    if (hasRegmap) {
        regmapDoc = new RegmapApplicationDocument();
        if (regmapDoc->importFileByName(regName)) {
            documents << regmapDoc;
        } else {
            errorExit("Failed to load regmap file:" + regName);
        }
    }

    if (hasGeo) {
        if (hasRegmap) {
            osgDoc = new OsgDocument();
            if (osgDoc->importFileByName(geoName)) {
                documents << osgDoc;
            } else {
                errorExit("Failed to load osg file:" + geoName);
            }
        } else {
            showWarning("Cannot load osg files without a regmap file.");
            hasGeo = false;
        }
    }

    // 4. Create views for the documents.
    QList<ApplicationView*> views;

    CompareShotlineView *compareView = new CompareShotlineView();
    views << compareView;

    LineplotShotlineView *lineplotView0 = new LineplotShotlineView();
    views << lineplotView0;

    LineplotShotlineView *lineplotView1 = new LineplotShotlineView();
    views << lineplotView1;

    TableShotlineView *tableView = new TableShotlineView();
    views << tableView;

    SysDefShotlineView *sysDefView = NULL;
    if (hasSysDef) {
        sysDefView = new SysDefShotlineView();
        views << sysDefView;
    }

    OsgView *osgView = NULL;
    if (hasGeo) {
        osgView = new OsgView();
        views << osgView;
    }

    // 5. Connect views and documents.
    // Each view is connected to all other views. Each view is connected to
    // all other documents. Some views (like the lineplotview) will just do
    // a no-op when they are connected to irrelevant documents (like sysdefdoc).
    for (int i = 0; i < views.size(); i++) {
        for (int j = i+1; j < views.size(); j++) {
            attach(views.at(i), views.at(j));
        }
    }

    foreach (ApplicationView *view, views) {
        foreach (ApplicationDocument *doc, documents) {
            attach(view, doc);
        }
    }

    // 6. Create windows and connect them to documents.
    QList<ShotViewerWindow*> windows;

    ShotViewerWindow *irWindow = new ShotViewerWindow();
    irWindow->setWindowTitle("IR Views");
    windows << irWindow;

    ShotViewerWindow *sysDefWindow = new ShotViewerWindow();
    sysDefWindow->setWindowTitle("SysDef View");
    windows << sysDefWindow;

    ShotViewerWindow *osgWindow;
    if (hasGeo) {
        osgWindow = new ShotViewerWindow();
        osgWindow->setWindowTitle("Geometry View");
        windows << osgWindow;
    }

    // Windows tell the IR doc when the user wants to change the aim points.
    foreach (ShotViewerWindow *window, windows) {
        QObject::connect(window, SIGNAL(changeAimPoints()),
                         irDoc, SLOT(showAimPointDialog()));
    }

    // 7. Shove views into windows.

    // Splitter is going to hold the table, compare and lineplot views.
    QSplitter *splitter = new QSplitter(Qt::Vertical);
    QFrame *frame = new QFrame();
    frame->setFrameShape(QFrame::VLine);

    // Add table and compare views.
    splitter->addWidget(tableView);
    splitter->addWidget(compareView);

    // Create widget to hold line plots
    QWidget *lineplotWidget = new QWidget();
    QHBoxLayout *lineplotLayout = new QHBoxLayout();
    lineplotLayout->addWidget(lineplotView0);
    lineplotLayout->addWidget(frame);
    lineplotLayout->addWidget(lineplotView1);
    lineplotWidget->setLayout(lineplotLayout);
    splitter->addWidget(lineplotWidget);

    // Put it all in the window.
    irWindow->setCentralWidget(splitter);
    irWindow->takeMenus(tableView);
    irWindow->takeMenus(compareView);

    // Create window for sysdef view
    if (hasSysDef) {
        sysDefWindow->setCentralWidget(sysDefView);
        sysDefWindow->takeMenus(sysDefView);
        sysDefWindow->setImageWidget(sysDefView->getImageWidget());
    }

    // Create window for osg view.
    if (hasGeo) {
        osgWindow->setCentralWidget(osgView);
        osgWindow->takeToolBars(osgView);
        osgWindow->takeMenus(osgView);
        osgWindow->setImageWidget(osgView->getImageWidget());
    }

    // Load window settings.
    if (!resetWindows) {
        foreach (ShotViewerWindow *window, windows) {
            window->settingsLoad();
        }
    }

    // 8. Enter the main loop.
    irWindow->show();

    if (hasSysDef) {
        sysDefWindow->show();
    }

    if (hasGeo) {
        osgWindow->show();
    }

    app.exec();

    // 9. Clean up.
    foreach (ShotViewerWindow *window, windows) {
        window->settingsSave();
    }

    foreach (ApplicationView *view, views) {
        delete view;
    }

    foreach (ApplicationDocument *doc, documents) {
        delete doc;
    }
}

void printUsage()
{
    QTextStream stream(stdout);
    stream << "Shotviewer: a tool for visualizing IR files" << endl;
    stream << "  Main operation mode [optional settings]:" << endl;
    stream << "     --ir=FILE                 ir file to be loaded" << endl;
    stream << "     --ap=n0,n1,...            aim points to be displayed (up to 4)" << endl;
    stream << "    [--sys=FILE]               sysdef file to be loaded" << endl;
    stream << "    [--geo=FILE]               osg or ive file to be loaded" << endl;
    stream << "    [--reg=FILE]               regmap file to be loaded" << endl;
    stream << "    [--pat=regexPattern]       pattern to match (eg \"SCJ\")" << endl;
    stream << "    [--tp=string0,string1,...] threat parameters displayed in table" << endl;
    stream << "    [--map=myColorMap.txt]     colormap file to be loaded" << endl;
    stream << "    [--showPk]                 will draw component pKs in compare view" << endl;
    stream << "    [--about]                  print developer information" << endl;
    stream << "    [--resetWindows]           ignores the saved window sizes and positions" << endl;
    stream << "    [--verbose]                enable very verbose debugging output" << endl;
    stream << "  Sample usage: " << qApp->applicationName() << " --ir=../data/9.1.ir --ap=7347 " << endl;
    stream << "Please report bugs to Ethan Kerzer (kerzner@sci.utah.edu)." << endl;
}

void errorExit(QString message)
{
    QTextStream stream(stdout);
    stream << "ERROR: " << message << endl;
    exit(-1);
}

void showWarning(QString message)
{
    QTextStream stream(stdout);
    stream << "WARNING: " << message << endl;
}

IRDocument *createIRDocument(QString irName)
{
    // Convert aim points to a list of ints.
    QStringList aimPointStrings = ICommandLinePlugin::argByKey("--ap", '=').split(",");
    QList<int> aimPoints;
    foreach (QString aimPoint, aimPointStrings) {
        if (!aimPoint.isEmpty()) {
            aimPoints << aimPoint.toInt();
        }
    }

    // Get threat name.
    QString threatName = ICommandLinePlugin::argByKey("--pat", '=');

    IRDocument *irDoc = new IRDocument(aimPoints, threatName);
    if (!irDoc->importFileByName(irName)) {
        errorExit("Failed to load ir file:" + irName);
    }

    return irDoc;
}
