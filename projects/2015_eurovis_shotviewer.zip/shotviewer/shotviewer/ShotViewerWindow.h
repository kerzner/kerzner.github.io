#ifndef SHOTVIEWERWINDOW_H
#define SHOTVIEWERWINDOW_H

#include <QMainWindow>

class QCloseEvent;
class ApplicationView;

namespace Ui
{
class ShotViewerWindow;
}

/** This class holds the various ApplicationViews that make up shotviewer. To
 * add a view to this window, we must call takeMenus and takeToolBars in order
 * for the view's menus and toolbars to be properly displayed. We must also
 * call setImageWidget on the widget that we want to use when taking screen
 * shots. Sometimes the "image widget" will just be the view that this is
 * displaying, other times the "image widget" will be some collection of views
 * that this is displaying.
 *
 * In addition to displaying menus and toolbars of its views, this also provides
 * a mechanism for closing the entire application. When the use selectes close
 * in ANY of the application's windows, it closes all the windows.
 *
 */
class ShotViewerWindow : public QMainWindow
{
    Q_OBJECT

public:

    /// Constructor
    explicit ShotViewerWindow(QWidget *parent = 0);

    /// Destructor
    ~ShotViewerWindow();

    /// Method called for all ApplicationViews that this will display. It calls
    /// view->getMenus and displays those menus.
    void takeMenus(ApplicationView *view);

    /// Method called for all ApplicationViews that this will display. It calls
    /// view->getToolBar and displays those tool bars.
    void takeToolBars(ApplicationView *view);

    /// The "image widget" is the widget that will get displayed when the user
    /// wants to save a screenshot. Sometimes this is just the central widget
    /// being displayed, other times, it is one specific widget that we set
    /// by hand.
    void setImageWidget(QWidget* widget);

    /// Load window position and splitter state.
    void settingsLoad();

    /// Save window position and splitter state.
    void settingsSave();

signals:

    /// Tell the IRDocument to change its aimpoints.
    void changeAimPoints();

private slots:

    /// Tell all other ShotViewerWindows to close.
    void closeEvent(QCloseEvent *event);

    /// Save the entire contents of this window.
    void on_actionSave_image_triggered();

    /// Save just the contents of the "image widget."
    void on_actionSave_view_image_triggered();

private:

    Ui::ShotViewerWindow *ui;

    /// Widget that gets captured when the user selects "save view image"
    QWidget *m_imageWidget;

};

#endif // SHOTVIEWERWINDOW_H
